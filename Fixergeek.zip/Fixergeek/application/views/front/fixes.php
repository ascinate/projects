<section class="total-bd-area">
  <div class="host-section-wrap fixes-main-page-wrap">
    <div class="container big-container">
     <div class="text-part-sec home-inside-d1">
      <div class="fixes-main-page-box">
        <div class="row">
          <?php 
		  $this->db->order_by('ordering', 'asc');
          $category_qry=$this->db->get_where('category_master')->result();
          foreach($category_qry as $category)
          {
          ?>
          <div class="col-md-12">
            <h6 class="fixes-main-page-heading mb-3"> <?=$category->category_name?> </h6>
          </div>
          <?php
          $subcategory_qry=$this->db->get_where('sub_category_master',array('cat_id'=>$category->id))->result();
          foreach($subcategory_qry as $subcategory)
          {
          ?>
          <div class="col-md-4">
            <div class="fixes-main-page-small-box security-1 mb-4">
              <h6 class="fixes-main-page-sub-heading mb-1"> <?=$subcategory->sub_category_name;?> </h6>
              <ul class="fixes-main-page-list">
                <?php
                $sub_sub_cat_qry=$this->db->get_where('sub_sub_category_master',array('sub_cat_id'=>$subcategory->id))->result();
                foreach($sub_sub_cat_qry as $sub_sub)
                {
                ?>
                <li><a href="<?php echo base_url();?>category/show/<?=(str_replace("&","-",str_replace(" ","_",$sub_sub->sub_sub_category_name)))?>"><?=$sub_sub->sub_sub_category_name?></a></li>
               <?php } ?>
              </ul>
            </div>
           </div>
                
         <?php } } ?> 
        </div>
      </div>
     </div>
    </div>
  </div>
</section>
