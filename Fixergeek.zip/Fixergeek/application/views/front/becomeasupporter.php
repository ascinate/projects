<section class="total-bd-area">
  <div class="container-fluid">
    <div class="row">
      <div class="new-add-sec">
        <div class="col-md-3 col-lg-3 pr-md-0">
          <div class="left-slidber-area">
            <div class="host-section-left-list">
              <?php $this->load->view('inc/left-navigation-supporters');?>
            </div>
          </div>
        </div>
        <div class="col-md-9 col-lg-9">
          <div class="bod-area">
            <div class="text-part-sec home-inside-d1 p-0">
              <div class="col-lg-9 mt-lg-0 mt-3 pr-xl-0 pr-3">
                <div class="become-a-supporter-box">
                  <h6 class="mt-3 mb-3 become-a-supporter-heading"> Make Money Online! </h6>
                  <p class="my-3">Following are our guidelines to become a Fixer Geek for Free!</p>
                  <h6 class="mt-3 mb-3 become-a-supporter-heading"> How to become a Fixer Geek? </h6>
                  <ul class="become-a-supporter-list-1 mb-3">
                    <li>1. You MUST Answer/Fix at least <span>1 Problems</span> in the category you want to become a Fixer Geek.</li>
                    <li>2. You MUST be <span>Technically Accurate</span> providing complete solution to the problem.</li>
                    <li>3. You MUST show <span>good use of Language</span>.</li>
                    <li>4. You MUST write <span>at least 250-500 words</span> in your reply to the problem.</li>
                    <li>5. You MUST write <span>a unique reply, plagarism will disqualify you</span>.</li>
                    <li>6. You MAY <span>use images and videos</span> to support your answer/fix.</li>
                    <li>7. You MAY <span>use headings and steps</span> in your write up.</li>
                  </ul>
                  <p class="mb-4">We review all answers/fixes to determine whether we qualify them or not on the points above.</p>
                  <p class="mb-4">Here are a few good examples of qualified fixes given by some of our Fixer Geeks.</p>
                  
                  <ul class="become-a-supporter-list-2 mb-3">
                    <?php
                       $ques = $this->db->query("select distinct(question_id) from `answers_master` order by id desc limit 0,3");
                      
					   foreach($ques->result() as $res)
                       {
					      $record = $this->db->get_where('questions_master', array('id' => $res->question_id))->row();
						  
						  $title = str_replace(" ","-",trim($record->question));
						  $title_1 = str_replace("?-","",$title);
						  $title_1 = str_replace("-?","",$title);
						  $title_1 = str_replace("-?-","",$title);
						  $title_2 = str_replace("?","",$title_1);
                    ?>
                    <li><a href="<?php echo base_url();?>details/show/<?=$title_2?>"><?=$record->question?></a></li>
                    <?php }?>
                  </ul>
                  
                  <p class="mb-3">Once you qualify, you’ll start earning money helping people using JUST your computer. Join thousands who are already making a fortune doing their favorite job!</p>
                  <p class="mb-3">Happy Supporting!</p>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
        
        <div class="sd1 new-spc"> <a href="#">Advertisement</a> </div>
    </div>
  </div>
</section>
