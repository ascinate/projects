<?php
   if( $this->session->userdata('id')=="")
   {
      redirect('/');
   } 
   
   $id = $this->session->userdata('id');
   $count = $this->db->query("select * from `message_master` 
                              where `sender_id` = '".$id."' OR `receiver_id` = '".$id."'" )->num_rows();
   
   $query = $this->db->query("select * from `fixergeek_master` where 
   							 `user_id` = '".$this->session->userdata('id')."'");
   $numrow = $query->num_rows();
   
   $user = $this->db->get_where('user_master', array('id'=>$id))->row();
   $status = $user->status;
   
    if($numrow!=0)
	{
	   $this->session->set_userdata('user_type', 'fixer');
	}
	else
	{
	   $this->session->set_userdata('user_type', 'asker');
	}
?>
<style>
.chat-part-details
{
  height: 325px;
  overflow: auto;
  display: flex;
  flex-direction: column-reverse;
  }
</style>
<section class="total-bd-area message-d1">
  <div class="container-fluid">
    <div class="row only-message-sec">
          <div class="left-slidber-area">
            <div class="host-section-left-list">
              <?php $this->load->view('inc/left-navigation-supporters');?>
            </div>
          </div>
      
      <?php if($count!=0) { ?>
      <div class="col comon-space-message">
        <div class="bod-area">
          <div class="messge-part">
            <div class="row messege_part_head">
              <div class="col-3 px-0 text-left">
                <p class="messege-1">Messeges</p>
              </div>
              <div class="col-5 px-0 text-right">&nbsp;</div>
              <div class="col-4 px-0 text-right">
                <P>
                  <b>Status:</b> 
                  <?php if($status=='online'){ ?>
                  <i class="fa fa-circle green_user-1"></i>
                  <?php } else {?>
                  <i class="fa fa-circle offline-1"></i>
                  <?php }?>
                  Online
                </P>
              </div>
            </div>
            
            
            <!-- 1st-row -->
            <div class="row ">
              <div class="col-xl-3 chat_name pl-lg-0 mt-2">
                <div class="chat_list_1">
                    <div class="nav nav-pills"  id="pills-tab" role="tablist">
                    
                    <?php
                         $query = $this->db->query("select * from `message_master` 
                                           			where `sender_id` = '".$id."' OR `receiver_id` = '".$id."' order by id desc" );
													
						 $i=1;
                         foreach($query->result() as $rec)
                         {
						    
						    if($rec->sender_id!=$id)
							{
                              $username = $this->db->get_where('user_master', array('id'=>$rec->sender_id))->row();
							  $stat = $username->status;
							}
							
							if($rec->receiver_id!=$id)
							{
							  $username = $this->db->get_where('user_master', array('id'=>$rec->receiver_id))->row();
							  $stat = $username->status;
							}
							
							$m_id = $rec->id;
							
							$msg = $this->db->query("select * from `chat_conversation_master` where 
													`message_id_fk` = '".$m_id."' order by id desc")->row();
                    ?>
                    
                    
                    <a class="nav-link default-btn <?php if($i==1) {?>active<?php }?>" data-toggle="pill" role="tab" 
                    href="#pills-d<?=$rec->id?>">
                      <div class="chat_name_part">
                        <div class="row mx-0">
                          <div class="col-2  px-2">
                            <div class="round-pic"> 
                              <?php
                                 if($username->profile_picture!="")
                                 {
                              ?>
                               <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                               style="border-radius:50%;" class="w-100">
                               <?php
                                 }
                                 else
                                 {
                                ?>
                                   <i class="far fa-user-circle"></i>
                                <?php
                                  }
                                ?>
                            </div>
                            <?php if($stat=='online'){ ?>
                            <div class="online-3"></div>
                            <?php } else {?>
                            <div class="offline-1"></div>
                            <?php }?>
                          </div>
                          <div class="col-10 pr-0">
                            <h6 class="chat_human"><?=$username->geek_name?></h6>
                            <p><?=substr($msg->reply,0,25);?> ...</p>
                          </div>
                          <div class="col-2 px-0">
                            
                          </div>
                        </div>
                        <!--  -->
                      </div>
                    </a>
                    
                   <?php
				        $i++;
                       }
                   ?> 
                    </div>
                </div>
              </div>
              <!-- col-4 -->
              
              <div class="col-xl-9 mt-2 px-0">
                <div class="chat-part tab-content" id="pills-tabContent">
                <?php
                   $query = $this->db->query("select * from `message_master` 
                                           			where `sender_id` = '".$id."' OR `receiver_id` = '".$id."' order by id desc" );
					
				   $x=1;						  
				   foreach($query->result() as $record)
                    {
					    
						 if($record->sender_id!=$id)
							{
							  $username = $this->db->get_where('user_master', array('id'=>$record->sender_id))->row();
							}
							
							if($record->receiver_id!=$id)
							{
							  $username = $this->db->get_where('user_master', array('id'=>$record->receiver_id))->row();
							}
							
						$query = $this->db->query("select * from `fixergeek_master` where 
   							 					  `user_id` = '".$username->id."'");
					    $numrow = $query->num_rows();
					   
						if($numrow!=0)
						{
						   $this->session->set_userdata('user_type', 'fixer');
						}
						else
						{
						   $this->session->set_userdata('user_type', 'asker');
						}
					   
					    $review=$this->db->get_where('review_master',array('fixer_id'=>$username->id));
						
						$score = $review->row();
						$tot = ($score->conduct+$score->timing+$score->literacy+$score->knowledge+$score->pchandle+$score->type_speed) / 6;
				?>
                   <div class="new-cls <?php if($x==1) {?>active show<?php }?>" id="pills-d<?=$record->id?>" role="tabpanel">
                      <div class="col-12 px-0">
                        <div class="chat-part-head">
                          <ul>
                            <li>
                              <p><b><?=ucwords($username->geek_name)?></b></p>
                            </li>
                            <li>
                              <p><?php if($this->session->userdata('user_type')=='fixer') { ?>Score: <?php echo number_format($tot,1); }?></p>
                            </li>
                            <li>
                              <p>Type: <?php echo ucwords($this->session->userdata('user_type'));?></p>
                            </li>
                            <!--<li>
                              <p>Level: 3</p>
                            </li>-->
                          </ul>
                        </div>
                      </div>
                      <!--  -->
                      <div class="col-12 px-0">
                        <div class="chat-part-details py-3" id="chat-b<?=$username->id?>">
                          
                           <?php 
						     $sub = $this->db->order_by('id', 'DESC')->get_where('chat_conversation_master', array('message_id_fk'=>$record->id));
							 
							 foreach($sub->result() as $rex)
							 {
							   $author = $this->db->get_where('user_master',array('id'=>$rex->user_id_fk))->row();
							   $ustat = $author->status;
						   ?> 
                          <!--  -->
                          <div class="row mt-4 mx-0 chating text-left">
                            <div class="col-1 px-2">
                              <div class="chat_pic float-left"> 
                                <?php
                                 if($author->profile_picture!="")
                                 {
                              ?>
                               <img src="<?php echo base_url();?>uploads/<?=$author->profile_picture?>" alt="user" 
                               style="border-radius:50%;" class="w-100">
                               <?php
                                 }
                                 else
                                 {
                                ?>
                                   <i class="far fa-user-circle"></i>
                                <?php
                                  }
                                ?>
                              </div>
                              
                              <?php if($ustat=='online'){ ?>
                              <div class="online-2"></div>
                              <?php } else {?>
                              <div class="offline-1"></div>
                              <?php }?>
                            </div>
                            <div class="col-10 chatting_messege px-4 pt-1">
                              <h6 class="mb-2"><b><?=$author->geek_name?></b></h6>
                              <p><?=$rex->reply?> </p>
                            </div>
                            <div class="col-1 pt-1 px-0">
                              <div class="chat-time">
                                <p><?php $ddt = explode(" ",$rex->date_time); echo $ddt[1];?></p>
                              </div>
                            </div>
                          </div>
                          <?php
                            }
						  ?>

                        </div>
                        
                        <div class="chat-part-details py-3" id="chat-b1<?=$username->id?>" style="display:none;">
                        
                        </div>
                        <!--  -->
                        <!-- send maeesege -->
                        <div class="row new-add-fild mt-2 mx-0">
                          
                          <div class="col-10 px-0">
                            <div class="form-group">
                            
                              <input type="text" class="form-control chat-input" id="mx<?=$username->id?>" placeholder="Type a Message..."  />
                              <input type="hidden" id="sender" value="<?=$id?>" />
                              <input type="hidden" id="receiver<?=$username->id?>" value="<?=$username->id?>" />
                              <input type="hidden" id="record_id<?=$record->id?>" value="<?=$record->id?>" />

                            </div>
                          </div>
                          <div class="col-2 pr-0">
                          <button type="button" name="btn<?=$username->id?>" id="btnChat" class="btn btn-primary default-btn w-100" 
                          onclick="javascript:chat(<?=$username->id?>,<?=$record->id?>)">Send</button>
                          </div>
                        </div>
                      </div>
                  <!--  -->
                  </div> 
                  <?php
				      $x++;
                    }
				  ?>
                  
                </div>
              </div>
              
              
            </div>
            
            
          </div>
        </div>
      </div>
      <?php } else { ?>
      
      <div class="col comon-space-message">
        <div class="bod-area">
          <div class="messge-part messge-part-new1">
            
            <div class="row">
             <div class="col-md-12">
                <div class="opps-text">
                   <h2> <i class="fa fa-frown-o" aria-hidden="true"></i> </h2>
                               
                   <h1> <span> Oops! </span> No records found! </h1>
                   <a href="#" class="buuton-home"> Go to Overview </a>
                </div>
                 
             
             </div>
            </div>
          
          </div>
        </div>
      </div>
      
      <?php }?>
      
    </div>
  </div>
  </div>
  
</section>

<script>
/* $(document).ready(function(){
   
     var sender = $("#sender").val();
	 var receiver = $("#receiver").val();
	 var receiver = $("#receiver").val();
	 
	  if(password=='' || user_name=='')
	  {
		 swal("Sorry!! Insert Your Login Data");
	  }
	  else
	  {
		 $.ajax({url: "<?php //echo base_url();?>message/ajaxinsert/"+sender+"/"+receiver+"/"+message, success: function(result){
				
				swal("Chating Successful.");
			 
		  }});
	  }
 });
 */
 
 $(document).ready(function()
 {
   
   $("#pills-tabContent").on("click", "input[type=text]", function() {
	
	var txtid = $(this).attr('id');
	//alert("#"+txtid);
	
	 $("#"+txtid).keyup(function(event) {

		if (event.keyCode === 13) {
			$("#btnChat").click();
		}
		
    });
	
	});
	
 });
 
 function chat(id,rid)
 {
      var sender = document.getElementById('sender').value;
	  var receiver = document.getElementById('receiver'+id).value;
	  var message = document.getElementById('mx'+id).value;
	  var record = document.getElementById('record_id'+rid).value;
	  
	  if(message=='')
	  {
	     swal("Message can't be blank!");
	  }
	  else
	  {
		  var xhttp = new XMLHttpRequest();
		  
		  xhttp.onload = function () {
			  document.getElementById('mx'+id).value = "";	 
			  document.getElementById("chat-b"+id).style.display="none";
			  document.getElementById("chat-b1"+id).style.display="block";
			  document.getElementById("chat-b1"+id).innerHTML = xhttp.responseText;
			  
			  var chatHistory = document.getElementById("chat-b1"+id);
			  chatHistory.scrollTop = chatHistory.scrollHeight;
		  };
	
		  //xhttp.open("GET", "<?php //echo base_url();?>messages/ajaxinsert/?s="+sender+"&r="+receiver, true);
		  xhttp.open("GET", "<?php echo base_url();?>messages/ajaxinsert/?s="+sender+"&r="+receiver+"&m="+message+"&id="+record, true);
		  xhttp.send();
	  }
 }
</script>
