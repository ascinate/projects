<?php 
error_reporting(0);

if($this->session->userdata('id')=="")
{
   redirect('/');
}

$id = $this->session->userdata('id');

$user=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
$country=$this->db->get_where('country_master',array('iso'=>$user->country))->row();

$fixergeek=$this->db->get_where('fixergeek_master',array('user_id'=>$id))->row();
$review=$this->db->get_where('review_master',array('fixer_id'=>$id));
$score = $review->row();
$tot = ($score->conduct+$score->timing+$score->literacy+$score->knowledge+$score->pchandle+$score->type_speed) / 6;

/*$this->db->select('*');
$this->db->from('questions_master');
$this->db->order_by('id', 'desc');
$this->db->limit(4, 0);*/

?>
<section class="total-bd-area">
  <div class="container-fluid">
    <div class="row">
       <div class="new-add-sec">
          <div class="col-md-3 col-lg-3 pr-md-0">
            <div class="left-slidber-area">
              <div class="host-section-left-list">
                 <?php $this->load->view('inc/left-navigation-supporters');?>
              </div>
            </div>
          </div>
          <div class="col-md-9 col-lg-9">
            <div class="bod-area overview">
              <div class="text-part-sec home-inside-d1 p-0">
                <div class="row">
                  <div class="col-md-4">
                    <div class="comon-part-sec">
                      <h6>Profile</h6>
                       <ul class="comon-li-sec">
                        <li> <span> Geek Name: </span><?=$user->geek_name?></li>
                        <li> <span> Email: </span><?=$user->email?></li>
                        <li> <span> Country: </span><?=$country->nicename?></li>
                      </ul>
                      <div class="host-section-grid-img text-center my-3"> 
                         <?php if($user->profile_picture!=""){?>
                          <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" alt="user">
                         <?php } else { ?>
                          <i class="fa fa-user" aria-hidden="true"></i>
                         <?php } ?>
                      </div>
                       <div class="but-link"> <a href="<?php echo base_url();?>profile">Change Info</a> </div> 
                      
                    </div>
                  </div>
                  <div class="col-md-4 middle-sec">
                    <div class="comon-part-sec">
                      <h6>Account Settings</h6>
                      <ul class="comon-li-sec">
                        <li> <span> Your Earnings: </span> </li>
                        <li> Today - <span> $650 </span> </li>
                        <li> This Week - <span> $650 </span> </li>
                        <li> This Month - <span> $650 </span> </li>
                        <li> This Year - <span> $650 </span> </li>
                      </ul>
                      <ul class="comon-li-sec">
                        <li> <span> Your payment method: </span> </li>
                        <li>Telegraphic Transfer</li>
                      </ul>
                      <ul class="comon-li-sec">
                        <li> <span> Your Default Credit/Debit Card: </span> </li>
                        <li> VISA ending 2308, exp 07/23 </li>
                      </ul>
                      <div class="but-link"> <a href="<?php echo base_url();?>accountsettings">See Details</a> </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="comon-part-sec new-sp">
                      <h6>Score & Comments</h6>
                      <h5> Geek Score </h5>
                      <h1> <?=number_format($tot,1)?> </h1>
                      <a href="#"></a> <a class="mb-0" href="#"> </a>
                      <div class="but-link"> <a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$user->id?>">See More</a> </div>
                    </div>
                  </div>
                  <div class="col-md-4 ">
                    <div class="comon-part-sec">
                      <h6>Fixer Geek Settings</h6>
                      <ul class="comon-li-sec">
                        <li> <span>Availability:</span> <?=$fixergeek->start_time?> to <?=$fixergeek->end_time?> </li>
                        <li> <span> Timezone: </span> <?=$fixergeek->timezone?> </li>
                      </ul>
                      
                      <ul class="comon-li-sec">
                        <li> <span> Your Fixer Categories: </span> </li>
                        <!--<li> <i class="fas fa-check"></i> Change Password </li>
                        <li> <i class="fas fa-check"></i> Deactivate Account </li>
                        <li> <i class="fas fa-check"></i> Delete Account </li>-->
                      </ul>
                      
                    <div class="supporter-page-list-2 new-ul-d2">
                      <ul>
                        <?php
                          $fixer=$this->db->get_where('fixergeek_master',array('user_id'=>$this->session->userdata('id')))->row();
                          $expert = explode(",",$fixer->sub_sub_cat_id);
						  $citrus = array_slice($expert,0,3);
						  
                          foreach($citrus as $val)
                          {
                           $item = $this->db->get_where('sub_sub_category_master',array('id'=>$val))->row();
                        ?>
                        <li class="pb-1"><?php echo $item->sub_sub_category_name;?></li>
                        <?php
                          }
                        ?>
                      </ul> <span style="font-size:11px;"> <?php if(count($expert) > 3) { echo (count($expert) - 3)." more..."; } ?></span>
                    </div>
                      
                      <div class="but-link"> <a href="<?php echo base_url();?>accountsupportersettings">View Settings</a> </div>
                    </div>
                  </div>
                  <div class="col-md-4 middle-sec">
                    <div class="comon-part-sec">
                      <h6>Your Fixes & Problems</h6>
                      <ul class="comon-li-sec">
                        <li> <span> Problems </span> </li>
                        <?php
						    $this->db->limit(3, 0);
							$question_qry = $this->db->get_where('questions_master', array('user_id' => $id));
							$cnt = $question_qry->num_rows();
							
						    if($cnt!=0)
							{
								$i=1;
								foreach($question_qry->result() as $val)
								{
								    $ans=$this->db->get_where('answers_master',array('question_id'=>$val->id))->num_rows();
								    $date=date_create($val->post_date);
								 
									$title = str_replace(" ","-",trim($val->question));
									$title_1 = str_replace("?-","",$title);
									$title_1 = str_replace("-?","",$title);
									$title_1 = str_replace("-?-","",$title);
									$title_2 = str_replace("?","",$title_1);
	
                        ?>
                             <li><a href="<?php echo base_url();?>details/show/<?=$title_2?>"><?=$val->question?></a></li>
                        <?php
                           	    } 
							}
							else
							{
                        ?>
                             <li>No problems found!</li>
						 <?php	
                            }
                        ?>
                      </ul>
                      <ul class="comon-li-sec">
                        <li> <span> Fixes </span> </li>
                        <?php
							$answer_qry = $this->db->get_where('answers_master', array('user_id' => $id));
							$count = $answer_qry->num_rows();
							
							if($count!=0)
							{
								foreach($answer_qry->result() as $val)
								{
								  $record = $this->db->get_where('questions_master',array('id'=>$val->question_id))->row();
								 
								  $title = str_replace(" ","-",trim($record->question));
								  $title_1 = str_replace("?-","",$title);
								  $title_1 = str_replace("-?","",$title);
								  $title_1 = str_replace("-?-","",$title);
								  $title_2 = str_replace("?","",$title_1);
							  ?>
								  <li><a href="<?php echo base_url();?>details/show/<?=$title_2?>"><?=$record->question?></a></li>
							 <?php
								} 
							}
							else
							{
						  ?>
								<li>No fixes found!</li>
						  <?php
							}
						  ?>
                      </ul>
                      <div class="but-link"> <a href="<?php echo base_url();?>fixerproblems">View More</a> </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="comon-part-sec">
                      <h6>Messeges</h6>
                      <ul class="comon-li-sec">
                        <li> <span> Admin Messages </span> </li>
                        <li> <a href="#"> Unread (2) </a> </li>
                      </ul>
                      <ul class="comon-li-sec">
                        <li> <span> Geek Messages </span> </li>
                        <li> <a href="#"> Unread (15) </a> </li>
                      </ul>
                      <div class="but-link"> <a href="<?php echo base_url();?>messages">Read all Messages</a> </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="comon-part-sec">
                      <h6>Notifications</h6>
                      <p> You’re in control of what emails you receive from FixerGeek.com </p>
                      <ul class="comon-li-sec">
                        <li> <a href="#"> Admin Notifications </a> </li>
                        <li> <a href="#"> Geek Notifications </a> </li>
                      </ul>
                      <div class="but-link"> <a href="<?php echo base_url();?>notifications">Change Notifications</a> </div>
                    </div>
                  </div>
                  <div class="col-md-4 middle-sec">
                    <div class="comon-part-sec">
                      <h6> Security Settings </h6>
                      <ul class="comon-li-sec">
                      <li> 
                           <a href="<?php echo base_url();?>securitysettings"> Block Geeks </a> </li>
                        <li> 
                           <a href="<?php echo base_url();?>profile/changepassword"> Change Password </a> </li>
                       <!-- <li>
                           <a href="<?php //echo base_url();?>profile/account"><?php //if($user->account=="Activate"){echo "Deactivate Account";}else{echo "Activate Account";}?> </a> 
                        </li>-->
                        <li> <a href="<?php echo base_url();?>profile/accountdelete"> Delete Account </a> </li>
                      </ul>
                      <div class="but-link"> <a href="<?php echo base_url();?>securitysettings">Change Security Options</a> </div>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
       </div>
       <div class="sd1 new-sd3 right-space new-special-home"> 
            <div class="new-right-sec-add-howit">
               <h3> How it works </h3>
               <a data-toggle="modal" data-target="#exampleModal-vieo">
                  <img src="<?php echo base_url();?>assets2/images/imgpsh_fullsize_anim.png" alt="user">
               </a>
            </div>
            <div class="ads-new-1">
              <a href="#">Advertisement</a>
            </div>
       </div>
    </div>
  </div>
</section>
