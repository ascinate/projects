<?php 
	$qus_id=$this->uri->segment(3);
	$question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
	$user=$this->db->get_where('user_master',array('id'=>$question->user_id))->row();
	$date=date_create($question->post_date);   
	$user_qry=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
	$category=$this->db->get_where('category_master',array('id'=>$question->category_name))->row();
	$sub_cat=$this->db->get_where('sub_category_master',array('id'=>$question->sub_cat_id))->row();
	$sub_sub_cat=$this->db->get_where('sub_sub_category_master',array('id'=>$question->sub_sub_cat_id))->row();
?>
<section class="total-bd-area2">
  <div class="container-fluid">
    <div class="latest-post1">
     <h6>Latest Category:-</h6>
      <ul>
        <li>
        <?php
        $this->db->order_by('id','desc');
        $mcat = $this->db->get_where("sub_sub_category_master",array('sub_cat_id'=>$question->sub_cat_id),2);
        foreach($mcat->result() as $rec) 
        { 
        ?>
        <a href="<?php echo base_url();?>category/show/<?=(str_replace("&","-",str_replace(" ","_",$rec->sub_sub_category_name)))?>">
        <?=$rec->sub_sub_category_name?>
        </a>
        <?php } ?>
          <a href="<?php echo base_url();?>category"> Show All </a>
        </li>
      </ul>
    </div>
    <div class="offline_website_ask_head breadcrumb-1"> 
     <a class="breadcrumb1-anchor nt-spl-anchor anchor-brc-1" href="#"><?=$category->category_name?></a>
      <a class="breadcrumb1-anchor nt-spl-anchor" href="#"><?=$sub_cat->sub_category_name?></a>
      <li class="nav-item dropdown dropdown1"> 
      <a class="breadcrumb1-anchor nav-link Profile-pad active dropdown-toggle button" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span><?=$sub_sub_cat->sub_sub_category_name?></span> </a>
        <div class="dropdown-menu drop-menu-new dropdown-menu1" aria-labelledby="navbarDropdown">
        <?php
        $mcat = $this->db->query("select * from `sub_sub_category_master` where sub_cat_id = '".$question->sub_cat_id."'");
        foreach($mcat->result() as $rec) 
        { 
        ?>
         <a class="dropdown-item" href="<?php echo base_url();?>category/show/<?=(str_replace("&","-",str_replace(" ","_",$rec->sub_sub_category_name)))?>">
          <?=$rec->sub_sub_category_name?> </a>
         <?php } ?>
       </div>
      </li>
    </div>
    <hr class="my-2">
    <div class="row">
          <div class="col-md-7 col-lg-9">
           <div class="detail-page-2">
              <div class="accordian-part mt-3">
                <div class="main">
                   <div class="question-area-n1 reload-div">
                       <h2><?=$question->question;?></h2>
                      <div class="profile-detail-user">
                            <figure>
                            <?php if($question->user_id=="Admin"){?>
                            <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user">
                            <?php }else{?>
                            <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" alt="user">
                            <?php } ?>
                            </figure>
                            <figcaption>
                            <?php if($question->user_id=='Admin'){echo"Administrator";}else{
                            echo $user->name;
                            }?>, Posted <?php echo date_format($date,"F j, Y");?> <span> <?=$sub_sub_cat->sub_sub_category_name;?></span>
                            </figcaption>
                           </div>
                      
                      <div class="comon-text-area comon-space">
                            
                            <ul class="details-content1 sanj">
                               <li><?=($question->content);?></li>
                             </ul>
                                                        
                            <div class="more-text1">
                              
                            <!--   <div class="detail-img">
                                  <img src="<?php echo base_url();?>uploads/<?=$question->uploaded_files?>" alt="user"> 
                              </div> -->
                              <div class="steps1">
                              
                              </div>
                              <?php 
                              /*if($this->session->userdata('id')!='')
                              {*/
							  ?>
                              <div class="detail-comment-sec2">
                                <form action="<?php echo base_url()?>details/submitcomment/<?=$user_qry->id?>/<?=$qus_id?>" method="post" > 
                                  <div class="form-group">
                                    <div class="row justify-content-center accordion-comment-section">
                                      <div class="col-md-1 text-right">
                                        <?php if($user_qry->profile_picture!="") {?>
                                        <img src="<?php echo base_url();?>uploads/<?=$user_qry->profile_picture?>" alt="user">
                                        <?php } else {?>
                                        <i class="fa fa-user" aria-hidden="true"></i>
                                        <?php }?>
                                      </div>
                                      <div class="col-md-9 px-0">
                                        <input type="hidden" id="user_id" value="<?=$user_qry->id?>">
                                        <input type="hidden" id="ques_id" value="<?=$qus_id?>">
                                       <input type="text" id="comment_text" name="comment<?=$qus_id?>" placeholder="" class="form-control">
                                      </div>
                                      <div class="col-md-2">
                                        <?php if($this->session->userdata('id')!='') { ?>
                                         <button type="button" id="add_comment" class="default-btn">Add Comment<br>
                                        <?php } else { ?>
                                         <button type="button" id="add_comment2" class="default-btn" data-toggle="modal"  data-target="#cusModal">Add Comment<br>
                                        <?php } ?>
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                 </form> 
                              </div>
                            <?php 
							 // } 
							?>
                            <hr>
                            <?php 
                            $this->db->order_by('id','desc');
                            $comment_qry=$this->db->get_where('comment_master',array('question_id'=>$qus_id))->result();
                            foreach($comment_qry as $val)
                            {
								$date2=date_create($val->post_date);
								$us=$this->db->get_where('user_master',array('id'=>$val->user_id))->row();
                            ?>
                              <div class="detial-comon-sec mb-3 contentt">
                                 <div class="comment-show-top">
                                   <figure>
                                    <?php if($val->user_id=="Admin"){?>
                                    <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user">
                                    <?php }else{?>
                                    <img src="<?php echo base_url();?>uploads/<?=$us->profile_picture?>" alt="user">
                                    <?php } ?>
                                   </figure>
                                   <figcaption>
                                    <?php if($val->user_id=='Admin'){echo"Administrator";}else{
                                    echo $us->name;
                                    }?><span>, Posted <?php echo date_format($date2,"F j, Y");?></span> </figcaption>
                                 </div>
                                 <p><?=$val->comments;?></p>
                                 <div class="comment-sec-bottom1 reply-div">
                                   <ul>
                                      <li>
                                        <a class="reply-box"> <i class="fa fa-reply"></i> Reply </a>
                                        <a href="#"> <i class="fa fa-arrow-up"></i> Upvote </a>
                                        <a id="hide2-new"> <i class="fa fa-arrow-down"></i> Downvote </a>
                                      </li>
                                    </ul>
                                    <!--<div class="right">
                                       <a class="btn dropdown-toggle padding-off" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-ellipsis-v"></i> </a>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                        <a class="dropdown-item" href="#"> Report </a>
                                      </div>
                                    </div>-->
                                    
                                 </div>
                                 <div class="chat2-new2 mt-2 chat-box-open" style="">
                                     <div class="comment-area2">
                                           <!-- <form action="<?php echo base_url()?>details/submitreply/<?=$val->user_id?>/<?=$val->question_id?>/<?=$val->id?>" method="post"> -->
                                             
                                               <div class="form-group">
                                                <input type="hidden" class="user_id" value="<?=$val->user_id?>">
                                                  <input type="hidden" class="ques_id" value="<?=$val->question_id?>">
                                                  <input type="hidden" class="comment_id" value="<?=$val->id?>">
                                                   <textarea name="reply<?=$val->id?>" placeholder="" class="form-control reply_text" required></textarea>
                                               </div>
                                          <?php if($this->session->userdata('id')!='') { ?>
                                           <button type="button" class="comment-bn add_reply" id="add_reply">Reply </button>
                                          <?php } else { ?>
                                           <button type="button" class="comment-bn add_reply" id="add_reply2" data-toggle="modal" data-target="#cusModal">Reply </button>
                                          <?php }?>
                                        <!-- </form> -->
                                     </div>
                                     <hr>
                                </div>
                              </div>
                             <?php } ?>
                             <a id="loadMore">View More Comments</a>
                            </div>
                            <a class="moreless-button1 ne-bn1" > 
                            Read more</a> </div>
                    </div>
                    <div class="colas-area">
                      <!--  <h1 class="text-center"> Related questions </h1> -->
                       <div class="accordion indicator-plus-before round-indicator mb-5" id="accordionH" aria-multiselectable="true">
                          <div class="card m-b-0">
                            <?php
                            $ques=$this->db->get_where('questions_master',array('sub_sub_cat_id'=>$question->sub_sub_cat_id,'id !='=>$question->id));
                            if($ques->num_rows()!=0)
                            {
                             foreach($ques->result() as $val)
                              {
                               $sub= $this->db->get_where("sub_sub_category_master",array('id'=>$val->sub_sub_cat_id))->row();
                              ?>
                              <div class="card-header collapsed" role="tab" id="headingOneH" href="#collapseOneH" data-toggle="collapse" data-parent="#accordionH" aria-expanded="false" aria-controls="collapseOneH">
                                  <a class="card-title"><?=$val->question?></a>
                              </div>
                              
                              <div class="collapse" id="collapseOneH" role="tabpanel" aria-labelledby="headingOneH">
                                  <div class="card-body">
                                    <div class="profile-detail-user">
                                    <figure>
                                    <?php if($val->user_id=="Admin"){?>
                                    <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user">
                                    <?php }else{?>
                                    <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" alt="user">
                                    <?php } ?>
                                    </figure>
                                    <figcaption>
                                    <?php if($val->user_id=='Admin'){echo"Administrator";}else{
                                    echo $user->name;
                                    }?>, Posted <?php echo date_format($date,"F j, Y");?> <span> <?=$sub->sub_sub_category_name;?></span>
                                    </figcaption>
                                    </div>
                                    <div class="comon-text-area comon-space">
                            
                            <ul class="details-content1 sanj">
                               <li><?=($val->content);?></li>
                             </ul>
                                                        
                            <div class="more-text1">
                              
                              <!-- <div class="detail-img">
                               <img src="<?php echo base_url();?>uploads/<?=$val->uploaded_files?>" alt="user"> 
                              </div> -->
                              <div class="steps1">
                              
                              </div>
                              <?php 
                              if($this->session->userdata('id')!='')
                              {?>
                              <div class="detail-comment-sec2">
                               <!-- <form action="<?php echo base_url()?>details/submitcomment/<?=$user_qry->id?>/<?=$val->id?>" method="post"> -->
                                  <div class="form-group">
                                    <div class="row justify-content-center accordion-comment-section">
                                      <div class="col-md-1 text-right"><img src="<?php echo base_url();?>uploads/<?=$user_qry->profile_picture?>" alt="user"></div>
                                      
                                      <div class="col-md-9 px-0">
                                        <input type="hidden" class="user_id" value="<?=$user_qry->id?>">
                                        <input type="hidden" class="quess_id" value="<?=$val->id?>">
                                       <input type="text" name="comment<?=$val->id?>" placeholder="" class="form-control comment_text">
                                      </div>
                                      <div class="col-md-2">
                                        <button type="button" id="" class="default-btn add_comment">Add Comment<br>
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                <!-- </form> -->
                              </div>
                            <?php } ?>
                            <hr>
                            <?php 
                            $this->db->order_by('id','desc');
                            $comment_qry=$this->db->get_where('comment_master',array('question_id'=>$val->id))->result();
                            foreach($comment_qry as $com)
                            {
                            $date2=date_create($com->post_date);
                            $us=$this->db->get_where('user_master',array('id'=>$com->user_id))->row();
                            ?>
                              <div class="detial-comon-sec mb-3 content">
                                 <div class="comment-show-top">
                                   <figure>
                                    <?php if($com->user_id=="Admin"){?>
                                    <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user">
                                    <?php }else{?>
                                    <img src="<?php echo base_url();?>uploads/<?=$us->profile_picture?>" alt="user">
                                    <?php } ?>
                                   </figure>
                                   <figcaption>
                                    <?php if($com->user_id=='Admin'){echo"Administrator";}else{
                                    echo $us->name;
                                    }?><span>Posted <?php echo date_format($date2,"j F ,Y");?></span> </figcaption>
                                 </div>
                                 <p><?=$com->comments;?></p>
                                 <div class="comment-sec-bottom1 reply-div">
                                    <ul>
                                      <li>
                                        <a  class="reply-box"> <i class="fa fa-reply"></i> Reply </a>
                                        <a href="#"> <i class="fa fa-arrow-up"></i> Upvote </a>
                                        <a  id="hide2-new"> <i class="fa fa-arrow-down"></i> Downvote </a>
                                      </li>
                                    </ul>
                                    <!--<div class="right">
                                       <a class="btn dropdown-toggle padding-off" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-ellipsis-v"></i> </a>
                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                        <a class="dropdown-item" href="#"> Report </a>
                                      </div>
                                    </div>-->
                                    
                                 </div>
                                 <div class="chat2-new2 mt-2 chat-box-open" style="">
                                     <div class="comment-area2">
                                          <!--  <form action="<?php echo base_url()?>details/submitreply/<?=$com->user_id?>/<?=$com->question_id?>/<?=$com->id?>" method="post"> -->
                                             
                                           <div class="form-group">
                                                <input type="hidden" class="user_id" value="<?=$com->user_id?>">
                                                  <input type="hidden" class="ques_id" value="<?=$com->question_id?>">
                                                  <input type="hidden" class="comment_id" value="<?=$com->id?>">
                                                   <textarea name="reply<?=$com->id?>" placeholder="" class="form-control reply_text" required></textarea>
                                               </div>
                                          
                                           <button type="button" class="comment-bn add_reply" id="add_reply">Reply </button>
                                        <!-- </form> -->
                                     </div>
                                     <hr>
                                </div>
                              </div>
                             <?php } ?>
                             <a id="loadMore" class="loadMore">View More Comments</a>
                            </div>
                            <a class="moreless-button1 ne-bn1" > 
                            Read more</a> </div>
                              
                                  </div>
                              </div>
                             <?php } } else{?>    
                              <div class="card-header collapsed" role="tab" id="headingOneH" href="#collapseOneH" data-toggle="collapse" data-parent="#accordionH" aria-expanded="false" aria-controls="collapseOneH">
                                  <a class="card-title">No Releated Questions Available</a>
                              </div>
                             <?php } ?>                        
                          </div>
			                  </div>
                      </div>
                    </div>
                  </div>
                </div>
          
            </div>
           
           
      <div class="col-md-5 col-lg-3">
        <div class="right-fixed-box fixed-carousel-spl-box new-width">
          <div class="host-section-right-carousel-box host-section-right-box">
            <div class="host-right-heading-box">
             <span class="text-center active-span"><i class="fa fa-circle" aria-hidden="true"></i> <b> 5 Fixer Geeks (online)</b></span> 
            </div>
            <div class="host-right-owl-box mb-3">
              <section class="client-logoarea">
                <div class="owl-carousel owl-theme">
                  <div class="lgo-items">
                    <div class="hover-link-part">
                      <h6> <a class="show-details-new1" href="#">SimonPhilip</a> - 3.9 score</h6>
                      <p> <i class="fas fa-check"></i> Fixed this Problem </p>
                    </div>
                    <div class="profile-hover-details profile-hover-carousel1 new-show-div1">
                      <div class="row">
                        <div class="col-md-12 mb-1">
                          <h6> <i class="far fa-user-circle"></i> JoeMartyJoe</h6>
                        </div>
                        <div class="col-md-12 mb-1"> <span>Score: 4.8 <a href="#">Read Comments</a></span> </div>
                        <div class="col-md-12 mb-1">
                          <p>Availability: 3:00pm to 8:00pm</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p>Timezone: Eastern Standard Time (GMT -5)</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                        </div>
                        <div class="col-md-12">
                          <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <ul class="profile-hover-list">
                            <li class="spl-li">Categories (Expet in):</li>
                            <li><a href="#">PC Speed Up</a></li>
                            <li><a href="#">Internet Speed Up</a></li>
                            <li><a href="#">Memory (RAM) Issues</a></li>
                            <li><a href="#">Personalization</a></li>
                            <li><a href="#">Gaming</a></li>
                            <li><a href="#">Apple Products</a></li>
                            <li><a href="#">Microsoft Products</a></li>
                          </ul>
                        </div>
                        <div class="col-md-12">
                          <div class="row">
                            <div class="col-md-6 text-left"> <a href="#">Read Full Profile</a> </div>
                            <div class="col-md-6 text-right"> <a href="#">Hire User</a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <a href="#">
                    <div class="one">
                      <h6> Get Remote Assistance <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level3.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Screen Sharing & Voice Chat Support <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level2.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Text Chat Support <span> on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level1.png" alt=""> </figure>
                    </div>
                    </a> </div>
                  <div class="lgo-items">
                    <div class="hover-link-part">
                      <h6> <a class="show-details-new2" href="#">AdamJosh</a> - 3.9 score</h6>
                      <p> <i class="fas fa-check"></i>Fixed this Problem </p>
                    </div>
                    <div class="profile-hover-details profile-hover-carousel2 new-show-div2">
                      <div class="row">
                        <div class="col-md-12 mb-1">
                          <h6><i class="far fa-user-circle"></i> AdamJosh</h6>
                        </div>
                        <div class="col-md-12 mb-1"> <span>Score: 4.8 <a href="#">Read Comments</a></span> </div>
                        <div class="col-md-12 mb-1">
                          <p>Availability: 3:00pm to 8:00pm</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p>Timezone: Eastern Standard Time (GMT -5)</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                        </div>
                        <div class="col-md-12">
                          <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <ul class="profile-hover-list">
                            <li class="spl-li">Categories (Expet in):</li>
                            <li><a href="#">PC Speed Up</a></li>
                            <li><a href="#">Internet Speed Up</a></li>
                            <li><a href="#">Memory (RAM) Issues</a></li>
                            <li><a href="#">Personalization</a></li>
                            <li><a href="#">Gaming</a></li>
                            <li><a href="#">Apple Products</a></li>
                            <li><a href="#">Microsoft Products</a></li>
                          </ul>
                        </div>
                        <div class="col-md-12">
                          <div class="row">
                            <div class="col-md-6 text-left"> <a href="#">Read Full Profile</a> </div>
                            <div class="col-md-6 text-right"> <a href="#">Hire User</a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <a href="#">
                    <div class="one">
                      <h6> Get Remote Assistance <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level3.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Screen Sharing & Voice Chat Support <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level2.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Text Chat Support <span> on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level1.png" alt=""> </figure>
                    </div>
                    </a> </div>
                  <div class="lgo-items">
                    <div class="hover-link-part">
                      <h6> <a class="show-details-new3" href="#">AdamJosh</a> - 3.9 score</h6>
                      <p> <i class="fas fa-check"></i> Fixed this Problem </p>
                    </div>
                    <div class="profile-hover-details profile-hover-carousel1 new-show-div3">
                      <div class="row">
                        <div class="col-md-12 mb-1">
                          <h6><i class="far fa-user-circle"></i> JoeMartyJoe</h6>
                        </div>
                        <div class="col-md-12 mb-1"> <span>Score: 4.8 <a href="#">Read Comments</a></span> </div>
                        <div class="col-md-12 mb-1">
                          <p>Availability: 3:00pm to 8:00pm</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p>Timezone: Eastern Standard Time (GMT -5)</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                        </div>
                        <div class="col-md-12">
                          <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <ul class="profile-hover-list">
                            <li class="spl-li">Categories (Expet in):</li>
                            <li><a href="#">PC Speed Up</a></li>
                            <li><a href="#">Internet Speed Up</a></li>
                            <li><a href="#">Memory (RAM) Issues</a></li>
                            <li><a href="#">Personalization</a></li>
                            <li><a href="#">Gaming</a></li>
                            <li><a href="#">Apple Products</a></li>
                            <li><a href="#">Microsoft Products</a></li>
                          </ul>
                        </div>
                        <div class="col-md-12">
                          <div class="row">
                            <div class="col-md-6 text-left"> <a href="#">Read Full Profile</a> </div>
                            <div class="col-md-6 text-right"> <a href="#">Hire User</a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <a href="#">
                    <div class="one">
                      <h6> Get Remote Assistance <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level3.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Screen Sharing & Voice Chat Support <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level2.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Text Chat Support <span> on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level1.png" alt=""> </figure>
                    </div>
                    </a> </div>
                  <div class="lgo-items">
                    <div class="hover-link-part">
                      <h6> <a class="show-details-new4" href="#">AdamJosh</a> - 3.9 score</h6>
                      <p> <i class="fas fa-check"></i> Fixed this Problem </p>
                    </div>
                    <div class="profile-hover-details profile-hover-carousel1 new-show-div4">
                      <div class="row">
                        <div class="col-md-12 mb-1">
                          <h6><i class="far fa-user-circle"></i> JoeMartyJoe</h6>
                        </div>
                        <div class="col-md-12 mb-1"> <span>Score: 4.8 <a href="#">Read Comments</a></span> </div>
                        <div class="col-md-12 mb-1">
                          <p>Availability: 3:00pm to 8:00pm</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p>Timezone: Eastern Standard Time (GMT -5)</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                        </div>
                        <div class="col-md-12">
                          <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <ul class="profile-hover-list">
                            <li class="spl-li">Categories (Expet in):</li>
                            <li><a href="#">PC Speed Up</a></li>
                            <li><a href="#">Internet Speed Up</a></li>
                            <li><a href="#">Memory (RAM) Issues</a></li>
                            <li><a href="#">Personalization</a></li>
                            <li><a href="#">Gaming</a></li>
                            <li><a href="#">Apple Products</a></li>
                            <li><a href="#">Microsoft Products</a></li>
                          </ul>
                        </div>
                        <div class="col-md-12">
                          <div class="row">
                            <div class="col-md-6 text-left"> <a href="#">Read Full Profile</a> </div>
                            <div class="col-md-6 text-right"> <a href="#">Hire User</a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <a href="#">
                    <div class="one">
                      <h6> Get Remote Assistance <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level3.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Screen Sharing & Voice Chat Support <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level2.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Text Chat Support <span> on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level1.png" alt=""> </figure>
                    </div>
                    </a> </div>
                </div>
              </section>
            </div>
            <div class="host-section-right-bottom"> <a href="#">See All Fixer Geeks...</a> </div>
          </div>
          <div class="host-section-right-box spl-right-box mt-3"> <a href="#">Advertisement</a> </div>
        </div>
      </div>
           
           
       </div>
      
      </div>
      <!-- col-9 -->
      
    </div>
    <div class="clearfix"></div>
  </div>
</section>

<? ######################### Sign in modal ####################### ?>

<div class="modal fade exampleModalask" id="cusModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header ask-modal modal-header-1"> <img src="<?php echo base_url();?>assets2/images/logo-head.png" alt="">
        <h5 class="modal-title" id="exampleModalLabel">Ask Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      <div id="modal-spl-26" class="modal-body modal-body1">
       <span id="txt" class="text-center" style="color:#FF0000;"></span>
        <div class="head-form head-form2x" id="next_hide">
          <div class="form-dp">
            <div class="top-sec-dp">
                <div class="form-group">
                  <label> User Name</label>
                  <input type="text" placeholder="" id="user_name" class="form-control" required>
                </div>
                <div class="form-group">
                  <label> Password </label>
                  <input type="password" placeholder="" id="password" class="form-control" required>
                </div>
                <button type="button" id="login_btn_comment" class="btn default-btn login">Log In</button>
            </div>
          </div>
          <div class="col-md-4">&nbsp;</div>
          <div class="col-12">
            <div class="header-drop-links-first">
              <p>Or Login With</p>
              <ul class="socal-media">
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i>
                  <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                  <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                  <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                  <span> Linkedin</span></a></li>
              </ul>
              
              <div class="sub-link">
                 <a href="#">Lost Password </a> or <a href="#"> User Name</a>
              </div>
            </div>
          </div>
          <div class="col-12 mt-4">
            <div class="header-drop-links-second">
              <p>Or Sign Up With</p>
              <hr class="my-2">
              <ul class="socal-media">
                <li><a class="icon-new" href="#"> <i class="fas fa-envelope"></i>
                  <span>Email</span></a></li>
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i>
                  <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                  <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                  <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                  <span> Linkedin</span></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    
    
    </div>
  </div>
</div>

<script>
    $(document).ready(function()
	{
	
	 //////////////////////////////////////////
	  $("#login_btn_comment").click(function()
	  {
		  var user_name = $("#user_name").val();
		  var password = $("#password").val();
			   
		  if(password=='' || user_name=='')
		  {
			 swal("Sorry!! Insert Your Login Data");
		  }
		  else
		  {
			 $.ajax({url: "<?php echo base_url();?>home/login/"+user_name+"/"+password, success: function(result){
				 location.reload(true);
			  }});
		  }
	 });
	 
	 
   });
</script>