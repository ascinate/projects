<?php 
    $qus = $this->uri->segment(3);
	$ques = str_replace("-"," ",$qus);
	$tques = $ques."?";
	
    $count = $this->db->get_where('questions_master', array('question'=>$tques))->num_rows();
	if($count!=0)
	{
      $title = $this->db->get_where('questions_master', array('question'=>$tques))->row();
	}
	else
	{
	  $title = $this->db->get_where('questions_master', array('question'=>$ques))->row();
	}
	
	$qus_id = $title->id;
	
	$userId = $this->session->userdata('id');
	
	$question = $this->db->get_where('questions_master',array('id'=>$qus_id))->row();
	$user = $this->db->get_where('user_master',array('id'=>$question->user_id))->row();
	
	$this->db->order_by('upvote', 'DESC');
	$answer = $this->db->get_where('answers_master',array('question_id'=>$qus_id));
	
	
	$date  = date_create($question->post_date);   
	
	$user_qry = $this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
	$category = $this->db->get_where('category_master',array('id'=>$question->category_name))->row();
	$sub_cat = $this->db->get_where('sub_category_master',array('id'=>$question->sub_cat_id))->row();
	$sub_sub_cat = $this->db->get_where('sub_sub_category_master',array('id'=>$question->sub_sub_cat_id))->row();
?>
<style>
.comon-space p {
	margin-top: 12px;
}
.imxx 
{
	border-radius:50%; 
	width:20px; 
	height:20px;
}
</style>
<section class="total-bd-area2 add-scroll-1" id="detailpage">

<div class="container-fluid">
  <div class="new-add-del-sec2">
    <div class="col-md-12 pl-0">
      <div class="details-devoplo-accordian mt-3 w-100">
        <div class="details-area-div">
          <div class="question-area-details-dv">
            <div class="top-question">
              <h1>
                <?=$question->question;?>
              </h1>
              <ul class="categories-d1">
                <li> Categories: </li>
                <li> <a href="<?php echo base_url();?>category/show/<?=(str_replace("&","-",str_replace(" ","_",$sub_sub_cat->sub_sub_category_name)))?>">
                  <?=$sub_sub_cat->sub_sub_category_name;?>
                  </a> </li>
              </ul>
            </div>
            <div class="colas-area-dv">
              <div id="accordion" class="accordion">
                <div class="answer-part">
                  <div class="ans-div-d1">
                    <? ######################### Answer Loop Start Here ################### ?>
                    <?php
						$i = 1;
						foreach($answer->result() as $record)
						{
						  $author_id = $record->user_id;
						  
						  $exdate = explode('-', $record->post_date);
						  $postdate = mktime(12,0,0, $exdate[1],$exdate[2],$exdate[0]);
						  $date = date("F j, Y", $postdate);
						  
						  $username = $this->db->get_where('user_master',array('id'=>$record->user_id))->row();
						  $fixergeek=$this->db->get_where('fixergeek_master',array('user_id'=>$record->user_id))->row();
						  
						  $vt = $this->db->query("select sum(upvote) as upvot from `answer_up_down` 
												  where `answer_id` = '".$record->id."'")->row();
						  $upv = $vt->upvot;  
						
						  $vt2 = $this->db->query("select sum(downvote) as downvot from `answer_up_down`
												   where `answer_id` = '".$record->id."'")->row();
						  $dwv = $vt2->downvot;
					?>
                    <div class="card-header collapsed question-comon-1" data-target="#collapse<?=$i?>" data-toggle="collapse" data-parent="#accordion"> 
                    <a class="card-title"> Answer by
                      <?php 
						  if($username->id=="Admin")
						  {
					  ?>
                     <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" class="imxx">
                      <?php
						 }
						 else
						 {
						   if($username->profile_picture!="")
						   {
					  ?>
                    <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" class="imxx">
                      <?php 
					       } 
					    else
					     {
					  ?>
                      <i class="far fa-user-circle"></i>
                      <?php 
						   }
						 }
					  ?>
                      <?=ucwords($username->geek_name)?> Posted on <?=$date?>
                      <!--@-->
                      <? /*$record->post_time?> - <?=$fixergeek->timezone*/ ?>
                      </a> </div>
                    <div id="collapse<?=$i?>" class="collapse <?php if($i==1){?>show<?php }?>" data-parent="#accordion">
                      <div class="card-body border-top-0">
                        <div class="comon-text-area comon-space">
                          <div class="total-edit-sec">
                            <?php if($this->session->userdata('id')==$author_id) {?>
                            <ul class="new-add-dl">
                              <li> <a class="dropdown-item" id="hide-bn" href="javascript:ansedit(<?=$record->id?>);"> Edit </a></li>
                              <li> <a class="dropdown-item" href="javascript:ansdelete(<?=$record->id?>);"> Delete </a> </li>
                            </ul>
                            <?php } ?>
                          </div>
                          <div class="detail-dv-textarea" id="mr<?=$record->id?>">
                            <div class="new-text-sec-d1" id="qans<?=$record->id?>">
                              <?=stripslashes($record->answer); ?>
                            </div>
                            <div class="new-text-sec-d1 new-add-email-sec" id="edit<?=$record->id?>" style="display:none;">
                            
                            <form name="editfrm<?=$record->id?>" action="<?php echo base_url();?>problems/editanswer/<?=$qus_id?>/<?=$userId?>" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                             <input type="hidden" name="upans_id" value="<?=$record->id?>" />
                              <textarea class="form-control" name="updateanswer<?=$record->id?>" rows="20" placeholder="Message..." id="upans<?=$record->id?>">
                                 <?=stripslashes($record->answer); ?>
                               </textarea>
                                 <script>
									ClassicEditor
										.create( document.querySelector( '#upans<?=$record->id?>' ) )
										.catch( error => {
											console.error( error );
										} );
								</script>
                                <button type="submit" name="btnedit<?=$record->id?>" id="submit1" style="border:none;"> Submit</button>
                                &nbsp;
                                <div id="show-bn-d1" class="d-inline">
                                  <button type="button" name="canceledit<?=$record->id?>" id="submit1" 
                                  onclick="javascript:revansedit(<?=$record->id?>);" style="border:none;">Cancel</button>
                                </div>
                              </form>
                            </div>
                            
                            <div class="more-text-d1" id="more-text1-dv">
                              <div class="more-details-sec-dv">
                                <div class="main-button1">
                                  <?php if($this->session->userdata('id')!='') { ?>
                                  <a class="add-ans-bn-d1" id="btans<?=$record->id?>" onclick="javascript:addanswer(<?=$record->id?>)"> 
                                  <i class="fas fa-plus"></i> Add Another Answer
                                  </a>
                                 <a class="add-ans-bn-d1" id="hbtans<?=$record->id?>" onclick="javascript:hideanswer(<?=$record->id?>)" style="display:none;">
                                  <i class="fas fa-plus"></i> Add Another Answer</a>
                                  <?php } else { ?>
                                  <!--<a class="comon-dv-bn" id="btcom<?=$record->id?>" data-toggle="modal" data-target="#cusModal">
                                                         Add comment</a>--> 
                                  
                                  <a class="add-ans-bn-d1" id="btans<?=$record->id?>" data-toggle="modal" data-target="#cusModal"> 
                                  <i class="fas fa-plus"></i> Add Another Answer</a>
                                  <?php }?>
                                  <?php if($this->session->userdata('id')!='') { ?>
                                  <a href="javascript: upvote(<?=$record->id?>,<?=$userId?>)" class="up"> 
                                  <i class="far fa-thumbs-up"></i> <span id="demo<?=$record->id?>">
                                  <?php if($upv==0){echo '';}else{echo $upv;}?>
                                  </span> </a> <a href="javascript: downvote(<?=$record->id?>,<?=$userId?>)" class="up"> 
                                  <i class="far fa-thumbs-down"></i> <span id="demo2<?=$record->id?>">
                                  <?php if($dwv==0){echo '';}else{echo $dwv;}?>
                                  </span> </a>
                                  <?php } else { ?>
                                  <a href="javascript: void(0);" class="up"> <i class="far fa-thumbs-up"></i> <span>
                                  <?php if($upv==0){echo '';}else{echo $upv;} ?>
                                  </span> </a> <a href="javascript: void(0);" class="up"> <i class="far fa-thumbs-down"></i> <span>
                                  <?php if($dwv==0){echo '';}else{echo $dwv;} ?>
                                  </span> </a>
                                  <?php }?>
                                  <?php //if($this->session->userdata('id')==$author_id) {?>
                                  <?php /*?>
								  <div class="dropdown detail-dp1">
								   <a href="#" class="option-bn-d1" id="dropdownMenuButton" data-toggle="dropdown" 
								   aria-haspopup="true" aria-expanded="false"> 
									 Option <i class="fas fa-caret-down"></i>
									  </a>
									 <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
										<a class="dropdown-item" href="javascript:ansedit(<?=$record->id?>);"> Edit </a>
										<a class="dropdown-item" href="javascript:ansdelete(<?=$record->id?>);"> Delete </a>
									  <?php //} else { ?>
										 <!--<a class="dropdown-item" href="#"> Locked </a>-->
									  </div>
								  </div><?php */?>
                                  <?php //} ?>
                                </div>
                                
                                <? #################################### Comments & Answer ##################################### ?>
                                
                                <div class="comment-sec-d1" id="ad<?=$record->id?>" style="display:block;">
                                  <div class="detail-comment-sec2 new-dt-sec">
                                    <form name="frmc<?=$record->id?>" action="" method="post">
                                      <input type="hidden" name="ans_id" value="<?=$record->id?>" />
                                      <div class="form-group">
                                        <div class="coment-area-dv">
                                          <div class="col-md-1 text-right">
                                            <?php if($user_qry->profile_picture!=""){ ?>
                                            <img src="<?php echo base_url();?>uploads/<?=$user_qry->profile_picture?>" alt="user" 
                                                            style="border-radius:50%; width:30px; height:30px;">
                                            <?php } else {?>
                                            <i class="fa fa-user" aria-hidden="true"></i>
                                            <?php }?>
                                          </div>
                                      <div class="col-md-9 px-0">
                                      <input type="text" name="comment<?=$record->id?>" id="com<?=$record->id?>" class="form-control" style="font-size:13px;">
                                      </div>
                                        <div class="col-md-2">
                                            <?php if($this->session->userdata('id')!='') { ?>
                                          <button type="button" id="add_comment2" class="comon-dv-bn" 
                                          onclick="javascript:insertcomment(<?=$record->id?>,<?=$qus_id?>,<?=$userId?>);">Add Comment</button>
                                            <?php  } else { ?>
										  <button type="button" id="add_comment2" class="comon-dv-bn" 
										  data-toggle="modal" data-target="#cusModal" style="border: none;">Add Comment</button>
										  <?php } ?>
                                          </div>
                                        </div>
                                      </div>
                                    </form>
                                  </div>
                                </div>
                                <div class="email-sec-d1" id="ans<?=$record->id?>" style="display:none;">
                                  <div>
                                   <form name="frm<?=$record->id?>" action="<?php echo base_url();?>problems/submitanswer/<?=$qus_id?>/<?=$userId?>" method="post" enctype="multipart/form-data">
                                   <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                   <input type="hidden" name="ans_id" value="<?=$record->id?>" />
                                   <textarea class="form-control" name="answer<?=$record->id?>" rows="20" id="anss<?=$record->id?>"></textarea>
                                    <script>
									 ClassicEditor
										.create( document.querySelector( '#anss<?=$record->id?>' ) )
										.catch( error => {
											console.error( error );
										} );
								    </script>
                                     
                                      <?php //if($this->session->userdata('id')!='') { ?>
                                      <button type="submit" class="comon-bn" id="submit1" style="border: none;">Submit</button>
                                      <button type="button" class="comon-bn" style="border:none;" onclick="javascript:hideanswer(<?=$record->id?>)">Cancel</button>
                                      <?php /*} else { ?>
                                      <button type="button" id="submit1" data-toggle="modal" data-target="#cusModal"
                                       style="border: none;">Submit</button>
                                     <?php }*/?>
                                    </form>
                                  </div>
                                </div>
                                <? #################################### End comments & answer ################################# ?>
                              </div>
                              <h5>Comments</h5>
                              <div id="comments_x">
                                <?php
								  $this->db->order_by('id', 'DESC');
								  $comment =$this->db->get_where('answer_comment',array('answer_id'=>$record->id));
								  $comnum = $comment->num_rows();
								  $x = 0;
								  
								  if($comnum!=0) {
								  foreach($comment->result() as $rec)
								  {
									$comId = $rec->id;
									$comauthor = $rec->user_id;
									
									$username = $this->db->get_where('user_master',array('id'=>$rec->user_id))->row();
									$exdate = explode('-', $rec->post_date);
									$postdate = mktime(12,0,0, $exdate[1],$exdate[2],$exdate[0]);
									$date = date("F j, Y", $postdate);
									
									  $cvt = $this->db->query("select sum(upvote) as upvot from `comment_up_down` where 
															  `comment_id` = '".$rec->id."'")->row();
									  $cupv = $cvt->upvot;  
									
									  $cvt2 = $this->db->query("select sum(downvote) as downvot from `comment_up_down` where 
															`comment_id` = '".$rec->id."'")->row();
									  $cdwv = $cvt2->downvot;
								   ?>
                                <div class="detial-new-comon <? if($x!=0){?>reply-div<?=$x?><? }?>">
                                  <div id="cmt">
                                    <div class="comment-show-top-new">
                                      <figure>
                                        <?php 
										  if($username->id=="Admin")
										  {
										?>
                                        <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" class="imxx">
                                        <?php
										  }
										  else
										  {
										   if($username->profile_picture!="")
										   {
										 ?>
                                        <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" class="imxx">
                                        <?php 
										   } 
										  else
										   {
										?>
                                        <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" class="imxx">
                                        <?php 
										   }
										  }
										?>
                                      </figure>
                                      <figcaption>
                                        <?=ucwords($username->geek_name)?>
                                        Commented on
                                        <?=$date?>
                                      </figcaption>
                                    </div>
                                    <div id="com1<?=$rec->id?>">
                                      <?=stripslashes(str_replace("%20"," ",$rec->comment));?>
                                    </div>
                                  </div>
                                  
                                  <!--<div id="ademo"></div>-->
                                  
                                  <div class="comment-sec-d1" id="comedit<?=$rec->id?>" style="display:none;">
                                    <div class="detail-comment-sec2 new-dt-sec">
                                      <div class="form-group">
                                        <div class="coment-area-dv">
                                          <div class="col-md-1 text-right">
                                            <?php if($username->profile_picture!=""){ ?>
                                            <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" class="imxx">
                                            <?php } else {?>
                                            <i class="fa fa-user" aria-hidden="true"></i>
                                            <?php }?>
                                          </div>
                                          <div class="col-md-9 px-0">
                                            <input type="text" name="commentedit<?=$rec->id?>" id="cedit<?=$rec->id?>" 
                                            class="form-control" value="<?=stripslashes(str_replace("%20"," ",$rec->comment));?>" style="font-size:13px;">
                                          </div>
                                          <div class="col-md-3">
                                            <button type="button" id="add_com<?=$rec->id?>" class="comon-dv-bn" 
                                            onclick="javascript:updatecomment(<?=$rec->id?>);">Update</button>
                                            <button type="button" id="cancel_com<?=$rec->id?>" class="comon-dv-bn" 
                                            onclick="javascript:comcancel(<?=$rec->id?>);">Cancel</button>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <?php //////////////////////// End Comments //////////////////// ?>
                                  
                                  <?php ///////////////// Reply over comments /////////////////////?>
                                  <div class="comment-sec-bottom1">
                                    <ul>
                                      <li class="d-flex"> 
                                      <a class="reply-box" id="show-d<?=$rec->id?>" onclick="javascript:replyshow(<?=$rec->id?>);"> 
                                      <i class="fa fa-reply"></i> Reply 
                                      </a> 
                                      <a class="reply-box" id="hide-d<?=$rec->id?>" onclick="javascript:replyhide(<?=$rec->id?>);" style="display:none;"> 
                                      <i class="fa fa-reply"></i> Reply 
                                      </a>
                                        <?php if($this->session->userdata('id')!='') { ?>
                                        <a href="javascript: comupvote(<?=$rec->id?>,<?=$userId?>)" class="up"> 
                                        <i class="far fa-thumbs-up"></i> <span id="demoo<?=$rec->id?>">
                                        <?php if($cupv==0){echo '';}else{echo $cupv;}?>
                                        </span> </a> <a href="javascript: comdownvote(<?=$rec->id?>,<?=$userId?>)" class="up"> 
                                        <i class="far fa-thumbs-down"></i><span id="demoo2<?=$rec->id?>">
                                        <?php if($cdwv==0){echo '';}else{echo $cdwv;}?>
                                        </span> </a>
                                        <?php } else { ?>
                                        <a href="javascript: void(0);" class="up"> <i class="far fa-thumbs-up"></i> <span>
                                        <?=$cupv?>
                                        </span> </a> <a href="javascript: void(0);" class="up"> <i class="far fa-thumbs-down"></i> <span>
                                        <?=$cdwv?>
                                        </span> </a>
                                        <?php }?>
                                        
                                        <?php if($this->session->userdata('id')== $comauthor) {?>
                                        <div class="dropdown detail-dp1"> 
                                        <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                        <i class="fas fa-ellipsis-h"></i> 
                                        </a>
                                          <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton"> 
                                          <a class="dropdown-item" href="javascript:editcomment(<?=$rec->id?>);"> Edit </a> 
                                          <a class="dropdown-item" href="javascript:removecomment(<?=$rec->id?>,<?=$record->id?>);"> Delete </a>
                                            <? //} else { ?>
                                          </div>
                                        </div>
                                        <?php }?>
                                      </li>
                                    </ul>
                                  </div>
                                  <form name="frmreply<?=$rec->id?>" action="" method="post">
                                    <input type="hidden" name="comment_id" value="<?=$rec->id?>" />
                                    <div class="chat-sec-1" id="chat-d<?=$rec->id?>" style="display:none;">
                                      <div class="comment-area2">
                                        <div class="form-group">
                                          <textarea name="reply<?=$rec->id?>" id="rep<?=$rec->id?>" class="form-control" 
                                           style="font-size:13px;" required></textarea>
                                        </div>
                                        <?php if($this->session->userdata('id')!='') { ?>
                                        <button type="button" class="rely-dv-bn" id="hide-d<?=$rec->id?>" 
                                         onclick="javascript:insertreply(<?=$qus_id?>,<?=$userId?>,<?=$rec->id?>,<?=$record->id?>)">Reply</button>
                                         
                                        <button type="button" class="rely-dv-bn" id="hide-d<?=$rec->id?>" onclick="javascript:replyhide(<?=$rec->id?>);">
                                        Cancel</button>
                                        <?php } else { ?>
                                        <button type="button" class="rely-dv-bn" id="hide-d<?=$rec->id?>" data-toggle="modal" 
                                         data-target="#cusModal">Reply</button>
                                        <?php }?>
                                      </div>
                                      <hr>
                                    </div>
                                  </form>
                                  <?php ///////////////// End Reply over comments /////////////////?>
                                  <?php
									  $this->db->order_by('id', 'DESC');
									  $reply = $this->db->get_where('reply_master',array('comment_id'=>$rec->id));
									  $x = 0;
									  
									  foreach($reply->result() as $rex)
									  {
										$relauthor = $rex->user_id;
										
										$uname = $this->db->get_where('user_master',array('id'=>$rex->user_id))->row();
										$exdt = explode('-', $rex->post_date);
										$postdt = mktime(12,0,0, $exdt[1],$exdt[2],$exdt[0]);
										$dt = date("F j, Y", $postdt);
										
										  $cvt3 = $this->db->query("select sum(upvote) as upvot from `reply_up_down` where 
																  `reply_id` = '".$rex->id."'")->row();
										  $cupv3 = $cvt3->upvot;  
										
										  $cvt3 = $this->db->query("select sum(downvote) as downvot from `reply_up_down` where 
																   `reply_id` = '".$rex->id."'")->row();
										  $cdwv3 = $cvt3->downvot;
								   ?>
                                  <div id="comrep">
                                    <div class="comment-show-top-new">
                                      <figure>
                                        <?php 
										  if($uname->id=="Admin")
										  {
										?>
                                        <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" class="imxx">
                                        <?php
										 }
										 else
										 {
										   if($uname->profile_picture!="")
										   {
										 ?>
                                        <img src="<?php echo base_url();?>uploads/<?=$uname->profile_picture?>" alt="user"  class="imxx">
                                        <?php 
										   } 
										  else
										   {
										?>
                                        <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user"  class="imxx">
                                        <?php 
										   }
										 }
										?>
                                      </figure>
                                      <figcaption>
                                        <?=$uname->geek_name?>
                                        Replied on
                                        <?=$dt?>
                                      </figcaption>
                                    </div>
                                    <div style="padding-left:10px; line-height:20px;" id="rep<?=$rex->id?>">
                                      <?=stripslashes($rex->reply)?>
                                    </div>
                                  </div>
                                  
                                  <!--<div id="comrep1"></div>-->
                                  
                                  <div class="chat-sec-1" id="rep-d<?=$rex->id?>" style="display:none;">
                                    <form name="frmedit" action="<?php echo base_url();?>problems/editreply/<?=$rex->id?>" method="post">
                                      <input type="hidden" name="ques_id" value="<?=$qus_id?>" />
                                      <div class="comment-area2">
                                        <div class="form-group">
                                          <input type="text" name="redit<?=$rex->id?>" class="form-control" style="font-size:13px;" 
                                                           value="<?=stripslashes($rex->reply)?>" required>
                                        </div>
                                        <button type="submit" class="rely-dv-bn" id="hide-d<?=$rex->id?>">Update</button>
                                        <button type="button" class="rely-dv-bn" onclick="javascript:reveditreply(<?=$rex->id?>);">Cancel</button>
                                      </div>
                                    </form>
                                    <hr>
                                  </div>
                                  <?php ///////////////// Reply over reply /////////////////?>
                                  <div class="comment-sec-bottom1">
                                    <ul>
                                      <li class="d-flex"> 
                                      <a class="reply-box" id="show-d_1<?=$rex->id?>" onclick="javascript:replyshow_1(<?=$rex->id?>);"> 
                                      <i class="fa fa-reply"></i> Reply 
                                      </a> 
                                      <a class="reply-box" id="hide-d_1<?=$rex->id?>" onclick="javascript:replyhide_1(<?=$rex->id?>);" style="display:none;">
                                      <i class="fa fa-reply"></i> Reply 
                                      </a>
                                        <?php if($this->session->userdata('id')!="") {?>
                                        <a href="javascript: comupvote_1(<?=$rex->id?>,<?=$userId?>)" class="up">
                                         <i class="far fa-thumbs-up"></i> <span id="demoo_1<?=$rex->id?>">
                                        <?php if($cupv3==0){echo '';}else{echo $cupv3;}?>
                                        </span> </a> <a href="javascript: comdownvote_1(<?=$rex->id?>,<?=$userId?>)" class="up"> 
                                        <i class="far fa-thumbs-down"></i> <span id="demoo2_1<?=$rex->id?>">
                                        <?php if($cdwv3==0){echo '';}else{echo $cdwv3;}?>
                                        </span> </a>
                                        <?php } else { ?>
                                        <a href="javascript: void(0)" class="up"> <i class="far fa-thumbs-up"></i> <span>
                                        <?php if($cupv3==0){echo '';}else{echo $cupv3;}?>
                                        </span> </a> <a href="javascript: void(0)" class="up"> <i class="far fa-thumbs-down"></i> <span>
                                        <?php if($cdwv3==0){echo '';}else{echo $cdwv3;}?>
                                        </span> </a>
                                        <?php }?>
                                        <?php if($this->session->userdata('id')== $relauthor) {?>
                                        <div class="dropdown detail-dp1"> 
                                        <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                         <i class="fas fa-ellipsis-h"></i> 
                                         </a>
                                          <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton"> 
                                          <a class="dropdown-item" href="javascript:editreply(<?=$rex->id?>);"> Edit </a> 
                                          <a class="dropdown-item" href="javascript:removereply(<?=$rex->id?>);"> Delete </a>
                                            <?php //} else { ?>
                                          </div>
                                        </div>
                                        <?php }?>
                                      </li>
                                    </ul>
                                  </div>
                      				<form name="subreply<?=$rex->id?>" action="<?php echo base_url();?>problems/submitreply/<?=$qus_id?>/<?=$userId?>" method="post">
                                    <input type="hidden" name="comment_id" value="<?=$comId?>" />
                                    <div class="chat-sec-1" id="chat-d_1<?=$rex->id?>" style="display:none;">
                                      <div class="comment-area2">
                                        <div class="form-group">
                                          <textarea name="reply<?=$comId?>" class="form-control" style="font-size:13px;" required> </textarea>
                                        </div>
                                        <?php if($this->session->userdata('id')!='') { ?>
                                        <button type="button" class="rely-dv-bn" id="hide-d_1<?=$rex->id?>" 
                                        onclick="javascript:insertreply(<?=$qus_id?>,<?=$userId?>,<?=$rex->id?>,<?=$record->id?>)">Reply</button>
                                        <?php } else { ?>
                                		<button type="button" class="rely-dv-bn" id="hide-d_1<?=$rex->id?>" data-toggle="modal" data-target="#cusModal">Reply</button>
                                        <?php }?>
                                      </div>
                                      <hr>
                                    </div>
                                  </form>
                                  <?php ///////////////// End Reply over reply /////////////////?>
                                  <?php
									  }
								   ?>
                                  <hr />
                                </div>
                                <?php
								  $x++;
								 } /// End Comments
							   
							   }
							  else
							  { 
							  ?>
                                <p align="center">No comments found.</p>
                                <?php
								  }
								?>
                              </div>
                              <div id="ademo"></div>
                              <div id="comrep1"></div>
                              <div id="ddemoo"></div>
                            </div>
                          </div>
                          <a class="comon-more-bn1 red-more-show-d1" id="more-bn-dv<?=$record->id?>" onclick="javascript:readmore(<?=$record->id?>)">
                          Read more
                          </a> 
                          <a class="comon-more-bn1" id="more-bn-dvc<?=$record->id?>" onclick="javascript:readless(<?=$record->id?>)" style="display:none;"> 
                          Read less
                          </a> 
                          </div>
                      </div>
                    </div>
                    <?php
						$i++;
					  }  /// End answer loop
					?>
                  </div>
                </div>
                <script>
					function readmore(id)
					{
						 document.getElementById("mr"+id).classList.remove("detail-dv-textarea");
						 document.getElementById("mr"+id).classList.add("detail-dv-textarea-next");
						 document.getElementById("more-bn-dv"+id).style.display='none';
						 document.getElementById("more-bn-dvc"+id).style.display='block';
					}
					
					function readless(id)
					{
						 document.getElementById("mr"+id).classList.add("detail-dv-textarea");
						 document.getElementById("mr"+id).classList.remove("detail-dv-textarea-next");
						 document.getElementById("more-bn-dv"+id).style.display='block';
						 document.getElementById("more-bn-dvc"+id).style.display='none';
					}
					
					function replyshow(id)
					{
						 document.getElementById("chat-d"+id).style.display='block';
						 document.getElementById("show-d"+id).style.display='none';
						 document.getElementById("hide-d"+id).style.display='block';
					}
					
					function replyhide(id)
					{
						 document.getElementById("chat-d"+id).style.display='none';
						 document.getElementById("show-d"+id).style.display='block';
						 document.getElementById("hide-d"+id).style.display='none';
					}
					
					function replyshow_1(id)
					{
						 document.getElementById("chat-d_1"+id).style.display='block';
						 document.getElementById("show-d_1"+id).style.display='none';
						 document.getElementById("hide-d_1"+id).style.display='block';
					}
					
					function replyhide_1(id)
					{
						 document.getElementById("chat-d_1"+id).style.display='none';
						 document.getElementById("show-d_1"+id).style.display='block';
						 document.getElementById("hide-d_1"+id).style.display='none';
					}
					
					function addcomment(id)
					{
					   document.getElementById("btcom"+id).style.display='none';
					   document.getElementById("hbtcom"+id).style.display='block';
					   
					   document.getElementById("ad"+id).style.display='block';
					   document.getElementById("ans"+id).style.display='none';
					}
					
					function insertcomment(aid,qid,uid)
					{
					  var xhttp = new XMLHttpRequest();
					  var content = document.getElementById('com'+aid).value;
					  if(content!="")
					  {
						  /*xhttp.open("GET", "<?php echo base_url();?>problems/addcomment/"+aid+"/"+qid+"/"+uid+"/"+content, false);
						  xhttp.send();*/
						  
						  xhttp.onreadystatechange = function() {
							if (this.readyState == 4 && this.status == 200) {
							  document.getElementById("comments_x").style.display = 'none';
							  document.getElementById("ademo").innerHTML = this.responseText;
							  document.getElementById('com'+aid).value = '';
							}
						  };
						  
						  xhttp.open("POST", "<?php echo base_url();?>problems/addcomment/", true);
						  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
						  xhttp.send("ans_id="+aid+"&ques_id="+qid+"&user_id="+uid+"&content="+content);
						  
						 /* document.getElementById("comments_x").style.display = 'none';
						  document.getElementById("ademo").innerHTML = xhttp.responseText;
						  document.getElementById('com'+aid).value = '';*/
						  
						 // $('#detailpage').fadeOut('slow').load('<?php //echo base_url();?>details/show/<?=$qus?>').fadeIn("slow");
					  }
					}
					
					function insertreply(qid,uid,cid,ansid)
					{
					  var xhttp = new XMLHttpRequest();
					  var content = document.getElementById('rep'+cid).value;
					  if(content!="")
					  {
						 /*xhttp.open("GET", "<?php //echo base_url();?>problems/addreply/"+qid+"/"+uid+"/"+cid+"/"+ansid+"/"+content, false);
						 xhttp.send();*/
						 
						  xhttp.onreadystatechange = function() {
							if (this.readyState == 4 && this.status == 200) {
							     document.getElementById("comments_x").style.display = 'none';
								 document.getElementById("comrep1").innerHTML = this.responseText;
								 document.getElementById('rep'+cid).value = '';
							}
						  };
						  
						  xhttp.open("POST", "<?php echo base_url();?>problems/addreply/", true);
						  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
						  xhttp.send("ques_id="+qid+"&user_id="+uid+"&comment_id="+cid+"&ans_id="+ansid+"&content="+content);
						  
						/* document.getElementById("comments_x").style.display = 'none';
						 document.getElementById("comrep1").innerHTML = xhttp.responseText;
						 document.getElementById('rep'+cid).value = '';*/
						 
						 //$('#data').fadeOut('slow').load('<?php //echo base_url();?>details/show/<?=$tques?>').fadeIn("slow");
					  }
					}
					
					function addanswer(id)
					{
					   document.getElementById("hbtans"+id).style.display='block';
					   document.getElementById("btans"+id).style.display='none';
					   
					   document.getElementById("ad"+id).style.display='none';
					   document.getElementById("ans"+id).style.display='block';
					}
					
					function hidecomment(id)
					{
					   document.getElementById("btcom"+id).style.display='block';
					   document.getElementById("hbtcom"+id).style.display='none';
					   
					   document.getElementById("ad"+id).style.display='none';
					}
					
					function hideanswer(id)
					{
					   document.getElementById("hbtans"+id).style.display='none';
					   document.getElementById("btans"+id).style.display='block';
					   
					   document.getElementById("ans"+id).style.display='none';
					   document.getElementById("ad"+id).style.display='block';
					}
					
					function ansedit(id)
					{
					   document.getElementById("qans"+id).style.display='none';
					   document.getElementById("edit"+id).style.display='block';
					   document.getElementById("more-bn-dv"+id).style.display='none';
					}
					
					function revansedit(id)
					{
					   document.getElementById("qans"+id).style.display='block';
					   document.getElementById("edit"+id).style.display='none';
					}
					
					function editcomment(id)
					{
					   document.getElementById("com1"+id).style.display='none';
					   document.getElementById("comedit"+id).style.display='block';
					}
					
					function deletecomment(id)
					{
					   document.getElementById("qans"+id).style.display='block';
					   document.getElementById("edit"+id).style.display='none';
					}
					
					function comcancel(id)
					{
					   document.getElementById("com1"+id).style.display='block';
					   document.getElementById("comedit"+id).style.display='none';
					}
					
					function editreply(id)
					{
					   document.getElementById("rep-d"+id).style.display='block';
					   document.getElementById("rep"+id).style.display='none';
					}
					
					function reveditreply(id)
					{
					   document.getElementById("rep-d"+id).style.display='none';
					   document.getElementById("rep"+id).style.display='block';
					}
			   </script> 
                <script>
				function upvote(id,userid) {
				  var xhttp = new XMLHttpRequest();
				  xhttp.open("GET", "<?php echo base_url();?>vote/ansupvote/"+id+"/"+userid, false);
				  xhttp.send();
				  document.getElementById("demo"+id).innerHTML = xhttp.responseText;
				}
				
				function downvote(id,userid) {
				  var xhttp = new XMLHttpRequest();
				  xhttp.open("GET", "<?php echo base_url();?>vote/ansdownvote/"+id+"/"+userid, false);
				  xhttp.send();
				  document.getElementById("demo2"+id).innerHTML = xhttp.responseText;
				}
				
				function comupvote(id,userid) {
				  var xhttp = new XMLHttpRequest();
				  xhttp.open("GET", "<?php echo base_url();?>vote/comupvote/"+id+"/"+userid, false);
				  xhttp.send();
				  document.getElementById("demoo"+id).innerHTML = xhttp.responseText;
				}
				
				function comdownvote(id,userid) {
				  var xhttp = new XMLHttpRequest();
				  xhttp.open("GET", "<?php echo base_url();?>vote/comdownvote/"+id+"/"+userid, false);
				  xhttp.send();
				  document.getElementById("demoo2"+id).innerHTML = xhttp.responseText;
				}
				
				function comupvote_1(id,userid) {
				  var xhttp = new XMLHttpRequest();
				  xhttp.open("GET", "<?php echo base_url();?>vote/replyupvote/"+id+"/"+userid, false);
				  xhttp.send();
				  document.getElementById("demoo_1"+id).innerHTML = xhttp.responseText;
				}
				
				function comdownvote_1(id,userid) {
				  var xhttp = new XMLHttpRequest();
				  xhttp.open("GET", "<?php echo base_url();?>vote/replydownvote/"+id+"/"+userid, false);
				  xhttp.send();
				  document.getElementById("demoo2_1"+id).innerHTML = xhttp.responseText;
				}
				
				function ansdelete(id) {
					  var xhttp = new XMLHttpRequest();
					  xhttp.open("GET", "<?php echo base_url();?>problems/deleteanswer/"+id, false);
					  xhttp.send();
					  /*xhttp.responseText;*/
					  location.reload(true);
				}
				
				function updatecomment(id)
				{
					  var content = document.getElementById('cedit'+id).value;
					  var xhttp = new XMLHttpRequest();
					  xhttp.open("GET", "<?php echo base_url();?>problems/editcomment/"+id+"/"+content, false);
					  xhttp.send();
					  location.reload(true);
				}
				
				function removecomment(id,ansid) 
				{
					  var xhttp = new XMLHttpRequest();
					  
					   /*xhttp.onreadystatechange = function() {
						if (this.readyState == 4 && this.status == 200) {
							
							 document.getElementById("comments_x").style.display = 'none';
							 document.getElementById("ademo").style.display = 'none';
							 document.getElementById('comrep1').style.display = 'none';
							 
							 document.getElementById("ddemoo").innerHTML = this.responseText;
						}
					  };*/
					  
					  xhttp.open("GET", "<?php echo base_url();?>problems/deletecomment/"+id+"/"+ansid, false);
					  xhttp.send();
					  
					  document.getElementById("comments_x").style.display = 'none';
					  document.getElementById("ademo").style.display = 'none';
					  document.getElementById("comrep1").style.display = 'none';
					  
					  document.getElementById("ddemoo").innerHTML = xhttp.responseText;
					  
					  /*xhttp.responseText;
					  location.reload(true);*/
				}
				
				function updatereply(id)
				{
					  var content = document.getElementById('redit'+id).value;
					  var xhttp = new XMLHttpRequest();
					  xhttp.open("GET", "<?php echo base_url();?>problems/editreply/"+id+"/"+content, false);
					  xhttp.send();
					  
					  location.reload(true);
				}
				
				function removereply(id) {
					  var xhttp = new XMLHttpRequest();
					  xhttp.open("GET", "<?php echo base_url();?>problems/deletereply/"+id, false);
					  xhttp.send();
					  /*xhttp.responseText;*/
					  location.reload(true);
				}
				</script> 
                
                <? ###############################  Related Questions Section ############################# ?>
                
                <?php $this->load->view('front/relatedQuestions.php');?>
                
                <? ##################################### End Related Question Section ###################### ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <? ########################## Right Side bar ###################### ?>
  <?php $this->load->view('front/rightsidebar.php');?>
  <? ################### Right Side bar end ############?>
  <!-- col-9 --> 
</div>
<div class="clearfix"></div>
</div>
</section>
<? ######################### Sign in modal ####################### ?>
<div class="modal fade exampleModalask" id="cusModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header ask-modal modal-header-1"> <img src="<?php echo base_url();?>assets2/images/logo-head.png" alt="">
        <h5 class="modal-title" id="exampleModalLabel">Ask Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      <div id="modal-spl-26" class="modal-body modal-body1"> <span id="txt" class="text-center" style="color:#FF0000;"></span>
        <div class="head-form head-form2x" id="next_hide">
          <div class="form-dp">
            <div class="top-sec-dp">
              <div class="form-group">
                <label> User Name</label>
                <input type="text" placeholder="" id="user_name2" class="form-control" value="" required>
              </div>
              <div class="form-group">
                <label> Password </label>
                <input type="password" placeholder="" id="password2" class="form-control" value="" required>
              </div>
              <button type="button" id="login_btn_comment2" class="btn default-btn login">Log In</button>
            </div>
          </div>
          <div class="col-md-4">&nbsp;</div>
          <div class="col-12">
            <div class="header-drop-links-first">
              <p>Or Login With</p>
              <ul class="socal-media">
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i> <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> <span> Linkedin</span></a></li>
              </ul>
              <div class="sub-link"> <a href="#">Lost Password </a> or <a href="#"> User Name</a> </div>
            </div>
          </div>
          <div class="col-12 mt-4">
            <div class="header-drop-links-second">
              <p>Or Sign Up With</p>
              <hr class="my-2">
              <ul class="socal-media">
                <li><a class="icon-new" href="#"> <i class="fas fa-envelope"></i> <span>Email</span></a></li>
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i> <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> <span> Linkedin</span></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
    $(document).ready(function()
	{
	 //////////////////////////////////////////
	  $("#login_btn_comment2").click(function()
	  {
		  var user_name = $("#user_name2").val();
		  var password = $("#password2").val();
			   
		  if(password=='' || user_name=='')
		  {
			 swal("Sorry!! Insert Your Login Data");
		  }
		  else
		  {
			 $.ajax({url: "<?php echo base_url();?>home/login/"+user_name+"/"+password, success: function(result){
				 /*if(result==success)
				 {*/
				   location.reload(true);
				/* }
				 else
				 {
				   $("#txt").html("Wrong username or password!");
				 }*/
			  }});
		  }
	 });
   });
</script> 
<script>
$(document).ready(function(){
   
   $("#btcom").click(function(){
      $(".ad1").show();
      $(".ad2").hide();
   });
   
   $("#btans").click(function(){
      $(".ad1").hide();
      $(".ad2").show();
   });
     $("#btcom2").click(function(){
      $(".ad3").show();
      $(".ad4").hide();
   });
   
   $("#btans2").click(function(){
      $(".ad3").hide();
      $(".ad4").show();
   });
});
</script> 
