<? ########################## Right Side bar ###################### ?>
   <?php
      $data = array();
      $online = $this->db->get_where('user_master',array('status'=>'online'));
      foreach($online->result() as $res)
      {
         $data[] = $res->id;
      }
      
      $count = $online->num_rows(); 
      
      $arr = array();
      $fixergeek=$this->db->get_where('fixergeek_master');
      foreach($fixergeek->result() as $rs)
      {
         $arr[] = $rs->user_id;
      }
      
      $result=array_intersect($data,$arr);
              
      if(count($result)!=0)
      {
   ?>
       <div class="col-md-5 col-lg-3">
        <div class="right-fixed-box fixed-carousel-spl-box new-width">
          <div class="host-section-right-carousel-box host-section-right-box">
            <div class="host-right-heading-box new-design-sec">
             <span class="text-center active-span">
                <i class="fa fa-circle" aria-hidden="true"></i> <b> <?=count($result)?> Fixer Geek (online)</b>
             </span> 
             <a href="<?php echo base_url();?>podium"> See All </a>
            </div>
            <div class="host-right-owl-box">
              <section class="client-logoarea">
                <div class="owl-carousel owl-theme">
                <?php
					foreach($result as $val)
					{
					   $res = $this->db->get_where('user_master',array('id'=>$val))->row();
					   
					   $review=$this->db->get_where('review_master',array('fixer_id'=>$val));
					   $score = $review->row();
					   $tot = ($score->conduct+$score->timing+$score->literacy+$score->knowledge+$score->pchandle+$score->type_speed) / 6;
					   
					   $fixergeek=$this->db->get_where('fixergeek_master',array('user_id'=>$val))->row();
					   
					   $expert = explode(",",$fixergeek->sub_sub_cat_id);
					   $slice = array_slice($expert, 0,3);
							  
					   $stat=$this->db->get_where('review_master',array('fixer_id'=>$val , 'status'=>'Fixed'));
					   $fixes = $stat->num_rows();
					   
					   $items = $this->db->get_where('sub_sub_category_master',array('id'=>$fixergeek->sub_sub_cat_id));
				?>
                  <div class="lgo-items">
                    <div class="hover-link-part new-style-add">
                      <h6> 
                        <div class="dropdown right-cl-dp">
                         <div class="top-sec-user">
                            <a class="dropdown-toggle show-details-new1" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">
                            <span class="us-pic-d1"><img src="<?php echo base_url();?>uploads/<?=$res->profile_picture?>" class="small-pic2" alt=""> </span> 
                            <?=ucwords($res->geek_name)?></a> 
                         </div>
                          
                           <div class="dropdown-menu show-del-d1" aria-labelledby="dropdownMenuButton">
                              <div class="profile-hover-details profile-hover-carousel1 new-show-div1">
                                <div class="row">
                                  <div class="col-md-12 mb-2">
                                    <h6 class="new-space-d1" style="color:#44a611;">
                                    <span class="us-pic-d1"> 
                                    <img src="<?php echo base_url();?>uploads/<?=$res->profile_picture?>" class="small-pic2">
                                    </span> <?=ucwords($res->geek_name)?></h6>
                                  </div>
                                  <div class="col-md-12 mb-1"> <span class="de-ancor-color new-ad-margin" style="color:#333;">Geek Score: <?=number_format($tot,1)?> &nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$res->id?>">View Score</a></span> </div>
                                  <div class="col-md-12 mb-1">
                                    <p>Availability: <?=$fixergeek->start_time?> to <?=$fixergeek->end_time?></p>
                                  </div>
                                  <div class="col-md-12 mb-1">
                                    <p>Timezone: <?=$fixergeek->timezone?></p>
                                  </div>
                                  <div class="col-md-12 mb-1">
                                    <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> <?=$fixes?> Problems Fixed</p>
                                  </div>
                                  <div class="col-md-12">
                                    <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                                  </div>
                                  <div class="col-md-12 mb-1">
                                    <ul class="profile-hover-list">
                                      <li class="spl-li">Categories (Expert in):</li>
                                      <?php
									    foreach($slice as $val)
										{
										  $item = $this->db->get_where('sub_sub_category_master',array('id'=>$val))->row(); 
									  ?>
                                      <li>
                                      <a href="<?php echo base_url();?>category/show/<?=(str_replace("&","-",str_replace(" ","_",$item->sub_sub_category_name)))?>">
									  <?=$item->sub_sub_category_name?></a>
                                      </li>
                                      <?php }?> <span style="font-size:11px;"> <a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$res->id?>"><?php if(count($expert) > 3) { echo (count($expert) - 3)." more..."; } ?></a></span>
                                    </ul>
                                  </div>
                                  <div class="col-md-12">
                                    <div class="row de-ancor-color">
                                      <div class="col-md-6 text-left "> 
                                      <a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$res->id?>">Read Full Profile</a> 
                                      </div>
                                      <div class="col-md-6 text-right"> 
                                      <a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$res->id?>">Hire Fixer</a> 
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                           </div>
                       </div>
                        <span class="sp-line-hegiht">  Geek Score: <span class="font-weight-bold"><?=number_format($tot,1)?> </span>  </span>
                      </h6>
                      <div class="col-md-12 p-0">
                              <p class="sp-flex-d1"> 
                              <span> <img src="<?php echo base_url();?>assets2/images/start-icon.jpg" class="small-pic" alt=""> </span> 
                              Fixed this problem in the past 
                              </p>
                          </div>
                      
                    </div>
                    
                    <a href="#" class="hover-right-sidebar">
                    <div class="one">
                      <div class="new-weight"><?php /*?> <h6> <?=$res->name?> can fix this <span> using Remote Assistance </span>  </h6><?php */?>
                        <div class="checkbox-hover">
                          <div  class="check-box-sec">
                            <p> <span> <i class="fas fa-check"></i> </span> Mouse </p>
                            <p> <span> <i class="fas fa-check"></i> </span> Keybord </p>
                            <p> <span> <i class="fas fa-check"></i> </span> File </p>
                            <p> <span> <i class="fas fa-check"></i> </span> Screen </p> 
                            <p> <span> <i class="fas fa-check"></i> </span>  Voice </p>
                            <p> <span> <i class="fas fa-check"></i> </span> Chat </p>  
                          </div>
                        </div>
                        <div class="delfaut-div-d">
                            <div class="delfaut-div">
                               <p>
                                 Let  <span> <?=ucwords($res->geek_name)?> </span> Control your PC to fix this problem
                               </p>
                            </div>
                        </div>
                        <button type="button" class="btn new-add-ds">
                           Get remote Assistance
                        </button>
                       </div>
                      <figure> <img src="<?php echo base_url();?>assets2/images/podium-pic-d1.png" alt="" class="sp-pic-2"> </figure>
                    </div>
                    </a>
                    <a href="#" class="hover-right-sidebar">
                    <div class="one">
                      <div class="new-weight"> 
                         <?php /*?><h6> <?=$res->name?> can fix this <span> using Screen Sharing </span>  </h6><?php */?>
                         <div class="checkbox-hover">
                           <div class="check-box-sec">
                              <p> <span> <i class="fas fa-check"></i> </span> Chat </p>
                              <p> <span> <i class="fas fa-check"></i>  </span> Level 2 </p>
                              <p> <span> <i class="fas fa-check"></i> </span> Cheaper </p>
                              <p> <span> <i class="fas fa-check"></i> </span> No Installation Required </p>
                          </div>
                        </div>
                        <div class="delfaut-div-d">
                          <div class="delfaut-div">
                             <p>
                               Let <span> <?=ucwords($res->geek_name)?> </span> chat with you to fix this problem
                             </p>
                          </div>
                        </div>
                        <button type="button" class="btn new-add-ds">
                           Get Chat Support
                        </button>
                      </div>
                      <figure class="ml-0"> <img src="<?php echo base_url();?>assets2/images/podium-pic-d3.png" alt="" class="sp-pic-l"> </figure>
                    </div>
                    </a> 
                    <!--<div class="new-sec-add-d1">
                      <div class="new-weight"> 
                        <a href="<?php //echo base_url();?>becomeafixer" class="new-tag">
                          Become a fixer geek
                        </a>
                      </div>
                    </div>-->
                    
                    <div align="center">
                       <a href="<?php echo base_url();?>becomeafixer" class="new-tag">
                          Become a Fixer Geek
                        </a>
                    </div>
                    
                    </div>
                  <?php }?>
                </div>
              </section>
            </div>
            <!--<div class="host-section-right-bottom"> <a href="<?php echo base_url();?>podium">See All Fixer Geeks...</a> </div>-->
          </div>
          <div class="host-section-right-box spl-right-box mt-3"> <a href="#">Advertisement</a> </div>
        </div>
      </div>
      <?php } else { ?>
      <div class="col-md-5 col-lg-3">
       <div class="mt-3  right-fixed-box fixed-carousel-spl-box new-width">
            <div class="host-section-right-offline-box host-section-right-box">
              <div class="host-offline-heading-box mb-2"> 
              <span class="text-center inactive-span"><i class="fa fa-circle" aria-hidden="true"></i> <b>No Fixers available</b></span> 
              <div class="new-add-para">
                 <p> Currenty there are no fixer Geeks who can fix this problem
for you by remotely connecting to your PC. </p>
              </div>
              </div>
              <a href="#">
                  <div class="host-middle-box comon-host-sec">
                    <div class="row mb-2">
                      <div class="col-md-8 my-auto pr-0">
                        <p>Make Money using just your PC & knowledge.</p>
                        <div class="new-add-bn-d1">
                       <button type="button" class="btn new-add-ds"> Become a Fixer Geek </button>
                    </div>
                      </div>
                      <div class="col-md-4 pl-xl-1 ne-pic-d1"> <img src="<?php echo base_url();?>assets2/images/no-fixer.png" alt=""> </div>
                    </div>
                  </div>
              </a>
              <a href="#">
                <div class="host-bottom-box comon-host-sec">
                  <div class="row">
                    <div class="col-md-12 text-center mb-2">
                    </div>
                    <div class="col-md-12">
                      <div class="row">
                        <div class="col-md-8 my-auto pr-0">
                          <p> Check availability of Fixers based on your timezone. </p>
                          <div class="new-add-bn-d1">
                     <button type="button" class="btn new-add-ds"> Check Availability </button> 
                  </div>
                        </div>
                        <div class="col-md-4 pl-xl-1 my-auto ne-pic-d1"> <img src="<?php echo base_url();?>assets2/images/troubleshoot.png" alt=""> </div>
                      </div>
                    </div>
                    
                  </div>
                </div>
              </a>
              
              <div class="col-md-12 mt-3">
                    <!--<div class="new-sec-add-d1">
                      <div class="new-weight"> 
                        <a href="<?php //echo base_url();?>becomeafixer" class="btn new-add-ds">
                          Ask a Troubleshooting Question
                        </a>
                      </div>
                    </div>-->
                    
                     <div align="center">
                       <a href="<?php echo base_url();?>becomeafixer" class="new-tag">
                          Ask a Troubleshooting Question
                        </a>
                    </div>
                    
             </div>
             
            </div>
            <div class="host-section-right-box spl-right-box mt-3"> <a href="#">Advertisement</a> </div>
          </div>
      </div>
      <?php }?>
      <? ################### Right Side bar end ############?> 