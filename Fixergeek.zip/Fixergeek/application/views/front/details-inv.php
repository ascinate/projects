<?php
	$qus_id=$this->uri->segment(3);
	$userId = $this->session->userdata('id');
	
	$question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
	$user=$this->db->get_where('user_master',array('id'=>$question->user_id))->row();
	
	$this->db->order_by('upvote', 'DESC');
	$answer=$this->db->get_where('answers_master',array('question_id'=>$qus_id));
	
	$date=date_create($question->post_date);   
	
	//$user_qry=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
	$category=$this->db->get_where('category_master',array('id'=>$question->category_name))->row();
	$sub_cat=$this->db->get_where('sub_category_master',array('id'=>$question->sub_cat_id))->row();
	$sub_sub_cat=$this->db->get_where('sub_sub_category_master',array('id'=>$question->sub_sub_cat_id))->row();
?>