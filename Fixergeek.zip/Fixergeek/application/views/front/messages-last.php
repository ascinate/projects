<?php
   $query = $this->db->query("select * from `fixergeek_master` where 
   							 `user_id` = '".$this->session->userdata('id')."'");
   $numrow = $query->num_rows();
   
    if($numrow!=0)
	{
	   $this->session->set_userdata('user_type', 'fixer');
	}
	else
	{
	   $this->session->set_userdata('user_type', 'asker');
	}
?>
<section class="total-bd-area">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3 col-lg-2 pr-md-0">
        <div class="left-slidber-area">
          <div class="host-section-left-list">
            <?php $this->load->view('inc/left-navigation-supporters');?>
          </div>
        </div>
      </div>
      <div class="col-md-9 col-lg-10">
        <div class="bod-area">
          <div class="messge-part">
            <div class="row messege_part_head">
              <div class="col-3 px-0 text-left">
                <p class="messege-1">Messeges</p>
              </div>
              <div class="col-5 px-0 text-right"> <a href="#" class="new-1">New Messeges</a> </div>
              <div class="col-4 px-0 text-right">
                <P><b>Status:</b> <i class="fa fa-circle green_user-1"></i>Online</P>
              </div>
            </div>
            <!-- 1st-row -->
            <div class="row ">
              <div class="col-xl-3 chat_name pl-lg-0 mt-2">
                <div class="chat_list_1">
                    <div class="nav nav-pills"  id="pills-tab" role="tablist">
                    
                    <?php
                      if($this->session->userdata('user_type')=='asker')
                      {
                         $query = $this->db->query("select distinct(fixer_id) from `message_master` 
                                           where `asker_id` = '".$this->session->userdata('id')."'" );
                         
                         //echo $this->db->last_query();
                         foreach($query->result() as $rec)
                         {
                            $username = $this->db->get_where('user_master',array('id'=>$rec->fixer_id))->row();
                    ?>
                    
                    <a  class="nav-link default-btn" data-toggle="pill" role="tab" href="#pills-d<?=$rec->fixer_id?>">
                      <div class="chat_name_part" id="pills-home-tab">
                        <div class="row mx-0">
                          <div class="col-2  px-2">
                            <div class="round-pic"> 
                              <?php
                                 if($username->profile_picture!="")
                                 {
                              ?>
                               <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                               style="border-radius:50%; width:20px; height:20px;" class="w-100">
                               <?php
                                 }
                                 else
                                 {
                                ?>
                                   <i class="far fa-user-circle"></i>
                                <?php
                                  }
                                ?>
                            </div>
                            <div class="offline-1"></div>
                          </div>
                          <div class="col-8  px-2">
                            <h6 class="chat_human"><?=$username->geek_name?></h6>
                            <p>How do i my PC to...</p>
                          </div>
                          <div class="col-2 px-0">
                            
                          </div>
                        </div>
                        <!--  -->
                      </div>
                    </a>
                   <?php
                       }
                      }
                   ?> 
                    
                    </div>
                </div>
              </div>
              <!-- col-4 -->
              <div class="col-xl-9 mt-2 px-0">
                <div class="chat-part tab-content" id="pills-tabContent">
                   <div class="tab-pane fade active show" id="pills-d1" role="tabpanel">
                      <div class="col-12 px-0">
                        <div class="chat-part-head">
                          <ul>
                            <li>
                              <p><b>JoeMartyJoe</b></p>
                            </li>
                            <li>
                              <p>Score: 4.5</p>
                            </li>
                            <li>
                              <p>Type: Fixer</p>
                            </li>
                            <li>
                              <p>Level: 3</p>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <!--  -->
                      <div class="col-12 px-0">
                        <div class="chat-part-details py-3">
                          <div class="row  mx-0 chating text-left">
                            <div class="col-1 px-2">
                              <div class="chat_pic float-left"> <img src="images/Steve-Jobs.jpg" class="w-100" alt=""> </div>
                              <div class="online-2"></div>
                            </div>
                            <div class="col-10 chatting_messege px-4 pt-1">
                              <h6 class="mb-2"><b>Steve James</b></h6>
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.tempor incididunt ut labore et dolore magna aliqua. Ut enim ad </p>
                            </div>
                            <div class="col-1 pt-1 px-0">
                              <div class="chat-time">
                                <p>1:35 P.M</p>
                              </div>
                            </div>
                          </div>
                          <!--  -->
                          <div class="row mt-4 mx-0 chating text-left">
                            <div class="col-1 px-2">
                              <div class="chat_pic float-left"> <img src="images/mark.jpg" class="w-100" alt=""> </div>
                              <div class="online-2"></div>
                            </div>
                            <div class="col-10 chatting_messege px-4 pt-1">
                              <h6 class="mb-2"><b>Mark Steves</b></h6>
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.tempor incididunt ut labore et dolore magna aliqua. Ut enim ad </p>
                              <p class="pt-1">proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
                            </div>
                            <div class="col-1 pt-1 px-0">
                              <div class="chat-time">
                                <p>1:37 P.M</p>
                              </div>
                            </div>
                          </div>
                          <!--  -->
                          <div class="row mt-4 mx-0 chating text-left">
                            <div class="col-1 px-2">
                              <div class="chat_pic float-left"> <img src="images/Steve-Jobs.jpg" class="w-100" alt=""> </div>
                              <div class="online-2"></div>
                            </div>
                            <div class="col-10 chatting_messege px-4 pt-1">
                              <h6 class="mb-2"><b>Steve James</b></h6>
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.tempor incididunt ut labore et dolore magna aliqua. Ut enim ad </p>
                              <p class="pt-1">proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
                              <p class="pt-1">proident, sunt in culpa qui. </p>
                            </div>
                            <div class="col-1 pt-1 px-0">
                              <div class="chat-time">
                                <p>1:38 P.M</p>
                              </div>
                            </div>
                          </div>
                          <!--  -->
                          <div class="row mt-4 mx-0 chating text-left">
                            <div class="col-1 px-2">
                              <div class="chat_pic float-left"> <img src="images/mark.jpg" class="w-100" alt=""> </div>
                              <div class="online-2"></div>
                            </div>
                            <div class="col-10 chatting_messege px-4 pt-1">
                              <h6 class="mb-2"><b>Mark Steves</b></h6>
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.tempor incididunt ut labore et dolore magna aliqua. Ut enim ad </p>
                              <p class="pt-1">proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>
                            </div>
                            <div class="col-1 pt-1 px-0">
                              <div class="chat-time">
                                <p>1:42 P.M</p>
                              </div>
                            </div>
                          </div>
                          <!--  -->
                          <div class="row mt-4 mx-0 chating text-left">
                            <div class="col-1 px-2">
                              <div class="chat_pic float-left"> <img src="images/Steve-Jobs.jpg" class="w-100" alt=""> </div>
                              <div class="online-2"></div>
                            </div>
                            <div class="col-10 chatting_messege px-4 pt-1">
                              <h6 class="mb-2"><b>Steve Jamess</b></h6>
                              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.tempor incididunt ut labore et dolore magna aliqua. Ut enim ad </p>
                            </div>
                            <div class="col-1 pt-1 px-0">
                              <div class="chat-time">
                                <p>1:44 P.M</p>
                              </div>
                            </div>
                          </div>
                          <!--  -->
                          <div class="row mt-4 mx-0 chating text-left">
                            <div class="col-1 px-2">
                              <div class="chat_pic float-left"> <img src="images/mark.jpg" class="w-100" alt=""> </div>
                              <div class="online-2"></div>
                            </div>
                            <div class="col-10 chatting_messege px-4 pt-1">
                              <h6 class="mb-2"><b>Mark Steves</b></h6>
                              <p>Typing..... </p>
                            </div>
                          </div>
                        </div>
                        <!--  -->
                        <!-- send maeesege -->
                        <div class="row mt-2 mx-0">
                          <div class="col-1 px-0">
                            <div class="image-upload">
                              <label for="file-input">
                              <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 511.999 511.999" style="enable-background:new 0 0 511.999 511.999;" xml:space="preserve">
                                <path d="M483.694,50.624c-18.473-18.679-40.704-28.526-64.357-28.526c-0.368,0-0.737,0.002-1.106,0.007
        c-22.542,0.292-44.66,9.872-62.278,26.973l-0.166,0.161L127.082,281.761c-22.883,23.123-22.889,56.695-0.014,79.825
        c11.093,11.216,25.244,17.392,39.848,17.392h0.007c14.781-0.002,29.025-6.178,40.177-17.459l158.073-161.49
        c7.724-7.891,7.589-20.549-0.303-28.274c-7.89-7.724-20.55-7.589-28.274,0.302l-158.004,161.42
        c-3.515,3.555-7.66,5.513-11.676,5.514c-3.951,0-7.793-1.858-11.419-5.523c-10.525-10.642-3.502-20.035,0.049-23.623
        L383.958,77.62c21.828-21.058,49.796-20.625,71.305,1.123c25.497,25.78,18.557,55.864,0.37,74.244
        c-7.767,7.848-7.7,20.507,0.147,28.275c7.851,7.768,20.509,7.699,28.275-0.148c17.548-17.732,27.467-40.276,27.928-63.475
        C512.466,93.357,502.419,69.558,483.694,50.624z" />
                                <path d="M420.9,217.665c-7.931-7.68-20.59-7.477-28.271,0.456L195.287,421.935c-17.865,18.04-40.468,27.976-63.656,27.979h-0.012
        c-23.18,0-45.172-9.846-63.594-28.472c-43.121-43.599-31.082-94.804-0.012-126.229l197.04-196.996
        c7.809-7.807,7.81-20.466,0.003-28.275c-7.806-7.809-20.465-7.81-28.275-0.003L39.703,266.973l-0.075,0.076
        c-24.714,24.974-38.772,56.464-39.589,88.671c-0.871,34.344,12.808,66.794,39.556,93.84
        c25.729,26.015,58.409,40.341,92.024,40.341h0.018c33.984-0.005,66.713-14.184,92.157-39.925l197.562-204.04
        C429.037,238.003,428.833,225.345,420.9,217.665z" />
                              </svg>
                              </label>
                              <input id="file-input" type="file" />
                            </div>
                          </div>
                          <div class="col-9 px-0">
                            <div class="form-group">
                              <input type="text" class="form-control chat-input" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Type a Massege...">
                            </div>
                          </div>
                          <div class="col-2 pr-0">
                            <button class="btn btn-primary default-btn w-100">Send</button>
                          </div>
                        </div>
                      </div>
                  <!--  -->
                  </div> 
                  
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</section>
