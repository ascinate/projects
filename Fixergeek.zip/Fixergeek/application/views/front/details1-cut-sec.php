<div class="new-add-del-sec2" style="top:117px;">
   <div class="col-md-12 pl-0">
      <div class="details-devoplo-accordian mt-3 w-100">
         <div class="details-area-div">
            <div class="question-area-details-dv">
               <div class="top-question">
                  <h1>
                     How to fix touch screen in windows 10 mobile OS?              
                  </h1>
                  <ul class="categories-d1">
                     <li> Categories: </li>
                     <li> <a href="http://fixergeek.com/staging/category/show/Pen_-_Touch">
                        Pen &amp; Touch                  </a> 
                     </li>
                  </ul>
               </div>
               <div class="colas-area-dv">
                  <div id="accordion" class="accordion">
                     <div class="answer-part">
                        <div class="ans-div-d1">
                           <div class="card-header collapsed question-comon-1" data-target="#collapse1" data-toggle="collapse" data-parent="#accordion">
                              <a class="card-title new-user-pic">
                                 Answer by
                                 <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" class="imxx">
                                 Geek321 Posted on November 3, 2020                      <!--@-->
                              </a>
                           </div>
                           <div id="collapse1" class="collapse show" data-parent="#accordion">
                              <div class="card-body border-top-0">
                                 <div class="comon-text-area comon-space">
                                    <div class="total-edit-sec">
                                    </div>
                                    <div class="detail-dv-textarea" id="mr97">
                                       <div class="new-text-sec-d1" id="qans97">
                                          <p>In any version of Windows, the Windows Media Player is present. It can play music in formats 'mp3' and 'wav' and also videos in formats 'avi' and 'mp4'. Just like in its description, its sole purpose is to 'play media', but little do we know that it can also edit videos.</p>
                                          <p>Initially, Windows Media Player has no capabilities of editing videos. But, there is something we called 'plug-in' in which the player can be compatible with, and through that, it can now edit and trim videos. The plug-in is an extension that a program needs in order to incorporate another related function that is not available on its basic version.</p>
                                          <p><i><strong>Cutting Videos through Windows Media Player</strong></i></p>
                                          <p>In this editing feature, the best it can do is to trim the length of the video. In here, a very common third-party application is used as a plug-in. It is called 'SolveigMM WMP Trimmer'. These are the steps on how to set it up and utilize it afterward.</p>
                                          <ol>
                                             <li>Download the SolveigMM WMP Trimmer plug-in on its website. It is easily searched in Google. The plug-in is available on a 21-day free trial, with a limit of 10 minutes. If you want to maximize its capabilities like longer cutting duration, you can decide to purchase the Home Edition or the Business Edition.</li>
                                             <li>Once downloaded, have it installed on the system.</li>
                                             <li>After installing, check if it is now integrated. Open the Windows Media Player and select the 'Tools' tab, then the 'Plug-ins' option. You will see that the 'SolveigMM WMP Trimmer Plug-in' has existed.</li>
                                          </ol>
                                          <figure class="image"><img alt="Description: https://images.wondershare.com/images/multimedia/video-editor/windows-media-player-plug-in.jpg"></figure>
                                          <p><a href="https://images.wondershare.com/images/multimedia/video-editor/windows-media-player-plug-in.jpg"><i>https://images.wondershare.com/images/multimedia/video-editor/windows-media-player-plug-in.jpg</i></a></p>
                                          <p>&nbsp;</p>
                                          <ol>
                                             <li>Play the video you want to trim down. While playing, you can move the blue slider of the video. If you want to start at a certain point, click 'Start' on the tools located at the bottom window of the Windows Media Player. If you want to stop, click on 'End'.</li>
                                          </ol>
                                          <figure class="image"><img alt="Description: https://images.wondershare.com/images/multimedia/video-editor/control.jpg"></figure>
                                       </div>
                                       <div class="new-text-sec-d1 new-add-email-sec" id="edit97" style="display:none;">
                                          
                                       </div>
                                       <div class="more-text-d1" id="more-text1-dv">
                                          <div class="more-details-sec-dv">
                                             <div class="main-button1">
                                                <a class="add-ans-bn-d1" id="btans97" onclick="javascript:addanswer(97)"> 
                                                <i class="fas fa-plus"></i> Add Another Answer
                                                </a>
                                                
                                                <a href="javascript: upvote(97,12)" class="up"> 
                                                    <i class="far fa-thumbs-up"></i> <span id="demo97">
                                                    </span> 
                                                </a> 
                                                <a href="javascript: downvote(97,12)" class="up"> 
                                                  <i class="far fa-thumbs-down"></i> <span id="demo297">
                                                  </span> 
                                                </a>
                                             </div>
                                             <div class="comment-sec-d1" id="ad97" style="display:block;">
                                                <div class="detail-comment-sec2 new-dt-sec">
                                                   <form name="frmc97" action="" method="post">
                                                      <input type="hidden" name="ans_id" value="97">
                                                      <div class="form-group">
                                                         <div class="coment-area-dv">
                                                            <div class="col-md-1 text-right">
                                                               <img src="http://fixergeek.com/staging/uploads/avatar12.png" alt="user" style="border-radius:50%; width:30px; height:30px;">
                                                            </div>
                                                            <div class="col-md-9 px-0">
                                                               <input type="text" name="comment97" id="com97" class="form-control" style="font-size:13px;">
                                                            </div>
                                                            <div class="col-md-2">
                                                               <button type="button" id="add_comment2" class="comon-dv-bn" onclick="javascript:insertcomment(97,33,12);">Add Comment</button>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </form>
                                                </div>
                                             </div>
                                             <div class="email-sec-d1" id="ans97" style="display:none;">
                                                <div>
                                                   
                                                </div>
                                             </div>
                                          </div>
                                          <h5>Comments</h5>
                                          <div id="comments_x">
                                             <div class="detial-new-comon ">
                                                <div id="cmt">
                                                   <div class="comment-show-top-new">
                                                      <figure>
                                                         <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" class="imxx">
                                                      </figure>
                                                      <figcaption>
                                                         Geek101                                        Commented on
                                                         November 7, 2020                                      
                                                      </figcaption>
                                                   </div>
                                                   <div id="com1129">
                                                      Test                                    
                                                   </div>
                                                </div>
                                                <!--<div id="ademo"></div>-->
                                                <div class="comment-sec-d1" id="comedit129" style="display:none;">
                                                   <div class="detail-comment-sec2 new-dt-sec">
                                                      <div class="form-group">
                                                         <div class="coment-area-dv">
                                                            <div class="col-md-1 text-right">
                                                               <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" class="imxx">
                                                            </div>
                                                            <div class="col-md-9 px-0">
                                                               <input type="text" name="commentedit129" id="cedit129" class="form-control" value="Test" style="font-size:13px;">
                                                            </div>
                                                            <div class="col-md-3">
                                                               <button type="button" id="add_com129" class="comon-dv-bn" onclick="javascript:updatecomment(129);">Update</button>
                                                               <button type="button" id="cancel_com129" class="comon-dv-bn" onclick="javascript:comcancel(129);">Cancel</button>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="comment-sec-bottom1">
                                                   <ul>
                                                      <li class="d-flex"> 
                                                         <a class="reply-box" id="show-d129" onclick="javascript:replyshow(129);"> 
                                                         <i class="fa fa-reply"></i> Reply 
                                                         </a> 
                                                         <a class="reply-box" id="hide-d129" onclick="javascript:replyhide(129);" style="display:none;"> 
                                                         <i class="fa fa-reply"></i> Reply 
                                                         </a>
                                                         <a href="javascript: comupvote(129,12)" class="up"> 
                                                         <i class="far fa-thumbs-up"></i> <span id="demoo129">
                                                         </span> </a> <a href="javascript: comdownvote(129,12)" class="up"> 
                                                         <i class="far fa-thumbs-down"></i><span id="demoo2129">
                                                         </span> </a>
                                                      </li>
                                                   </ul>
                                                </div>
                                                <form name="frmreply129" action="" method="post">
                                                   <input type="hidden" name="comment_id" value="129">
                                                   <div class="chat-sec-1" id="chat-d129" style="display:none;">
                                                      <div class="comment-area2">
                                                         <div class="form-group">
                                                            <textarea name="reply129" id="rep129" class="form-control" style="font-size:13px;" required=""></textarea>
                                                         </div>
                                                         <button type="button" class="rely-dv-bn" id="hide-d129" onclick="javascript:insertreply(33,12,129,97)">Reply</button>
                                                      </div>
                                                      <hr>
                                                   </div>
                                                </form>
                                                <div id="comrep">
                                                   <div class="comment-show-top-new">
                                                      <figure>
                                                         <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" class="imxx">
                                                      </figure>
                                                      <figcaption>
                                                         geek101                                        Replied on
                                                         November 7, 2020                                      
                                                      </figcaption>
                                                   </div>
                                                   <div style="padding-left:10px; line-height:20px;" id="rep67">
                                                      Hi there. JHow are you?                                    
                                                   </div>
                                                </div>
                                                <!--<div id="comrep1"></div>-->
                                                <div class="chat-sec-1" id="rep-d67" style="display:none;">
                                                   <form name="frmedit" action="http://fixergeek.com/staging/problems/editreply/67" method="post">
                                                      <input type="hidden" name="ques_id" value="33">
                                                      <div class="comment-area2">
                                                         <div class="form-group">
                                                            <input type="text" name="redit67" class="form-control" style="font-size:13px;" value="Hi there. JHow are you?" required="">
                                                         </div>
                                                         <button type="submit" class="rely-dv-bn" id="hide-d67">Update</button>
                                                         <button type="button" class="rely-dv-bn" onclick="javascript:reveditreply(67);">Cancel</button>
                                                      </div>
                                                   </form>
                                                   <hr>
                                                </div>
                                                <div class="comment-sec-bottom1">
                                                   <ul>
                                                      <li class="d-flex"> 
                                                         <a class="reply-box" id="show-d_167" onclick="javascript:replyshow_1(67);"> 
                                                         <i class="fa fa-reply"></i> Reply 
                                                         </a> 
                                                         <a class="reply-box" id="hide-d_167" onclick="javascript:replyhide_1(67);" style="display:none;">
                                                         <i class="fa fa-reply"></i> Reply 
                                                         </a>
                                                         <a href="javascript: comupvote_1(67,12)" class="up">
                                                         <i class="far fa-thumbs-up"></i> <span id="demoo_167">
                                                         </span> </a> <a href="javascript: comdownvote_1(67,12)" class="up"> 
                                                         <i class="far fa-thumbs-down"></i> <span id="demoo2_167">
                                                         </span> </a>
                                                      </li>
                                                   </ul>
                                                </div>
                                                <form name="subreply67" action="http://fixergeek.com/staging/problems/submitreply/33/12" method="post">
                                                   <input type="hidden" name="comment_id" value="129">
                                                   <div class="chat-sec-1" id="chat-d_167" style="display:none;">
                                                      <div class="comment-area2">
                                                         <div class="form-group">
                                                            <textarea name="reply129" class="form-control" style="font-size:13px;" required=""> </textarea>
                                                         </div>
                                                         <button type="button" class="rely-dv-bn" id="hide-d_167" onclick="javascript:insertreply(33,12,67,97)">Reply</button>
                                                      </div>
                                                      <hr>
                                                   </div>
                                                </form>
                                                <hr>
                                             </div>
                                             <div class="detial-new-comon reply-div1">
                                                <div id="cmt">
                                                   <div class="comment-show-top-new">
                                                      <figure>
                                                         <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" class="imxx">
                                                      </figure>
                                                      <figcaption>
                                                         Geek321                                        Commented on
                                                         November 3, 2020                                      
                                                      </figcaption>
                                                   </div>
                                                   <div id="com1122">
                                                      yes                                    
                                                   </div>
                                                </div>
                                                <!--<div id="ademo"></div>-->
                                                <div class="comment-sec-d1" id="comedit122" style="display:none;">
                                                   <div class="detail-comment-sec2 new-dt-sec">
                                                      <div class="form-group">
                                                         <div class="coment-area-dv">
                                                            <div class="col-md-1 text-right">
                                                               <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" class="imxx">
                                                            </div>
                                                            <div class="col-md-9 px-0">
                                                               <input type="text" name="commentedit122" id="cedit122" class="form-control" value="yes" style="font-size:13px;">
                                                            </div>
                                                            <div class="col-md-3">
                                                               <button type="button" id="add_com122" class="comon-dv-bn" onclick="javascript:updatecomment(122);">Update</button>
                                                               <button type="button" id="cancel_com122" class="comon-dv-bn" onclick="javascript:comcancel(122);">Cancel</button>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="comment-sec-bottom1">
                                                   <ul>
                                                      <li class="d-flex"> 
                                                         <a class="reply-box" id="show-d122" onclick="javascript:replyshow(122);"> 
                                                         <i class="fa fa-reply"></i> Reply 
                                                         </a> 
                                                         <a class="reply-box" id="hide-d122" onclick="javascript:replyhide(122);" style="display:none;"> 
                                                         <i class="fa fa-reply"></i> Reply 
                                                         </a>
                                                         <a href="javascript: comupvote(122,12)" class="up"> 
                                                         <i class="far fa-thumbs-up"></i> <span id="demoo122">
                                                         </span> </a> <a href="javascript: comdownvote(122,12)" class="up"> 
                                                         <i class="far fa-thumbs-down"></i><span id="demoo2122">
                                                         </span> </a>
                                                      </li>
                                                   </ul>
                                                </div>
                                                <form name="frmreply122" action="" method="post">
                                                   <input type="hidden" name="comment_id" value="122">
                                                   <div class="chat-sec-1" id="chat-d122" style="display:none;">
                                                      <div class="comment-area2">
                                                         <div class="form-group">
                                                            <textarea name="reply122" id="rep122" class="form-control" style="font-size:13px;" required=""></textarea>
                                                         </div>
                                                         <button type="button" class="rely-dv-bn" id="hide-d122" onclick="javascript:insertreply(33,12,122,97)">Reply</button>
                                                      </div>
                                                      <hr>
                                                   </div>
                                                </form>
                                                <hr>
                                             </div>
                                          </div>
                                          <div id="ademo"></div>
                                          <div id="comrep1"></div>
                                          <div id="ddemoo"></div>
                                       </div>
                                    </div>
                                    <a class="comon-more-bn1 red-more-show-d1" id="more-bn-dv97" onclick="javascript:readmore(97)">
                                    Read more
                                    </a> 
                                    <a class="comon-more-bn1" id="more-bn-dvc97" onclick="javascript:readless(97)" style="display:none;"> 
                                    Read less
                                    </a> 
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <script>
                        function readmore(id)
                        {
                        	 document.getElementById("mr"+id).classList.remove("detail-dv-textarea");
                        	 document.getElementById("mr"+id).classList.add("detail-dv-textarea-next");
                        	 document.getElementById("more-bn-dv"+id).style.display='none';
                        	 document.getElementById("more-bn-dvc"+id).style.display='block';
                        }
                        
                        function readless(id)
                        {
                        	 document.getElementById("mr"+id).classList.add("detail-dv-textarea");
                        	 document.getElementById("mr"+id).classList.remove("detail-dv-textarea-next");
                        	 document.getElementById("more-bn-dv"+id).style.display='block';
                        	 document.getElementById("more-bn-dvc"+id).style.display='none';
                        }
                        
                        function replyshow(id)
                        {
                        	 document.getElementById("chat-d"+id).style.display='block';
                        	 document.getElementById("show-d"+id).style.display='none';
                        	 document.getElementById("hide-d"+id).style.display='block';
                        }
                        
                        function replyhide(id)
                        {
                        	 document.getElementById("chat-d"+id).style.display='none';
                        	 document.getElementById("show-d"+id).style.display='block';
                        	 document.getElementById("hide-d"+id).style.display='none';
                        }
                        
                        function replyshow_1(id)
                        {
                        	 document.getElementById("chat-d_1"+id).style.display='block';
                        	 document.getElementById("show-d_1"+id).style.display='none';
                        	 document.getElementById("hide-d_1"+id).style.display='block';
                        }
                        
                        function replyhide_1(id)
                        {
                        	 document.getElementById("chat-d_1"+id).style.display='none';
                        	 document.getElementById("show-d_1"+id).style.display='block';
                        	 document.getElementById("hide-d_1"+id).style.display='none';
                        }
                        
                        function addcomment(id)
                        {
                           document.getElementById("btcom"+id).style.display='none';
                           document.getElementById("hbtcom"+id).style.display='block';
                           
                           document.getElementById("ad"+id).style.display='block';
                           document.getElementById("ans"+id).style.display='none';
                        }
                        
                        function insertcomment(aid,qid,uid)
                        {
                          var xhttp = new XMLHttpRequest();
                          var content = document.getElementById('com'+aid).value;
                          if(content!="")
                          {
                        	  /*xhttp.open("GET", "http://fixergeek.com/staging/problems/addcomment/"+aid+"/"+qid+"/"+uid+"/"+content, false);
                        	  xhttp.send();*/
                        	  
                        	  xhttp.onreadystatechange = function() {
                        		if (this.readyState == 4 && this.status == 200) {
                        		  document.getElementById("comments_x").style.display = 'none';
                        		  document.getElementById("ademo").innerHTML = this.responseText;
                        		  document.getElementById('com'+aid).value = '';
                        		}
                        	  };
                        	  
                        	  xhttp.open("POST", "http://fixergeek.com/staging/problems/addcomment/", true);
                        	  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                        	  xhttp.send("ans_id="+aid+"&ques_id="+qid+"&user_id="+uid+"&content="+content);
                        	  
                        	 /* document.getElementById("comments_x").style.display = 'none';
                        	  document.getElementById("ademo").innerHTML = xhttp.responseText;
                        	  document.getElementById('com'+aid).value = '';*/
                        	  
                        	 // $('#detailpage').fadeOut('slow').load('details/show/How-to-fix-touch-screen-in-windows-10-mobile-OS').fadeIn("slow");
                          }
                        }
                        
                        function insertreply(qid,uid,cid,ansid)
                        {
                          var xhttp = new XMLHttpRequest();
                          var content = document.getElementById('rep'+cid).value;
                          if(content!="")
                          {
                        	 /*xhttp.open("GET", "problems/addreply/"+qid+"/"+uid+"/"+cid+"/"+ansid+"/"+content, false);
                        	 xhttp.send();*/
                        	 
                        	  xhttp.onreadystatechange = function() {
                        		if (this.readyState == 4 && this.status == 200) {
                        		     document.getElementById("comments_x").style.display = 'none';
                        			 document.getElementById("comrep1").innerHTML = this.responseText;
                        			 document.getElementById('rep'+cid).value = '';
                        		}
                        	  };
                        	  
                        	  xhttp.open("POST", "http://fixergeek.com/staging/problems/addreply/", true);
                        	  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                        	  xhttp.send("ques_id="+qid+"&user_id="+uid+"&comment_id="+cid+"&ans_id="+ansid+"&content="+content);
                        	  
                        	/* document.getElementById("comments_x").style.display = 'none';
                        	 document.getElementById("comrep1").innerHTML = xhttp.responseText;
                        	 document.getElementById('rep'+cid).value = '';*/
                        	 
                        	 //$('#data').fadeOut('slow').load('details/show/How to fix touch screen in windows 10 mobile OS?').fadeIn("slow");
                          }
                        }
                        
                        function addanswer(id)
                        {
                           document.getElementById("hbtans"+id).style.display='block';
                           document.getElementById("btans"+id).style.display='none';
                           
                           document.getElementById("ad"+id).style.display='none';
                           document.getElementById("ans"+id).style.display='block';
                        }
                        
                        function hidecomment(id)
                        {
                           document.getElementById("btcom"+id).style.display='block';
                           document.getElementById("hbtcom"+id).style.display='none';
                           
                           document.getElementById("ad"+id).style.display='none';
                        }
                        
                        function hideanswer(id)
                        {
                           document.getElementById("hbtans"+id).style.display='none';
                           document.getElementById("btans"+id).style.display='block';
                           
                           document.getElementById("ans"+id).style.display='none';
                        }
                        
                        function ansedit(id)
                        {
                           document.getElementById("qans"+id).style.display='none';
                           document.getElementById("edit"+id).style.display='block';
                           document.getElementById("more-bn-dv"+id).style.display='none';
                        }
                        
                        function revansedit(id)
                        {
                           document.getElementById("qans"+id).style.display='block';
                           document.getElementById("edit"+id).style.display='none';
                        }
                        
                        function editcomment(id)
                        {
                           document.getElementById("com1"+id).style.display='none';
                           document.getElementById("comedit"+id).style.display='block';
                        }
                        
                        function deletecomment(id)
                        {
                           document.getElementById("qans"+id).style.display='block';
                           document.getElementById("edit"+id).style.display='none';
                        }
                        
                        function comcancel(id)
                        {
                           document.getElementById("com1"+id).style.display='block';
                           document.getElementById("comedit"+id).style.display='none';
                        }
                        
                        function editreply(id)
                        {
                           document.getElementById("rep-d"+id).style.display='block';
                           document.getElementById("rep"+id).style.display='none';
                        }
                        
                        function reveditreply(id)
                        {
                           document.getElementById("rep-d"+id).style.display='none';
                           document.getElementById("rep"+id).style.display='block';
                        }
                         
                     </script> 
                     <script>
                        function upvote(id,userid) {
                          var xhttp = new XMLHttpRequest();
                          xhttp.open("GET", "http://fixergeek.com/staging/vote/ansupvote/"+id+"/"+userid, false);
                          xhttp.send();
                          document.getElementById("demo"+id).innerHTML = xhttp.responseText;
                        }
                        
                        function downvote(id,userid) {
                          var xhttp = new XMLHttpRequest();
                          xhttp.open("GET", "http://fixergeek.com/staging/vote/ansdownvote/"+id+"/"+userid, false);
                          xhttp.send();
                          document.getElementById("demo2"+id).innerHTML = xhttp.responseText;
                        }
                        
                        function comupvote(id,userid) {
                          var xhttp = new XMLHttpRequest();
                          xhttp.open("GET", "http://fixergeek.com/staging/vote/comupvote/"+id+"/"+userid, false);
                          xhttp.send();
                          document.getElementById("demoo"+id).innerHTML = xhttp.responseText;
                        }
                        
                        function comdownvote(id,userid) {
                          var xhttp = new XMLHttpRequest();
                          xhttp.open("GET", "http://fixergeek.com/staging/vote/comdownvote/"+id+"/"+userid, false);
                          xhttp.send();
                          document.getElementById("demoo2"+id).innerHTML = xhttp.responseText;
                        }
                        
                        function comupvote_1(id,userid) {
                          var xhttp = new XMLHttpRequest();
                          xhttp.open("GET", "http://fixergeek.com/staging/vote/replyupvote/"+id+"/"+userid, false);
                          xhttp.send();
                          document.getElementById("demoo_1"+id).innerHTML = xhttp.responseText;
                        }
                        
                        function comdownvote_1(id,userid) {
                          var xhttp = new XMLHttpRequest();
                          xhttp.open("GET", "http://fixergeek.com/staging/vote/replydownvote/"+id+"/"+userid, false);
                          xhttp.send();
                          document.getElementById("demoo2_1"+id).innerHTML = xhttp.responseText;
                        }
                        
                        function ansdelete(id) {
                        	  var xhttp = new XMLHttpRequest();
                        	  xhttp.open("GET", "http://fixergeek.com/staging/problems/deleteanswer/"+id, false);
                        	  xhttp.send();
                        	  /*xhttp.responseText;*/
                        	  location.reload(true);
                        }
                        
                        function updatecomment(id)
                        {
                        	  var content = document.getElementById('cedit'+id).value;
                        	  var xhttp = new XMLHttpRequest();
                        	  xhttp.open("GET", "http://fixergeek.com/staging/problems/editcomment/"+id+"/"+content, false);
                        	  xhttp.send();
                        	  location.reload(true);
                        }
                        
                        function removecomment(id,ansid) 
                        {
                        	  var xhttp = new XMLHttpRequest();
                        	  
                        	   /*xhttp.onreadystatechange = function() {
                        		if (this.readyState == 4 && this.status == 200) {
                        			
                        			 document.getElementById("comments_x").style.display = 'none';
                        			 document.getElementById("ademo").style.display = 'none';
                        			 document.getElementById('comrep1').style.display = 'none';
                        			 
                        			 document.getElementById("ddemoo").innerHTML = this.responseText;
                        		}
                        	  };*/
                        	  
                        	  xhttp.open("GET", "http://fixergeek.com/staging/problems/deletecomment/"+id+"/"+ansid, false);
                        	  xhttp.send();
                        	  
                        	  document.getElementById("comments_x").style.display = 'none';
                        	  document.getElementById("ademo").style.display = 'none';
                        	  document.getElementById("comrep1").style.display = 'none';
                        	  
                        	  document.getElementById("ddemoo").innerHTML = xhttp.responseText;
                        	  
                        	  /*xhttp.responseText;
                        	  location.reload(true);*/
                        }
                        
                        function updatereply(id)
                        {
                        	  var content = document.getElementById('redit'+id).value;
                        	  var xhttp = new XMLHttpRequest();
                        	  xhttp.open("GET", "http://fixergeek.com/staging/problems/editreply/"+id+"/"+content, false);
                        	  xhttp.send();
                        	  
                        	  location.reload(true);
                        }
                        
                        function removereply(id) {
                        	  var xhttp = new XMLHttpRequest();
                        	  xhttp.open("GET", "http://fixergeek.com/staging/problems/deletereply/"+id, false);
                        	  xhttp.send();
                        	  /*xhttp.responseText;*/
                        	  location.reload(true);
                        }
                     </script> 
                     
                     
                     
                     
                     <!-------------- Related ---------------->

                     
                     <div class="related-question-area">
                        <div class="sub-hedding-d1">
                           <h2> Related Question</h2>
                        </div>
                     </div>
                     <div class="answer-part2">
                        <div id="headingOne" class="accordion">
                           <div class="card-header collapsed" data-toggle="collapse" data-target="#collapse20" aria-expanded="true" aria-controls="collapseOne"> <a class="card-title">
                              How to fix touch screen or pen to work on my Windows 10?                       </a> 
                           </div>
                           <div id="collapse20" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                              <ul class="categories-d1">
                                 <li> Categories: </li>
                                 <li> <a href="http://fixergeek.com/staging/category/show/Pen_-_Touch">
                                    Pen &amp; Touch                          </a> 
                                 </li>
                              </ul>
                              <div class="card-body p-0" id="child1">
                                 <div class="card sub-related-ans-area">
                                    <div class="card-header collapsed" data-toggle="collapse" data-target="#collapse94">
                                       <a class="card-title new-user-pic">
                                          Answer by
                                          <img src="http://fixergeek.com/staging/uploads/avatar9.png" alt="user" class="imxx">
                                          subhojit1                            Posted on
                                          October 30, 2020                            <!--@-->
                                       </a>
                                    </div>
                                    <div class="card-body collapse show" data-parent="#child1" id="collapse94">
                                       <div class="comon-text-area comon-space">
                                          <div class="detail-dv-textarea" id="rq94">
                                             <div class="new-text-sec-d1 " id="qans294">
                                                <p>The closest fix to <a href="https://www.makeuseof.com/tag/rebooting-computer-fix-many-issues/"><strong>rebooting the entire computer</strong></a>, which should have been your very first step, is turning the touchscreen off and back on.</p>
                                                <p>Press <strong>CTRL + X</strong> and select <strong>Device Manager</strong>. <strong>Double click&nbsp;</strong>on <strong>Human Interface Devices </strong>to open the dropdown. <strong>Right click </strong>the listing for <strong>HID-compliant touch screen </strong>and select <strong>Disable</strong>. You'll be asked to confirm this, so click <strong>Yes</strong>.</p>
                                                <p>&nbsp;</p>
                                                <p>You now need <strong>right click </strong>the listing again, but this time select <strong>Enable</strong>. This is one of the simplest solutions, but it doesn't always work. In fact, you may find that the issue still continues after a system restart. If that's the case, please read on.</p>
                                             </div>
                                             <div class="new-text-sec-d1 new-add-email-sec" id="edit294" style="display:none;">
                                                
                                             </div>
                                             <div class="more-text2" id="more-text1-dv294">
                                                <div class="more-details-sec-dv">
                                                   <div class="main-button1">
                                                      <a class="comon-dv-bn" id="btcom94" onclick="javascript:addcomment2(94)"> Add comment</a> 
                                                      <a class="comon-dv-bn" id="hbtcom94" onclick="javascript:hidecomment2(94)" style="display:none;"> Add comment</a> 
                                                      <a class="comon-dv-bn" id="btans94" onclick="javascript:addanswer2(94)"> Add Another Answer</a> 
                                                      <a class="comon-dv-bn" id="hbtans94" onclick="javascript:hideanswer2(94)" style="display:none;"> Add Another Answer </a>
                                                      <a href="javascript:upvote2(94,12)" class="up"> 
                                                      <i class="far fa-thumbs-up"></i> <span id="demi94">
                                                      1                                      </span> 
                                                      </a> 
                                                      <a href="javascript:downvote2(94,12)" class="up">
                                                      <i class="far fa-thumbs-down"></i> <span id="demi294">
                                                      0                                      </span> 
                                                      </a>
                                                   </div>
                                                   <div id="ad294" class="comment-sec-d1">
                                                      <div class="detail-comment-sec2 new-dt-sec">
                                                         <form name="frm94" action="" method="post">
                                                            <input type="hidden" name="ans_id" value="94">
                                                            <div class="form-group">
                                                               <div class="coment-area-dv">
                                                                  <div class="col-md-1 text-right">
                                                                     <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" style="border-radius:50%; width:20px; height:20px;">
                                                                  </div>
                                                                  <div class="col-md-9 px-0">
                                                                     <input type="text" name="comment94" id="com294" class="form-control" style="font-size:13px;">
                                                                  </div>
                                                                  <div class="col-md-2">
                                                                     <button type="button" id="add_comment2" class="comon-dv-bn" onclick="javascript:insertcomment2(94,20,12)">Add Comment</button>
                                                                  </div>
                                                               </div>
                                                            </div>
                                                         </form>
                                                      </div>
                                                   </div>
                                                   <div id="ans294" class="comment-sec-d1">
                                                      <div id="anstext">
                                                         
                                                      </div>
                                                   </div>
                                                </div>
                                                <h5>Comments</h5>
                                                <div id="reldet">
                                                   <div class="detial-new-comon reply-div">
                                                      <div class="comment-show-top-new">
                                                         <figure>
                                                            <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" style="border-radius:50%; width:30px; height:30px;">
                                                         </figure>
                                                         <figcaption>
                                                            Test Steve                                          Commented on
                                                            November 2, 2020                                        
                                                         </figcaption>
                                                      </div>
                                                      <p id="com_1121">
                                                         hello world                                      
                                                      </p>
                                                      <div id="com_edit121" class="comment-sec-d1">
                                                         <div class="detail-comment-sec2 new-dt-sec">
                                                            <form name="frm121" action="http://fixergeek.com/staging/problems/editcomment2/121" method="post">
                                                               <input type="hidden" name="ques_id" value="20">
                                                               <div class="form-group">
                                                                  <div class="coment-area-dv">
                                                                     <div class="col-md-1 text-right">
                                                                        <img src="http://fixergeek.com/staging/uploads/avatar5.png" style="border-radius:50%; width:20px; height:20px;">
                                                                     </div>
                                                                     <div class="col-md-9 px-0">
                                                                        <input type="text" name="cedit2121" class="form-control" style="font-size:13px;" value="hello world">
                                                                     </div>
                                                                     <div class="col-md-3">
                                                                        <button type="submit" id="e_comment2121" class="comon-dv-bn" onclick="javascript:updatecomment2(121);"> Update </button>
                                                                        <button type="button" id="d_comment2121" class="comon-dv-bn" onclick="javascript:comcancel2(121);"> Cancel </button>
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </form>
                                                         </div>
                                                      </div>
                                                      <div class="comment-sec-bottom1">
                                                         <ul>
                                                            <li class="d-flex"> 
                                                               <a class="reply-box" id="show-d2121" onclick="javascript:replyshow2(121);"> 
                                                               <i class="fa fa-reply"></i> Reply 
                                                               </a> 
                                                               <a class="reply-box" id="hide-d2121" onclick="javascript:replyhide2(121);" style="display:none;">
                                                               <i class="fa fa-reply"></i> Reply 
                                                               </a>
                                                               <a href="javascript:comupvote2(121,12)" class="up"> <i class="far fa-thumbs-up"></i><span id="demoox121">
                                                               </span> </a> <a href="javascript:comdownvote2(121,12)" class="up"> <i class="far fa-thumbs-down"></i><span id="demoox2121">
                                                               </span> </a>
                                                            </li>
                                                         </ul>
                                                      </div>
                                                      <form name="frmreply121" action="http://fixergeek.com/staging/problems/submitreply/20/12" method="post">
                                                         <input type="hidden" name="comment_id" value="121">
                                                         <div class="chat-sec-1" id="chat-d2121" style="display:none;">
                                                            <div class="comment-area2">
                                                               <div class="form-group">
                                                                  <textarea name="reply121" class="form-control" style="font-size:13px;" required=""></textarea>
                                                               </div>
                                                               <button type="button" class="rely-dv-bn" id="hide-d2121" onclick="javascript:insertcomment2(121,20,12)">Reply</button>
                                                            </div>
                                                            <hr>
                                                         </div>
                                                      </form>
                                                      <hr>
                                                   </div>
                                                   <div class="detial-new-comon reply-div">
                                                      <div class="comment-show-top-new">
                                                         <figure>
                                                            <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" style="border-radius:50%; width:30px; height:30px;">
                                                         </figure>
                                                         <figcaption>
                                                            Test Steve                                          Commented on
                                                            November 2, 2020                                        
                                                         </figcaption>
                                                      </div>
                                                      <p id="com_1120">
                                                         nice                                      
                                                      </p>
                                                      <div id="com_edit120" class="comment-sec-d1">
                                                         <div class="detail-comment-sec2 new-dt-sec">
                                                            <form name="frm120" action="http://fixergeek.com/staging/problems/editcomment2/120" method="post">
                                                               <input type="hidden" name="ques_id" value="20">
                                                               <div class="form-group">
                                                                  <div class="coment-area-dv">
                                                                     <div class="col-md-1 text-right">
                                                                        <img src="http://fixergeek.com/staging/uploads/avatar5.png" style="border-radius:50%; width:20px; height:20px;">
                                                                     </div>
                                                                     <div class="col-md-9 px-0">
                                                                        <input type="text" name="cedit2120" class="form-control" style="font-size:13px;" value="nice">
                                                                     </div>
                                                                     <div class="col-md-3">
                                                                        <button type="submit" id="e_comment2120" class="comon-dv-bn" onclick="javascript:updatecomment2(120);"> Update </button>
                                                                        <button type="button" id="d_comment2120" class="comon-dv-bn" onclick="javascript:comcancel2(120);"> Cancel </button>
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </form>
                                                         </div>
                                                      </div>
                                                      <div class="comment-sec-bottom1">
                                                         <ul>
                                                            <li class="d-flex"> 
                                                               <a class="reply-box" id="show-d2120" onclick="javascript:replyshow2(120);"> 
                                                               <i class="fa fa-reply"></i> Reply 
                                                               </a> 
                                                               <a class="reply-box" id="hide-d2120" onclick="javascript:replyhide2(120);" style="display:none;">
                                                               <i class="fa fa-reply"></i> Reply 
                                                               </a>
                                                               <a href="javascript:comupvote2(120,12)" class="up"> <i class="far fa-thumbs-up"></i><span id="demoox120">
                                                               </span> </a> <a href="javascript:comdownvote2(120,12)" class="up"> <i class="far fa-thumbs-down"></i><span id="demoox2120">
                                                               </span> </a>
                                                            </li>
                                                         </ul>
                                                      </div>
                                                      <form name="frmreply120" action="http://fixergeek.com/staging/problems/submitreply/20/12" method="post">
                                                         <input type="hidden" name="comment_id" value="120">
                                                         <div class="chat-sec-1" id="chat-d2120" style="display:none;">
                                                            <div class="comment-area2">
                                                               <div class="form-group">
                                                                  <textarea name="reply120" class="form-control" style="font-size:13px;" required=""></textarea>
                                                               </div>
                                                               <button type="button" class="rely-dv-bn" id="hide-d2120" onclick="javascript:insertcomment2(120,20,12)">Reply</button>
                                                            </div>
                                                            <hr>
                                                         </div>
                                                      </form>
                                                      <hr>
                                                   </div>
                                                   <div class="detial-new-comon reply-div">
                                                      <div class="comment-show-top-new">
                                                         <figure>
                                                            <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" style="border-radius:50%; width:30px; height:30px;">
                                                         </figure>
                                                         <figcaption>
                                                            Test Steve                                          Commented on
                                                            October 31, 2020                                        
                                                         </figcaption>
                                                      </div>
                                                      <p id="com_1118">
                                                         nice                                      
                                                      </p>
                                                      <div id="com_edit118" class="comment-sec-d1">
                                                         <div class="detail-comment-sec2 new-dt-sec">
                                                            <form name="frm118" action="http://fixergeek.com/staging/problems/editcomment2/118" method="post">
                                                               <input type="hidden" name="ques_id" value="20">
                                                               <div class="form-group">
                                                                  <div class="coment-area-dv">
                                                                     <div class="col-md-1 text-right">
                                                                        <img src="http://fixergeek.com/staging/uploads/avatar5.png" style="border-radius:50%; width:20px; height:20px;">
                                                                     </div>
                                                                     <div class="col-md-9 px-0">
                                                                        <input type="text" name="cedit2118" class="form-control" style="font-size:13px;" value="nice">
                                                                     </div>
                                                                     <div class="col-md-3">
                                                                        <button type="submit" id="e_comment2118" class="comon-dv-bn" onclick="javascript:updatecomment2(118);"> Update </button>
                                                                        <button type="button" id="d_comment2118" class="comon-dv-bn" onclick="javascript:comcancel2(118);"> Cancel </button>
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </form>
                                                         </div>
                                                      </div>
                                                      <div class="comment-sec-bottom1">

                                                         <ul>
                                                            <li class="d-flex"> 
                                                               <a class="reply-box" id="show-d2118" onclick="javascript:replyshow2(118);"> 
                                                               <i class="fa fa-reply"></i> Reply 
                                                               </a> 
                                                               <a class="reply-box" id="hide-d2118" onclick="javascript:replyhide2(118);" style="display:none;">
                                                               <i class="fa fa-reply"></i> Reply 
                                                               </a>
                                                               <a href="javascript:comupvote2(118,12)" class="up"> <i class="far fa-thumbs-up"></i><span id="demoox118">
                                                               </span> </a> <a href="javascript:comdownvote2(118,12)" class="up"> <i class="far fa-thumbs-down"></i><span id="demoox2118">
                                                               </span> </a>
                                                            </li>
                                                         </ul>
                                                      </div>
                                                      <form name="frmreply118" action="http://fixergeek.com/staging/problems/submitreply/20/12" method="post">
                                                         <input type="hidden" name="comment_id" value="118">
                                                         <div class="chat-sec-1" id="chat-d2118" style="display:none;">
                                                            <div class="comment-area2">
                                                               <div class="form-group">
                                                                  <textarea name="reply118" class="form-control" style="font-size:13px;" required=""></textarea>
                                                               </div>
                                                               <button type="button" class="rely-dv-bn" id="hide-d2118" onclick="javascript:insertcomment2(118,20,12)">Reply</button>
                                                            </div>
                                                            <hr>
                                                         </div>
                                                      </form>
                                                      <hr>
                                                   </div>
                                                   <div class="detial-new-comon reply-div">
                                                      <div class="comment-show-top-new">
                                                         <figure>
                                                            <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" style="border-radius:50%; width:30px; height:30px;">
                                                         </figure>
                                                         <figcaption>
                                                            Test Steve                                          Commented on
                                                            October 31, 2020                                        
                                                         </figcaption>
                                                      </div>
                                                      <p id="com_1117">
                                                         hi how r you                                      
                                                      </p>
                                                      <div id="com_edit117" class="comment-sec-d1">
                                                         <div class="detail-comment-sec2 new-dt-sec">
                                                            <form name="frm117" action="http://fixergeek.com/staging/problems/editcomment2/117" method="post">
                                                               <input type="hidden" name="ques_id" value="20">
                                                               <div class="form-group">
                                                                  <div class="coment-area-dv">
                                                                     <div class="col-md-1 text-right">
                                                                        <img src="http://fixergeek.com/staging/uploads/avatar5.png" style="border-radius:50%; width:20px; height:20px;">
                                                                     </div>
                                                                     <div class="col-md-9 px-0">
                                                                        <input type="text" name="cedit2117" class="form-control" style="font-size:13px;" value="hi how r you">
                                                                     </div>
                                                                     <div class="col-md-3">
                                                                        <button type="submit" id="e_comment2117" class="comon-dv-bn" onclick="javascript:updatecomment2(117);"> Update </button>
                                                                        <button type="button" id="d_comment2117" class="comon-dv-bn" onclick="javascript:comcancel2(117);"> Cancel </button>
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </form>
                                                         </div>
                                                      </div>
                                                      <div class="comment-sec-bottom1">
                                                         <ul>
                                                            <li class="d-flex"> 
                                                               <a class="reply-box" id="show-d2117" onclick="javascript:replyshow2(117);"> 
                                                               <i class="fa fa-reply"></i> Reply 
                                                               </a> 
                                                               <a class="reply-box" id="hide-d2117" onclick="javascript:replyhide2(117);" style="display:none;">
                                                               <i class="fa fa-reply"></i> Reply 
                                                               </a>
                                                               <a href="javascript:comupvote2(117,12)" class="up"> <i class="far fa-thumbs-up"></i><span id="demoox117">
                                                               </span> </a> <a href="javascript:comdownvote2(117,12)" class="up"> <i class="far fa-thumbs-down"></i><span id="demoox2117">
                                                               </span> </a>
                                                            </li>
                                                         </ul>
                                                      </div>
                                                      <form name="frmreply117" action="http://fixergeek.com/staging/problems/submitreply/20/12" method="post">
                                                         <input type="hidden" name="comment_id" value="117">
                                                         <div class="chat-sec-1" id="chat-d2117" style="display:none;">
                                                            <div class="comment-area2">
                                                               <div class="form-group">
                                                                  <textarea name="reply117" class="form-control" style="font-size:13px;" required=""></textarea>
                                                               </div>
                                                               <button type="button" class="rely-dv-bn" id="hide-d2117" onclick="javascript:insertcomment2(117,20,12)">Reply</button>
                                                            </div>
                                                            <hr>
                                                         </div>
                                                      </form>
                                                      <hr>
                                                   </div>
                                                   <div class="detial-new-comon reply-div">
                                                      <div class="comment-show-top-new">
                                                         <figure>
                                                            <img src="http://fixergeek.com/staging/uploads/avatar12.png" alt="user" style="border-radius:50%; width:30px; height:30px;">
                                                         </figure>
                                                         <figcaption>
                                                            Test Hunter                                          Commented on
                                                            October 30, 2020                                        
                                                         </figcaption>
                                                      </div>
                                                      <p id="com_1116">
                                                         nice                                      
                                                      </p>
                                                      <div id="com_edit116" class="comment-sec-d1">
                                                         <div class="detail-comment-sec2 new-dt-sec">
                                                            <form name="frm116" action="http://fixergeek.com/staging/problems/editcomment2/116" method="post">
                                                               <input type="hidden" name="ques_id" value="20">
                                                               <div class="form-group">
                                                                  <div class="coment-area-dv">
                                                                     <div class="col-md-1 text-right">
                                                                        <img src="http://fixergeek.com/staging/uploads/avatar12.png" style="border-radius:50%; width:20px; height:20px;">
                                                                     </div>
                                                                     <div class="col-md-9 px-0">
                                                                        <input type="text" name="cedit2116" class="form-control" style="font-size:13px;" value="nice">
                                                                     </div>
                                                                     <div class="col-md-3">
                                                                        <button type="submit" id="e_comment2116" class="comon-dv-bn" onclick="javascript:updatecomment2(116);"> Update </button>
                                                                        <button type="button" id="d_comment2116" class="comon-dv-bn" onclick="javascript:comcancel2(116);"> Cancel </button>
                                                                     </div>
                                                                  </div>
                                                               </div>
                                                            </form>
                                                         </div>
                                                      </div>
                                                      <div class="comment-sec-bottom1">
                                                         <ul>
                                                            <li class="d-flex">
                                                               <a class="reply-box" id="show-d2116" onclick="javascript:replyshow2(116);"> 
                                                               <i class="fa fa-reply"></i> Reply 
                                                               </a> 
                                                               <a class="reply-box" id="hide-d2116" onclick="javascript:replyhide2(116);" style="display:none;">
                                                               <i class="fa fa-reply"></i> Reply 
                                                               </a>
                                                               <a href="javascript:comupvote2(116,12)" class="up"> <i class="far fa-thumbs-up"></i><span id="demoox116">
                                                               </span> </a> <a href="javascript:comdownvote2(116,12)" class="up"> <i class="far fa-thumbs-down"></i><span id="demoox2116">
                                                               </span> </a>
                                                               <div class="dropdown detail-dp1">
                                                                  <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-ellipsis-h"></i> </a>
                                                                  <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton"> 
                                                                     <a class="dropdown-item" href="javascript:editcomment2(116);"> Edit </a> 
                                                                     <a class="dropdown-item" href="javascript:removecomment2(116);"> Delete </a>
                                                                  </div>
                                                               </div>
                                                            </li>
                                                         </ul>
                                                      </div>
                                                      <form name="frmreply116" action="http://fixergeek.com/staging/problems/submitreply/20/12" method="post">
                                                         <input type="hidden" name="comment_id" value="116">
                                                         <div class="chat-sec-1" id="chat-d2116" style="display:none;">
                                                            <div class="comment-area2">
                                                               <div class="form-group">
                                                                  <textarea name="reply116" class="form-control" style="font-size:13px;" required=""></textarea>
                                                               </div>
                                                               <button type="button" class="rely-dv-bn" id="hide-d2116" onclick="javascript:insertcomment2(116,20,12)">Reply</button>
                                                            </div>
                                                            <hr>
                                                         </div>
                                                      </form>
                                                      <div class="comment-show-top-new">
                                                         <figure>
                                                            <img src="http://fixergeek.com/staging/uploads/avatar5.png" alt="user" style="border-radius:50%; width:30px; height:30px;">
                                                         </figure>
                                                         <figcaption> Geek321 Replied on October 30, 2020 </figcaption>
                                                      </div>
                                                      <p style="padding-left:10px; line-height:20px;" id="rep266">
                                                         zxczx                                      
                                                      </p>
                                                      <div class="chat-sec-1" id="rep-d266" style="display:none;">
                                                         <form name="frmedit" action="http://fixergeek.com/staging/problems/editreply/66" method="post">
                                                            <input type="hidden" name="ques_id" value="20">
                                                            <div class="comment-area2">
                                                               <div class="form-group">
                                                                  <input type="text" name="redit66" class="form-control" style="font-size:13px;" value="zxczx" required="">
                                                               </div>
                                                               <button type="submit" class="rely-dv-bn" id="hide-d66">Update</button>
                                                               <button type="button" class="rely-dv-bn" onclick="javascript:reveditreply2(66);">Cancel</button>
                                                            </div>
                                                         </form>
                                                         <hr>
                                                      </div>
                                                      <div class="comment-sec-bottom1">
                                                         <ul>
                                                            <li class="d-flex"> 
                                                               <a class="reply-box" id="show-d2_166" onclick="javascript:replyshow2_1(66);"> 
                                                               <i class="fa fa-reply"></i> Reply </a> 
                                                               <a class="reply-box" id="hide-d2_166" onclick="javascript:replyhide2_1(66);" style="display:none;">
                                                               <i class="fa fa-reply"></i> Reply </a> <a href="javascript:replyupvote2_1(66)" class="up"> 
                                                               <i class="far fa-thumbs-up"></i><span id="demooxr66">
                                                               </span> </a> 
                                                               <a href="javascript:replydownvote2_1(66)" class="up"> <i class="far fa-thumbs-down"></i><span id="demoox2r66">
                                                               </span> </a>
                                                            </li>
                                                         </ul>
                                                      </div>
                                                      <form name="frmreply66" action="http://fixergeek.com/staging/problems/submitreply/20/12" method="post">
                                                         <input type="hidden" name="comment_id" value="116">
                                                         <div class="chat-sec-1" id="chat-d2_166" style="display:none;">
                                                            <div class="comment-area2">
                                                               <div class="form-group">
                                                                  <textarea name="reply116" class="form-control" style="font-size:13px;" required=""></textarea>
                                                               </div>
                                                               <button type="submit" class="rely-dv-bn" id="hide-d266">Reply</button>
                                                            </div>
                                                            <hr>
                                                         </div>
                                                      </form>
                                                      <hr>
                                                   </div>
                                                </div>
                                                <div id="reldet2"></div>
                                             </div>
                                          </div>
                                          <a class="comon-more-bn1" id="moreless-button-new3_94" onclick="javascript:readmore2(94)">Read more</a> 
                                          <a class="comon-more-bn1" id="moreless-button-new3c_94" onclick="javascript:readless2(94)" style="display:none;">Read less</a> 
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!--------------- End -------------------> 
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>