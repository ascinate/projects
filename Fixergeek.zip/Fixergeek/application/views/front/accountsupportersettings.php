<?php 
error_reporting(0);
if($this->session->userdata('id')=="")
{
   redirect('/');
}

$user_qry=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();

$fixer=$this->db->get_where('fixergeek_master',array('user_id'=>$this->session->userdata('id')))->row();

$day = array_map('trim',explode(",", $user_qry->available_days));


?>
<section class="total-bd-area">
  <input type="hidden" id="u_id" value="<?=$this->session->userdata('id')?>">
  <div class="container-fluid">
    <div class="row">
       <div class="new-add-sec">
          <div class="col-md-3 col-lg-3 pr-md-0">
            <div class="left-slidber-area">
              <div class="host-section-left-list">
                <?php $this->load->view('inc/left-navigation-supporters');?>
              </div>
            </div>
          </div>
          <div class="col-md-9 col-lg-9">
            <div class="bod-area">
              <div class="text-part-sec home-inside-d1">
                <div class="supporter-settings-wrap">
                  <div class="row mb-3">
                    <div class="col-md-12">
                      <div class="supporter-box-1">
                        <p class="mb-3">
                        You are currently a Fixer Geek. You can earn money by helping other geeks on Fixer Geek.com. Being a Fixer Geek you can provide services as a:
                        </p>
                        <div class="supporter-page-list-1">
                          <ul>
                            <li class="pb-1"><i class="fa fa-check" aria-hidden="true"></i> <b>Fixer (Level 3) </b> - Remote Access Assistance</li>
                            <li class="pb-1"><i class="fa fa-check" aria-hidden="true"></i> <b>Helper (Level 2) </b> - Screen Sharing & Voice Chat</li>
                            <li class="pb-1"><i class="fa fa-check" aria-hidden="true"></i> <b>Chatter (Level 1) </b> - Text Chat Support</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="supporter-settings-form-box">
                        <h6 class="mb-1"><b>Your Availability:</b></h6>
                        <p>Being a Fixer Geek, you MUST choose your availability time so that other geeks can find out when you get Online to give your services. This time will be displayed on Fixer Geek.com</p>
                        <form>
                          <div class="row form-group mt-3 mb-3">
                            <div class="col mr-2 d-flex pr-0">
                              <label class="w-75">Choose Time</label>
                              <!--<input class="form-control spl-drop-time12" id="start_time" type="time" name="start_time" title="Start Time" value="<?=$user_qry->start_time?>">-->
    
                                <select class="form-control" name="start_time" id="start_time">
                                  <option>Start time</option>
                                  <option value="12:00 AM"<?php if($fixer->start_time=='12:00 AM') { echo 'selected';}?>>12:00 AM</option>
                                  <option value="12:30 AM"<?php if($fixer->start_time=="12:30 AM") { echo 'selected';}?>>12:30 AM</option>
                                  <option value="1:00 AM"<?php if($fixer->start_time=='1:00 AM') { echo 'selected';}?>>1:00 AM</option>
                                  <option value="1:30 AM"<?php if($fixer->start_time=='1:30 AM') { echo 'selected';}?>>1:30 AM</option>
                                  <option value="2:00 AM"<?php if($fixer->start_time=='2:00 AM') { echo 'selected';}?>>2:00 AM</option>
                                  <option value="2:30 AM"<?php if($fixer->start_time=='2:30 AM') { echo 'selected';}?>>2:30 AM</option>
                                  <option value="3:00 AM"<?php if($fixer->start_time=='3:00 AM') { echo 'selected';}?>>3:00 AM</option>
                                  <option value="3:30 AM"<?php if($fixer->start_time=='3:30 AM') { echo 'selected';}?>>3:30 AM</option>
                                  <option value="4:00 AM"<?php if($fixer->start_time=='4:00 AM') { echo 'selected';}?>>4:00 AM</option>
                                  <option value="4:30 AM"<?php if($fixer->start_time=='4:30 AM') { echo 'selected';}?>>4:30 AM</option>
                                  <option value="5:00 AM"<?php if($fixer->start_time=='5:00 AM') { echo 'selected';}?>>5:00 AM</option>
                                  <option value="5:30 AM"<?php if($fixer->start_time=='5:30 AM') { echo 'selected';}?>>5:30 AM</option>
                                  <option value="6:00 AM"<?php if($fixer->start_time=='6:00 AM') { echo 'selected';}?>>6:00 AM</option>
                                  <option value="6:30 AM"<?php if($fixer->start_time=='6:30 AM') { echo 'selected';}?>>6:30 AM</option>
                                  <option value="7:00 AM"<?php if($fixer->start_time=='7:00 AM') { echo 'selected';}?>>7:00 AM</option>
                                  <option value="7:30 AM"<?php if($fixer->start_time=='7:30 AM') { echo 'selected';}?>>7:30 AM</option>
                                  <option value="8:00 AM"<?php if($fixer->start_time=='8:00 AM') { echo 'selected';}?>>8:00 AM</option>
                                  <option value="8:30 AM"<?php if($fixer->start_time=='8:30 AM') { echo 'selected';}?>>8:30 AM</option>
                                  <option value="9:00 AM"<?php if($fixer->start_time=='9:00 AM') { echo 'selected';}?>>9:00 AM</option>
                                  <option value="9:30 AM"<?php if($fixer->start_time=='9:30 AM') { echo 'selected';}?>>9:30 AM</option>
                                  <option value="10:00 AM"<?php if($fixer->start_time=='10:00 AM') { echo 'selected';}?>>10:00 AM</option>
                                  <option value="10:30 AM"<?php if($fixer->start_time=='10:30 AM') { echo 'selected';}?>>10:30 AM</option>
                                  <option value="11:00 AM"<?php if($fixer->start_time=='11:00 AM') { echo 'selected';}?>>11:00 AM</option>
                                  <option value="11:30 AM"<?php if($fixer->start_time=='11:30 AM') { echo 'selected';}?>>11:30 AM</option>
                                  <option value="12:00 PM"<?php if($fixer->start_time=='12:00 PM') { echo 'selected';}?>>12:00 PM</option>
                                  <option value="12:30 PM"<?php if($fixer->start_time=='12:30 PM') { echo 'selected';}?>>12:30 PM</option>
                                  <option value="1:00 PM"<?php if($fixer->start_time=='1:00 PM') { echo 'selected';}?>>1:00 PM</option>
                                  <option value="1:30 PM"<?php if($fixer->start_time=='1:30 PM') { echo 'selected';}?>>1:30 PM</option>
                                  <option value="2:00 PM"<?php if($fixer->start_time=='2:00 PM') { echo 'selected';}?>>2:00 PM</option>
                                  <option value="2:30 PM"<?php if($fixer->start_time=='2:30 PM') { echo 'selected';}?>>2:30 PM</option>
                                  <option value="3:00 PM"<?php if($fixer->start_time=='3:00 PM') { echo 'selected';}?>>3:00 PM</option>
                                  <option value="3:30 PM"<?php if($fixer->start_time=='3:30 PM') { echo 'selected';}?>>3:30 PM</option>
                                  <option value="4:00 PM"<?php if($fixer->start_time=='4:00 PM') { echo 'selected';}?>>4:00 PM</option>
                                  <option value="4:30 PM"<?php if($fixer->start_time=='4:30 PM') { echo 'selected';}?>>4:30 PM</option>
                                  <option value="5:00 PM"<?php if($fixer->start_time=='5:00 PM') { echo 'selected';}?>>5:00 PM</option>
                                  <option value="5:30 PM"<?php if($fixer->start_time=='5:30 PM') { echo 'selected';}?>>5:30 PM</option>
                                  <option value="6:00 PM"<?php if($fixer->start_time=='6:00 PM') { echo 'selected';}?>>6:00 PM</option>
                                  <option value="6:30 PM"<?php if($fixer->start_time=='6:30 PM') { echo 'selected';}?>>6:30 PM</option>
                                  <option value="7:00 PM"<?php if($fixer->start_time=='7:00 PM') { echo 'selected';}?>>7:00 PM</option>
                                  <option value="7:30 PM"<?php if($fixer->start_time=='7:30 PM') { echo 'selected';}?>>7:30 PM</option>
                                  <option value="8:00 PM"<?php if($fixer->start_time=='8:00 PM') { echo 'selected';}?>>8:00 PM</option>
                                  <option value="8:30 PM"<?php if($fixer->start_time=='8:30 PM') { echo 'selected';}?>>8:30 PM</option>
                                  <option value="9:00 PM"<?php if($fixer->start_time=='9:00 PM') { echo 'selected';}?>>9:00 PM</option>
                                  <option value="9:30 PM"<?php if($fixer->start_time=='9:30 PM') { echo 'selected';}?>>9:30 PM</option>
                                  <option value="10:00 PM"<?php if($fixer->start_time=='10:00 PM') { echo 'selected';}?>>10:00 PM</option>
                                  <option value="10:30 PM"<?php if($fixer->start_time=='10:30 PM') { echo 'selected';}?>>10:30 PM</option>
                                  <option value="11:00 PM"<?php if($fixer->start_time=='11:00 PM') { echo 'selected';}?>>11:00 PM</option>
                                  <option value="11:30 PM"<?php if($fixer->start_time=='11:30 PM') { echo 'selected';}?>>11:30 PM</option>
                                </select>
    
                            </div>
                            <div class="col-md-2 pl-0">
    
                               <select class="form-control" name="end_time" id="end_time">
                                  <option>End time</option>
                                  <option value="12:00 AM"<?php if($fixer->end_time=='12:00 AM') { echo 'selected';}?>>12:00 AM</option>
                                  <option value="12:30 AM"<?php if($fixer->end_time=='12:30 AM') { echo 'selected';}?>>12:30 AM</option>
                                  <option value="1:00 AM"<?php if($fixer->end_time=='1:00 AM') { echo 'selected';}?>>1:00 AM</option>
                                  <option value="1:30 AM"<?php if($fixer->end_time=='1:30 AM') { echo 'selected';}?>>1:30 AM</option>
                                  <option value="2:00 AM"<?php if($fixer->end_time=='2:00 AM') { echo 'selected';}?>>2:00 AM</option>
                                  <option value="2:30 AM"<?php if($fixer->end_time=='2:30 AM') { echo 'selected';}?>>2:30 AM</option>
                                  <option value="3:00 AM"<?php if($fixer->end_time=='3:00 AM') { echo 'selected';}?>>3:00 AM</option>
                                  <option value="3:30 AM"<?php if($fixer->end_time=='3:30 AM') { echo 'selected';}?>>3:30 AM</option>
                                  <option value="4:00 AM"<?php if($fixer->end_time=='4:00 AM') { echo 'selected';}?>>4:00 AM</option>
                                  <option value="4:30 AM"<?php if($fixer->end_time=='4:30 AM') { echo 'selected';}?>>4:30 AM</option>
                                  <option value="5:00 AM"<?php if($fixer->end_time=='5:00 AM') { echo 'selected';}?>>5:00 AM</option>
                                  <option value="5:30 AM"<?php if($fixer->end_time=='5:30 AM') { echo 'selected';}?>>5:30 AM</option>
                                  <option value="6:00 AM"<?php if($fixer->end_time=='6:00 AM') { echo 'selected';}?>>6:00 AM</option>
                                  <option value="6:30 AM"<?php if($fixer->end_time=='6:30 AM') { echo 'selected';}?>>6:30 AM</option>
                                  <option value="7:00 AM"<?php if($fixer->end_time=='7:00 AM') { echo 'selected';}?>>7:00 AM</option>
                                  <option value="7:30 AM"<?php if($fixer->end_time=='7:30 AM') { echo 'selected';}?>>7:30 AM</option>
                                  <option value="8:00 AM"<?php if($fixer->end_time=='8:00 AM') { echo 'selected';}?>>8:00 AM</option>
                                  <option value="8:30 AM"<?php if($fixer->end_time=='8:30 AM') { echo 'selected';}?>>8:30 AM</option>
                                  <option value="9:00 AM"<?php if($fixer->end_time=='9:00 AM') { echo 'selected';}?>>9:00 AM</option>
                                  <option value="9:30 AM"<?php if($fixer->end_time=='9:30 AM') { echo 'selected';}?>>9:30 AM</option>
                                  <option value="10:00 AM"<?php if($fixer->end_time=='10:00 AM') { echo 'selected';}?>>10:00 AM</option>
                                  <option value="10:30 AM"<?php if($fixer->end_time=='10:30 AM') { echo 'selected';}?>>10:30 AM</option>
                                  <option value="11:00 AM"<?php if($fixer->end_time=='11:00 AM') { echo 'selected';}?>>11:00 AM</option>
                                  <option value="11:30 AM"<?php if($fixer->end_time=='11:30 AM') { echo 'selected';}?>>11:30 AM</option>
                                  <option value="12:00 PM"<?php if($fixer->end_time=='12:00 PM') { echo 'selected';}?>>12:00 PM</option>
                                  <option value="12:30 PM"<?php if($fixer->end_time=='12:30 PM') { echo 'selected';}?>>12:30 PM</option>
                                  <option value="1:00 PM"<?php if($fixer->end_time=='1:00 PM') { echo 'selected';}?>>1:00 PM</option>
                                  <option value="1:30 PM"<?php if($fixer->end_time=='1:30 PM') { echo 'selected';}?>>1:30 PM</option>
                                  <option value="2:00 PM"<?php if($fixer->end_time=='2:00 PM') { echo 'selected';}?>>2:00 PM</option>
                                  <option value="2:30 PM"<?php if($fixer->end_time=='2:30 PM') { echo 'selected';}?>>2:30 PM</option>
                                  <option value="3:00 PM"<?php if($fixer->end_time=='3:00 PM') { echo 'selected';}?>>3:00 PM</option>
                                  <option value="3:30 PM"<?php if($fixer->end_time=='3:30 PM') { echo 'selected';}?>>3:30 PM</option>
                                  <option value="4:00 PM"<?php if($fixer->end_time=='4:00 PM') { echo 'selected';}?>>4:00 PM</option>
                                  <option value="4:30 PM"<?php if($fixer->end_time=='4:30 PM') { echo 'selected';}?>>4:30 PM</option>
                                  <option value="5:00 PM"<?php if($fixer->end_time=='5:00 PM') { echo 'selected';}?>>5:00 PM</option>
                                  <option value="5:30 PM"<?php if($fixer->end_time=='5:30 PM') { echo 'selected';}?>>5:30 PM</option>
                                  <option value="6:00 PM"<?php if($fixer->end_time=='6:00 PM') { echo 'selected';}?>>6:00 PM</option>
                                  <option value="6:30 PM"<?php if($fixer->end_time=='6:30 PM') { echo 'selected';}?>>6:30 PM</option>
                                  <option value="7:00 PM"<?php if($fixer->end_time=='7:00 PM') { echo 'selected';}?>>7:00 PM</option>
                                  <option value="7:30 PM"<?php if($fixer->end_time=='7:30 PM') { echo 'selected';}?>>7:30 PM</option>
                                  <option value="8:00 PM"<?php if($fixer->end_time=='8:00 PM') { echo 'selected';}?>>8:00 PM</option>
                                  <option value="8:30 PM"<?php if($fixer->end_time=='8:30 PM') { echo 'selected';}?>>8:30 PM</option>
                                  <option value="9:00 PM"<?php if($fixer->end_time=='9:00 PM') { echo 'selected';}?>>9:00 PM</option>
                                  <option value="9:30 PM"<?php if($fixer->end_time=='9:30 PM') { echo 'selected';}?>>9:30 PM</option>
                                  <option value="10:00 PM"<?php if($fixer->end_time=='10:00 PM') { echo 'selected';}?>>10:00 PM</option>
                                  <option value="10:30 PM"<?php if($fixer->end_time=='10:30 PM') { echo 'selected';}?>>10:30 PM</option>
                                  <option value="11:00 PM"<?php if($fixer->end_time=='11:00 PM') { echo 'selected';}?>>11:00 PM</option>
                                  <option value="11:30 PM"<?php if($fixer->end_time=='11:30 PM') { echo 'selected';}?>>11:30 PM</option>
                                </select>
                            </div>
                            <div class="col-md-7 pl-0 ml-auto supporter-spl-dropdown">
                              <div class="dropdown-spl">
                                <div class="select sa-select"> 
                                <span id="dval">
                                          <?php 
                                            if($user_qry->available_days=="") { echo "Choose Days"; } 
                                            else { //echo $day[0].",".$day[1].",".$day[2].",".$day[3].",".$day[4].",".$day[5].",".$day[6];
                                                echo $user_qry->available_days;
                                               }
                                          ?>
                                </span> 
                                </div>
                                <input type="hidden" id="days" value="<?=$user_qry->available_days?>">
                                <ul class="dropdown-menu-spl">
                                  <li>
                                    <div class="form-check">
                                      <input type="radio" name="click" class="form-check-input sa" id="Alldays"<?php foreach($day as $val){if($val=="Monday" && $val=="Tuesday" && $val=="Wednesday" && $val=="Thursday" && $val=="Friday" && $val=="Saturday" && $val=="Sunday" ){echo "checked";}}?>>
                                      <label class="form-check-label" for="exampleCheck1">All Days</label>
                                    </div>
                                  </li>
                                  <hr>
                                  <li>
                                    <div class="form-check">
                                      <input type="radio" name="click" class="form-check-input sa" id="Weekdays"<?php foreach($day as $val){if($val=="Monday" && $val=="Tuesday" && $val=="Wednesday" && $val=="Thursday" && $val=="Friday" ){echo "checked";}}?>>
                                      <label class="form-check-label" for="exampleCheck1">Weekdays</label>
                                    </div>
                                  </li>
                                  <li>
                                    <div class="form-check">
                                      <input type="radio" name="click" class="form-check-input sa" id="Weekends"<?php foreach($day as $val){if($val=="Saturday" && $val=="Sunday" ){echo"checked";}}?>>
                                      <label class="form-check-label" for="exampleCheck1">Weekends</label>
                                    </div>
                                  </li>
                                  <hr>
                                  <li>
                                    <div class="form-check">
                                      <input type="checkbox" name="days[]" class="form-check-input days" value="Monday" 
                                      id="Monday"<?php if(in_array("Monday", $day)) { echo "checked"; }?>>
                                      <label class="form-check-label" for="exampleCheck1">Monday</label>
                                    </div>
                                  </li>
                                  <li>
                                    <div class="form-check">
                                      <input type="checkbox" name="days[]" class="form-check-input days" value="Tuesday" 
                                      id="Tuesday"<?php if(in_array("Tuesday", $day)) { echo "checked"; }?>>
                                      <label class="form-check-label" for="exampleCheck1">Tuesday</label>
                                    </div>
                                  </li>
                                  <li>
                                    <div class="form-check">
                                      <input type="checkbox" name="days[]" class="form-check-input days" value="Wednesday" 
                                      id="Wednesday"<?php if(in_array("Wednesday", $day)) { echo "checked"; }?>>
                                      <label class="form-check-label" for="exampleCheck1">Wednesday</label>
                                    </div>
                                  </li>
                                  <li>
                                    <div class="form-check">
                                      <input type="checkbox" name="days[]" class="form-check-input days" value="Thursday" 
                                      id="Thursday"<?php if(in_array("Thursday", $day)) { echo "checked"; }?>>
                                      <label class="form-check-label" for="exampleCheck1">Thursday</label>
                                    </div>
                                  </li>
                                  <li>
                                    <div class="form-check">
                                      <input type="checkbox" name="days[]" class="form-check-input days" value="Friday" 
                                      id="Friday"<?php if(in_array("Friday", $day)) { echo "checked"; }?>>
                                      <label class="form-check-label" for="exampleCheck1">Friday</label>
                                    </div>
                                  </li>
                                  <li>
                                    <div class="form-check">
                                      <input type="checkbox" name="days[]" class="form-check-input days" value="Saturday"
                                       id="Saturday"<?php if(in_array("Saturday", $day)) { echo "checked"; }?>>
    
                                      <label class="form-check-label" for="exampleCheck1">Saturday</label>
                                    </div>
                                  </li>
                                  <li>
                                    <div class="form-check">
                                      <input type="checkbox" name="days[]" class="form-check-input days" value="Sunday" 
                                      id="Sunday"<?php if(in_array("Sunday", $day)) { echo "checked"; }?>>
                                      <label class="form-check-label" for="exampleCheck1">Sunday</label>
                                    </div>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                          
                          <div class="row form-group mb-3">
                            <div class="col-md-2 my-auto pr-0">
                              <label for="exampleFormControlSelect100">Your Timezone</label>
                            </div>
                            <div class="col-md-4 pl-0 new-time">
    
                               <select class="form-control" name="timezone" id="timezone">
                                  <option>Choose Your Timezone</option>
                                  <option value="UTC-12:00"<?php if($user_qry->timezone=="UTC-12:00"){echo "selected";}?>>UTC-12:00</option>
                                  <option value="UTC-11:00"<?php if($user_qry->timezone=="UTC-11:00"){echo "selected";}?>>UTC-11:00</option>
                                  <option value="UTC-10:00"<?php if($user_qry->timezone=="UTC-10:00"){echo "selected";}?>>UTC-10:00</option>
                                  <option value="UTC-9:00"<?php if($user_qry->timezone=="UTC-9:00"){echo "selected";}?>>UTC-9:00</option>
                                  <option value="UTC-8:00"<?php if($user_qry->timezone=="UTC-8:00"){echo "selected";}?>>UTC-8:00</option>
                                  <option value="UTC-7:00"<?php if($user_qry->timezone=="UTC-7:00"){echo "selected";}?>>UTC-7:00</option>
                                  <option value="UTC-6:00"<?php if($user_qry->timezone=="UTC-6:00"){echo "selected";}?>>UTC-6:00</option>
                                  <option value="UTC-5:00"<?php if($user_qry->timezone=="UTC-5:00"){echo "selected";}?>>UTC-5:00</option>
                                  <option value="UTC-4:00"<?php if($user_qry->timezone=="UTC-4:00"){echo "selected";}?>>UTC-4:00</option>
                                  <option value="UTC-3:00"<?php if($user_qry->timezone=="UTC-3:00"){echo "selected";}?>>UTC-3:00</option>
                                  <option value="UTC-2:00"<?php if($user_qry->timezone=="UTC-2:00"){echo "selected";}?>>UTC-2:00</option>
                                  <option value="UTC-1:00"<?php if($user_qry->timezone=="UTC-1:00"){echo "selected";}?>>UTC-1:00</option>
                                  <option value="UTC+0:00"<?php if($user_qry->timezone=="UTC+0:00"){echo "selected";}?>>UTC+0:00</option>
                                  <option value="UTC+1:00"<?php if($user_qry->timezone=="UTC+1:00"){echo "selected";}?>>UTC+1:00</option>
                                  <option value="UTC+2:00"<?php if($user_qry->timezone=="UTC+2:00"){echo "selected";}?>>UTC+2:00</option>
                                  <option value="UTC+3:00"<?php if($user_qry->timezone=="UTC+3:00"){echo "selected";}?>>UTC+3:00</option>
                                  <option value="UTC+3:30"<?php if($user_qry->timezone=="UTC+3:30"){echo "selected";}?>>UTC+3:30</option>
                                  <option value="UTC+4:00"<?php if($user_qry->timezone=="UTC+4:00"){echo "selected";}?>>UTC+4:00</option>
                                  <option value="UTC+4:30"<?php if($user_qry->timezone=="UTC+4:30"){echo "selected";}?>>UTC+4:30</option>
                                  <option value="UTC+5:00"<?php if($user_qry->timezone=="UTC+5:00"){echo "selected";}?>>UTC+5:00</option>
                                  <option value="UTC+5:30"<?php if($user_qry->timezone=="UTC+5:30"){echo "selected";}?>>UTC+5:30</option>
                                  <option value="UTC+5:45"<?php if($user_qry->timezone=="UTC+5:45"){echo "selected";}?>>UTC+5:45</option>
                                  <option value="UTC+6:00"<?php if($user_qry->timezone=="UTC+6:00"){echo "selected";}?>>UTC+6:00</option>
                                  <option value="UTC+6:30"<?php if($user_qry->timezone=="UTC+6:30"){echo "selected";}?>>UTC+6:30</option>
                                  <option value="UTC+7:00"<?php if($user_qry->timezone=="UTC+7:00"){echo "selected";}?>>UTC+7:00</option>
                                  <option value="UTC+8:00"<?php if($user_qry->timezone=="UTC+8:00"){echo "selected";}?>>UTC+8:00</option>
                                  <option value="UTC+8:45"<?php if($user_qry->timezone=="UTC+8:45"){echo "selected";}?>>UTC+8:45</option>
                                  <option value="UTC+9:00"<?php if($user_qry->timezone=="UTC+9:00"){echo "selected";}?>>UTC+9:00</option>
                                  <option value="UTC+9:30"<?php if($user_qry->timezone=="UTC+9:30"){echo "selected";}?>>UTC+9:30</option>
                                  <option value="UTC+10:00"<?php if($user_qry->timezone=="UTC+10:00"){echo "selected";}?>>UTC+10:00</option>
                                  <option value="UTC+10:30"<?php if($user_qry->timezone=="UTC+10:30"){echo "selected";}?>>UTC+10:30</option>
                                  <option value="UTC+11:00"<?php if($user_qry->timezone=="UTC+11:00"){echo "selected";}?>>UTC+11:00</option>
                                  <option value="UTC+12:00"<?php if($user_qry->timezone=="UTC+12:00"){echo "selected";}?>>UTC+12:00</option>
                                  <option value="UTC+12:45"<?php if($user_qry->timezone=="UTC+12:45"){echo "selected";}?>>UTC+12:45</option>
                                  <option value="UTC+13:00"<?php if($user_qry->timezone=="UTC+13:00"){echo "selected";}?>>UTC+13:00</option>
                                  <option value="UTC+14:00"<?php if($user_qry->timezone=="UTC+14:00"){echo "selected";}?>>UTC+14:00</option>
                              </select>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="row mt-3 mb-4">
                    <div class="col-md-12">
                      <div class="supporter-box-2">
                        <h6 class="mb-1"><b>Your Fixer Geeks Categories:</b></h6>
                        <p class="mb-2">You are qualified as a Fixer Geeks in the categories below.</p>
                        <div class="supporter-page-list-2 new-ul-d2">
                          <ul>
                            <!--<li class="pb-1">
                            <i class="fa fa-check" aria-hidden="true"></i> 
                            <b>Viruses & Malware </b> (Viruses, Spyware, Ransomeware, Rootkit, Phishing, Spam, Key Logging, Firewall)
                            </li>-->
                            <?php
                              $expert = explode(",",$fixer->sub_sub_cat_id);
                              foreach($expert as $val)
                              {
							   $item = $this->db->get_where('sub_sub_category_master',array('id'=>$val))->row();
							?>
                            <li class="pb-1"><?=$item->sub_sub_category_name?></li>
                            <?php
							  }
                            ?>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <!--<div class="row mb-4">
                    <div class="col-md-12">
                      <div class="supporter-box-3">
                        <h6 class="mb-1"><b>Categories that you can qualify:</b></h6>
                        <p class="mb-2">In the following categories, you can qualify to become a Fixer Geek as soon as you give 3 answers/fixes for each based on our guidelines.</p>
                        <div class="supporter-page-list-3">
                          <ul>
                            <li class="pb-1"><b>Memory (RAM) Issues </b> (2 qualified answers/fixes so far!)</li>
                            <li class="pb-1"><b>Gaming </b> (1 qualified answer/fix so far!)</li>
                          </ul>
                          <p class="mt-2 mb-2">If you want to add more categories in your profile as a Fixer Geek, reply as many problems as you can in desired category. Following are our guidelines:</p>
                        </div>
                      </div>
                    </div>
                  </div>-->
                  
                  <div class="row">
                    <div class="col-md-12">
                      <div class="supporter-box-4">
                        <h6 class="mb-3"><b>How to become a Fixer Geek?</b></h6>
                        <div class="supporter-page-list-4 pt-1">
                          <ul>
                            <li class="pb-1">1. You MUST Answer/Fix at least <span>1 Problems</span> in the category you want to become a Fixer Geek.</li>
                            <li class="pb-1">2. You MUST be <span>Technically Accurate</span> providing complete solution to the problem.</li>
                            <li class="pb-1">3. You MUST show <span>good use of Language</span>.</li>
                            <li class="pb-1">4. You MUST write <span>at least 250-500 words</span> in your reply to the problem.</li>
                            <li class="pb-1">5. You MUST write <span>a unique reply, plagarism will disqualify you</span>.</li>
                            <li class="pb-1">6. You MAY <span>use images and videos</span> to support your answer/fix.</li>
                            <li class="pb-1">7. You MAY <span>use headings and steps</span> in your write up.</li>
                          </ul>
                        </div>
                        <p class="pt-3">We review all answers/fixes to determine whether we qualify them or not on the points above.</p>
                        <p class="pt-2">Here are a few good examples of qualified fixes given by some of our Fixer Geeks.</p>
                        <div class="supporter-page-list-5 pt-3">
                          <ul>
                            <li class="pb-1"><a href="#">How do I install animated Wallpaper in Windows?</a></li>
                            <li class="pb-1"><a href="#">How do I play Neo Geo on RetroArch Emulator for Windows?</a></li>
                            <li class="pb-1"><a href="#">How do I Speed up my PC to play graphic intensive games?</a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
       </div>
      
      
      
      <div class="sd1 new-spc new-special-home"> 
         <div class="new-right-sec-add-howit">
             <h3> How it works </h3>
             <a data-toggle="modal" data-target="#exampleModal-vieo">
                <img src="<?php echo base_url();?>assets2/images/imgpsh_fullsize_anim.png" alt="user">
             </a>
          </div>
          <div class="ads-new-1">
            <a href="#">Advertisement</a>
          </div>
      </div>
    </div>
  </div>
</section>
<script type="text/javascript">

    $(document).ready(function(){
        

        $("#start_time").on('change',function(){
            var start_time = $("#start_time").val();
            var id=$("#u_id").val();
            $.ajax({
            url:'<?php echo base_url();?>accountsupportersettings/updatestart_time',
            type:'post',
            data:{id:id,start_time:start_time},
            success:function(data)
            {

              if(data=='success')
              {
               // alert('Data Updated Successfully');
              }
              else
              {
               window.location.href=url;
              }
              
            }
          });
          
   
        });
        /////////////////////////////
          $("#end_time").on('change',function(){
            var end_time = $("#end_time").val();
            var id=$("#u_id").val();
            $.ajax({
            url:'<?php echo base_url();?>accountsupportersettings/updateend_time',
            type:'post',
            data:{id:id,end_time:end_time},
            success:function(data)
            {

              if(data=='success')
              {
               // alert('Data Updated Successfully');
              }
              else
              {
               window.location.href=url;
              }
              
            }
          });
          
   
        });
           /////////////////////////////
          $("#timezone").on('change',function(){
            var timezone = $("#timezone").val();
            // alert("My favourite sports are: " + timezone);
            var id=$("#u_id").val();
            $.ajax({
            url:'<?php echo base_url();?>accountsupportersettings/updatetimezone',
            type:'post',
            data:{id:id,timezone:timezone},
            success:function(data)
            {

              if(data=='success')
              {
               // alert('Data Updated Successfully');
              }
              else
              {
               window.location.href=url;
              }
              
            }
          });
          
   
        });
          /////////////////////////////
     
          $(".sa-select").on('click',function(){
            var days = $("#days").val();
            // alert("My favourite sports are: " + days);
            var id=$("#u_id").val();
      
            $.ajax({
            url:'<?php echo base_url();?>accountsupportersettings/updatedays',
            type:'post',
            data:{id:id,days:days},
            success:function(data)
            {

              if(data=='success')
              {
               // alert('Data Updated Successfully');
              }
              else
              {
               window.location.href=url;
              }
              
            }
          });
        });
    });


$(document).ready(function()
{
		/////////////////////////  Multiple Dropdown ///////////////////

         $('.sa-select').click(function() {
            var favorite = [];
            $.each($("input[name='days[]']:checked"), function(){
            favorite.push($(this).val());
            });
            var days = favorite.join(", ");
            $('#days').val(favorite.join(", "));
            // alert("My favourite sports are: " + days);
            if( $(this).hasClass('active'))
            {
              $(this).removeClass('active');
              $('.dropdown-menu-spl').slideUp();  
            }
			else
            {
              $(this).addClass('active');
              $('.dropdown-menu-spl').slideDown();  
            }
			
			if(days=="")
			{
			  $("#dval").html('Choose Days');
			}
         });
		 
          $('#Alldays').click(function() {
           $('#Monday').prop( "checked", true );
           $('#Tuesday').prop( "checked", true );
           $('#Wednesday').prop( "checked", true );
           $('#Thursday').prop( "checked", true );
           $('#Friday').prop( "checked", true );
           $('#Saturday').prop( "checked", true );
           $('#Sunday').prop( "checked", true );
            var favorite = [];
            $.each($("input[name='days[]']:checked"), function(){
            favorite.push($(this).val());
            });
            var days = favorite.join(", ");
            var day=$('#days').val(days);
			
			$("#dval").html(days);
            // alert("My favourite sports are: " + favorite.join(", "));
          });
		
          $('#Weekdays').click(function() {
           $('#Monday').prop( "checked", true );
           $('#Tuesday').prop( "checked", true );
           $('#Wednesday').prop( "checked", true );
           $('#Thursday').prop( "checked", true );
           $('#Friday').prop( "checked", true );
           $('#Saturday').prop( "checked", false );
           $('#Sunday').prop( "checked", false );
            var favorite = [];
            $.each($("input[name='days[]']:checked"), function(){
            favorite.push($(this).val());
            });
            var days = favorite.join(", ");
            var day=$('#days').val(days);
			$("#dval").html(days);
            // alert("My favourite sports are: " + favorite.join(", "));
           });
		   
           $('#Weekends').click(function() {
           $('#Monday').prop( "checked", false );
           $('#Tuesday').prop( "checked", false );
           $('#Wednesday').prop( "checked", false );
           $('#Thursday').prop( "checked", false );
           $('#Friday').prop( "checked", false );
           $('#Saturday').prop( "checked", true );
           $('#Sunday').prop( "checked", true );
            var favorite = [];
            $.each($("input[name='days[]']:checked"), function(){
            favorite.push($(this).val());

            });
            var days = favorite.join(", ");
            var day=$('#days').val(days);
			
			$("#dval").html(days);
            // alert("My favourite sports are: " + favorite.join(", "));
          });
  
        // $('.dropdown-spl').focusout(function() {
        //     $(this).removeClass('active');
        //     $(this).find('.dropdown-menu-spl').slideUp(300);
        // });
        /*$('.dropdown-spl .dropdown-menu-spl li').click(function() {
            $(this).parents('.dropdown-spl').find('span').text($(this).text());
            $(this).parents('.dropdown-spl').find('input').attr('value', $(this).attr('id'));
        });*/
		
        $('#Monday').click(function() {
	       if($('#Monday').prop("checked") == true)
		   {
                var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		   else
		   {
		       $('#Monday').prop( "checked", false );
			   var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		});
		
		 $('#Tuesday').click(function() {
	       if($('#Tuesday').prop("checked") == true)
		   {
                var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		   else
		   {
		       $('#Tuesday').prop( "checked", false );
			   var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		});
		
		 $('#Wednesday').click(function() {
	       if($('#Wednesday').prop("checked") == true)
		   {
                var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		   else
		   {
		       $('#Wednesday').prop( "checked", false );
			   var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		});
		
		$('#Thursday').click(function() {
	       if($('#Thursday').prop("checked") == true)
		   {
                var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		   
		   else
		   {
		       $('#Thursday').prop( "checked", false );
			   var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		});
		
		$('#Friday').click(function() {
	       if($('#Friday').prop("checked") == true)
		   {
                var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		   
		   else
		   {
		       $('#Friday').prop( "checked", false );
			   var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		});
		
		$('#Saturday').click(function() {
	       if($('#Saturday').prop("checked") == true)
		   {
                var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		   
		   else
		   {
		       $('#Saturday').prop( "checked", false );
			   var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		});
		
		$('#Sunday').click(function() {
	       if($('#Sunday').prop("checked") == true)
		   {
                var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		   
		   else
		   {
		       $('#Sunday').prop( "checked", false );
			   var favorite = [];
				$.each($("input[name='days[]']:checked"), function(){
				favorite.push($(this).val());
	
				});
				var days = favorite.join(", ");
				var day=$('#days').val(days);
				$("#dval").html(days);
		   }
		});
});
</script>