<?php
  $userid = $this->session->userdata('id');
  
  $problems = $this->db->get_where('questions_assign_master', array('assigned_to' => $userid, 'status' => 'pending'));
  $fixes = $this->db->get_where('questions_assign_master', array('assigned_to' => $userid, 'status' => 'completed'));
  $pcnt = $problems->num_rows();
  $fcnt = $fixes->num_rows();
?>
<section class="total-bd-area">
  <div class="container-fluid">
    <div class="row">
      <div class="new-add-sec">
          <div class="col-md-3 col-lg-3">
            <div class="left-slidber-area">
              <div class="host-section-left-list">
                <?php $this->load->view('inc/left-navigation-supporters');?>
              </div>
            </div>
          </div>
          <div class="col-md-9 col-lg-9 pl-0">
            <div class="bod-area">
              <div class="text-part-sec home-inside-d1 p-0">
                <div class="sub-page">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="problems-wrap mb-3">
                        <h6 class="mb-3"><b>Your Problems:</b></h6>
                        <div class="ancor"> 
                        <?php
                           if($pcnt==0) 
                           {
                             echo 'No problems found.';
                           }
                           else
                           {
                             foreach($problems->result() as $res)
                             {
                               $question=$this->db->get_where('questions_master', array('id'=>$res->question_id))->row();
                        ?>
                            <a href="<?php echo base_url();?>details/show/<?=$res->question_id?>" class="mb-1"><?=$question->question?></a> 
                         <?php
                             }
                           }
                         ?>
                        </div>
                      </div>
                      <div class="fixes-wrap mb-3">
                        <div class="ancor">
                          <h6 class="mb-3"><b>Your Fixes:</b></h6>
                          
                          <?php
                           if($fcnt==0) 
                           {
                             echo 'No fixes found.';
                           }
                           else
                           {
                             foreach($fixes->result() as $rs)
                             {
                               $question=$this->db->get_where('questions_master', array('id'=>$rs->question_id))->row();
                          ?>
                            <a href="<?php echo base_url();?>details/show/<?=$rs->question_id?>" class="mb-1"><?=$question->question?></a> 
                         <?php
                             }
                           }
                         ?>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
          
      </div>
      <div class="sd1 new-spc"> <a href="#">Advertisement</a> </div>
    </div>
  </div>
</section>