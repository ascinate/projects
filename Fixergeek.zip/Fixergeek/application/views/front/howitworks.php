<style>
#cms ul { line-height: 35px; }
</style>
<section class="total-bd-area">
  <div class="container-fluid" id="cms">
    <div class="text-part-sec home-inside-d1"> 
		<?php
          $result = $this->db->get_where('cms_master', array('id' => 1))->row();
          echo stripslashes($result->content);
        ?>
    </div>
  </div>
</section>
