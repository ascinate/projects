<?php
  $id = $this->session->userdata('id');
  $assign = $this->db->get_where('questions_assign_master',array('assigned_by'=>$id, 'status'=>'Fixed'));
  $count = $assign->num_rows();
?>
<section class="total-bd-area">
  <div class="container-fluid">
    <div class="row">
       <div class="new-add-sec">
          <div class="col-md-3 col-lg-3 pr-md-0">
            <div class="left-slidber-area">
              <div class="host-section-left-box">
                <div class="host-section-left-list">
                  <?php $this->load->view('inc/left-navigation-supporters');?>
                </div>
              </div>
            </div>
          </div>
          <!--  -->
          <div class="col-md-9 col-lg-9">
            <div class="bod-area">
              <div class="text-part-sec home-inside-d1">
                <div class="ac_set_wrap">
                  <div class="ac_set_wrap_head">
                    <h6><b>Payment</b></h6>
                    <h6 class="mt-3"><b>Report & Finance</b></h6>
                  </div>
                  <div class="ac-set-boxes mt-2">
                    <div class="row">
                      <div class="col-sm-3 mt-3">
                        <div class="weekly">
                          <div class="form-group  mb-0">
                            <select class="form-control act-set-from-control" id="exampleFormControlSelect1">
                              <option>Weekly</option>
                              <option>Monthly</option>
                              <option>Yearly</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-3 mt-3">
                        <div class="calender-2">
                          <input placeholder="From" type="text" name="checkIn" id="datepicker" value="" class="calendar w-100">
                          <i class="fas fa-calendar-alt"></i> </div>
                      </div>
                      <div class="col-sm-3 mt-3">
                        <div class="calender-2">
                          <input placeholder="To" type="text" name="checkIn" id="datepicker1" value="" class="calendar w-100">
                          <i class="fas fa-calendar-alt"></i> </div>
                      </div>
                      <div class="col-sm-3 mt-3">
                        <button class="default-btn">Run Report<br>
                        </button>
                      </div>
                    </div>
                  </div>
                  <!--  -->
                  <div class="ac-set-table mt-4">
                    <table class="table table-account">
                      <thead class="thead-dark">
                        <tr>
                          <th scope="col">Date & Time</th>
                          <th scope="col">User Name</th>
                          <th scope="col">Price</th>
                          <th scope="col">Commission</th>
                          <th scope="col">Revenue</th>
                        </tr>
                      </thead>
                      <tbody>
                      
                      <?php
                        if($count!=0) {
                        foreach($assign->result() as $rec)
                        {
                          $user=$this->db->get_where('user_master',array('id'=>$rec->assigned_by))->row();
                          $revenue = ($rec->price - $rec->commision);
                      ?>
                        <tr>
                          <th scope="row"><?=$rec->assign_date?></th>
                          <td><?=$user->geek_name?></td>
                          <td>$<?=$rec->price?></td>
                          <td>$<?=$rec->commision?></td>
                          <td><?=$revenue?></td>
                        </tr>
                     <?php
                         }
                        }	
                        else
                        {
                     ?>
                        <tr><td colspan="5" align="center">No Records Found!</td></tr>
                     <?php
                        }
                      ?>
                      </tbody>
                    </table>
                  </div>
                  <!--  -->
                  <div class="account-settings-payment mt-4">
                    <h6><b>Choose Method of Payment</b></h6>
                    <p class="mt-2">Choose how would you like to get paid each month for your services at FixerGeek.com</p>
                    <hr class="my-2">
                    <!-- check-box-start -->
                    <div class="form-check my-1 form-check-inline">
                      <input class="form-check-input" type="radio" name="method" id="inlineRadio1" value="option2">
                      <label class="form-check-label form-check-label-1" for="inlineRadio1">Check</label>
                    </div>
                    <div class="form-check my-4 form-check-inline">
                      <input class="form-check-input" type="radio" name="method" id="inlineRadio2" value="option2">
                      <label class="form-check-label form-check-label-1" for="inlineRadio2">Telegraphic Transfer</label>
                    </div>
                    
                    <div id="check-form" class="row mt-4" style="display:none;">
                      <div class="col-sm-9 col-12">
                        <div class="row mx-0">
                          <div class="col-4 form-payment px-0">
                            <p class="pt-2">Full Name</p>
                          </div>
                          <div class="col-8">
                            <div class="form-group">
                              <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                            </div>
                          </div>
                        </div>
                        <!--  -->
                        <div class="row mx-0">
                          <div class="col-4  form-payment px-0">
                            <p class="pt-2">Address</p>
                          </div>
                          <div class="col-8">
                            <div class="form-group">
                              <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                            </div>
                          </div>
                        </div>
                        <!--  -->
                        <div class="row mx-0">
                          <div class="col-4  form-payment px-0">
                            <p class="pt-2">City</p>
                          </div>
                          <div class="col-8">
                            <div class="form-group">
                              <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                            </div>
                          </div>
                        </div>
                        <!--  -->
                        <div class="row mx-0">
                          <div class="col-4  form-payment px-0">
                            <p class="pt-2">Zip Code</p>
                          </div>
                          <div class="col-8">
                            <div class="form-group">
                              <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                            </div>
                          </div>
                        </div>
                        <!--  -->
                        <div class="row mx-0">
                          <div class="col-4  form-payment px-0">
                            <p class="pt-2">State</p>
                          </div>
                          <div class="col-8">
                            <div class="form-group">
                              <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                            </div>
                          </div>
                        </div>
                        <div class="row mx-0">
                          <div class="col-4 form-payment px-0">
                            <p class="pt-2">Country</p>
                          </div>
                          <div class="col-8">
                            <div class="form-group">
                              <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                            </div>
                          </div>
                        </div>
                        
                        <div class="row mx-0">
                          <div class="col-4 form-payment px-0">&nbsp; </div>
                          <div class="col-8">
                            <div class="form-group">
                              <button class="default-btn">Submit</button>
                            </div>
                          </div>
                        </div>
                        
                      </div>
                    </div>
    
                    <div id="telegraphic-form" class="row mt-4" style="display:none;">
                      <div class="col-sm-9 col-12">
                        <div class="row mx-0">
                          <div class="col-4  form-payment px-0">
                            <p class="pt-2">Full Name</p>
                          </div>
                          <div class="col-8">
                            <div class="form-group">
                              <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                            </div>
                          </div>
                        </div>
                        <!--  -->
                        <div class="row mx-0">
                          <div class="col-4  form-payment px-0">
                            <p class="pt-2">Bank Account No.</p>
                          </div>
                          <div class="col-8">
                            <div class="form-group">
                              <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                            </div>
                          </div>
                        </div>
                        <!--  -->
                        <div class="row mx-0">
                          <div class="col-sm-4 col-4  form-payment px-0">
                            <p class="pt-2">Swift Code</p>
                          </div>
                          <div class="col-sm-8 col-8">
                            <div class="form-group">
                              <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                            </div>
                          </div>
                        </div>
                        
                        <div class="row mx-0">
                          <div class="col-4 form-payment px-0">&nbsp; </div>
                          <div class="col-8">
                            <div class="form-group">
                              <button class="default-btn">Submit</button>
                            </div>
                          </div>
                        </div>
                        <!--  -->
                        <!--  -->
                      </div>
                    </div>
                    <!-- 1-radio-option -->
                  </div>
                  <hr>
                  <div class="account-set-billing mt-3">
                    <div class="row">
                      <div class="col-6">
                        <h6><b>Billing</b></h6>
                        <p class="mt-2">Save Credit / Debit Cards</p>
                      </div>
                      <div class="col-6 text-right">
                        <button class="default-btn">Add Card</button>
                      </div>
                    </div>
                    <hr class="my-2">
                    <div class="row justify-content-center mx-0 mt-3">
                      <div class="col-md-12">
                        <div class="row">
                          <div class=" mb-3 col-xl-12 mx-0">
                            <div class="row">
                              <div class="col-4 px-0">
                                <div class="row mx-0">
                                  <div class="col-5 d-sm-block d-none billing-img"> <img src="<?php echo base_url();?>assets2/images/visa_PNG38.png.jpg" alt=""> </div>
                                  <div class="col-7 my-auto visa px-2">
                                    <p>Visa (Default)</p>
                                    <p>**** **** **** 2308</p>
                                  </div>
                                </div>
                              </div>
                              <div class="col-4 my-auto px-0 text-center expires">
                                <p>Expires</p>
                                <p>07/12/2028</p>
                              </div>
                              <div class="col-4 px-0 my-auto text-center expires"> <a href="#">Delete</a> </div>
                            </div>
                          </div>
                          <div class=" mb-3 col-xl-12 mx-0">
                            <div class="row">
                              <div class="col-4 px-0">
                                <div class="row mx-0">
                                  <div class="col-5 d-sm-block d-none billing-img"> <img src="<?php echo base_url();?>assets2/images/mastercard_PNG13.png" alt=""> </div>
                                  <div class="col-7 my-auto visa px-2">
                                    <p>Visa (Default)</p>
                                    <p>**** **** **** 2308</p>
                                  </div>
                                </div>
                              </div>
                              <div class="col-4 my-auto px-0 text-center expires">
                                <p>Expires</p>
                                <p>07/12/2028</p>
                              </div>
                              <div class="col-4 px-0 my-auto text-center expires"> <a href="#">Set Default</a><br>
                                <a href="#">Delete</a> </div>
                            </div>
                          </div>
                          <div class=" mb-3 col-xl-12 mx-0">
                            <div class="row">
                              <div class="col-4 px-0">
                                <div class="row mx-0">
                                  <div class="col-5 d-sm-block d-none billing-img"> <img src="<?php echo base_url();?>assets2/images/mastercard_PNG13.png" alt=""> </div>
                                  <div class="col-7 my-auto visa px-2">
                                    <p>Visa (Default)</p>
                                    <p>**** **** **** 2308</p>
                                  </div>
                                </div>
                              </div>
                              <div class="col-4 my-auto px-0 text-center expires">
                                <p>Expires</p>
                                <p>07/12/2028</p>
                              </div>
                              <div class="col-4 px-0 my-auto text-center expires"> <a href="#">Set Default</a><br>
                                <a href="#">Delete</a> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
          
        </div>
        
       <div class="sd1 new-spc"> <a href="#">Advertisement</a> </div>   
          
    </div>
  </div>
</section>

<script>
$(document).ready(function(){
   $("#inlineRadio1").click(function(){
     $("#check-form").show();
	 $("#telegraphic-form").hide();
   });
   
   $("#inlineRadio2").click(function(){
     $("#telegraphic-form").show();
	 $("#check-form").hide();
   });
});
</script>
