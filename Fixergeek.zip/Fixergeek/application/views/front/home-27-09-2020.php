<?php 
 error_reporting(0);
 // if($this->session->userdata('id')=="")
 // {
 //    redirect('/');
 // }
 $user=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
?>
<section class="total-bd-area">
    <div class="container-fluid">
          <div class="row">
             <div class="new-add-sec">
              <div class="col-md-3 col-lg-3">
                <div class="left-slidber-area">
                   <div class="host-section-left-list">
                         <?php $this->load->view('inc/leftpanel');?>
                     </div>
                </div>
              </div>
              <div class="col-md-9 col-lg-9 pl-0">
                 <div class="bod-area">
                    <div class="text-part-sec2 home-inside-d1 border-0 p-0">
                    <?php 
                     if($this->session->userdata('id')!="")
                     {
                      ?>
                       <div class="host-section-mid-profile-box">
                          <div class="comon-border">
                              <div class="ask-area-middle">
                                 <div class="profile-feed">
                                    <div class="pic-user">
                                      <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" alt="user">
                                    </div>
                                    <p><?=$user->name?></p>
                                 </div>

                                   <?php
                                    $query = $this->db->query("select * from `fixergeek_master` 
                                             where `user_id` = '".$this->session->userdata('id')."'");
                                    $numrow = $query->num_rows();
                                
                                    if($numrow!=0)
                                    {
                                    ?>
                                    <a class="question-hadding text-center mb-3" href="#" data-toggle="modal" data-target="#exampleModal">
                                      What is your question or link?
                                    </a>
                                    <?php
                                     }
                                     else
                                     {
                                    ?>
                                    <a class="question-hadding text-center mb-3" href="#" data-toggle="modal" data-target="#comon-page-Modal">
                                      What is your question or link?
                                    </a> 
                                  <?php
                                   }
                                 ?>
                                   
                              </div>
                          </div>
                        
                        </div>
                        <?php } ?>
                        <!-- START Question -->
                        <?php
                        $this->db->order_by('id','desc');
                        $question_qry=$this->db->get('questions_master')->result();
						$i=1;
						$j=1;
						$k=1;
						
                          foreach ($question_qry as $val) 
                          {  
						  
						    $result_answer =  $this->db->get_where('answers_master',array('question_id'=>$val->id))->row();
							
							$htmlString = file_get_contents($result_answer->answer);
 
							$htmlDom = new DOMDocument;
							 
							$htmlDom->loadHTML($htmlString);
							 
							$imageTags = $htmlDom->getElementsByTagName('img');
							 
							$extractedImages = array();
							
							foreach($imageTags as $imageTag)
							{
							  echo $imgSrc = $imageTag->getAttribute('src');
							}
							
							$user=$this->db->get_where('user_master',array('id'=>$val->user_id))->row();
							$date=date_create($val->post_date);   
							$sub= $this->db->get_where("sub_sub_category_master",array('id'=>$val->sub_sub_cat_id))->row();   
							
							$vt = $this->db->query("select sum(up_vote) as upvot from `question_up_down` where `question_id` = '".$val->id."'")->row();
			                $upv = $vt->upvot;  
							
							$vt2 = $this->db->query("select sum(down_vote) as downvot from `question_up_down` where `question_id` = '".$val->id."'")->row();
			 				$dwv = $vt2->downvot;         
                        ?>
                        <div class="host-section-mid-profile-box">
                          <div class="comon-border">
                            <div class="ask-area-middle">

                                 
                               <div class="post-area">
                                  <div id="Div1">
                                     <div class="card card-body">

                                        <div class="middle-post-area">
                                            <div class="left-sec-post">
                                               <div class="user-pic">
                                                <?php if($val->user_id=="Admin"){?>
                                                  <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user">
                                                <?php }else{?>
                                                  <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" alt="user">
                                                <?php } ?>
                                               </div>
                                               <div class="post-adte">
                                                  <strong><?php if($val->user_id=='Admin'){echo "Administrator";}else{ echo $user->name;}?></strong>, Posted on <?php echo date_format($date,"F j, Y");?> <br> <?=$sub->sub_sub_category_name?>
                                               </div>
                                            </div>
                                            <div class="right-sec-post">

                                            </div>
                                        </div>
                                        <div class="last-post-area">
                                            <div class="left-sec-post">
                                                <div class="post-adte" id="post-adte<?=$i++?>">
                                                  <a href="<?php echo base_url();?>details/show/<?=$val->id?>">
                                                   <h6><?=$val->question;?></h6> 
                                                  </a>
                                                  <div class="read_less" id="read-less<?=$j++?>">
                                                   <p>
                                                   <?php echo substr($result_answer->answer,0,200);?>... 
                                                   <a href="<?php echo base_url();?>details/show/<?=$val->id?>"> 
                                                   <span class="moreless-button" style="cursor: pointer;">(Read more)</span> 
                                                   </a> 
                                                   </p> 
                                                  </div>
                                               </div>
                                              
                                               <div class="user-pic">
                                                  <a href="<?php echo base_url();?>details/show/<?=$val->id?>">
                                                  <img src="<?php echo base_url();?>uploads/<?=$val->uploaded_files?>" alt="user">
                                                </a>
                                               </div>

                                            </div>
                                        </div>
                                        <div class="footer-post-sec">&nbsp;</div>
                                           <a href="javascript:void(0);" class="up" style="cursor:default;"> 
                                           <i class="far fa-thumbs-up"></i><span id="demo<?=$val->id?>"> <?=$upv?> </span>  
                                           </a>
                                           <a href="javascript:void(0);" class="up" style="cursor:default;"> 
                                           <i class="far fa-thumbs-down"></i><span id="demo2<?=$val->id?>"> <?=$dwv?> </span> 
                                           </a>
                                       <hr>
                                   <?php 
									   $this->db->order_by('id','desc');
									   $comment_qry=$this->db->get_where('comment_master',array('question_id'=>$val->id))->result();
									   foreach($comment_qry as $comment)
									   {
										   $date2=date_create($comment->post_date);
										   $us=$this->db->get_where('user_master',array('id'=>$comment->user_id))->row();
                                   ?>
                                   <div class="post-area mt-2 content">
                                      <div class="middle-post-area">
                                          <div class="left-sec-post p-0">
                                             <div class="user-pic">
                                               <?php if($comment->user_id=="Admin"){?>
                                                  <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user">
                                                <?php }else{?>
                                                  <img src="<?php echo base_url();?>uploads/<?=$us->profile_picture?>" alt="user">
                                                <?php } ?>
                                             </div>
                                             <div class="post-adte">
                                                <?php if($comment->user_id=='Admin'){echo"Administrator";}else{
                                                    echo $us->name;
                                                  }?><br>Posted <?php echo date_format($date2,"j F ,Y");?>
                                             </div>
                                          </div>
                                         
                                      </div>
                                      <div class="last-post-area">
                                          <div class="left-sec-post">
                                              <div class="post-adte">
                                                <p><?=$comment->comments;?></p>
                                                
                                                <a class="moreless-button-d1 comon-bn-detials">(More)</a>
                                             </div>
                                          </div>
                                          <div class="footer-post-sec reply-div">
                                        <ul class="right-fot">
                                          <li> <a class="pr-2 pl-1 mx-1 reply-box"> <i class="fa fa-reply"></i>Reply</a> </li>
                                          <li> <a href="#" class="pr-2 pl-1 mx-1"><i class="fa fa-arrow-up"></i>Upvote</a> </li>
                                          <li> <a href="#" id="hide2-new" class="pr-2 pl-1 mx-1"><i class="fa fa-arrow-down"></i>Downvote</a> </li>
                                        </ul>
                                        <!--right-fot-->
                                        <ul class="left-fot">
                                          
                                          <li class="dropdown show share-bn"> 
                                             <a class="btn btn-secondary dropdown-toggle padding-off" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-ellipsis-v"></i> </a> 
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                              <a class="dropdown-item" href="#"> Report </a>
                                            </div>
                                          </li>
                                        </ul><!--left-fot-->                                    
                                        </div><!--footer-post-sec-->
                                          <div class="chat2-new2 mt-2 chat-box-open" style="display: none;">
                                           <div class="comment-area2">
                                <form action="<?php echo base_url()?>details/submitreplyfromhome/<?=$comment->user_id?>/<?=$comment->question_id?>/<?=$comment->id?>" method="post">
                                                   
                                                     <div class="form-group">
                                                        <textarea name="reply<?=$comment->id?>" placeholder="" class="form-control" required></textarea>
                                                     </div>
                                                
                                                 <button type="submit" class="comment-bn" id="hide2-new">Reply </button>
                                              </form>
                                           </div>
                                           <hr>
                                      </div>
                                      </div>                                     
                                   </div>
                                  <?php } ?>
                                   <!--  -->

                                     </div>
                                  </div>
                                  <?php
                                    $user=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row(); 
                                    if($this->session->userdata('id')!='')
                                    {
                                  ?>
                                  <div id="Div2">
                                    <a href="#">
                                       <div class="common-group-bn">
                                         <p> Downvote Answer </p>
                                         <i class="fas fa-angle-right"></i>
                                     </div>
                                    </a>
                                    <a href="#">
                                       <div class="common-group-bn">
                                         <p> Mute Photograph Recommendations </p>
                                         <i class="fas fa-angle-right"></i>
                                     </div>
                                    </a>
                                    <a href="#">
                                       <div class="common-group-bn">
                                         <p> Report </p>
                                         <i class="fas fa-angle-right"></i>
                                     </div>
                                    </a>
                                  </div>
                                <?php } ?>
                               </div>
                            </div>
                          </div>
                        </div>
                       <?php } ?>
                       <!-- END Question -->
                      </div>
                 </div>
              </div>
              
             </div>
             <div class="sd1 new-spc"> <a href="#">Advertisement</a>
                    
             </div>
          </div>
        </div>
 </section>


