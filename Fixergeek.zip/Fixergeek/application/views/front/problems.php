<?php   
    set_time_limit(0);
    $user_qry=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
?>
<section class="total-bd-area res-problem">
  <div class="container-fluid">
    <div class="row">
      <div class="bod-area problems">
        <div class="text-part-sec home-inside-d1 p-0">
          <div class="sub-page">
            <div class="row">
              <div class="col-md-12">
                 <?php 
					$this->db->order_by('id','desc');
					$question_qry=$this->db->get_where('questions_master')->result();
                 ?>
                <div class="problems-wrap mb-3">
                  <h6 class="mb-3 mt-3 ml-3"><b>Latest Questions</b></h6>
                  <hr />
                 <?php
					foreach($question_qry as $val)
					{
					  $sub_sub_cat=$this->db->get_where('sub_sub_category_master',array('id'=>$val->sub_sub_cat_id))->row();
					  $user=$this->db->get_where('user_master',array('id'=>$val->user_id))->row();
					  
					  if($val->user_id=='Admin')
					  {
					    $name = 'Admin';
					  }
					  else
					  {
					    $name = $user->geek_name;
					  }
					  
					  $ans=$this->db->get_where('answers_master',array('question_id'=>$val->id))->num_rows();
					  $date=date_create($val->post_date);
					  
					  if($ans==0)
					  {
				  ?>
                  <div class="quset-comon-sec border-top-0">
                     
                      <!--<a href="#" id="Button1" class="close1"> <i class="fas fa-close"></i></a>--> 
                     <div id="Div1">
                       <div class="ans-sec-1">
                            <h2> <a href="#"><?=$val->question?></a> </h2>
                            <div class="categoy-problem-page">
                              <ul>
                                <li>Category</li>
                                <li> <a href="<?php echo base_url();?>category/show/<?=(str_replace("&","-",str_replace(" ","_",$sub_sub_cat->sub_sub_category_name)))?>"> <?=$sub_sub_cat->sub_sub_category_name;?> </a> </li>
                              </ul>
                            </div>
                             <h5>
                             <span> Posted </span> by <?=$name?> <span>on <?php echo date_format($date,"j F, Y");?> </span> </h5>
                            <div class="bottom-div">
                              <?php
                              //if($this->session->userdata('id')!='')
                              //{ 
                              ?>
                              <a href="#">
							  <?php if($ans!=0){echo $ans." Answer";}else{echo"No answer yet";}?></a>.
                               <a href="javascript: answer(<?=$val->id?>);" class="show-one problem-ans-bn default-btn" id="show-one<?=$val->id?>"> 
                                 <i class="far fa-edit"></i> Answer 
                               </a>
                               <a href="javascript: answerclose(<?=$val->id?>);" class="show-one problem-ans-bn default-btn" 
                               id="show-one1<?=$val->id?>" style="display:none;"> 
                                 <i class="far fa-edit"></i> Answer 
                               </a>
                               <!--<ul class="left-pb">
                                  <li class="download"> <a href="#"> <i class="fas fa-arrow-up"></i> </a> </li>
                                  <li class="dropdown show share-bn"> 
                                     <a class="btn-new1 dropdown-toggle padding-off" href="#" role="button" id="dropdownMenuLink" 
                                     data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                     <i class="fas fa-share"></i> </a> 
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                      <a class="dropdown-item" href="#">Facebook</a>
                                      <a class="dropdown-item" href="#">Twitter</a>
                                       <a class="dropdown-item" href="#">Copy link</a>
                                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#exampleModal-new">Embed Answer</a>
                                    </div>
                                  </li>
                               </ul>-->
                             <?php //} ?>
                            </div>
                         </div>
                     </div>
                     
                     <div id="Div2">
                        <a href="#">
                           <div class="common-group-bn">
                             <p> Downvote Answer </p>
                             <i class="fas fa-angle-right"></i>
                         </div>
                        </a>
                        <a href="#">
                           <div class="common-group-bn">
                             <p> Mute Photograph Recommendations </p>
                             <i class="fas fa-angle-right"></i>
                         </div>
                        </a>
                        <a href="#">
                           <div class="common-group-bn">
                             <p> Report </p>
                             <i class="fas fa-angle-right"></i>
                         </div>
                        </a>
                      </div>
                     
                     <div class="email-text" id="anstext<?=$val->id?>" style="display:none;">
                      <form action="<?php echo base_url();?>problems/submitproblemanswer/<?=$val->id?>/<?=$user_qry->id?>" method="post">
                     <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                         <textarea class="form-control" name="answer<?=$val->id?>" rows="20" id="ans<?=$val->id?>"></textarea>
                        
                         <script>
							tinymce.init({
							  selector: '#ans<?=$val->id?>',
							  plugins: 'a11ychecker advcode casechange formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
							  toolbar: 'a11ycheck addcomment showcomments casechange checklist code formatpainter media mediaembed pageembed permanentpen powerpaste table tinymcespellchecker',
							  toolbar_mode: 'floating',
							  tinycomments_mode: 'embedded',
							  tinycomments_author: 'Author name',
							});
						  </script>
                        
                         <?php if($this->session->userdata('id')!='') { ?>
                          <button type="submit" id="submit1" style="border: none;">Submit</button>&nbsp;
                          <button type="button" id="submit1" style="border: none;" onclick="javascript: answerclose(<?=$val->id?>);">Cancel</button>
                         <?php } else { ?>
                          <button type="button" id="submit1" data-toggle="modal"  data-target="#customModal" style="border: none;">Submit</button>
                          <button type="button" id="submit1" style="border: none;" onclick="javascript: answerclose(<?=$val->id?>);">Cancel</button>
                         <?php }?>
                      </form>
                       </div>
                     </div>
                     
                   <?php
				      } 
				    } 
				  ?>
                </div>
              </div>
            </div>
          </div>
        </div>
        
      </div>
      <div class="sd1 new-spc right-0 new-special-home">
         <div class="new-right-sec-add-howit">
             <h3> How it works </h3>
             <a data-toggle="modal" data-target="#exampleModal-vieo">
                <img src="<?php echo base_url();?>assets2/images/imgpsh_fullsize_anim.png" alt="user">
             </a>
          </div>
          <div class="ads-new-1">
            <a href="#">Advertisement</a>
          </div>
      </div>
    </div>
  </div>
</section>

<div class="modal fade exampleModalask" id="customModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header ask-modal modal-header-1"> <img src="<?php echo base_url();?>assets2/images/logo-head.png" alt="">
        <h5 class="modal-title" id="exampleModalLabel">Ask Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      <div id="modal-spl-26" class="modal-body modal-body1">
       <span id="msg" class="text-center" style="color:#FF0000;"></span>
        <div class="head-form head-form2x" id="next_hide">
          <div class="form-dp">
            <div class="top-sec-dp">
                <div class="form-group">
                  <label> User Name</label>
                  <input type="text" placeholder="" id="username" class="form-control" required>
                </div>
                <div class="form-group">
                  <label> Password </label>
                  <input type="password" placeholder="" id="pass" class="form-control" required>
                </div>
                <button type="button" id="login_btn2" class="btn default-btn login">Log In</button>
            </div>
          </div>
          <div class="col-md-4">&nbsp;</div>
          <div class="col-12">
            <div class="header-drop-links-first">
              <p>Or Login With</p>
              <ul class="socal-media">
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i>
                  <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                  <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                  <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                  <span> Linkedin</span></a></li>
              </ul>
              
              <div class="sub-link">
                 <a href="#">Lost Password </a> or <a href="#"> User Name</a>
              </div>
            </div>
          </div>
          <div class="col-12 mt-4">
            <div class="header-drop-links-second">
              <p>Or Sign Up With</p>
              <hr class="my-2">
              <ul class="socal-media">
                <li><a class="icon-new" href="#"> <i class="fas fa-envelope"></i>
                  <span>Email</span></a></li>
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i>
                  <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                  <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                  <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                  <span> Linkedin</span></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>  

<script>
 function answer(id)
 {
   document.getElementById("anstext"+id).style.display="block";
   document.getElementById("show-one"+id).style.display="none";
   document.getElementById("show-one1"+id).style.display="block";
 }
 
 function answerclose(id)
 {
   document.getElementById("anstext"+id).style.display="none";
   document.getElementById("show-one"+id).style.display="block";
   document.getElementById("show-one1"+id).style.display="none";
 }
 
</script>

<script>
    $(document).ready(function()
	{
		/*$("#login_btn2").click(function()
		{
			  var username = $("#username").val();
			  var pass = $("#pass").val();
				   
			  if(pass=='' || username=='')
			  {
				 swal("Sorry!! Insert Your Login Data");
			  }
			  else
			  {
				$.ajax({
				url:'<?php //echo base_url();?>home/login',
				type:'post',
				result:{user_name:username,password:pass},
				success:function(result)
				{
				  if(result=='success')
				  {
				   location.reload(true);
				  }
				  else
				  {
				   $('#msg').html("Wrong username or password!");
				  }
				}
			  });
		    }
	   });*/
	   
	   $("#login_btn2").click(function()
		{
		      var username = $("#username").val();
			  var pass = $("#pass").val();
				   
			  if(pass=='' || username=='')
			  {
				 swal("Sorry!! Insert Your Login Data");
			  }
			  else
			  {
			     $.ajax({url: "<?php echo base_url();?>home/login/"+username+"/"+pass, success: function(result){
					 location.reload(true);
				  }});
			  }
		});
  });
</script>

