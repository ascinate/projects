 <!--    host-account-section-start-->
    <section class="body-background py-5">
        <div class="host-section-wrap py-2">
            <div class="container big-container">
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <div class="supporters-podium-wrap">
                            <div class="supporters-podium-top-part">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h6 class="mt-1 mb-3">Welcome to Fixer Geek’s Podium!</h6>
                                        <p class="mb-4">Here you can find Fixers who can help you fix your problem using Remote Access Assistance, Screen Sharing & Voice Chat or Text Chat Support. If however, you’re a Fixer,you can find Users who need fix for their problems as well by clicking Just-A User tab.</p>
                                        <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link default-btn active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Fixer Geeks</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link default-btn" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Just-A Geeks</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!--                        <hr>-->
                            <div class="supporters-podium-bottom-part mx-lg-3">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="tab-content" id="pills-tabContent">
                                            <div class="tab-pane fixer-users-tab fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                                <div class="fixer-users-tab-top">
                                                    <form>
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-3">
                                                                    <div class="row">
                                                                        <div class="col-md-2 pr-0 my-auto">
                                                                            <label for="exampleInputEmail1">Search</label>
                                                                        </div>
                                                                        <div class="col-md-10">
                                                                            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-2">
                                                                    <div class="row">
                                                                        <div class="col-md-4 pr-0 my-auto">
                                                                            <label for="exampleFormControlSelect1">Filter by</label>
                                                                        </div>
                                                                        <div class="col-md-8 pl-0">
                                                                            <select class="form-control" id="exampleFormControlSelect1">
                                                                                <option>Geek Score</option>
                                                                                <option>3.5</option>
                                                                                <option>3.7</option>
                                                                                <option>4.0</option>
                                                                                <option>4.2</option>
                                                                                <option>4.5</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="row">
                                                                        <div class="col-md-2 pr-0 my-auto">
                                                                            <label for="exampleFormControlSelect1">Availability</label>
                                                                        </div>
                                                                        <div class="col-md-3 pr-0">
                                                                            <select class="form-control" id="exampleFormControlSelect1">
                                                                                <option>From</option>
                                                                                <option>10.00 AM</option>
                                                                                <option>10.30 AM</option>
                                                                                <option>11.00 AM</option>
                                                                                <option>11.30 AM</option>
                                                                                <option>12.00 PM</option>
                                                                            </select>
                                                                        </div>

                                                                        <div class="col-md-3 pr-0">
                                                                            <select class="form-control" id="exampleFormControlSelect1">
                                                                                <option>To</option>
                                                                                <option>10.00 AM</option>
                                                                                <option>10.30 AM</option>
                                                                                <option>11.00 AM</option>
                                                                                <option>11.30 AM</option>
                                                                                <option>12.00 PM</option>
                                                                            </select>
                                                                        </div>

                                                                        <div class="col-md-4">
                                                                            <select class="form-control" id="exampleFormControlSelect1">
                                                                                <option>Timezone</option>
                                                                                <option>GMT+00:00</option>
                                                                                <option>GMT+01:00</option>
                                                                                <option>GMT+02:00</option>
                                                                                <option>GMT+03:00</option>
                                                                                <option>GMT+04:00</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <ul class="">
                                                                        <li class="dropdown dropdown1-1 fixes nav-item">
                                                                            <a class="dropdown-toggle nav-link modal-link border-right-1 fix_id3 position-relative" href="#" id="plus-mode2">Select Category</a>
                                                                            <ul class="dropdown-menu dropdown-menu2 dropdown_menu20" aria-labelledby="navbarDropdown" id="table-mode2">
                                                                                <li><a id="table-dropdown-li-11" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                                                        <div class="plus-minus"></div> Repairs & security
                                                                                    </a></li>
                                                                                <div id="table-list-11" class="fixes-drop checkbox_listing-2">
                                                                                    <ul>
                                                                                        <li><a id="table-dropdown-li-12" class="dropdown-li plus-mode-1 dropdown-toggle d-flex" href="#">
                                                                                                <div class="plus-minus"></div>Operating System Issues
                                                                                            </a></li>
                                                                                        <div id="table-list-12" class="fixes-drop checkbox_listing checkbox_listing-1">
                                                                                            <ul>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table1">
                                                                                                        <label for="table1">Fix Notification</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table2">
                                                                                                        <label for="table2">Spyware</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table3">
                                                                                                        <label for="table3">Ransomware</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table4">
                                                                                                        <label for="table4">Phishing</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table5">
                                                                                                        <label for="table5">Spam</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table6">
                                                                                                        <label for="table6">Key Logging</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table7">
                                                                                                        <label for="table7">FireWall</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table8">
                                                                                                        <label for="table8">Identity Theft</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </div>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table9">
                                                                                                <label for="table9">Device Management & Drivers</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table10">
                                                                                                <label for="table10">Disk Management</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table11">
                                                                                                <label for="table11">Computer Management</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table12">
                                                                                                <label for="table12">Command Line</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table13">
                                                                                                <label for="table13">User Controls & Rights</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table14">
                                                                                                <label for="table14">Network Issues</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table15">
                                                                                                <label for="table15">Connection Issues</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table16">
                                                                                                <label for="table16">File Explorer</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table17">
                                                                                                <label for="table17">Start menu & Taskbar</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table18">
                                                                                                <label for="table18">FUsers & Accountsr</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table19">
                                                                                                <label for="table19">Printing</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table20">
                                                                                                <label for="table20">Output</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table21">
                                                                                                <label for="table21">Input</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table22">
                                                                                                <label for="table22">Miscellaneous</label>
                                                                                            </div>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                                <li>
                                                                                    <a id="table-dropdown-li-13" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                                                        <div class="plus-minus"></div>Optimization & Customization
                                                                                    </a>
                                                                                </li>
                                                                                <div id="table-list-13" class="fixes-drop">
                                                                                    <ul>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table23">
                                                                                                <label for="table23">Steam</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table24">
                                                                                                <label for="table24">Emulators</label>
                                                                                            </div>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                                <li>
                                                                                    <a id="table-dropdown-li-14" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                                                        <div class="plus-minus"></div>Apps & Features
                                                                                    </a>
                                                                                </li>
                                                                                <div id="table-list-14" class="fixes-drop">
                                                                                    <ul>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table25">
                                                                                                <label for="table25">Retroarch</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table26">
                                                                                                <label for="table26">Xbox</label>
                                                                                            </div>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                                <li><a id="table-dropdown-li-9" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                                                        <div class="plus-minus"></div>Essential Apps
                                                                                    </a></li>
                                                                                <div id="table-list-9" class="fixes-drop">
                                                                                    <ul>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table27">
                                                                                                <label for="table27">Steam</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table28">
                                                                                                <label for="table28">Emulators</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table29">
                                                                                                <label for="table29">Retroarch</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table30">
                                                                                                <label for="table30">Dolphin</label>
                                                                                            </div>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                                <li><a id="table-dropdown-li-8" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                                                        <div class="plus-minus"></div>Special Apps
                                                                                    </a></li>
                                                                                <div id="table-list-8" class="fixes-drop">
                                                                                    <ul>

                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table31">
                                                                                                <label for="table31">Producitivity Tools</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table32">
                                                                                                <label for="table32">Password Management</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table33">
                                                                                                <label for="table33">Photos</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table34">
                                                                                                <label for="table34">Audio & Music</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table35">
                                                                                                <label for="table35">CD/DVD/Blue-Ray</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li><a id="table-dropdown-li-10" class="dropdown-li dropdown-toggle plus-mode-1 d-flex " href="#">
                                                                                                <div class="plus-minus"></div>Gaming
                                                                                            </a></li>
                                                                                        <div id="table-list-10">
                                                                                            <ul>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table36">
                                                                                                        <label for="table36">Game Stores</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table37">
                                                                                                        <label for="table37">Xbox</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table38">
                                                                                                        <label for="table38">Steam</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table39">
                                                                                                        <label for="table39">Emulators</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                        <input type="checkbox" id="table40">
                                                                                                        <label for="table40">Retroarch</label>
                                                                                                    </div>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </div>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table41">
                                                                                                <label for="table41">Virtualization</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table42">
                                                                                                <label for="table42">Miscellaneous</label>
                                                                                            </div>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                                <li>
                                                                                    <a id="table-dropdown-li-15" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                                                        <div class="plus-minus"></div>Files Data & Content
                                                                                    </a>
                                                                                </li>
                                                                                <div id="table-list-15">
                                                                                    <ul>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table43">
                                                                                                <label for="table43">User Controls & Rights</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table44">
                                                                                                <label for="table44">Network Issues</label>
                                                                                            </div>
                                                                                        </li>
                                                                                        <li>
                                                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                                <input type="checkbox" id="table45">
                                                                                                <label for="table45">Connection Issues</label>
                                                                                            </div>
                                                                                    </ul>
                                                                                </div>
                                                                                <li>
                                                                                    <a id="table-dropdown-li-16" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                                                        <div class="plus-minus"></div>Office Management & Security
                                                                                    </a>
                                                                                </li>
                                                                                <div id="table-list-16">
                                                                                    <li>
                                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                            <input type="checkbox" id="table46">
                                                                                            <label for="table46">FireWall</label>
                                                                                        </div>
                                                                                    </li>
                                                                                    <li>
                                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                                            <input type="checkbox" id="table47">
                                                                                            <label for="table47">Identity Theft</label>
                                                                                        </div>
                                                                                    </li>
                                                                                </div>
                                                                            </ul>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                                <div class="fixer-users-tab-bottom">
                                                    <table class="table respond">
                                                        <thead>
                                                            <tr>
                                                                <th class="text-center" scope="col">Online</th>
                                                                <th class="text-center" scope="col">Geek Name</th>
                                                                <th class="text-center" scope="col">Score</th>
                                                                <th class="text-center" scope="col">Availability</th>
                                                                <th class="text-center" scope="col">Timezone</th>
                                                                <th class="text-center" scope="col">Problems Fixed</th>
                                                                <th class="text-center" style="width: 22%;" scope="col">Categories (Expert in)</th>
                                                                <th class="text-center" scope="col"> View/Hire</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <th scope="row"><i class="fa fa-circle online" aria-hidden="true"></i></th>
                                                                <td class="profile-spl-anchor"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <a class="profile-special1" href="#">Maxbrayne</a>
                                                                    <div class="profile-hover-details profile-hover-details1">
                                                                        <div class="row">
                                                                            <div class="col-md-12 mb-1">
                                                                                <h6><i class="fa fa-user-circle-o" aria-hidden="true"></i> Maxbrayne</h6>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <span>Score: 4.8 <a href="#">Read Comments</a></span>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <p>Availability: 3:00pm to 8:00pm</p>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <p>Timezone: Eastern Standard Time (GMT -5)</p>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                                                                            </div>
                                                                            <div class="col-md-12">
                                                                                <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <ul class="profile-hover-list">
                                                                                    <li>Categories (Expet in):</li>
                                                                                    <li><a href="#">PC Speed Up</a></li>
                                                                                    <li><a href="#">Internet Speed Up</a></li>
                                                                                    <li><a href="#">Memory (RAM) Issues</a></li>
                                                                                    <li><a href="#">Personalization</a></li>
                                                                                    <li><a href="#">Gaming</a></li>
                                                                                    <li><a href="#">Apple Products</a></li>
                                                                                    <li><a href="#">Microsoft Products</a></li>
                                                                                </ul>
                                                                            </div>
                                                                            <div class="col-md-12">
                                                                                <div class="row">
                                                                                    <div class="col-md-6 text-left">
                                                                                        <a href="#">Read Full Profile</a>
                                                                                    </div>
                                                                                    <div class="col-md-6 text-right">
                                                                                        <a href="#">Hire User</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </td>
                                                                <td class="text-center">4.8</td>
                                                                <td class="text-center">3:00pm to 8:00pm</td>
                                                                <td class="text-center">GMT -5</td>
                                                                <td class="text-center"><i class="fa fa-check" aria-hidden="true"></i> 35</td>
                                                                <td>
                                                                    <ul>
                                                                        <li><a href="#">Gaming</a></li>
                                                                        <li><a href="#">Animation & 3D</a></li>
                                                                    </ul>
                                                                    <ul>
                                                                        <li><a href="#">Optimization for Gaming</a></li>
                                                                    </ul>
                                                                </td>
                                                                <td class="text-center">
                                                                    <a href="#">View Profile</a>
                                                                    <br>
                                                                    <a href="#">Hire Fixer</a>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th scope="row"><i class="fa fa-circle online" aria-hidden="true"></i></th>
                                                                <td class="profile-spl-anchor"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <a href="#" class="profile-special2">JoeMartyJoe</a>
                                                                    <div class="profile-hover-details profile-hover-details2">
                                                                        <div class="row">
                                                                            <div class="col-md-12 mb-1">
                                                                                <h6><i class="fa fa-user-circle-o" aria-hidden="true"></i> JoeMartyJoe</h6>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <span>Score: 4.8 <a href="#">Read Comments</a></span>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <p>Availability: 3:00pm to 8:00pm</p>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <p>Timezone: Eastern Standard Time (GMT -5)</p>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                                                                            </div>
                                                                            <div class="col-md-12">
                                                                                <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <ul class="profile-hover-list">
                                                                                    <li>Categories (Expet in):</li>
                                                                                    <li><a href="#">PC Speed Up</a></li>
                                                                                    <li><a href="#">Internet Speed Up</a></li>
                                                                                    <li><a href="#">Memory (RAM) Issues</a></li>
                                                                                    <li><a href="#">Personalization</a></li>
                                                                                    <li><a href="#">Gaming</a></li>
                                                                                    <li><a href="#">Apple Products</a></li>
                                                                                    <li><a href="#">Microsoft Products</a></li>
                                                                                </ul>
                                                                            </div>
                                                                            <div class="col-md-12">
                                                                                <div class="row">
                                                                                    <div class="col-md-6 text-left">
                                                                                        <a href="#">Read Full Profile</a>
                                                                                    </div>
                                                                                    <div class="col-md-6 text-right">
                                                                                        <a href="#">Hire User</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </td>
                                                                <td class="text-center">4.7</td>
                                                                <td class="text-center">10:00am to 4:00pm</td>
                                                                <td class="text-center">GMT -3</td>
                                                                <td class="text-center"><i class="fa fa-check" aria-hidden="true"></i> 12</td>
                                                                <td>
                                                                    <ul>
                                                                        <li><a href="#">PC Speed Up</a></li>
                                                                        <li><a href="#">Internet Speed Up</a></li>
                                                                    </ul>
                                                                    <ul>
                                                                        <li><a href="#">Memory (RAM) Issues</a></li>
                                                                        <li><a id="toggle-more1">More...</a></li>
                                                                    </ul>
                                                                    <ul id="more-list1">
                                                                        <li><a href="#">PC Speed Up</a></li>
                                                                        <li><a href="#">Memory (RAM) Issues</a></li>
                                                                    </ul>
                                                                </td>
                                                                <td class="text-center">
                                                                    <a href="#">View Profile</a>
                                                                    <br>
                                                                    <a href="#">Hire Fixer</a>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th scope="row"><i class="fa fa-circle offline" aria-hidden="true"></i></th>
                                                                <td class="profile-spl-anchor"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <a href="#" class="profile-special3">Shawn667</a>
                                                                    <div class="profile-hover-details profile-hover-details3">
                                                                        <div class="row">
                                                                            <div class="col-md-12 mb-1">
                                                                                <h6><i class="fa fa-user-circle-o" aria-hidden="true"></i> Shawn667</h6>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <span>Score: 4.8 <a href="#">Read Comments</a></span>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <p>Availability: 3:00pm to 8:00pm</p>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <p>Timezone: Eastern Standard Time (GMT -5)</p>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                                                                            </div>
                                                                            <div class="col-md-12">
                                                                                <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                                                                            </div>
                                                                            <div class="col-md-12 mb-1">
                                                                                <ul class="profile-hover-list">
                                                                                    <li>Categories (Expet in):</li>
                                                                                    <li><a href="#">PC Speed Up</a></li>
                                                                                    <li><a href="#">Internet Speed Up</a></li>
                                                                                    <li><a href="#">Memory (RAM) Issues</a></li>
                                                                                    <li><a href="#">Personalization</a></li>
                                                                                    <li><a href="#">Gaming</a></li>
                                                                                    <li><a href="#">Apple Products</a></li>
                                                                                    <li><a href="#">Microsoft Products</a></li>
                                                                                </ul>
                                                                            </div>
                                                                            <div class="col-md-12">
                                                                                <div class="row">
                                                                                    <div class="col-md-6 text-left">
                                                                                        <a href="#">Read Full Profile</a>
                                                                                    </div>
                                                                                    <div class="col-md-6 text-right">
                                                                                        <a href="#">Hire User</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="clearfix"></div>
                                                                    </div>
                                                                </td>
                                                                <td class="text-center">4.7</td>
                                                                <td class="text-center">5:00pm to 10:00pm</td>
                                                                <td class="text-center">GMT 0</td>
                                                                <td class="text-center"><i class="fa fa-check" aria-hidden="true"></i> 102</td>
                                                                <td>
                                                                    <ul>
                                                                        <li><a href="#">Memory (RAM) Issues</a></li>
                                                                        <li><a href="#">Personalization</a></li>
                                                                    </ul>
                                                                    <ul>
                                                                        <li><a href="#">Browser</a></li>
                                                                        <li><a href="#">Security & Encryption</a></li>
                                                                        <li><a id="toggle-more2">More...</a></li>
                                                                    </ul>
                                                                    <ul id="more-list2">
                                                                        <li><a href="#">Browser</a></li>
                                                                        <li><a href="#">Security & Encryption</a></li>
                                                                    </ul>
                                                                </td>
                                                                <td class="text-center">
                                                                    <a href="#">View Profile</a>
                                                                    <br>
                                                                    <a href="#">Hire Fixer</a>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>


                                            <div class="tab-pane just-a-user-tab fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                                                <div class="just-a-user-tab-top">
                                                    <form>
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-3">
                                                                    <div class="row">
                                                                        <div class="col-md-2 pr-0 my-auto">
                                                                            <label for="exampleInputEmail1">Search</label>
                                                                        </div>
                                                                        <div class="col-md-10">
                                                                            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-2">
                                                                    <div class="row">
                                                                        <div class="col-md-4 pr-0 my-auto">
                                                                            <label for="exampleFormControlSelect1">Filter by</label>
                                                                        </div>
                                                                        <div class="col-md-8 pl-0">
                                                                            <select class="form-control" id="exampleFormControlSelect1">
                                                                                <option>Online</option>
                                                                                <option>Offline</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-2">
                                                                    <div class="row">
                                                                        <div class="col-md-10">
                                                                            <select class="form-control" id="exampleFormControlSelect1">
                                                                                <option>Level Required</option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                                <div class="just-a-user-tab-bottom fixer-users-tab-bottom">
                                                    <table class="table respond">
                                                        <thead>
                                                            <tr>
                                                                <th class="text-center" scope="col">Online</th>
                                                                <th class="text-center" scope="col">Geek Name</th>
                                                                <th class="text-center" scope="col">Level Required</th>
                                                                <th class="text-center" scope="col">Current Problem</th>
                                                                <th class="text-center" scope="col">Problems Fixed</th>
                                                                <th class="text-center" scope="col">Problems Not Fixed</th>
                                                                <th class="text-center" scope="col">View/Fix</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <th scope="row"><i class="fa fa-circle online" aria-hidden="true"></i></th>
                                                                <td class="nt-special-a"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <a href="#">MarkSelby25</a></td>
                                                                <td class="text-center">Fixer (Level 3)</td>
                                                                <td>How do I install animated Wallpaper in Windows 10?</td>
                                                                <td class="text-center"><i class="fa fa-check" aria-hidden="true"></i> 12</td>
                                                                <td class="text-center"><i class="fa fa-times" aria-hidden="true"></i> 3</td>
                                                                <td class="text-center">
                                                                    <a href="#">View Profile</a>
                                                                    <br>
                                                                    <a href="#">Fix this Problem</a>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th scope="row"><i class="fa fa-circle online" aria-hidden="true"></i></th>
                                                                <td class="nt-special-a"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <a href="#">Susan_2020</a></td>
                                                                <td class="text-center">Chatter (Level 1) </td>
                                                                <td>How do I speed up my PC for gaming, I have tried to update my GForce<br> driver but it doesn’t work. Please help me solve it, I can pay you high ba...</td>
                                                                <td class="text-center"><i class="fa fa-check" aria-hidden="true"></i> 2</td>
                                                                <td class="text-center"><i class="fa fa-times" aria-hidden="true"></i> 1</td>
                                                                <td class="text-center">
                                                                    <a href="#">View Profile</a>
                                                                    <br>
                                                                    <a href="#">Fix this Problem</a>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th scope="row"><i class="fa fa-circle offline" aria-hidden="true"></i></th>
                                                                <td class="nt-special-a"><i class="fa fa-user-circle-o" aria-hidden="true"></i> <a href="#">Shariq2027</a></td>
                                                                <td class="text-center">Helper (Level 2)</td>
                                                                <td>How do I play Metal Arch on Metal Slug? </td>
                                                                <td class="text-center"><i class="fa fa-check" aria-hidden="true"></i> 34</td>
                                                                <td class="text-center">0</td>
                                                                <td class="text-center">
                                                                    <a href="#">View Profile</a>
                                                                    <br>
                                                                    <a href="#">Fix this Problem</a>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <!--    host-account-section-end-->
