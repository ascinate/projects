<?php 
	error_reporting(0);
	$userid = $this->session->userdata('id');
	
	if($this->session->userdata('id')=="")
	{
	   redirect('/');
	}
	
	$user=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
	$country=$this->db->get_where('country_master',array('iso'=>$user->country))->row();
	
	/*$this->db->select('*');
	$this->db->from('questions_master');
	$this->db->order_by('id', 'desc');
	$this->db->limit(4, 0);
	$question_qry = $this->db->get()->result();*/
	
	$question_qry = $this->db->get_where('questions_master', array('user_id' => $userid));
	$cnt = $question_qry->num_rows();
?>
<section class="total-bd-area">
   <div class="container-fluid">
      <div class="row">
        <div class="new-add-sec">
            <div class="col-md-3 col-lg-3 pr-md-0">
             <div class="left-slidber-area">
                <div class="host-section-left-list">
                  <?php $this->load->view('inc/left-navigation-supporters');?>
               </div>
             </div>
              
            </div>
            <div class="col-md-9 col-lg-9">
              <div class="bod-area">
                 <div class="text-part-sec home-inside-d1">
                    <div class="row">
                        <div class="col-md-4">
                          <div class="comon-part-sec">
                            <h6>Profile</h6>
                            <ul class="comon-li-sec">
                              <li> <span> Geek Name: </span><?=$user->geek_name?></li>
                              <li> <span> Email: </span><?=$user->email?></li>
                              <li> <span> Country: </span><?=$country->nicename?></li>
                            </ul>
                            <div class="host-section-grid-img text-center my-3"> 
                             <?php if($user->profile_picture!=""){?>
                              <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" alt="user">
                             <?php } else { ?>
                              <i class="fa fa-user" aria-hidden="true"></i>
                             <?php } ?>
                            </div>
                             <div class="but-link"> <a href="<?php echo base_url();?>profile">Change Info</a> </div> 
                          </div>
                        </div>
                        <div class="col-md-4 middle-sec">
                          <div class="comon-part-sec">
                            <h6>Become a Fixer Geek</h6>
                            <ul class="comon-li-sec">
                              <li> <span> Make Money Online. </span>  </li>
                              <li> Follow our guidelines when  </li>
                              <li> answering/fixing problems of users to </li>
                              <li> become a Fixer Geek </li>
                            </ul>
                            <ul class="comon-li-sec">
                              <li> <span> How to become a Fixer Geek? </span> </li>
                              <li>1. Fix 1 Problems per Category</li>
                              <li>2. Be Technically Accurate</li>
                              <li>3. Show Good Use of Language</li>
                              <li>4. Write at least 250-500 Words</li>
                            </ul>
                            <div class="but-link"> <a href="<?php echo base_url();?>becomeasupporter">Our Guidelines</a> </div>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="comon-part-sec">
                            <h6>Your Fixes & Problems</h6>
                            <ul class="comon-li-sec">
                              <li> <span> Problems </span> </li>
                              
                              <?php
							    if($cnt!=0)
								{
									$i=1;
									foreach($question_qry->result() as $val)
									{
									  $title = str_replace(" ","-",trim($val->question));
									  $title_1 = str_replace("?-","",$title);
									  $title_1 = str_replace("-?","",$title);
									  $title_1 = str_replace("-?-","",$title);
									  $title_2 = str_replace("?","",$title_1);
                            ?>
                                 <li><a href="<?php echo base_url();?>details/show/<?=$title_2?>"><?=$val->question?></a></li>
                            <?php
                               		} 
								}
								else
								{
							 ?>
                                 <li>No problems found!</li>
                             <?php	
								}
                            ?>
                            </ul>
                            <ul class="comon-li-sec">
                              <li> <span> Fixes </span> </li>
                              <?php
                                $answer_qry = $this->db->get_where('answers_master', array('user_id' => $userid));
								$count = $answer_qry->num_rows();
								
								if($count!=0)
								{
									foreach($answer_qry->result() as $val)
									{
									  $record = $this->db->get_where('questions_master',array('id'=>$val->question_id))->row();
									 
									  $title = str_replace(" ","-",trim($record->question));
									  $title_1 = str_replace("?-","",$title);
									  $title_1 = str_replace("-?","",$title);
									  $title_1 = str_replace("-?-","",$title);
									  $title_2 = str_replace("?","",$title_1);
								  ?>
									  <li><a href="<?php echo base_url();?>details/show/<?=$title_2?>"><?=$record->question?></a></li>
								 <?php
									} 
								}
								else
								{
                              ?>
                              		<li>No fixes found!</li>
                              <?php
                                }
							  ?>
                            </ul>
                            <div class="but-link"> <a href="<?php echo base_url();?>askerproblems">See More</a> </div>
                          </div>
                        </div>
                        <div class="col-md-4 ">
                          <div class="comon-part-sec">
                            <h6>Messeges</h6>
                            <ul class="comon-li-sec">
                              <li> <span> Admin Messages </span> </li>
                              <li>  <a href="<?php echo base_url();?>messages">Unread (2)</a> </li>
                            </ul>
                             <ul class="comon-li-sec">
                              <li> <span> Geek Messages </span> </li>
                              <li>  <a href="<?php echo base_url();?>messages">Unread (15)</a> </li>
                            </ul>
                           
                            <div class="but-link"> <a href="<?php echo base_url();?>messages">Read all Messages</a> </div>
                          </div>
                        </div>
                        <div class="col-md-4 middle-sec">
                          <div class="comon-part-sec">
                            <h6>Notifications</h6>
                            <ul class="comon-li-sec">
                              <li> You’re in control of what emails you  </li>
                              <li>  receive from FixerGeek.com </li>
                            </ul>
                            <ul class="comon-li-sec">
                              <li> <a href="<?php echo base_url();?>notifications"> Admin Notifications </a>  </li>
                              <li>  <a href="<?php echo base_url();?>notifications"> Geek Notifications </a>  </li>
                            </ul>
                            
                            <div class="but-link"> <a href="<?php echo base_url();?>notifications">Change Notifications</a> </div>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="comon-part-sec">
                            <h6>Account Settings</h6>
                            <ul class="comon-li-sec">
                              <li> <span> Your Default Credit/Debit Card: </span>  </li>
                              <li>  VISA Ending 2308, exp 07/23 </li>
                              <li>  <a href="<?php echo base_url();?>askersettings"> View Payment & Billing Info </a> </li>
                            </ul>
                            <ul class="comon-li-sec">
                              <li> <span> Security Settings</span> </li>
                              
                              <li><a href="<?php echo base_url();?>securitysettings">Block Geeks</a></li>
                               <li><a href="<?php echo base_url();?>securitysettings">Change Password</a></li>
                              <!--<li><a href="<?php //echo base_url();?>securitysettings">
                              <?php //if($user->account=="Activate"){echo "Deactivate Account";}else{echo" Activate Account";}?> </a>
                              </li>-->
                              <li><a href="<?php echo base_url();?>securitysettings">Delete Account</a></li>
                            </ul>
                            <div class="but-link"> <a href="<?php echo base_url();?>askersettings">Change Account Settings</a> </div>
                          </div>
                        </div>
                      </div>
                  </div>
              </div>
            </div>
        </div>
        <div class="sd1 new-spc"> <a href="#">Advertisement</a> </div>
      </div>
    </div>
</section>