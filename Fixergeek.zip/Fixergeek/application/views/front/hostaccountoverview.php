<section class="total-bd-area">
   <div class="container-fluid">
      <div class="row">
        <div class="col-md-3 col-lg-2 pr-md-0">
         <div class="left-slidber-area">
            <div class="host-section-left-list">
              <?php $this->load->view('inc/left-navigation-supporters');?>
           </div>
         </div>
          
        </div>
        <div class="col-md-9 col-lg-10">
          <div class="bod-area">
             <div class="text-part-sec">
                <div class="row">
                    <div class="col-md-4">
                      <div class="comon-part-sec">
                        <h6>Profile</h6>
                        <ul class="comon-li-sec">
                          <li> <span> Geek Name: </span> maxbrayne </li>
                          <li> <span> Email: </span> maxbrayne@gmail.com</li>
                          <li> <span> Country: </span> Canada</li>
                        </ul>
                        <div class="host-section-grid-img text-center my-3"> <i class="fa fa-user" aria-hidden="true"></i> </div>
                         <div class="but-link"> <a href="#">Change Info</a> </div> 
                      </div>
                    </div>
                    <div class="col-md-4 middle-sec">
                      <div class="comon-part-sec">
                        <h6>Become a Fixer Geek</h6>
                        <ul class="comon-li-sec">
                          <li> <span> Make Money Online. </span>  </li>
                          <li> Follow our guidelines when  </li>
                          <li> answering/fixing problems of users to </li>
                          <li> become a Fixer Geek </li>
                        </ul>
                        <ul class="comon-li-sec">
                          <li> <span> How to become a Fixer Geek? </span> </li>
                          <li>1. Fix 3 Problems per Category</li>
                          <li>2. Be Technically Accurate</li>
                          <li>3. Show Good Use of Language</li>
                          <li>4. Write at least 250-500 Words</li>
                        </ul>
                        <div class="but-link"> <a href="#">Our Guidelines</a> </div>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="comon-part-sec">
                        <h6>Fixes & Problems</h6>
                        <ul class="comon-li-sec">
                          <li> <span> Problems </span> </li>
                          <li> <a href="#"> How can I start virtualization through BIOS Configuration? </a> </li>
                          <li> <a href="#"> How do I install retroArch on my PC ? </a> </li>
                        </ul>
                        <ul class="comon-li-sec">
                          <li> <span> Fixes </span> </li>
                          <li> <a href="#"> How do I install animated Wallpaper on my PC ? </a> </li>
                          <li> <a href="#"> How do I overclock my processor in Windows 10?  </a> </li>
                        </ul>
                        <a href="#"></a> <a class="mb-0" href="#"> </a>
                        <div class="but-link"> <a href="#">See More</a> </div>
                      </div>
                    </div>
                    <div class="col-md-4 ">
                      <div class="comon-part-sec">
                        <h6>Messeges</h6>
                        <ul class="comon-li-sec">
                          <li> <span> Admin Messages </span> </li>
                          <li>  <a href="#">Unread (2)</a> </li>
                        </ul>
                         <ul class="comon-li-sec">
                          <li> <span> Geek Messages </span> </li>
                          <li>  <a href="#">Unread (15)</a> </li>
                        </ul>
                       
                        <div class="but-link"> <a href="#">Read all Messages</a> </div>
                      </div>
                    </div>
                    <div class="col-md-4 middle-sec">
                      <div class="comon-part-sec">
                        <h6>Notifications</h6>
                        <ul class="comon-li-sec">
                          <li> You’re in control of what emails you  </li>
                          <li>  receive from FixerGeek.com </li>
                        </ul>
                        <ul class="comon-li-sec">
                          <li> <a href="#"> Admin Notifications </a>  </li>
                          <li>  <a href="#"> Geek Notifications </a>  </li>
                        </ul>
                        
                        <div class="but-link"> <a href="#">Change Notifications</a> </div>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="comon-part-sec">
                        <h6>Account Settings</h6>
                        <ul class="comon-li-sec">
                          <li> <span> Your Default Credit/Debit Card: </span>  </li>
                          <li>  VISA Ending 2308, exp 07/23 </li>
                          <li>  <a href="#"> View Payment & Billing Info </a> </li>
                        </ul>
                        <ul class="comon-li-sec">
                          <li> <span> Security Settings</span> </li>
                          <li><a href="#">Change Password</a></li>
                          <li><a href="#">Deactiviate Account</a></li>
                          <li><a href="#">Delete Account</a></li>
                        </ul>
                        <div class="but-link"> <a href="#">Change Security Options</a> </div>
                      </div>
                    </div>
                  </div>
              </div>
              <div class="sd1"> <a href="#">Advertisement</a> </div>
          </div>
        </div>
      </div>
    </div>
</section>