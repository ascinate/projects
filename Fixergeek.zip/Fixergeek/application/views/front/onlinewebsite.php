<section class="total-bd-area2">
  <div class="container-fluid">
    <div class="offline_website_ask_head breadcrumb-1"> 
     <a class="breadcrumb1-anchor nt-spl-anchor anchor-brc-1" href="#">Categories</a>
      <a class="breadcrumb1-anchor nt-spl-anchor" href="#">Special Apps</a>
      <li class="nav-item dropdown dropdown1"> 
      <a class="breadcrumb1-anchor nav-link Profile-pad active dropdown-toggle button" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span>Gaming</span> </a>
        <div class="dropdown-menu drop-menu-new dropdown-menu1" aria-labelledby="navbarDropdown">
         <a class="dropdown-item" href="#">GAMESTORES</a> 
         <a class="dropdown-item" href="#">XBOX</a> 
         <a class="dropdown-item" href="#">STEAM</a> 
         <a class="dropdown-item" href="#">EMULATORS</a> 
         <a class="dropdown-item" href="#">RETROARCH</a> 
         <a class="dropdown-item" href="#">LAUNCHBOX</a> 
         <a class="dropdown-item" href="#">DOLPHIN</a> 
       </div>
      </li>
    </div>
    <hr class="my-2">
    <div class="row">
      <div class="col-md-7 col-lg-9">
        <div class="accordian-part mt-3">
          <div class="main">
            <div id="accordion" class="accordion">
              <div class="card mb-0">
                <div class="card-header collapsed" data-toggle="collapse" href="#collapseOne"> <a class="card-title"> How do I play Metal Slug on RetroArch? </a> </div>
                <div id="collapseOne" class="collapse show" data-parent="#accordion" >
                  <div class="card-body">
                    <div class="comon-text-area comon-space">
                      <p> I recommend you the following:Go to </p>
                      <p><a href="#"> http://www.retroarch.com </a> and download the latest version of Retroacrch
                        and follow these steps </p>
                      <div class="steps1">
                        <h5 class="bold-text">Step 1:</h5>
                        <p> Run RetroArch and click Settings</p>
                      </div>
                      <div class="steps1">
                        <h5 class="bold-text">Step 2:</h5>
                        <p> Click the Bios button </p>
                      </div>
                      <div class="steps1">
                        <h5 class="bold-text">Step 3:</h5>
                        <p> Choose the bios file windl.bios from the list in the Bios menu. </p>
                      </div>
                      <div class="more-text1">
                        <p class="mt-3 steps"><b>Step 4:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <p class="mt-3 steps"><b>Step 5:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <p class="mt-3 steps"><b>Step 6:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <br>
                        <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                        <hr>
                        <form class="my-4">
                          <div class="form-group">
                            <div class="row justify-content-center accordion-comment-section">
                              <div class="col-md-1 text-right"> <i class="fa fa-user" aria-hidden="true"></i> </div>
                              <div class="col-md-9 px-0">
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" 
                                                                              placeholder="Add a comment..."></textarea>
                              </div>
                              <div class="col-md-2">
                                <button class="default-btn">Add Comment<br>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                      <div class="bn-area"> <a class="moreless-button1" >Read more</a> </div>
                    </div>
                  </div>
                </div>
                <div class="card-header collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"> <a class="card-title"> How can I play any ROM? </a> </div>
                <div id="collapseTwo" class="collapse" data-parent="#accordion" >
                  <div class="card-body">
                    <div class="comon-text-area comon-space">
                      <p> I recommend you the following:Go to </p>
                      <p><a href="#"> http://www.retroarch.com </a> and download the latest version of Retroacrch
                        and follow these steps </p>
                      <div class="steps1">
                        <h5 class="bold-text">Step 1:</h5>
                        <p> Run RetroArch and click Settings</p>
                      </div>
                      <div class="steps1">
                        <h5 class="bold-text">Step 2:</h5>
                        <p> Click the Bios button </p>
                      </div>
                      <div class="steps1">
                        <h5 class="bold-text">Step 3:</h5>
                        <p> Choose the bios file windl.bios from the list in the Bios menu. </p>
                      </div>
                      <div class="more-text2">
                        <p class="mt-3 steps"><b>Step 4:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <p class="mt-3 steps"><b>Step 5:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <p class="mt-3 steps"><b>Step 6:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <br>
                        <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                        <hr>
                        <form class="my-4">
                          <div class="form-group">
                            <div class="row justify-content-center accordion-comment-section">
                              <div class="col-md-1 text-right"> <i class="fa fa-user" aria-hidden="true"></i> </div>
                              <div class="col-md-9 px-0">
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" 
                                                                              placeholder="Add a comment..."></textarea>
                              </div>
                              <div class="col-md-2">
                                <button class="default-btn">Add Comment<br>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                      <div class="bn-area"> <a class="moreless-button2" >Read more</a> </div>
                    </div>
                  </div>
                </div>
                <div class="card-header collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree"> <a class="card-title"> Where can I find RetroArch? </a> </div>
                <div id="collapseThree" class="collapse" data-parent="#accordion" >
                  <div class="card-body">
                    <div class="comon-text-area comon-space">
                      <p> I recommend you the following:Go to </p>
                      <p><a href="#"> http://www.retroarch.com </a> and download the latest version of Retroacrch
                        and follow these steps </p>
                      <div class="steps1">
                        <h5 class="bold-text">Step 1:</h5>
                        <p> Run RetroArch and click Settings</p>
                      </div>
                      <div class="steps1">
                        <h5 class="bold-text">Step 2:</h5>
                        <p> Click the Bios button </p>
                      </div>
                      <div class="steps1">
                        <h5 class="bold-text">Step 3:</h5>
                        <p> Choose the bios file windl.bios from the list in the Bios menu. </p>
                      </div>
                      <div class="more-text3">
                        <p class="mt-3 steps"><b>Step 4:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <p class="mt-3 steps"><b>Step 5:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <p class="mt-3 steps"><b>Step 6:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <br>
                        <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                        <hr>
                        <form class="my-4">
                          <div class="form-group">
                            <div class="row justify-content-center accordion-comment-section">
                              <div class="col-md-1 text-right"> <i class="fa fa-user" aria-hidden="true"></i> </div>
                              <div class="col-md-9 px-0">
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" 
                                                                              placeholder="Add a comment..."></textarea>
                              </div>
                              <div class="col-md-2">
                                <button class="default-btn">Add Comment<br>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                      <div class="bn-area"> <a class="moreless-button3" >Read more</a> </div>
                    </div>
                  </div>
                </div>
                <div class="card-header collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapsefour"> <a class="card-title"> I want to play metal slug arcade game </a> </div>
                <div id="collapsefour" class="collapse" data-parent="#accordion" >
                  <div class="card-body">
                    <div class="comon-text-area comon-space">
                      <p> I recommend you the following:Go to </p>
                      <p><a href="#"> http://www.retroarch.com </a> and download the latest version of Retroacrch
                        and follow these steps </p>
                      <div class="steps1">
                        <h5 class="bold-text">Step 1:</h5>
                        <p> Run RetroArch and click Settings</p>
                      </div>
                      <div class="steps1">
                        <h5 class="bold-text">Step 2:</h5>
                        <p> Click the Bios button </p>
                      </div>
                      <div class="steps1">
                        <h5 class="bold-text">Step 3:</h5>
                        <p> Choose the bios file windl.bios from the list in the Bios menu. </p>
                      </div>
                      <div class="more-text4">
                        <p class="mt-3 steps"><b>Step 4:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <p class="mt-3 steps"><b>Step 5:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <p class="mt-3 steps"><b>Step 6:</b></p>
                        <span class="steps-span">Click the Bios button</span>
                        <!--  -->
                        <br>
                        <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                        <hr>
                        <form class="my-4">
                          <div class="form-group">
                            <div class="row justify-content-center accordion-comment-section">
                              <div class="col-md-1 text-right"> <i class="fa fa-user" aria-hidden="true"></i> </div>
                              <div class="col-md-9 px-0">
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" 
                                                                              placeholder="Add a comment..."></textarea>
                              </div>
                              <div class="col-md-2">
                                <button class="default-btn">Add Comment<br>
                                </button>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                      <div class="bn-area"> <a class="moreless-button4" >Read more</a> </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- col-9 -->
      <div class="col-md-5 col-lg-3">
        <div class="right-fixed-box fixed-carousel-spl-box new-width">
          <div class="host-section-right-carousel-box host-section-right-box">
            <div class="host-right-heading-box"> <span class="text-center active-span"><i class="fa fa-circle" aria-hidden="true"></i> <b> 5 Fixer Geeks (online)</b></span> </div>
            <div class="host-right-owl-box mb-3">
              <section class="client-logoarea">
                <div class="owl-carousel owl-theme">
                  <div class="lgo-items">
                    <div class="hover-link-part">
                      <h6> <a class="show-details-new1" href="#">SimonPhilip</a> - 3.9 score</h6>
                      <p> <i class="fas fa-check"></i> Fixed this Problem </p>
                    </div>
                    <div class="profile-hover-details profile-hover-carousel1 new-show-div1">
                      <div class="row">
                        <div class="col-md-12 mb-1">
                          <h6> <i class="far fa-user-circle"></i> JoeMartyJoe</h6>
                        </div>
                        <div class="col-md-12 mb-1"> <span>Score: 4.8 <a href="#">Read Comments</a></span> </div>
                        <div class="col-md-12 mb-1">
                          <p>Availability: 3:00pm to 8:00pm</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p>Timezone: Eastern Standard Time (GMT -5)</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                        </div>
                        <div class="col-md-12">
                          <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <ul class="profile-hover-list">
                            <li class="spl-li">Categories (Expet in):</li>
                            <li><a href="#">PC Speed Up</a></li>
                            <li><a href="#">Internet Speed Up</a></li>
                            <li><a href="#">Memory (RAM) Issues</a></li>
                            <li><a href="#">Personalization</a></li>
                            <li><a href="#">Gaming</a></li>
                            <li><a href="#">Apple Products</a></li>
                            <li><a href="#">Microsoft Products</a></li>
                          </ul>
                        </div>
                        <div class="col-md-12">
                          <div class="row">
                            <div class="col-md-6 text-left"> <a href="#">Read Full Profile</a> </div>
                            <div class="col-md-6 text-right"> <a href="#">Hire User</a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <a href="#">
                    <div class="one">
                      <h6> Get Remote Assistance <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level3.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Screen Sharing & Voice Chat Support <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level2.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Text Chat Support <span> on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level1.png" alt=""> </figure>
                    </div>
                    </a> </div>
                  <div class="lgo-items">
                    <div class="hover-link-part">
                      <h6> <a class="show-details-new2" href="#">AdamJosh</a> - 3.9 score</h6>
                      <p> <i class="fas fa-check"></i>Fixed this Problem </p>
                    </div>
                    <div class="profile-hover-details profile-hover-carousel2 new-show-div2">
                      <div class="row">
                        <div class="col-md-12 mb-1">
                          <h6><i class="far fa-user-circle"></i> AdamJosh</h6>
                        </div>
                        <div class="col-md-12 mb-1"> <span>Score: 4.8 <a href="#">Read Comments</a></span> </div>
                        <div class="col-md-12 mb-1">
                          <p>Availability: 3:00pm to 8:00pm</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p>Timezone: Eastern Standard Time (GMT -5)</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                        </div>
                        <div class="col-md-12">
                          <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <ul class="profile-hover-list">
                            <li class="spl-li">Categories (Expet in):</li>
                            <li><a href="#">PC Speed Up</a></li>
                            <li><a href="#">Internet Speed Up</a></li>
                            <li><a href="#">Memory (RAM) Issues</a></li>
                            <li><a href="#">Personalization</a></li>
                            <li><a href="#">Gaming</a></li>
                            <li><a href="#">Apple Products</a></li>
                            <li><a href="#">Microsoft Products</a></li>
                          </ul>
                        </div>
                        <div class="col-md-12">
                          <div class="row">
                            <div class="col-md-6 text-left"> <a href="#">Read Full Profile</a> </div>
                            <div class="col-md-6 text-right"> <a href="#">Hire User</a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <a href="#">
                    <div class="one">
                      <h6> Get Remote Assistance <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level3.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Screen Sharing & Voice Chat Support <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level2.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Text Chat Support <span> on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level1.png" alt=""> </figure>
                    </div>
                    </a> </div>
                  <div class="lgo-items">
                    <div class="hover-link-part">
                      <h6> <a class="show-details-new3" href="#">AdamJosh</a> - 3.9 score</h6>
                      <p> <i class="fas fa-check"></i> Fixed this Problem </p>
                    </div>
                    <div class="profile-hover-details profile-hover-carousel1 new-show-div3">
                      <div class="row">
                        <div class="col-md-12 mb-1">
                          <h6><i class="far fa-user-circle"></i> JoeMartyJoe</h6>
                        </div>
                        <div class="col-md-12 mb-1"> <span>Score: 4.8 <a href="#">Read Comments</a></span> </div>
                        <div class="col-md-12 mb-1">
                          <p>Availability: 3:00pm to 8:00pm</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p>Timezone: Eastern Standard Time (GMT -5)</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                        </div>
                        <div class="col-md-12">
                          <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <ul class="profile-hover-list">
                            <li class="spl-li">Categories (Expet in):</li>
                            <li><a href="#">PC Speed Up</a></li>
                            <li><a href="#">Internet Speed Up</a></li>
                            <li><a href="#">Memory (RAM) Issues</a></li>
                            <li><a href="#">Personalization</a></li>
                            <li><a href="#">Gaming</a></li>
                            <li><a href="#">Apple Products</a></li>
                            <li><a href="#">Microsoft Products</a></li>
                          </ul>
                        </div>
                        <div class="col-md-12">
                          <div class="row">
                            <div class="col-md-6 text-left"> <a href="#">Read Full Profile</a> </div>
                            <div class="col-md-6 text-right"> <a href="#">Hire User</a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <a href="#">
                    <div class="one">
                      <h6> Get Remote Assistance <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level3.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Screen Sharing & Voice Chat Support <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level2.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Text Chat Support <span> on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level1.png" alt=""> </figure>
                    </div>
                    </a> </div>
                  <div class="lgo-items">
                    <div class="hover-link-part">
                      <h6> <a class="show-details-new4" href="#">AdamJosh</a> - 3.9 score</h6>
                      <p> <i class="fas fa-check"></i> Fixed this Problem </p>
                    </div>
                    <div class="profile-hover-details profile-hover-carousel1 new-show-div4">
                      <div class="row">
                        <div class="col-md-12 mb-1">
                          <h6><i class="far fa-user-circle"></i> JoeMartyJoe</h6>
                        </div>
                        <div class="col-md-12 mb-1"> <span>Score: 4.8 <a href="#">Read Comments</a></span> </div>
                        <div class="col-md-12 mb-1">
                          <p>Availability: 3:00pm to 8:00pm</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p>Timezone: Eastern Standard Time (GMT -5)</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                        </div>
                        <div class="col-md-12">
                          <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                        </div>
                        <div class="col-md-12 mb-1">
                          <ul class="profile-hover-list">
                            <li class="spl-li">Categories (Expet in):</li>
                            <li><a href="#">PC Speed Up</a></li>
                            <li><a href="#">Internet Speed Up</a></li>
                            <li><a href="#">Memory (RAM) Issues</a></li>
                            <li><a href="#">Personalization</a></li>
                            <li><a href="#">Gaming</a></li>
                            <li><a href="#">Apple Products</a></li>
                            <li><a href="#">Microsoft Products</a></li>
                          </ul>
                        </div>
                        <div class="col-md-12">
                          <div class="row">
                            <div class="col-md-6 text-left"> <a href="#">Read Full Profile</a> </div>
                            <div class="col-md-6 text-right"> <a href="#">Hire User</a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                    <a href="#">
                    <div class="one">
                      <h6> Get Remote Assistance <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level3.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Screen Sharing & Voice Chat Support <span>on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level2.png" alt=""> </figure>
                    </div>
                    </a> <a href="#">
                    <div class="one">
                      <h6> Get Text Chat Support <span> on this problem from </span> JoeMartyJoe </h6>
                      <figure> <img src="<?php echo base_url();?>assets2/images/level1.png" alt=""> </figure>
                    </div>
                    </a> </div>
                </div>
              </section>
            </div>
            <div class="host-section-right-bottom"> <a href="#">See All Fixer Geeks...</a> </div>
          </div>
          <div class="host-section-right-box spl-right-box mt-3"> <a href="#">Advertisement</a> </div>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</section>
