<?php 
	$qus_id=$this->uri->segment(3);
	$userId = $this->session->userdata('id');
	
	$question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
	$user=$this->db->get_where('user_master',array('id'=>$question->user_id))->row();
	
	$this->db->order_by('upvote', 'DESC');
	$answer=$this->db->get_where('answers_master',array('question_id'=>$qus_id));
	
	$date=date_create($question->post_date);   
	
	//$user_qry=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
	$category=$this->db->get_where('category_master',array('id'=>$question->category_name))->row();
	$sub_cat=$this->db->get_where('sub_category_master',array('id'=>$question->sub_cat_id))->row();
	$sub_sub_cat=$this->db->get_where('sub_sub_category_master',array('id'=>$question->sub_sub_cat_id))->row();
?>

<section class="total-bd-area2 add-scroll-1">
  <div class="container-fluid">
       <div class="new-add-del-sec2">
          <div class="col-md-12 pl-0">
           
            <div class="details-devoplo-accordian mt-3 w-100">
                  <div class="details-area-div">
                      <div class="question-area-details-dv">
                           <div class="top-question"> 
                              <h1> <?=$question->question;?> </h1>
                              <ul class="categories-d1">
                                 <li> Categories: </li>
                                 <li> <a href="#"><?=$sub_sub_cat->sub_sub_category_name;?></a> </li>
                              </ul>
                           </div>
                          <div class="colas-area-dv">
                             <div id="accordion" class="accordion">
                                    <div class="answer-part">
                                       <div class="ans-div-d1">
                                       <? ######################### Answer Loop Start Here ################### ?>
										<?php
                                            $i = 1;
                                            foreach($answer->result() as $record)
                                            {
											  $author_id = $record->user_id;
											  
                                              $exdate = explode('-', $record->post_date);
                                              $postdate = mktime(12,0,0, $exdate[1],$exdate[2],$exdate[0]);
                                              $date = date("F j, Y", $postdate);
                                              
                                              $username = $this->db->get_where('user_master',array('id'=>$record->user_id))->row();
											  $fixergeek=$this->db->get_where('fixergeek_master',array('user_id'=>$record->user_id))->row();
											  
											  $vt = $this->db->query("select sum(upvote) as upvot from `answer_up_down` 
											  						  where `answer_id` = '".$record->id."'")->row();
											  $upv = $vt->upvot;  
											
											  $vt2 = $this->db->query("select sum(downvote) as downvot from `answer_up_down`
											  						   where `answer_id` = '".$record->id."'")->row();
											  $dwv = $vt2->downvot;
                                        ?>
                                          <div class="card-header collapsed question-comon-1" data-target="#collapse<?=$i?>" 
                                          data-toggle="collapse" data-parent="#accordion">
                                              <a class="card-title">
                                                Answer #<?=$i?> by 
                                                
                                                 <?php 
												  if($username->id=="Admin")
												  {
												?>
												   <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" 
                                                   style="border-radius:50%; width:20px; height:20px;">
												<?php
												 }
												 else
												 {
												   if($username->profile_picture!="")
												   {
												 ?>
												   <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
												   style="border-radius:50%; width:20px; height:20px;">
												<?php 
												   } 
												  else
												   {
												?>
												   <i class="far fa-user-circle"></i>
												<?php 
												   }
												 }
												?>
												
												<?=$username->geek_name?> Posted on <?=$date?> 
                                                <!--@--> <? /*$record->post_time?> - <?=$fixergeek->timezone*/ ?>
                                              </a>
                                          </div>
                                              
                                          <div id="collapse<?=$i?>" class="collapse <?php if($i==1){?>show<?php }?>" data-parent="#accordion">
                                              <div class="card-body border-top-0">
                                                <div class="comon-text-area comon-space">
                                                 <div class="total-edit-sec">
                                                 <?php if($this->session->userdata('id')==$author_id) {?>
                                                   <ul class="new-add-dl">
                                                      <li> <a class="dropdown-item" id="hide-bn" href="javascript:ansedit(<?=$record->id?>);"> 
                                                       Edit </a></li>
                                                      <li> 
                                                        <a class="dropdown-item" href="javascript:ansdelete(<?=$record->id?>);"> Delete </a>
                                                      </li>
                                                   </ul>
                                                 <?php } ?>
                                                  </div>
                                                <div class="detail-dv-textarea" id="mr<?=$record->id?>">
                                                <div class="new-text-sec-d1" id="qans<?=$record->id?>"><?=stripslashes($record->answer); ?></div>
                                                
                                                <div class="new-text-sec-d1 new-add-email-sec" id="edit<?=$record->id?>" style="display:none;">
                                                    <form name="editfrm<?=$record->id?>" action="<?php echo base_url();?>problems/editanswer/<?=$qus_id?>/<?=$userId?>" 
                                                      method="post">
                                                      <input type="hidden" name="upans_id" value="<?=$record->id?>" />
                                                         <textarea class="form-control" name="updateanswer<?=$record->id?>" rows="20" placeholder="Message..." 
                                                         id="upans<?=$record->id?>">
                                                           <?=stripslashes($record->answer); ?>
                                                         </textarea>
                                                         <script>
                                                           CKEDITOR.replace('updateanswer<?=$record->id?>');
                                                         </script>

                                                          <button type="submit" name="btnedit<?=$record->id?>" id="submit1" style="border:none;">Submit</button>&nbsp;      
                                                          <div id="show-bn-d1" class="d-inline">
                                                          <button type="button" name="canceledit<?=$record->id?>" id="submit1" 
                                                          onclick="javascript:revansedit(<?=$record->id?>);" style="border:none;">Cancel</button>
                                                          </div>
                                                      </form>
                                                </div>
                                                
                                                <div class="more-text-d1" id="more-text1-dv">
                                                     <div class="more-details-sec-dv">
                                                      <div class="main-button1">
                                                      
                                                      <?php if($this->session->userdata('id')!='') { ?>
                                                       <a class="comon-dv-bn" id="btcom<?=$record->id?>" onclick="javascript:addcomment(<?=$record->id?>)"> Add comment</a>
                                                       <a class="comon-dv-bn" id="hbtcom<?=$record->id?>" onclick="javascript:hidecomment(<?=$record->id?>)" 
                                                       style="display:none;"> Add comment</a>
                                                      
                                                       <a class="add-ans-bn-d1" id="btans<?=$record->id?>" onclick="javascript:addanswer(<?=$record->id?>)">
                                                       <i class="fas fa-plus"></i> Add Another Answer
                                                       </a>
                                                       
                                                       <a class="add-ans-bn-d1" id="hbtans<?=$record->id?>" onclick="javascript:hideanswer(<?=$record->id?>)" 
                                                       style="display:none;"><i class="fas fa-plus"></i> Add Another Answer
                                                       </a>
                                                       <?php } else { ?>
                                                        <a class="comon-dv-bn" id="btcom<?=$record->id?>" data-toggle="modal" data-target="#cusModal"> Add comment</a>
                                                       
                                                        <a class="add-ans-bn-d1" id="btans<?=$record->id?>" data-toggle="modal" data-target="#cusModal">
                                                         <i class="fas fa-plus"></i> Add Another Answer
                                                        </a>
                                                       <?php }?>
                                                       
                                                      <?php if($this->session->userdata('id')!='') { ?>
                                                      <a href="javascript: upvote(<?=$record->id?>,<?=$userId?>)" class="up"> 
                                                      <i class="far fa-thumbs-up"></i>  <span id="demo<?=$record->id?>"> <?=$upv?> </span> 
                                                      </a>
                                                      <a href="javascript: downvote(<?=$record->id?>,<?=$userId?>)" class="up"> 
                                                      <i class="far fa-thumbs-down"></i>  <span id="demo2<?=$record->id?>"> <?=$dwv?> </span> 
                                                      </a>
                                                      <?php } else { ?>
                                                      <a href="javascript: void(0);" class="up"> 
                                                         <i class="far fa-thumbs-up"></i>  <span> <?=$upv?> </span> 
                                                      </a>
                                                      <a href="javascript: void(0);" class="up"> 
                                                         <i class="far fa-thumbs-down"></i>  <span> <?=$dwv?> </span> 
                                                      </a>
                                                      <?php }?>
                                                      
                                                      <?php //if($this->session->userdata('id')==$author_id) {?>
                                                      <?php /*?><div class="dropdown detail-dp1">
                                                       <a href="#" class="option-bn-d1" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                                         Option <i class="fas fa-caret-down"></i>
                                                          </a>
                                                         <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                                                            <a class="dropdown-item" href="javascript:ansedit(<?=$record->id?>);"> Edit </a>
                                                            <a class="dropdown-item" href="javascript:ansdelete(<?=$record->id?>);"> Delete </a>
                                                          <?php //} else { ?>
                                                             <!--<a class="dropdown-item" href="#"> Locked </a>-->
                                                          </div>
                                                      </div><?php */?>
                                                      <?php //} ?>
                                                   </div>
                                                   
                                                 <? #################################### Comments & Answer ##################################### ?>   
                                                        
                                                 <div class="comment-sec-d1" id="ad<?=$record->id?>" style="display:none;">
                                                    <div class="detail-comment-sec2 new-dt-sec">
                                                       <form name="frmc<?=$record->id?>" action="<?php echo base_url();?>problems/submitcomment/<?=$qus_id?>/<?=$userId?>" 
                                                       method="post"> 
                                                       <input type="hidden" name="ans_id" value="<?=$record->id?>" />
                                                        <div class="form-group">
                                                          <div class="coment-area-dv">
                                                            <div class="col-md-1 text-right">
                                                            <?php if($username->profile_picture!=""){ ?>
                                                           <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                                                            style="border-radius:50%; width:30px; height:30px;">
                                                           <?php } else {?>
                                                           <i class="fa fa-user" aria-hidden="true"></i>
                                                           <?php }?>
                                                            </div>
                                                            <div class="col-md-9 px-0">
                                                              <input type="text" name="comment<?=$record->id?>" class="form-control" value="" style="font-size:13px;">
                                                            </div>
                                                            <div class="col-md-2">
                                                             <?php //if($this->session->userdata('id')!='') { ?>
                                                              <button type="submit" id="add_comment2" class="comon-dv-bn">Add Comment</button>
                                                             <?php /*} else { ?>
                                                              <button type="button" id="add_comment2" class="comon-dv-bn" data-toggle="modal" data-target="#cusModal"
                                                           style="border: none;">Add Comment</button>
                                                              <?php }*/?>
                                                            </div>
                                                          </div>
                                                        </div>
                                                       </form> 
                                                    </div>
                                                  </div>
                                                  
                                                  <div class="email-sec-d1" id="ans<?=$record->id?>" style="display:none;">
                                                    <div>
                                                      <form name="frm<?=$record->id?>" action="<?php echo base_url();?>problems/submitanswer/<?=$qus_id?>/<?=$userId?>" 
                                                      method="post">
                                                      <input type="hidden" name="ans_id" value="<?=$record->id?>" />
                                                         <textarea class="form-control" name="answer<?=$record->id?>" rows="20" placeholder="Message..." 
                                                         id="ans<?=$record->id?>"></textarea>
                                                         <script>
                                                           CKEDITOR.replace('answer<?=$record->id?>');
                                                         </script>
                                                         <?php //if($this->session->userdata('id')!='') { ?>
                                                          <button type="submit" id="submit1" style="border: none;">Submit</button>
                                                         <?php /*} else { ?>
                                                          <button type="button" id="submit1" data-toggle="modal" data-target="#cusModal"
                                                           style="border: none;">Submit</button>
                                                         <?php }*/?>
                                                      </form>
                                                    </div>
                                                  </div>
                                                 <? ############################ End comments & answer ########################## ?> 
                                                  
                                            </div>
                                            <h5>Comments</h5>
                                            <?php
											  $this->db->order_by('id', 'DESC');
                                              $comment =$this->db->get_where('answer_comment',array('answer_id'=>$record->id));
											  $comnum = $comment->num_rows();
                                              $x = 0;
											  
											  if($comnum!=0) {
                                              foreach($comment->result() as $rec)
                                              {
											    $comId = $rec->id;
												$comauthor = $rec->user_id;
												
                                                $username = $this->db->get_where('user_master',array('id'=>$rec->user_id))->row();
                                                $exdate = explode('-', $rec->post_date);
                                                $postdate = mktime(12,0,0, $exdate[1],$exdate[2],$exdate[0]);
                                                $date = date("F j, Y", $postdate);
												
												  $cvt = $this->db->query("select sum(upvote) as upvot from `comment_up_down` where 
																		  `comment_id` = '".$rec->id."'")->row();
												  $cupv = $cvt->upvot;  
												
												  $cvt2 = $this->db->query("select sum(downvote) as downvot from `comment_up_down` where 
																		`comment_id` = '".$rec->id."'")->row();
												  $cdwv = $cvt2->downvot;
                                            ?>
                                            <div class="detial-new-comon <? if($x!=0){?>reply-div<?=$x?><? }?>">
                                                     <div id="cmt">
                                                         <div class="comment-show-top-new">
                                                           <figure>
                                                            <?php 
                                                              if($username->id=="Admin")
                                                              {
                                                            ?>
                                                               <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" width="30" height="30">
                                                            <?php
                                                             }
                                                             else
                                                             {
                                                               if($username->profile_picture!="")
                                                               {
                                                             ?>
                                                               <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                                                               style="border-radius:50%; width:30px; height:30px;">
                                                            <?php 
                                                               } 
                                                              else
                                                               {
                                                            ?>
                                                               <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                                                            <?php 
                                                               }
                                                             }
                                                            ?>
                                                            </figure>
                                                           <figcaption><?=$username->geek_name?> Commented on <?=$date?></figcaption>
                                                         </div>
                                                         
                                                           <div id="com1<?=$rec->id?>"> <?=stripslashes(str_replace("%20"," ",$rec->comment));?> </div>
                                                      </div> 
                                                        <div class="comment-sec-d1" id="comedit<?=$rec->id?>" style="display:none;">
                                                        <div class="detail-comment-sec2 new-dt-sec">
                                                           
                                                            <div class="form-group">
                                                              <div class="coment-area-dv">
                                                                <div class="col-md-1 text-right">
                                                                   <?php if($username->profile_picture!=""){ ?>
                                                                   <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                                                           		   style="border-radius:50%; width:20px; height:20px;">
                                                           		   <?php } else {?>
                                                                   <i class="fa fa-user" aria-hidden="true"></i>
                                                                   <?php }?>
                                                                </div>
                                                                <div class="col-md-9 px-0">
                                                                  <input type="text" name="commentedit<?=$rec->id?>" id="cedit<?=$rec->id?>" class="form-control" 
                                                                  value="<?=stripslashes(str_replace("%20"," ",$rec->comment));?>" style="font-size:13px;">
                                                                </div>
                                                                <div class="col-md-3">
                                                                  <button type="button" id="add_com<?=$rec->id?>" class="comon-dv-bn" 
                                                                  onclick="javascript:updatecomment(<?=$rec->id?>);">Update</button>
                                                                  
                                                                  <button type="button" id="cancel_com<?=$rec->id?>" class="comon-dv-bn" 
                                                                  onclick="javascript:comcancel(<?=$rec->id?>);">Cancel</button>
                                                                </div>
                                                              </div>
                                                            </div>

                                                        </div>
                                                      </div>
                                                       
                                                      <?php //////////////////////// End Comments //////////////////// ?> 
                                                      
                                                      <?php ///////////////// Reply over comments /////////////////?>
                                                      <div class="comment-sec-bottom1">
                                                       <ul>
                                                          <li class="d-flex">
                                                          <a class="reply-box" id="show-d<?=$rec->id?>" onclick="javascript:replyshow(<?=$rec->id?>);">
                                                             <i class="fa fa-reply"></i> Reply
                                                          </a>
                                                          <a class="reply-box" id="hide-d<?=$rec->id?>" onclick="javascript:replyhide(<?=$rec->id?>);" style="display:none;">
                                                             <i class="fa fa-reply"></i> Reply
                                                          </a>
                                                          
                                                          <?php if($this->session->userdata('id')!='') { ?>
                                                          <a href="javascript: comupvote(<?=$rec->id?>,<?=$userId?>)" class="up">
                                                          <i class="far fa-thumbs-up"></i> <span id="demoo<?=$rec->id?>"> <?=$cupv?> </span>
                                                          </a>
                                                          <a href="javascript: comdownvote(<?=$rec->id?>,<?=$userId?>)" class="up">
                                                          <i class="far fa-thumbs-down"></i> <span id="demoo2<?=$rec->id?>"> <?=$cdwv?> </span>
                                                          </a>
                                                          <?php } else { ?>
                                                          <a href="javascript: void(0);" class="up"> 
                                                             <i class="far fa-thumbs-up"></i>  <span> <?=$cupv?> </span> 
                                                          </a>
                                                          <a href="javascript: void(0);" class="up"> 
                                                             <i class="far fa-thumbs-down"></i>  <span> <?=$cdwv?> </span> 
                                                          </a>
                                                          <?php }?>
                                                          
                                                          <?php if($this->session->userdata('id')== $comauthor) {?>
                                                            <div class="dropdown detail-dp1">
                                                               <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                                               <i class="fas fa-ellipsis-h"></i> 
                                                               </a>
                                                               <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                                                                  <a class="dropdown-item" href="javascript:editcomment(<?=$rec->id?>);"> Edit </a>
                                                                  <a class="dropdown-item" href="javascript:removecomment(<?=$rec->id?>);"> Delete </a>
                                                                  <? //} else { ?>
                                                                </div>
                                                            </div>
                                                            <?php }?>
                                                            
                                                          </li>
                                                        </ul>
                                                     </div>
                                                     
                                                      <form name="frmreply<?=$rec->id?>" action="<?php echo base_url();?>problems/submitreply/<?=$qus_id?>/<?=$userId?>"
                                                       method="post">
                                                     <input type="hidden" name="comment_id" value="<?=$rec->id?>" />
                                                     <div class="chat-sec-1" id="chat-d<?=$rec->id?>" style="display:none;">
                                                         <div class="comment-area2">
                                                               <div class="form-group">
                                                                   <textarea name="reply<?=$rec->id?>" class="form-control" style="font-size:13px;" required></textarea>
                                                               </div>
                                                               <?php if($this->session->userdata('id')!='') { ?>
                                                               <button type="submit" class="rely-dv-bn" id="hide-d<?=$rec->id?>">Reply</button>
                                                               <?php } else { ?>
                                                               <button type="button" class="rely-dv-bn" id="hide-d<?=$rec->id?>" data-toggle="modal" 
                                                               data-target="#cusModal">Reply</button>
                                                             <?php }?>
                                                         </div>
                                                         <hr>
                                                    </div>
                                                    </form>
                                                    
                                                      <?php ///////////////// End Reply over comments /////////////////?>
                                                       
                                                      <?php
                                                          $reply =$this->db->get_where('reply_master',array('comment_id'=>$rec->id));
														  $x = 0;
														  
														  foreach($reply->result() as $rex)
														  {
														    $relauthor = $rex->user_id;
															
														    $uname = $this->db->get_where('user_master',array('id'=>$rex->user_id))->row();
															$exdt = explode('-', $rex->post_date);
															$postdt = mktime(12,0,0, $exdt[1],$exdt[2],$exdt[0]);
															$dt = date("F j, Y", $postdt);
															
															  $cvt3 = $this->db->query("select sum(upvote) as upvot from `reply_up_down` where 
																		              `reply_id` = '".$rex->id."'")->row();
															  $cupv3 = $cvt3->upvot;  
															
															  $cvt3 = $this->db->query("select sum(downvote) as downvot from `reply_up_down` where 
																					   `reply_id` = '".$rex->id."'")->row();
															  $cdwv3 = $cvt3->downvot;
													   ?>
                                                       <div class="comment-show-top-new">
                                                       <figure>
                                                        <?php 
                                                          if($uname->id=="Admin")
                                                          {
                                                        ?>
                                                           <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" width="25" height="25">
                                                        <?php
                                                         }
                                                         else
                                                         {
                                                           if($uname->profile_picture!="")
                                                           {
                                                         ?>
                                                           <img src="<?php echo base_url();?>uploads/<?=$uname->profile_picture?>" alt="user" 
                                                           style="border-radius:50%; width:30px; height:30px;">
                                                        <?php 
                                                           } 
                                                          else
                                                           {
                                                        ?>
                                                           <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                                                        <?php 
                                                           }
                                                         }
                                                        ?>
                                                        </figure>
                                                       <figcaption>
                                                        <?=$uname->name?> Replied on <?=$dt?>
                                                       </figcaption>
                                                     </div>
                                                     
                                                     <div style="padding-left:10px; line-height:20px;" id="rep<?=$rex->id?>"><?=stripslashes($rex->reply)?></div>
                                                     
                                                     <div class="chat-sec-1" id="rep-d<?=$rex->id?>" style="display:none;">
                                                     
                                                     <form name="frmedit" action="<?php echo base_url();?>problems/editreply/<?=$rex->id?>" method="post">
                                                     <input type="hidden" name="ques_id" value="<?=$qus_id?>" />
                                                     <div class="comment-area2">
                                                       <div class="form-group">
                                                           <input type="text" name="redit<?=$rex->id?>" class="form-control" style="font-size:13px;" 
                                                           value="<?=stripslashes($rex->reply)?>" required>
                                                       </div>
                                                        <button type="submit" class="rely-dv-bn" id="hide-d<?=$rex->id?>">Update</button>
                                                        <button type="button" class="rely-dv-bn" onclick="javascript:reveditreply(<?=$rex->id?>);">Cancel</button>
                                                      </div>
                                                      </form>
                                                      
                                                     <hr>
                                                    </div>
                                                     
                                                     
                                                      <?php ///////////////// Reply over reply /////////////////?>
                                                      <div class="comment-sec-bottom1">
                                                       <ul>
                                                          <li class="d-flex">
                                                          <a class="reply-box" id="show-d_1<?=$rex->id?>" onclick="javascript:replyshow_1(<?=$rex->id?>);">
                                                             <i class="fa fa-reply"></i> Reply
                                                          </a>
                                                          <a class="reply-box" id="hide-d_1<?=$rex->id?>" onclick="javascript:replyhide_1(<?=$rex->id?>);" style="display:none;">
                                                             <i class="fa fa-reply"></i> Reply
                                                          </a>
                                                          
                                                          <?php if($this->session->userdata('id')!="") {?>
                                                          <a href="javascript: comupvote_1(<?=$rex->id?>,<?=$userId?>)" class="up">
                                                          <i class="far fa-thumbs-up"></i> <span id="demoo_1<?=$rex->id?>"> <?=$cupv3?> </span>
                                                          </a>
                                                          <a href="javascript: comdownvote_1(<?=$rex->id?>,<?=$userId?>)" class="up">
                                                          <i class="far fa-thumbs-down"></i> <span id="demoo2_1<?=$rex->id?>"> <?=$cdwv3?> </span>
                                                          </a>
                                                           <?php } else { ?>
                                                              <a href="javascript: void(0)" class="up">
                                                                <i class="far fa-thumbs-up"></i> <span> <?=$cupv3?> </span>
                                                              </a>
                                                              <a href="javascript: void(0)" class="up">
                                                                <i class="far fa-thumbs-down"></i> <span> <?=$cdwv3?> </span>
                                                              </a> 
                                                           <?php }?>
                                                           
                                                           <?php if($this->session->userdata('id')== $relauthor) {?>
                                                            <div class="dropdown detail-dp1">
                                                               <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                                               <i class="fas fa-ellipsis-h"></i> 
                                                               </a>
                                                               <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                                                                  
                                                                  <a class="dropdown-item" href="javascript:editreply(<?=$rex->id?>);"> Edit </a>
                                                                  <a class="dropdown-item" href="javascript:removereply(<?=$rex->id?>);"> Delete </a>
                                                                  <?php //} else { ?>
                                                                </div>
                                                            </div>
                                                            <?php }?>
                                                            
                                                          </li>
                                                     </ul>
                                               </div>
                                                     
                                                     <form name="subreply<?=$rex->id?>" action="<?php echo base_url();?>problems/submitreply/<?=$qus_id?>/<?=$userId?>"
                                                     method="post">
                                                     <input type="hidden" name="comment_id" value="<?=$comId?>" />
                                                     <div class="chat-sec-1" id="chat-d_1<?=$rex->id?>" style="display:none;">
                                                         <div class="comment-area2">
                                                               <div class="form-group">
                                                                   <textarea name="reply<?=$comId?>" class="form-control" style="font-size:13px;" required></textarea>
                                                               </div>
                                                               <?php if($this->session->userdata('id')!='') { ?>
                                                               <button type="submit" class="rely-dv-bn" id="hide-d_1<?=$rex->id?>">Reply</button>
                                                               <?php } else { ?>
                                                               <button type="button" class="rely-dv-bn" id="hide-d_1<?=$rex->id?>" data-toggle="modal" 
                                                               data-target="#cusModal">Reply</button>
                                                             <?php }?>
                                                         </div>
                                                         <hr>
                                                    </div>
                                                    </form>
                                                      <?php ///////////////// End Reply over reply /////////////////?>
                                                         
                                                       <?php
                                                          }
													   ?>
                                                    <hr />
                                                  </div>
												  <?php
                                                      $x++;
                                                    } /// End Comments
												   
												  }
												  else
												  { 
                                               ?>
                                                 <p align="center">No comments found.</p>
                                               <?php
                                                  }
											   ?>
                                         </div>
                                                 
                                     </div>
                                   <a class="comon-more-bn1 red-more-show-d1" id="more-bn-dv<?=$record->id?>" onclick="javascript:readmore(<?=$record->id?>)">Read more</a> 
                                   <a class="comon-more-bn1" id="more-bn-dvc<?=$record->id?>" onclick="javascript:readless(<?=$record->id?>)" style="display:none;">Read less</a>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php
											$i++;
										  }  /// End answer loop
										?>    
                                       </div> 
                                    </div>
                                    <script>
										function readmore(id)
										{
											 document.getElementById("mr"+id).classList.remove("detail-dv-textarea");
											 document.getElementById("mr"+id).classList.add("detail-dv-textarea-next");
											 document.getElementById("more-bn-dv"+id).style.display='none';
											 document.getElementById("more-bn-dvc"+id).style.display='block';
										}
										
										function readless(id)
										{
											 document.getElementById("mr"+id).classList.add("detail-dv-textarea");
											 document.getElementById("mr"+id).classList.remove("detail-dv-textarea-next");
											 document.getElementById("more-bn-dv"+id).style.display='block';
											 document.getElementById("more-bn-dvc"+id).style.display='none';
										}
										
										function replyshow(id)
										{
											 document.getElementById("chat-d"+id).style.display='block';
											 document.getElementById("show-d"+id).style.display='none';
											 document.getElementById("hide-d"+id).style.display='block';
										}
										
										function replyhide(id)
										{
											 document.getElementById("chat-d"+id).style.display='none';
											 document.getElementById("show-d"+id).style.display='block';
											 document.getElementById("hide-d"+id).style.display='none';
										}
										
										function replyshow_1(id)
										{
											 document.getElementById("chat-d_1"+id).style.display='block';
											 document.getElementById("show-d_1"+id).style.display='none';
											 document.getElementById("hide-d_1"+id).style.display='block';
										}
										
										function replyhide_1(id)
										{
											 document.getElementById("chat-d_1"+id).style.display='none';
											 document.getElementById("show-d_1"+id).style.display='block';
											 document.getElementById("hide-d_1"+id).style.display='none';
										}
										
										function addcomment(id)
										{
										   document.getElementById("btcom"+id).style.display='none';
										   document.getElementById("hbtcom"+id).style.display='block';
										   
										   document.getElementById("ad"+id).style.display='block';
										   document.getElementById("ans"+id).style.display='none';
										}
										
										function addanswer(id)
										{
										   document.getElementById("hbtans"+id).style.display='block';
										   document.getElementById("btans"+id).style.display='none';
										   
										   document.getElementById("ad"+id).style.display='none';
										   document.getElementById("ans"+id).style.display='block';
										}
										
										function hidecomment(id)
										{
										   document.getElementById("btcom"+id).style.display='block';
										   document.getElementById("hbtcom"+id).style.display='none';
										   
										   document.getElementById("ad"+id).style.display='none';
										}
										
										function hideanswer(id)
										{
										   document.getElementById("hbtans"+id).style.display='none';
										   document.getElementById("btans"+id).style.display='block';
										   
										   document.getElementById("ans"+id).style.display='none';
										}
										
										function ansedit(id)
										{
										   document.getElementById("qans"+id).style.display='none';
										   document.getElementById("edit"+id).style.display='block';
										   document.getElementById("more-bn-dv"+id).style.display='none';
										}
										
										function revansedit(id)
										{
										   document.getElementById("qans"+id).style.display='block';
										   document.getElementById("edit"+id).style.display='none';
										}
										
										function editcomment(id)
										{
										   document.getElementById("com1"+id).style.display='none';
										   document.getElementById("comedit"+id).style.display='block';
										}
										
										function deletecomment(id)
										{
										   document.getElementById("qans"+id).style.display='block';
										   document.getElementById("edit"+id).style.display='none';
										}
										
										function comcancel(id)
										{
										   document.getElementById("com1"+id).style.display='block';
										   document.getElementById("comedit"+id).style.display='none';
										}
										
										function editreply(id)
										{
										   document.getElementById("rep-d"+id).style.display='block';
										   document.getElementById("rep"+id).style.display='none';
										}
										
										function reveditreply(id)
										{
										   document.getElementById("rep-d"+id).style.display='none';
										   document.getElementById("rep"+id).style.display='block';
										}
								   </script>
                                   
                                   <script>
									function upvote(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/ansupvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demo"+id).innerHTML = xhttp.responseText;
									}
									
									function downvote(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/ansdownvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demo2"+id).innerHTML = xhttp.responseText;
									}
									
									function comupvote(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/comupvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demoo"+id).innerHTML = xhttp.responseText;
									}
									
									function comdownvote(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/comdownvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demoo2"+id).innerHTML = xhttp.responseText;
									}
									
									function comupvote_1(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/replyupvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demoo_1"+id).innerHTML = xhttp.responseText;
									}
									
									function comdownvote_1(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/replydownvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demoo2_1"+id).innerHTML = xhttp.responseText;
									}
									
									function ansdelete(id) {
										  var xhttp = new XMLHttpRequest();
										  xhttp.open("GET", "<?php echo base_url();?>problems/deleteanswer/"+id, false);
										  xhttp.send();
										  /*xhttp.responseText;*/
										  location.reload(true);
									}
									
									function updatecomment(id)
									{
									      var content = document.getElementById('cedit'+id).value;
									      var xhttp = new XMLHttpRequest();
										  xhttp.open("GET", "<?php echo base_url();?>problems/editcomment/"+id+"/"+content, false);
										  xhttp.send();
										  location.reload(true);
									}
									
									function removecomment(id) {
										  var xhttp = new XMLHttpRequest();
										  xhttp.open("GET", "<?php echo base_url();?>problems/deletecomment/"+id, false);
										  xhttp.send();
										  /*xhttp.responseText;*/
										  location.reload(true);
									}
									
									function updatereply(id)
									{
									      var content = document.getElementById('redit'+id).value;
									      var xhttp = new XMLHttpRequest();
										  xhttp.open("GET", "<?php echo base_url();?>problems/editreply/"+id+"/"+content, false);
										  xhttp.send();
										  
										  location.reload(true);
									}
									
									function removereply(id) {
										  var xhttp = new XMLHttpRequest();
										  xhttp.open("GET", "<?php echo base_url();?>problems/deletereply/"+id, false);
										  xhttp.send();
										  /*xhttp.responseText;*/
										  location.reload(true);
									}
									</script>
                                   
                                  <? ########################## Related Questions ############################## ?> 
                                  
                                  <?php
                                  	 $sql=$this->db->query("select * from `questions_master` where `sub_sub_cat_id` = '".$sub_sub_cat->id."'");
									 $cnt = $sql->num_rows();
									 
									 if($cnt!=0) {
								  ?>
                                  
                                  <div class="related-question-area">
                                        <div class="sub-hedding-d1">
                                          <h2> Related Question</h2>
                                        </div>
                                  </div>
								  <?php }?>
								  <div class="answer-part2">
                                    <div id="headingOne" class="accordion">
                                    <?php
									   // Start question loop
									   foreach($sql->result() as $rs)
									   {
									     $qId = $rs->id;
										 
										 $this->db->order_by('upvote', 'DESC');
									     $relanswer=$this->db->get_where('answers_master',array('question_id'=>$rs->id));
										 $anscnt = $relanswer->num_rows();
										 										 
									     if($rs->question!=$question->question)
										 {
									?>
                                       <div class="card-header collapsed" data-toggle="collapse" data-target="#collapse<?=$rs->id?>" aria-expanded="true" 
                                       aria-controls="collapseOne">
                                            <a class="card-title"><?=$rs->question?></a>
                                        </div>

                                       <div id="collapse<?=$rs->id?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                        <ul class="categories-d1">
                                            <li> Categories: </li>
                                            <li> <a href="#"> <?=$sub_sub_cat->sub_sub_category_name;?> </a> </li>
                                        </ul>
                                        <div class="card-body p-0" id="child1">
                                        <div class="card sub-related-ans-area">
                                        
                                        <?php 
										  if($anscnt!=0) 
										  {
										      $a = 1;
											  // start answer loop
											  foreach($relanswer->result() as $rx) 
											  {
											      $author_id = $rx->user_id;
												 
												  $xdate = explode('-', $rx->post_date);
												  $pdate = mktime(12,0,0, $xdate[1],$xdate[2],$xdate[0]);
												  $ansdate = date("F j, Y", $pdate);
												  
												  $uid = $this->db->get_where('user_master',array('id'=>$rx->user_id))->row();
												  $fixergeek=$this->db->get_where('fixergeek_master',array('user_id'=>$rx->user_id))->row();
												  
												  $vt = $this->db->query("select sum(upvote) as upvot from `answer_up_down` where `answer_id` = '".$rx->id."'")->row();
												  $upv = $vt->upvot;  
												
												  $vt2 = $this->db->query("select sum(downvote) as downvot from `answer_up_down` where `answer_id` = '".$rx->id."'")->row();
												  $dwv = $vt2->downvot;
											?>
											<div class="card-header collapsed" data-toggle="collapse" data-target="#collapse<?=$rx->id?>">
											   <a class="card-title">
												  Answer #<?=$a?> by 
												  
                                                  <?php 
												  if($uid->id=="Admin")
												  {
												  ?>
												   <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" 
                                                   style="border-radius:50%; width:20px; height:20px;">
												<?php
												 }
												 else
												 {
												   if($uid->profile_picture!="")
												   {
												 ?>
												   <img src="<?php echo base_url();?>uploads/<?=$uid->profile_picture?>" alt="user" 
												   style="border-radius:50%; width:20px; height:20px;">
												<?php 
												   } 
												  else
												   {
												?>
												   <i class="far fa-user-circle"></i>
												<?php 
												   }
												 }
												?>
                                                  
												<?=$uid->geek_name?> Posted on <?=$ansdate?> <!--@--> <? /*$rx->post_time?> - <?=$fixergeek->timezone*/ ?>
											   </a>
											</div>
											
											<div class="card-body collapse" data-parent="#child1" id="collapse<?=$rx->id?>">
											<div class="comon-text-area comon-space">
											  <?php if($this->session->userdata('id')==$author_id) {?>
                                                   <ul class="new-add-dl">
                                                      <li> <a class="dropdown-item" href="javascript:ansedit2(<?=$rx->id?>);"> Edit </a></li>
                                                      <li> 
                                                        <a class="dropdown-item" href="javascript:ansdelete2(<?=$rx->id?>);"> Delete </a>
                                                      </li>
                                                   </ul>
                                              <?php } ?>
											<div class="detail-dv-textarea" id="rq<?=$rx->id?>">
												  <div class="new-text-sec-d1 " id="qans2<?=$rx->id?>"> <?=stripslashes($rx->answer); ?></div>
                                                  
                                                  <div class="new-text-sec-d1 new-add-email-sec" id="edit2<?=$rx->id?>" style="display:none;">
                                                    <form name="editfrm2<?=$rx->id?>" action="<?php echo base_url();?>problems/releditanswer/<?=$qId?>/<?=$userId?>" 
                                                      method="post">
                                                      <input type="hidden" name="upans_id2" value="<?=$rx->id?>" />
                                                         <textarea class="form-control" name="updateanswer2<?=$rx->id?>" rows="20" placeholder="Message..." 
                                                         id="upans2<?=$rx->id?>">
                                                           <?=stripslashes($rx->answer); ?>
                                                         </textarea>
                                                         <script>
                                                           CKEDITOR.replace('updateanswer2<?=$rx->id?>');
                                                         </script>

                                                          <button type="submit" name="btnedit2<?=$rx->id?>" id="submit1" style="border:none;">Submit</button>&nbsp;
                                                          <div id="show-bn-d1" class="d-inline">
                                                          <button type="button" name="canceledit2<?=$rx->id?>" id="submit1" 
                                                          onclick="javascript:revansedit2(<?=$rx->id?>);" style="border:none;">Cancel</button>
                                                          </div>
                                                      </form>
                                                </div>
                                                  
                                                  
												  <div class="more-text2" id="more-text1-dv2<?=$rx->id?>">
													 <div class="more-details-sec-dv">
													  <div class="main-button1">
                                                      
													  <?php if($this->session->userdata('id')!='') { ?>  
                                                      <a class="comon-dv-bn" id="btcom<?=$rx->id?>" onclick="javascript:addcomment2(<?=$rx->id?>)"> Add comment</a>
                                                      <a class="comon-dv-bn" id="hbtcom<?=$rx->id?>" onclick="javascript:hidecomment2(<?=$rx->id?>)" style="display:none;"> 
                                                        Add comment
                                                      </a>
                                                      
                                                      <a class="comon-dv-bn" id="btans<?=$rx->id?>" onclick="javascript:addanswer2(<?=$rx->id?>)"> Add Another Answer</a>
                                                      <a class="comon-dv-bn" id="hbtans<?=$rx->id?>" onclick="javascript:hideanswer2(<?=$rx->id?>)" style="display:none;"> 
                                                       Add Another Answer
                                                      </a>
                                                      <?php } else { ?>
                                                      <a class="comon-dv-bn" id="btcom<?=$rx->id?>" data-toggle="modal" data-target="#cusModal"> Add comment</a>
                                                      <a class="comon-dv-bn" id="btans<?=$rx->id?>" data-toggle="modal" data-target="#cusModal"> Add Another Answer</a>
                                                      <?php }?>
                                                      
                                                      <?php if($this->session->userdata('id')!='') { ?>  
                                                          <a href="javascript:upvote2(<?=$rx->id?>,<?=$userId?>)" class="up"> 
                                                             <i class="far fa-thumbs-up"></i> <span id="demi<?=$rx->id?>"> <?=$upv?> </span> 
                                                          </a>
                                                          <a href="javascript:downvote2(<?=$rx->id?>,<?=$userId?>)" class="up"> 
                                                             <i class="far fa-thumbs-down"></i> <span id="demi2<?=$rx->id?>"> <?=$dwv?> </span> 
                                                          </a>
                                                      <?php } else { ?>
                                                         <a href="javascript:void(0);" class="up"> 
                                                             <i class="far fa-thumbs-up"></i> <span> <?=$upv?> </span> 
                                                          </a>
                                                          <a href="javascript:void(0);" class="up"> 
                                                             <i class="far fa-thumbs-down"></i> <span> <?=$dwv?> </span> 
                                                          </a>
                                                      <?php }?>
                                                      
                                                     <?php if($this->session->userdata('id')==$author_id) {?>
                                                      <!--<div class="dropdown detail-dp1">
													 <a href="#" id="dropdownMenuButton" class="option-bn-d1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
														Option <i class="fas fa-caret-down"></i>
													 </a>
                                                     <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                                                         
                                                            <a class="dropdown-item" href="javascript:ansedit2(<?=$rx->id?>);"> Edit </a>
                                                            <a class="dropdown-item" href="javascript:ansdelete2(<?=$rx->id?>);"> Delete </a>
                                                          <?php //} else { ?>
                                                          
                                                      </div>
                                                  </div>-->
                                                  <?php }?>
                                                  
                                               </div>
													   
                                             <div id="ad2<?=$rx->id?>" class="comment-sec-d1">
                                                <div class="detail-comment-sec2 new-dt-sec">
                                                  <form name="frm<?=$rx->id?>" action="<?php echo base_url();?>problems/submitcomment/<?=$qId?>/<?=$userId?>" method="post">
                                                  <input type="hidden" name="ans_id" value="<?=$rx->id?>" /> 
                                                    <div class="form-group">
                                                      <div class="coment-area-dv">
                                                        <div class="col-md-1 text-right">
                                                         <?php
														 if($username->profile_picture!="")
                                                         {  
														?>
                                                          <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                                                       style="border-radius:50%; width:20px; height:20px;">
                                                        <?php } else {?>
                                                          <i class="fa fa-user" aria-hidden="true"></i>
                                                         <?php }?>
                                                        </div>
                                                        <div class="col-md-9 px-0">
                                                         <input type="text" name="comment<?=$rx->id?>" class="form-control" style="font-size:13px;">
                                                        </div>
                                                        <div class="col-md-2">
                                                        <?php //if($this->session->userdata('id')!='') { ?>
                                                         <button type="submit" id="add_comment2" class="comon-dv-bn">Add Comment</button>
                                                        <?php /*} else { ?>
                                                         <button type="button" id="add_comment2" class="comon-dv-bn" data-toggle="modal" data-target="#cusModal" 
                                                      style="border: none;">Add Comment</button>
                                                         <?php }*/?>
                                                        </div>
                                                      </div>
                                                    </div>
                                                   </form> 
                                                </div>
                                              </div>
                                              
                                              <div id="ans2<?=$rx->id?>" class="comment-sec-d1">
                                                <div id="anstext<?=$val->id?>">
                                                  <form name="frm<?=$rx->id?>" action="<?php echo base_url();?>problems/submitanswer/<?=$qId?>/<?=$userId?>" 
                                                  method="post">
                                                  <input type="hidden" value="<?=$rx->id?>" name="ans_id" />
                                                     <textarea class="form-control" name="answer<?=$rx->id?>" rows="20" placeholder="Message..." 
                                                     id="ans<?=$rx->id?>"></textarea>
                                                     <script>
                                                       CKEDITOR.replace('answer<?=$rx->id?>');
                                                     </script>
                                                     <?php //if($this->session->userdata('id')!='') { ?>
                                                      <button type="submit" id="submit1" style="border: none;">Submit</button>
                                                     <?php /*} else { ?>
                                                      <button type="button" id="submit1" data-toggle="modal"  data-target="#cusModal" 
                                                      style="border: none;">Submit</button>
                                                     <?php }*/?>
                                                  </form>
                                                </div>
                                              </div>
                                         </div>
                                                     
                                          <h5>Comments</h5>
                                           <?php
                                              $comment2 =$this->db->get_where('answer_comment',array('answer_id'=>$rx->id));
											  $cntnum = $comment2->num_rows();
                                              $k = 0;
											  
											  if($cntnum!=0) {
                                              foreach($comment2->result() as $rec)
                                              {
											    $comId = $rec->id;
												$authorcom = $rec->user_id;
												
                                                $username = $this->db->get_where('user_master',array('id'=>$rec->user_id))->row();
                                                $exdate = explode('-', $rec->post_date);
                                                $postdate = mktime(12,0,0, $exdate[1],$exdate[2],$exdate[0]);
                                                $date = date("F j, Y", $postdate);
												
												$cvt = $this->db->query("select sum(upvote) as upvot from `comment_up_down` where `comment_id` = '".$rec->id."'")->row();
											    $cupv = $cvt->upvot;  
											
											    $cvt2 = $this->db->query("select sum(downvote) as downvot from `comment_up_down` where `comment_id` = '".$rec->id."'")->row();
											    $cdwv = $cvt2->downvot;
                                            ?>
                                            
                                          <div class="detial-new-comon reply-div">
                                                
                                                 <div class="comment-show-top-new">
                                                   <figure>
                                                     
                                                    <?php 
                                                      if($username->id=="Admin")
                                                      {
                                                    ?>
                                                       <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" 
                                                       style="border-radius:50%; width:30px; height:30px;">
                                                    <?php
                                                     }
                                                     else
                                                     {
                                                       if($username->profile_picture!="")
                                                       {
                                                     ?>
                                                       <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                                                       style="border-radius:50%; width:30px; height:30px;">
                                                    <?php 
                                                       } 
                                                      else
                                                       {
                                                    ?>
                                                      <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                                                    <?php 
                                                       }
                                                     }
                                                    ?>
                                                    </figure>
                                                   <figcaption>
                                                    <?=$username->name?> Commented on <?=$date?>
                                                   </figcaption>
                                                  </div>
                                                  <p id="com_1<?=$comId?>"><?=stripslashes(str_replace("%20"," ",$rec->comment))?></p>
                                                  
                                                <div id="com_edit<?=$comId?>" class="comment-sec-d1">
                                                <div class="detail-comment-sec2 new-dt-sec">
                                                  <form name="frm<?=$comId?>" action="<?php echo base_url();?>problems/editcomment2/<?=$comId?>" method="post">
                                                  <input type="hidden" name="ques_id" value="<?=$qId?>" /> 
                                                    <div class="form-group">
                                                      <div class="coment-area-dv">
                                                        <div class="col-md-1 text-right">
                                                        <?php
														 if($username->profile_picture!="")
                                                         {  
														?>
                                                        <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" 
                                                          style="border-radius:50%; width:20px; height:20px;">
                                                        <?php } else {?>
                                                          <i class="fa fa-user" aria-hidden="true"></i>
                                                         <?php }?>
                                                        </div>
                                                        <div class="col-md-9 px-0">
                                                         <input type="text" name="cedit2<?=$comId?>" class="form-control" style="font-size:13px;" 
                                                         value="<?=stripslashes(str_replace("%20"," ",$rec->comment))?>">
                                                        </div>
                                                    <div class="col-md-3">
                                                    
                                                     <button type="submit" id="e_comment2<?=$comId?>" class="comon-dv-bn" onclick="javascript:updatecomment2(<?=$comId?>);">
                                                       Update
                                                     </button>
                                                     <button type="button" id="d_comment2<?=$comId?>" class="comon-dv-bn" onclick="javascript:comcancel2(<?=$comId?>);">
                                                       Cancel
                                                     </button>
                                                     
                                                    </div>
                                                  </div>
                                                </div>
                                               </form> 
                                            </div>
                                          </div>
                                                  
                                                  <? /////////////////////////  Reply for comments /////////////////////////////// ?>
                                                  
                                                <div class="comment-sec-bottom1">
                                                   <ul>
                                                      <li class="d-flex">
                                                         <a class="reply-box" id="show-d2<?=$rec->id?>" onclick="javascript:replyshow2(<?=$rec->id?>);">
                                                             <i class="fa fa-reply"></i> Reply
                                                          </a>
                                                          <a class="reply-box" id="hide-d2<?=$rec->id?>" onclick="javascript:replyhide2(<?=$rec->id?>);" 
                                                          style="display:none;"><i class="fa fa-reply"></i> Reply
                                                          </a>
                                                       
                                                        <?php if($this->session->userdata('id')!="") {?>   
                                                         <a href="javascript:comupvote2(<?=$rec->id?>,<?=$userId?>)" class="up">
                                                          <i class="far fa-thumbs-up"></i><span id="demoox<?=$rec->id?>"> <?=$cupv?> </span>  
                                                         </a>
                                                         <a href="javascript:comdownvote2(<?=$rec->id?>,<?=$userId?>)" class="up"> 
                                                           <i class="far fa-thumbs-down"></i><span id="demoox2<?=$rec->id?>"> <?=$cdwv?> </span> 
                                                         </a>
                                                         <?php } else { ?>
                                                         <a href="javascript:void(0);" class="up">
                                                          <i class="far fa-thumbs-up"></i><span> <?=$cupv?> </span>  
                                                         </a>
                                                         <a href="javascript:void(0)" class="up"> 
                                                           <i class="far fa-thumbs-down"></i><span> <?=$cdwv?> </span> 
                                                         </a>
                                                         <?php }?>
                                                         
                                                         <?php if($this->session->userdata('id')== $authorcom) {?>
                                                        <div class="dropdown detail-dp1">
                                                           <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                                             <i class="fas fa-ellipsis-h"></i> 
                                                            </a>
                                                           <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                                                              <a class="dropdown-item" href="javascript:editcomment2(<?=$rec->id?>);"> Edit </a>
                                                              <a class="dropdown-item" href="javascript:removecomment2(<?=$rec->id?>);"> Delete </a>
                                                              <?php //} else { ?>
                                                            </div>
                                                        </div>
                                                        <?php }?>
                                                      </li>
                                                    </ul>
                                                   </div>
                                                   
                                                     <form name="frmreply<?=$rec->id?>" action="<?php echo base_url();?>problems/submitreply/<?=$qId?>/<?=$userId?>"
                                                       method="post">
                                                     <input type="hidden" name="comment_id" value="<?=$comId?>" />
                                                     <div class="chat-sec-1" id="chat-d2<?=$rec->id?>" style="display:none;">
                                                         <div class="comment-area2">
                                                               <div class="form-group">
                                                                   <textarea name="reply<?=$rec->id?>" class="form-control" style="font-size:13px;" required></textarea>
                                                               </div>
                                                               <?php if($this->session->userdata('id')!='') { ?>
                                                               <button type="submit" class="rely-dv-bn" id="hide-d2<?=$rec->id?>">Reply</button>
                                                               <?php } else { ?>
                                                               <button type="button" class="rely-dv-bn" id="hide-d2<?=$rec->id?>" data-toggle="modal" 
                                                               data-target="#cusModal">Reply</button>
                                                             <?php }?>
                                                         </div>
                                                         <hr>
                                                    </div>
                                                    </form>
                                                  
                                                  <? /////////////////////////// End Reply //////////////////////////////////////// ?>
                                                 
												  <?php
                                                      $reply =$this->db->get_where('reply_master',array('comment_id'=>$rec->id));
                                                      $x = 0;
                                                      foreach($reply->result() as $rex)
                                                      {
													    $authorrep = $rex->user_id;
                                                        $uname = $this->db->get_where('user_master',array('id'=>$rex->user_id))->row();
                                                        $exdt = explode('-', $rex->post_date);
                                                        $postdt = mktime(12,0,0, $exdt[1],$exdt[2],$exdt[0]);
                                                        $dt = date("F j, Y", $postdt);
														
														$rcvt = $this->db->query("select sum(upvote) as upvot from `reply_up_down` where 
																				`reply_id` = '".$rex->id."'")->row();
														$rcupv = $rcvt->upvot;  
													
														$rcvt2 = $this->db->query("select sum(downvote) as downvot from `reply_up_down` where 
																				 `reply_id` = '".$rex->id."'")->row();
														$rcdwv = $rcvt2->downvot;
                                                   ?>
                                                   <div class="comment-show-top-new">
                                                   <figure>
                                                    <?php 
                                                      if($uname->id=="Admin")
                                                      {
                                                    ?>
                                                       <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" width="30" height="30">
                                                    <?php
                                                     }
                                                     else
                                                     {
                                                       if($uname->profile_picture!="")
                                                       {
                                                     ?>
                                                       <img src="<?php echo base_url();?>uploads/<?=$uname->profile_picture?>" alt="user" 
                                                       style="border-radius:50%; width:30px; height:30px;">
                                                    <?php 
                                                       } 
                                                      else
                                                       {
                                                    ?>
                                                       <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                                                    <?php 
                                                       }
                                                     }
                                                    ?>
                                                    </figure>
                                                   <figcaption>
                                                    <?=$uname->name?> Replied on <?=$dt?>
                                                   </figcaption>
                                                 </div>
                                                     <p style="padding-left:10px; line-height:20px;" id="rep2<?=$rex->id?>"><?=stripslashes($rex->reply)?></p>
                                                     
                                                     <div class="chat-sec-1" id="rep-d2<?=$rex->id?>" style="display:none;">
                                                     
                                                     <form name="frmedit" action="<?php echo base_url();?>problems/editreply/<?=$rex->id?>" method="post">
                                                     <input type="hidden" name="ques_id" value="<?=$qId?>" />
                                                     <div class="comment-area2">
                                                       <div class="form-group">
                                                           <input type="text" name="redit<?=$rex->id?>" class="form-control" style="font-size:13px;" 
                                                           value="<?=stripslashes($rex->reply)?>" required>
                                                       </div>
                                                        <button type="submit" class="rely-dv-bn" id="hide-d<?=$rex->id?>">Update</button>
                                                        <button type="button" class="rely-dv-bn" onclick="javascript:reveditreply2(<?=$rex->id?>);">Cancel</button>
                                                      </div>
                                                      </form>
                                                      
                                                     <hr>
                                                    </div>
                                                  
                                                   <?php  ///////////////////////////// Reply over reply /////////////////////////////// ?>
                                                    
                                                  <div class="comment-sec-bottom1">
                                                   <ul>
                                                      <li class="d-flex">
                                                         <a class="reply-box" id="show-d2_1<?=$rex->id?>" onclick="javascript:replyshow2_1(<?=$rex->id?>);">
                                                             <i class="fa fa-reply"></i> Reply
                                                          </a>
                                                          <a class="reply-box" id="hide-d2_1<?=$rex->id?>" onclick="javascript:replyhide2_1(<?=$rex->id?>);" 
                                                          style="display:none;"><i class="fa fa-reply"></i> Reply
                                                          </a>
                                                          
                                                        <a href="javascript:replyupvote2_1(<?=$rex->id?>)" class="up">
                                                          <i class="far fa-thumbs-up"></i><span id="demooxr<?=$rex->id?>"> <?=$rcupv?> </span>  
                                                        </a>
                                                        <a href="javascript:replydownvote2_1(<?=$rex->id?>)" class="up"> 
                                                           <i class="far fa-thumbs-down"></i><span id="demoox2r<?=$rex->id?>"> <?=$rcdwv?> </span> 
                                                        </a>
                                                        
                                                        <?php if($this->session->userdata('id')== $authorrep) {?>
                                                        <div class="dropdown detail-dp1">
                                                           <a href="#" id="dropdownMenuButton" data-toggle="dropdown" 
                                                           aria-haspopup="true" aria-expanded="false"> <i class="fas fa-ellipsis-h"></i> 
                                                            </a>
                                                           <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                                                              
                                                              <a class="dropdown-item" href="javascript:editreply2(<?=$rex->id?>)"> Edit </a>
                                                              <a class="dropdown-item" href="javascript:removereply2(<?=$rex->id?>)"> Delete </a>
                                                              <?php //} else { ?>
                                                            </div>
                                                        </div>
                                                         <?php }?>
                                                        
                                                      </li>
                                                    </ul>
                                                   </div>
                                                   
                                                     <form name="frmreply<?=$rex->id?>" action="<?php echo base_url();?>problems/submitreply/<?=$qId?>/<?=$userId?>"
                                                       method="post">
                                                     <input type="hidden" name="comment_id" value="<?=$comId?>" />
                                                     <div class="chat-sec-1" id="chat-d2_1<?=$rex->id?>" style="display:none;">
                                                         <div class="comment-area2">
                                                               <div class="form-group">
                                                                   <textarea name="reply<?=$comId?>" class="form-control" style="font-size:13px;" required></textarea>
                                                               </div>
                                                               <?php if($this->session->userdata('id')!='') { ?>
                                                               <button type="submit" class="rely-dv-bn" id="hide-d2<?=$rex->id?>">Reply</button>
                                                               <?php } else { ?>
                                                               <button type="button" class="rely-dv-bn" id="hide-d2<?=$rex->id?>" data-toggle="modal" 
                                                               data-target="#cusModal">Reply</button>
                                                             <?php }?>
                                                         </div>
                                                         <hr>
                                                    </div>
                                                    </form>
                                                    
                                                   <? /////////////////////////////// End Reply over reply ////////////////////////// ?>
                                                    <?php
                                                      }
                                                   ?>
                                                   <hr />
                                                </div>
                                                    
                                                    <?php
                                                        } // End comment loop for related
   												     }
													 else
													 {
													?>
                                                      <div align="center">No Comments Found!</div>
                                                    <?php
													  }
													 ?>
												 </div>
											 </div>
											
                            <a class="comon-more-bn1" id="moreless-button-new3_<?=$rx->id?>" onclick="javascript:readmore2(<?=$rx->id?>)">Read more</a> 
                            <a class="comon-more-bn1" id="moreless-button-new3c_<?=$rx->id?>" onclick="javascript:readless2(<?=$rx->id?>)" style="display:none;">Read less</a>

											</div>
											</div>
											
											<?php 
											  } // End answer loop
										  }
										   else
										   {
										?>
                                         <div class="card-header collapsed">
											   <a class="card-title">
												  No answers found for this question.
											   </a>
											</div>
                                        <?php
                                          }
										?>
                                        </div>
                                      </div>
									</div>
                                    <?php
									      }
                                        }  // end main question foreach
									?>
									<script>
										function readmore2(id)
										{
											 document.getElementById("rq"+id).classList.remove("detail-dv-textarea");
											 document.getElementById("rq"+id).classList.add("detail-dv-textarea-next");
											 document.getElementById("moreless-button-new3_"+id).style.display='none';
											 document.getElementById("moreless-button-new3c_"+id).style.display='block'; 
										}
										
										function readless2(id)
										{
											 document.getElementById("rq"+id).classList.add("detail-dv-textarea");
											 document.getElementById("rq"+id).classList.remove("detail-dv-textarea-next");
											 document.getElementById("moreless-button-new3_"+id).style.display='block';
											 document.getElementById("moreless-button-new3c_"+id).style.display='none';
										}
										
										function replyshow2(id)
										{
											 document.getElementById("chat-d2"+id).style.display='block';
											 document.getElementById("show-d2"+id).style.display='none';
											 document.getElementById("hide-d2"+id).style.display='block';
										}
										
										function replyhide2(id)
										{
											 document.getElementById("chat-d2"+id).style.display='none';
											 document.getElementById("show-d2"+id).style.display='block';
											 document.getElementById("hide-d2"+id).style.display='none';
										}
										
										function replyshow2_1(id)
										{
											 document.getElementById("chat-d2_1"+id).style.display='block';
											 document.getElementById("show-d2_1"+id).style.display='none';
											 document.getElementById("hide-d2_1"+id).style.display='block';
										}
										
										function replyhide2_1(id)
										{
											 document.getElementById("chat-d2_1"+id).style.display='none';
											 document.getElementById("show-d2_1"+id).style.display='block';
											 document.getElementById("hide-d2_1"+id).style.display='none';
										}
										
										function addcomment2(id)
										{
										   document.getElementById("ad2"+id).style.display='block';
										   document.getElementById("ans2"+id).style.display='none';
										}
										
										function addanswer2(id)
										{
										   document.getElementById("ad2"+id).style.display='none';
										   document.getElementById("ans2"+id).style.display='block';
										}
										
										function hidecomment2(id)
										{
										   document.getElementById("btcom"+id).style.display='block';
										   document.getElementById("hbtcom"+id).style.display='none';
										   
										   document.getElementById("ad2"+id).style.display='none';
										}
										
										function hideanswer2(id)
										{
										   document.getElementById("hbtans"+id).style.display='none';
										   document.getElementById("btans"+id).style.display='block';
										   
										   document.getElementById("ans2"+id).style.display='none';
										}
										
										function ansedit2(id)
										{
										   document.getElementById("qans2"+id).style.display='none';
										   document.getElementById("edit2"+id).style.display='block';
										}
										
										function revansedit2(id)
										{
										   document.getElementById("qans2"+id).style.display='block';
										   document.getElementById("edit2"+id).style.display='none';
										}
										
										function editcomment2(id)
										{
										   document.getElementById("com_1"+id).style.display='none';
										   document.getElementById("com_edit"+id).style.display='block';
										}
										
										function comcancel2(id)
										{
										   document.getElementById("com_1"+id).style.display='block';
										   document.getElementById("com_edit"+id).style.display='none';
										}
										
										function editreply2(id)
										{
										   document.getElementById("rep-d2"+id).style.display='block';
										   document.getElementById("rep2"+id).style.display='none';
										}
										
										function reveditreply2(id)
										{
										   document.getElementById("rep-d2"+id).style.display='none';
										   document.getElementById("rep2"+id).style.display='block';
										}
										
								   </script>
                                   
                                   <script>
									function upvote2(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/ansupvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demi"+id).innerHTML = xhttp.responseText;
									}
									
									function downvote2(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/ansdownvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demi2"+id).innerHTML = xhttp.responseText;
									}
									
									function comupvote2(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/comupvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demoox"+id).innerHTML = xhttp.responseText;
									}
									
									function comdownvote2(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/comdownvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demoox2"+id).innerHTML = xhttp.responseText;
									}
									
									function replyupvote2_1(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/replyupvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demooxr"+id).innerHTML = xhttp.responseText;
									}
									
									function replydownvote2_1(id,userid) {
									  var xhttp = new XMLHttpRequest();
									  xhttp.open("GET", "<?php echo base_url();?>vote/replydownvote/"+id+"/"+userid, false);
									  xhttp.send();
									  document.getElementById("demoox2r"+id).innerHTML = xhttp.responseText;
									}
									
									function ansdelete2(id) {
										  var xhttp = new XMLHttpRequest();
										  xhttp.open("GET", "<?php echo base_url();?>problems/reldeleteanswer/"+id, false);
										  xhttp.send();
										  /*xhttp.responseText;*/
										  
										  location.reload(true);
									}
									
									function updatecomment2(id)
									{
									      var content = document.getElementById('cedit2'+id).value;
										  /*alert(content);*/
									      var xhttp = new XMLHttpRequest();
										  xhttp.open("GET", "<?php echo base_url();?>problems/editcomment/"+id+"/"+content, false);
										  xhttp.send();
										  location.reload(true);
									}
									
									function removecomment2(id) {
										  var xhttp = new XMLHttpRequest();
										  xhttp.open("GET", "<?php echo base_url();?>problems/deletecomment/"+id, false);
										  xhttp.send();
										  /*xhttp.responseText;*/
										  location.reload(true);
									}
									
									function updatereply2(id)
									{
									      var content = document.getElementById('redit2'+id).value;
									      var xhttp = new XMLHttpRequest();
										  xhttp.open("GET", "<?php echo base_url();?>problems/editreply/"+id+"/"+content, false);
										  xhttp.send();
										  
										  location.reload(true);
									}
									
									function removereply2(id) {
										  var xhttp = new XMLHttpRequest();
										  xhttp.open("GET", "<?php echo base_url();?>problems/deletereply/"+id, false);
										  xhttp.send();
										  /*xhttp.responseText;*/
										  location.reload(true);
									}
									</script>
                                    </div>
                                  </div>
							     <? ########################## End Related Questions ############################## ?> 
                            </div> 
                      </div>
                  </div>
              </div>
            </div>
       </div>
       </div>
       <? ########################## Right Side bar ###################### ?>
        <?php $this->load->view('front/rightsidebar.php');?>
       <? ################### Right Side bar end ############?> 
      <!-- col-9 -->
    </div>
    <div class="clearfix"></div>
  </div>
</section>

<? ######################### Sign in modal ####################### ?>

<div class="modal fade exampleModalask" id="cusModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header ask-modal modal-header-1"> <img src="<?php echo base_url();?>assets2/images/logo-head.png" alt="">
        <h5 class="modal-title" id="exampleModalLabel">Ask Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      <div id="modal-spl-26" class="modal-body modal-body1">
       <span id="txt" class="text-center" style="color:#FF0000;"></span>
        <div class="head-form head-form2x" id="next_hide">
          <div class="form-dp">
            <div class="top-sec-dp">
                <div class="form-group">
                  <label> User Name</label>
                  <input type="text" placeholder="" id="user_name2" class="form-control" value="" required>
                </div>
                <div class="form-group">
                  <label> Password </label>
                  <input type="password" placeholder="" id="password2" class="form-control" value="" required>
                </div>
                <button type="button" id="login_btn_comment2" class="btn default-btn login">Log In</button>
            </div>
          </div>
          <div class="col-md-4">&nbsp;</div>
          <div class="col-12">
            <div class="header-drop-links-first">
              <p>Or Login With</p>
              <ul class="socal-media">
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i>
                  <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                  <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                  <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                  <span> Linkedin</span></a></li>
              </ul>
              
              <div class="sub-link">
                 <a href="#">Lost Password </a> or <a href="#"> User Name</a>
              </div>
            </div>
          </div>
          <div class="col-12 mt-4">
            <div class="header-drop-links-second">
              <p>Or Sign Up With</p>
              <hr class="my-2">
              <ul class="socal-media">
                <li><a class="icon-new" href="#"> <i class="fas fa-envelope"></i>
                  <span>Email</span></a></li>
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i>
                  <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                  <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                  <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                  <span> Linkedin</span></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    
    </div>
  </div>
</div>

<script>
    $(document).ready(function()
	{
	 //////////////////////////////////////////
	  $("#login_btn_comment2").click(function()
	  {
		  var user_name = $("#user_name2").val();
		  var password = $("#password2").val();
			   
		  if(password=='' || user_name=='')
		  {
			 swal("Sorry!! Insert Your Login Data");
		  }
		  else
		  {
			 $.ajax({url: "<?php echo base_url();?>home/login/"+user_name+"/"+password, success: function(result){
				 /*if(result==success)
				 {*/
				   location.reload(true);
				/* }
				 else
				 {
				   $("#txt").html("Wrong username or password!");
				 }*/
			  }});
		  }
	 });
   });
</script>

<script>
$(document).ready(function(){
   
   $("#btcom").click(function(){
      $(".ad1").show();
      $(".ad2").hide();
   });
   
   $("#btans").click(function(){
      $(".ad1").hide();
      $(".ad2").show();
   });
     $("#btcom2").click(function(){
      $(".ad3").show();
      $(".ad4").hide();
   });
   
   $("#btans2").click(function(){
      $(".ad3").hide();
      $(".ad4").show();
   });
});
</script>




