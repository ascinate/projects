<!--    host-account-section-start-->
<section class="total-bd-area ">
  <div class="container-fluid">
    <div class="row">
     <div class="new-add-sec">
      <div class="col-md-3 col-lg-3 pr-md-0">
        <div class="left-slidber-area">
          <div class="host-section-left-list">
				      <?php $this->load->view('inc/left-navigation-supporters');?>
          </div>
        </div>
      </div>
      <div class="col-md-9 col-lg-9">
        <div class="bod-area">
          <div class="text-part-sec incrise-pd home-inside-d1 p-0">
            <div class="row justify-content-center p-2">
              <div class="col-md-12 text-center">
                <p style="color: green;"><?php echo $this->session->flashdata('msg');?></p>
              </div>
            </div>
            <div class="account-profile-form">
              <?php 
                 if($this->session->userdata('id')=="")
                 {
                    redirect('/');
                 }
                 $row=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
                ?>
              <form name="frm" action="<?php echo base_url();?>profile/editaccount/<?=$this->session->userdata('id')?>" method="post" enctype="multipart/form-data">
                <div class="form-group">
                   <div class="row mb-3">
                    <div class="col-md-4 my-auto">
                      <label for="exampleInputEmail1"><?php if($row->account=="Deactivate"){echo"Activate Your Account";}else{echo"Deactivate Your Account";}?></label>
                    </div>
                  </div>
                 <hr>
                  
                  <div class="row mb-3">
                    <div class="col-md-12 my-auto">
                     <p>You really want to <?php if($row->account=="Deactivate"){echo "Activate";}else{echo "Deactivate";}?>your account.</p>
                    </div>
                  </div>
                </div>
                <hr>
                
                <div class="form-group">
                   <div class="row mb-3 text-right">
                     <div class="col-md-1">
                       <button type="submit" name="btnsubmit" class="submit-bn-add">Yes</button>&nbsp;
                     </div>
                     <div class="col-md-1">
                     <a href="javascript:javascript: history.go(-1);">
                       <button type="button" name="btncancel" class="submit-bn-add">No</button>
                     </a>
                     </div>
                   </div>
                 </div>
              </form>
                          
            </div>
          </div>
        </div>
      </div>
       
     </div>
     <div class="sd1 new-sd3 right-space"> <a href="#">Advertisement</a> </div>
    </div>
  </div>
</section>
<!--    host-account-section-end-->
