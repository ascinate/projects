<?php
   $userid = $this->session->userdata('id');
   $result = $this->db->get_where('notification_master', array('user_id' => $userid))->row();
?>
<section class="total-bd-area">
    <div class="host-section-wrap">
        <div class="container-fluid">
            <div class="row">
                <div class="new-add-sec">
                    <div class="col-md-3 col-lg-3 pr-md-0">
                        <div class="left-slidber-area">
                            <div class="host-section-left-list">
                                <?php $this->load->view('inc/left-navigation-supporters');?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-9 col-lg-9">
                        <div class="bod-area">
                            <div class="text-part-sec home-inside-d1 p-0">
                                <div class="host-section-mid-profile-box notifica-set-wrap">
                                    <div class="notifica-set-wrap-head">
                                        <p>You will be informed via email for activity in your account on the following criteria.</p>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="admin_notification mt-4 text-left">
                                                <p class="mb-3"><b>Admin Notifications:</b></p>
                                                <form name="frm" action="" method="post" class="checkbox_listing checkbox_listing-1">
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html1" checked />
                                                        <label for="html1">Welcome Notification on Successful Signup (Notify me for successfully signup at FixerGeek.com)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html2" checked>
                                                        <label for="html2">Forgot Password or User Name Notification (Notify me for email address verification etc.)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html3" checked>
                                                        <label for="html3">Payment Notification (Notify me each month with amount earned for services)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html4" checked>
                                                        <label for="html4">Billing Notification (Notify if my Credit/Debit Card expires, floors etc.)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html5" checked>
                                                        <label for="html5">Deactivate Account Notification (Notify me if my account gets deactivated)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html6" checked>
                                                        <label for="html6">Delete Account Notification (Notify if your account gets deleted)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html7" checked>
                                                        <label for="html7"> Let Admin Contact me Notification (Notify me if FixerGeek.com want to contact me)</label>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                    <hr class="my-0">
                                    <div class="row mt-3">
                                        <div class="col-12">
                                            <div class="User_notification mt-4 text-left">
                                                <p class="mb-3"><b>User Notifications:</b></p>
                                                <form class="checkbox_listing checkbox_listing-1">
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html91" checked>
                                                        <label for="html91">Fix Notification (Notify me if a Fix of my problem has been given)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html101" checked>
                                                        <label for="html101">Problem Notification (Notify me requests of geeks to fix their problems)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html111" checked>
                                                        <label for="html111">User Message Notification (Noify me if a User messages me)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html121" checked>
                                                        <label for="html121">Score & Comment Notification (Notify me if a User leaves a Score & Comment for me)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html131" checked>
                                                        <label for="html131">Hire Notification (Notify me if a user hires me through app)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html141" checked>
                                                        <label for="html141">Decline Notification (Notify me if a user declines a request for support)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html151" checked>
                                                        <label for="html151">Deny Notification (Notify me if a user denies an offer for support)</label>
                                                    </div>
                                                    <div class="form-group form-group-1 mb-1">
                                                        <input type="checkbox" id="html161" checked>
                                                        <label for="html161">Block Notification (Notify me if a user blocks me)</label>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>


                <div class="sd1 new-spc new-special-home"> 
                   <div class="new-right-sec-add-howit">
                       <h3> How it works </h3>
                       <a data-toggle="modal" data-target="#exampleModal-vieo">
                          <img src="<?php echo base_url();?>assets2/images/imgpsh_fullsize_anim.png" alt="user">
                       </a>
                    </div>
                    <div class="ads-new-1">
                      <a href="#">Advertisement</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    function notify(val) {
        alert(val);
        /*var xhttp = new XMLHttpRequest();
        var content = document.getElementById('com'+aid).value;
        xhttp.open("GET", "<?php //echo base_url();?>notifications/notify/"+aid+"/"+qid+"/"+uid+"/"+content, false);
        xhttp.send();*/
    }

</script>
