<!-- comon footer -->
<!-- comon footer -->
<div class="modal fade" id="exampleModal-vieo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">How it works </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body video-body">
        <video id='video' controls="controls" width="100%">
          <source id='mp4' src="<?php echo base_url();?>assets2/images/video-1.mp4" type='video/mp4' />
          
        </video>
      </div>
      <!--<div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>-->
    </div>
  </div>
</div>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>assets2/js/coustom.js"></script>
<script src="<?php echo base_url();?>assets2/js/modal-dropdown.js"></script>
<script src="<?php echo base_url();?>assets2/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url();?>assets2/js/bootstrap-datepicker.js"></script>
<!--<script src="https://tinymce.cachefly.net/4.1/tinymce.min.js"></script>-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.3/js/standalone/selectize.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.4.4/parsley.min.js"></script>

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/utils.js"></script> -->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/intlTelInput.min.js"></script>-->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/utils.js"></script> -->

</body>
</html>

<script>

  function statusChangeCallback(response) {  // Called with the results from FB.getLoginStatus().
    console.log('statusChangeCallback');
    console.log(response);                   // The current login status of the person.
    if (response.status === 'connected') {   // Logged into your webpage and Facebook.
      testAPI();  
    } else {                                 // Not logged into your webpage or we are unable to tell.
      document.getElementById('status').innerHTML = 'Please log ' +
        'into this webpage.';
    }
  }


  function checkLoginState() {               // Called when a person is finished with the Login Button.
    FB.getLoginStatus(function(response) {   // See the onlogin handler
      statusChangeCallback(response);
    });
  }


  window.fbAsyncInit = function() {
    FB.init({
      appId      : '{571891813717008}',
      cookie     : true,                     // Enable cookies to allow the server to access the session.
      xfbml      : true,                     // Parse social plugins on this webpage.
      version    : '{v7.0}'           // Use this Graph API version for this call.
    });


    FB.getLoginStatus(function(response) {   // Called after the JS SDK has been initialized.
      statusChangeCallback(response);        // Returns the login status.
    });
  };
 
  function testAPI() {                      // Testing Graph API after login.  See statusChangeCallback() for when this call is made.
    console.log('Welcome!  Fetching your information.... ');
    FB.api('/me', function(response) {
      // console.log('Successful login for: ' + response.name);
      // document.getElementById('status').innerHTML =
        // 'Thanks for logging in, ' + response.name + '!';
       
            var f_name=response.name;
            //alert(f_name);
            $.ajax({
            url:'<?php echo base_url();?>signin/oauthfacebook',
            type:'post',
            data:{f_name:f_name},
            success:function(data)
            {
              if(data=="fixeroverview")
              {
                var url="<?php echo base_url('fixeroverview')?>";
                window.location.href=url;
              }
               if(data=="askeroverview")
              {
                var url="<?php echo base_url('askeroverview')?>";
                window.location.href=url;
              }
             
            }
          }); 
    });
  }
 

</script>
<script type="text/javascript">
  function filterFunction(that, event) {
    let container, input, filter, li, input_val;
    container = $(that).closest(".searchable");
    input_val = container.find("input").val().toUpperCase();


		if (["ArrowDown", "ArrowUp", "Enter"].indexOf(event.key) != -1) {
			keyControl(event, container)
		} else {
			li = container.find("ul li");
			li.each(function (i, obj) {
				if ($(this).text().toUpperCase().indexOf(input_val) > -1) {
					$(this).show();
				} else {
					$(this).hide();
				}
			});
	
			container.find("ul li").removeClass("selected");
			setTimeout(function () {
				container.find("ul li:visible").first().addClass("selected");
			}, 100)
		}

}

function keyControl(e, container) {
    if (e.key == "ArrowDown") {

        if (container.find("ul li").hasClass("selected")) {
            if (container.find("ul li:visible").index(container.find("ul li.selected")) + 1 < container.find("ul li:visible").length) {
                container.find("ul li.selected").removeClass("selected").nextAll().not('[style*="display: none"]').first().addClass("selected");
            }

        } else {
            container.find("ul li:first-child").addClass("selected");
        }

    } else if (e.key == "ArrowUp") {

        if (container.find("ul li:visible").index(container.find("ul li.selected")) > 0) {
            container.find("ul li.selected").removeClass("selected").prevAll().not('[style*="display: none"]').first().addClass("selected");
        }
    } else if (e.key == "Enter") {
        container.find("input").val(container.find("ul li.selected").text()).blur();
        onSelect(container.find("ul li.selected").text())
    }

    container.find("ul li.selected")[0].scrollIntoView({
        behavior: "smooth",
    });
}

function onSelect(val) {
    //alert(val)
}

/*$("#category").focus(function () {
		  $(this).closest(".searchable").find("ul").show();
		  $(this).closest(".searchable").find("ul li").show();
});

$(".searchable input").blur(function () {
    let that = this;
    setTimeout(function () {
        $(that).closest(".searchable").find("ul").hide();
    }, 300);
});

$(document).on('click', '.searchable ul li', function () {
    $(this).closest(".searchable").find("input").val($(this).text()).blur();
    onSelect($(this).text())
});

$(".searchable ul li").hover(function () {
    $(this).closest(".searchable").find("ul li.selected").removeClass("selected");
    $(this).addClass("selected");
});*/
</script>

<script>
  $(document).ready(function(){
     $('.google_connect').click(function() {

     $('.abcRioButtonContentWrapper').click();

      });
     $('.connected').click(function(){
     swal('Already Connected');
     });
   
    });
</script>

<script>

      function onConnectIn(googleUser) {
        // Useful data for your client-side scripts:
        var profile = googleUser.getBasicProfile();
        console.log("ID: " + profile.getId()); // Don't send this directly to your server!
        console.log('Full Name: ' + profile.getName());
        console.log('Given Name: ' + profile.getGivenName());
        console.log('Family Name: ' + profile.getFamilyName());
        console.log("Image URL: " + profile.getImageUrl());
        console.log("Email: " + profile.getEmail());

        // The ID token you need to pass to your backend:
        var id_token = googleUser.getAuthResponse().id_token;
        console.log("ID Token: " + id_token);
           
            var email = profile.getEmail();
            var id=$('#u_id').val();
            $.ajax({
            url:'<?php echo base_url();?>signin/addmail',
            type:'post',
            data:{id:id,email:email},
            success:function(data)
            {
              if(data=="profile")
              {
                var url="<?php echo base_url('profile')?>";
                window.location.href=url;
              }
             
            }
          });
          
      }
    </script>

  <script>
  function signOut() {
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function () {
      console.log('User signed out.');
     FB.logout(function(response) {
   // Person is now logged out
  });
    });
  }
</script>
<script>
    
      function onSignIn(googleUser) {
        // Useful data for your client-side scripts:
        var profile = googleUser.getBasicProfile();
        console.log("ID: " + profile.getId()); // Don't send this directly to your server!
        console.log('Full Name: ' + profile.getName());
        console.log('Given Name: ' + profile.getGivenName());
        console.log('Family Name: ' + profile.getFamilyName());
        console.log("Image URL: " + profile.getImageUrl());
        console.log("Email: " + profile.getEmail());

        // The ID token you need to pass to your backend:
        var id_token = googleUser.getAuthResponse().id_token;
        console.log("ID Token: " + id_token);
            
            var email = profile.getEmail();
            // alert("My favourite sports are: " + days);
            var g_name=profile.getGivenName();
            var f_name=profile.getName();
      
            $.ajax({
            url:'<?php echo base_url();?>signin/oauth2callback',
            type:'post',
            data:{email:email,f_name:f_name,g_name:g_name},
            success:function(data)
            {
              if(data=="fixeroverview")
              {
                var url="<?php echo base_url('fixeroverview')?>";
                window.location.href=url;
              }
               if(data=="askeroverview")
              {
                var url="<?php echo base_url('askeroverview')?>";
                window.location.href=url;
              }
             
            }
          });
      }
    </script>
    <script type="text/javascript">

    $(document).ready(function(){
        

        $("#add_comment").click(function(){
            var user_id = $("#user_id").val();
            var ques_id = $("#ques_id").val();
            var comment = $("#comment_text").val();
          if(comment=='')
          {
             swal(" Comments cannot be null!! ");
          }
          else
          {
            $.ajax({
            url:'<?php echo base_url();?>details/submitcomment',
            type:'post',
            data:{user_id:user_id,ques_id:ques_id,comment:comment},
            success:function(data)
            {

              if(data=='success')
              {
               $('#comment_text').load();
              }
              else
              {
                
                window.location.href=url;
              }
              
            }
          });
          }
   
        });
        //////////////////////////////
         $(".add_comment").click(function(){
            var user_id = $(".user_id").val();
            var ques_id = $(".quess_id").val();
            var comment = $(".comment_text").val();
          if(comment=='')
          {
             swal(" Comments cannot be null!! ");
          }
          else
          {
            $.ajax({
            url:'<?php echo base_url();?>details/submitcomment',
            type:'post',
            data:{user_id:user_id,ques_id:ques_id,comment:comment},
            success:function(data)
            {

              if(data=='success')
              {
               $('.comment_text').load();
              }
              else
              {
                
                window.location.href=url;
              }
              
            }
          });
          }
   
        });
        ////////////////////////////
        $(".chat-box-open button").click(function(){
            var user_id = $(".user_id").val();
            var ques_id = $(".ques_id").val();
            var comm_id = $(".comment_id").val();
            var reply = $(".reply_text").val();
          if(reply=='')
          {
             swal("Reply cannot be null!! ");
          }
          else
          {
            $.ajax({
            url:'<?php echo base_url();?>details/submitreply',
            type:'post',
            data:{user_id:user_id,ques_id:ques_id,comm_id:comm_id,reply:reply},
            success:function(data)
            {

              if(data=='success')
              {
               $('.chat-box-open').hide();
              }
              else
              {
                
                window.location.href=url;
              }
              
            }
          });
          }
   
        })

    });

</script>