<!-------------- Related ---------------->
<? ########################## Related Questions ############################## ?>
<?php
    $qus = $this->uri->segment(3);
	$ques = str_replace("-"," ",$qus);
	$tques = $ques."?";
	
   	$count = $this->db->get_where('questions_master', array('question'=>$tques))->num_rows();
	if($count!=0)
	{
      $title = $this->db->get_where('questions_master', array('question'=>$tques))->row();
	}
	else
	{
	  $title = $this->db->get_where('questions_master', array('question'=>$ques))->row();
	}
	
	
	$qus_id = $title->id;
	
	$userId = $this->session->userdata('id');
	
	$question = $this->db->get_where('questions_master',array('id'=>$qus_id))->row();
	$user = $this->db->get_where('user_master',array('id'=>$question->user_id))->row();
	
	$username = $this->db->get_where('user_master',array('id'=>$userId))->row();
	
	$this->db->order_by('upvote', 'DESC');
	$answer = $this->db->get_where('answers_master',array('question_id'=>$qus_id));
	
	
	$date  = date_create($question->post_date);   
	
	$user_qry = $this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
	$category = $this->db->get_where('category_master',array('id'=>$question->category_name))->row();
	$sub_cat = $this->db->get_where('sub_category_master',array('id'=>$question->sub_cat_id))->row();
	$sub_sub_cat = $this->db->get_where('sub_sub_category_master',array('id'=>$question->sub_sub_cat_id))->row();
	
	 $sub_sub_cat = $this->db->get_where('sub_sub_category_master',array('id'=>$question->sub_sub_cat_id))->row();
	
	 $sqlQry = $this->db->query("select * from `questions_master` where `sub_sub_cat_id` = '".$sub_sub_cat->id."'");
	 $cnt = $sqlQry->num_rows();
	 
	 if($cnt > 1) {
?>
<div class="related-question-area">
  <div class="sub-hedding-d1">
    <h2> Related Question</h2>
  </div>
</div>
<?php }?>
<div class="answer-part2">
  <div id="headingOne" class="accordion">
    <?php
       // Start question loop
       foreach($sqlQry->result() as $rs)
       {
         $qId = $rs->id;
         
         $this->db->order_by('upvote', 'DESC');
         $relanswer=$this->db->get_where('answers_master',array('question_id'=>$rs->id));
         $anscnt = $relanswer->num_rows();
                                                 
         if($rs->question!=$question->question)
         {
    ?>
    <div class="card-header collapsed" data-toggle="collapse" data-target="#collapse<?=$rs->id?>" aria-expanded="true" 
                   aria-controls="collapseOne"> <a class="card-title">
      <?=$rs->question?>
      </a> </div>
    <div id="collapse<?=$rs->id?>" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
      <ul class="categories-d1">
        <li> Categories: </li>
        <li> <a href="<?php echo base_url();?>category/show/<?=(str_replace("&","-",str_replace(" ","_",$sub_sub_cat->sub_sub_category_name)))?>">
          <?=$sub_sub_cat->sub_sub_category_name;?>
          </a> </li>
      </ul>
      <div class="card-body p-0" id="child1">
        <div class="card sub-related-ans-area">
          <?php 
          if($anscnt!=0) 
          {
              $a = 1;
              // start answer loop
              foreach($relanswer->result() as $rx) 
              {
              $author_id = $rx->user_id;
             
              $xdate = explode('-', $rx->post_date);
              $pdate = mktime(12,0,0, $xdate[1],$xdate[2],$xdate[0]);
              $ansdate = date("F j, Y", $pdate);
              
              $uid = $this->db->get_where('user_master',array('id'=>$rx->user_id))->row();
              $fixergeek=$this->db->get_where('fixergeek_master',array('user_id'=>$rx->user_id))->row();
              
              $vt = $this->db->query("select sum(upvote) as upvot from `answer_up_down` where `answer_id` = '".$rx->id."'")->row();
              $upv = $vt->upvot;  
            
              $vt2 = $this->db->query("select sum(downvote) as downvot from `answer_up_down` where `answer_id` = '".$rx->id."'")->row();
              $dwv = $vt2->downvot;
            ?>
          <div class="card-header collapsed" data-toggle="collapse" data-target="#collapse<?=$rx->id?>"> <a class="card-title"> Answer by
            <?php 
              if($uid->id=="Admin")
              {
              ?>
            <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" class="imxx">
            <?php
             }
             else
             {
               if($uid->profile_picture!="")
               {
             ?>
            <img src="<?php echo base_url();?>uploads/<?=$uid->profile_picture?>" alt="user"  class="imxx">
            <?php 
               } 
              else
               {
            ?>
            <i class="far fa-user-circle"></i>
            <?php 
               }
             }
            ?>
            <?=$uid->geek_name?>
            Posted on
            <?=$ansdate?>
            <!--@-->
            <? /*$rx->post_time?> - <?=$fixergeek->timezone*/ ?>
            </a> </div>
          <div class="card-body collapse show" data-parent="#child1" id="collapse<?=$rx->id?>">
            <div class="comon-text-area comon-space">
              <?php if($this->session->userdata('id')==$author_id) {?>
              <ul class="new-add-dl">
                <li> <a class="dropdown-item" href="javascript:ansedit2(<?=$rx->id?>);"> Edit </a></li>
                <li> <a class="dropdown-item" href="javascript:ansdelete2(<?=$rx->id?>);"> Delete </a> </li>
              </ul>
              <?php } ?>
              <div class="detail-dv-textarea" id="rq<?=$rx->id?>">
                <div class="new-text-sec-d1 " id="qans2<?=$rx->id?>">
                  <?=stripslashes($rx->answer); ?>
                </div>
                <div class="new-text-sec-d1 new-add-email-sec" id="edit2<?=$rx->id?>" style="display:none;">
            <form name="editfrm2<?=$rx->id?>" action="<?php echo base_url();?>problems/releditanswer/<?=$qId?>/<?=$userId?>" method="post">
                    <input type="hidden" name="upans_id2" value="<?=$rx->id?>" />
                    <textarea class="form-control" name="updateanswer2<?=$rx->id?>" rows="20" id="upans2<?=$rx->id?>">
                       <?=stripslashes($rx->answer); ?>
                     </textarea>
                     <script>
                     /*ClassicEditor
                        .create( document.querySelector( '#upans2<?=$rx->id?>' ) )
                        .catch( error => {
                            console.error( error );
                        } );*/
                    </script>
                    
                  <script>
					tinymce.init({
					  selector: '#upans2<?=$record->id?>',
					  plugins: 'a11ychecker advcode casechange formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
					  toolbar: 'a11ycheck addcomment showcomments casechange checklist code formatpainter pageembed permanentpen table',
					  toolbar_mode: 'floating',
					  tinycomments_mode: 'embedded',
					  tinycomments_author: 'Author name',
					});
				  </script>
                     
                    <button type="submit" name="btnedit2<?=$rx->id?>" id="submit1" style="border:none;">Submit</button>
                    &nbsp;
                    <div id="show-bn-d1" class="d-inline">
                      <button type="button" name="canceledit2<?=$rx->id?>" id="submit1" onclick="javascript:revansedit2(<?=$rx->id?>);" 
                      style="border:none;">Cancel</button>
                    </div>
                  </form>
                </div>
                <div class="more-text2" id="more-text1-dv2<?=$rx->id?>">
                  <div class="more-details-sec-dv">
                    <div class="main-button1">
                      <?php if($this->session->userdata('id')!='') { ?>
                      <a class="comon-dv-bn" id="btcom<?=$rx->id?>" onclick="javascript:addcomment2(<?=$rx->id?>)"> Add comment</a> 
                      <a class="comon-dv-bn" id="hbtcom<?=$rx->id?>" onclick="javascript:hidecomment2(<?=$rx->id?>)" style="display:none;"> Add comment</a> 
                      <a class="comon-dv-bn" id="btans<?=$rx->id?>" onclick="javascript:addanswer2(<?=$rx->id?>)"> Add Another Answer</a> 
                      <a class="comon-dv-bn" id="hbtans<?=$rx->id?>" onclick="javascript:hideanswer2(<?=$rx->id?>)" style="display:none;"> Add Another Answer </a>
                      <?php } else { ?>
                      <a class="comon-dv-bn" id="btcom<?=$rx->id?>" data-toggle="modal" data-target="#cusModal"> Add comment</a> 
                      <a class="comon-dv-bn" id="btans<?=$rx->id?>" data-toggle="modal" data-target="#cusModal"> Add Another Answer</a>
                      <?php }?>
                      <?php if($this->session->userdata('id')!='') { ?>
                      <a href="javascript:upvote2(<?=$rx->id?>,<?=$userId?>)" class="up"> 
                      <i class="far fa-thumbs-up"></i> <span id="demi<?=$rx->id?>">
                      <?=$upv?>
                      </span> 
                      </a> 
                      <a href="javascript:downvote2(<?=$rx->id?>,<?=$userId?>)" class="up">
                       <i class="far fa-thumbs-down"></i> <span id="demi2<?=$rx->id?>">
                      <?=$dwv?>
                      </span> 
                      </a>
                      <?php } else { ?>
                      <a href="javascript:void(0);" class="up"> <i class="far fa-thumbs-up"></i> <span>
                      <?=$upv?>
                      </span> </a> <a href="javascript:void(0);" class="up">
                       <i class="far fa-thumbs-down"></i> <span> <?=$dwv?>
                      </span> </a>
                      <?php }?>
                      <?php if($this->session->userdata('id')==$author_id) {?>
                      <!--<div class="dropdown detail-dp1">
                                 <a href="#" id="dropdownMenuButton" class="option-bn-d1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                    Option <i class="fas fa-caret-down"></i>
                                 </a>
                                 <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                                     
                                        <a class="dropdown-item" href="javascript:ansedit2(<?=$rx->id?>);"> Edit </a>
                                        <a class="dropdown-item" href="javascript:ansdelete2(<?=$rx->id?>);"> Delete </a>
                                      <?php //} else { ?>
                                      
                                  </div>
                              </div>-->
                      <?php }?>
                    </div>
                    
                    <div id="ad2<?=$rx->id?>" class="comment-sec-d1" style="display:block;">
                      <div class="detail-comment-sec2 new-dt-sec">
                        <form name="frm<?=$rx->id?>" action="" method="post">
                          <input type="hidden" name="ans_id" value="<?=$rx->id?>" />
                          <div class="form-group">
                            <div class="coment-area-dv">
                              <div class="col-md-1 text-right">
                                <?php
                                     if($user->profile_picture!="")
                                     {  
                                    ?>
                                <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" alt="user" 
                                   style="border-radius:50%; width:20px; height:20px;">
                                <?php } else {?>
                                <i class="fa fa-user" aria-hidden="true"></i>
                                <?php }?>
                              </div>
                              <div class="col-md-9 px-0">
                            <input type="text" name="comment<?=$rx->id?>" id="com2<?=$rx->id?>" class="form-control" style="font-size:13px;">
                              </div>
                              <div class="col-md-2">
                                <?php //if($this->session->userdata('id')!='') { ?>
                                <button type="button" id="add_comment2" class="comon-dv-bn" 
                                     onclick="javascript:insertcomment2(<?=$rx->id?>,<?=$qId?>,<?=$userId?>)">Add Comment</button>
                                <?php /*} else { ?>
                                     <button type="button" id="add_comment2" class="comon-dv-bn" data-toggle="modal" data-target="#cusModal" 
                                  style="border: none;">Add Comment</button>
                                     <?php }*/?>
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                    
                    <div id="ans2<?=$rx->id?>" class="comment-sec-d1">
                      <div id="anstext<?=$val->id?>">
                    <form name="frm<?=$rx->id?>" action="<?php echo base_url();?>problems/submitanswer/<?=$qId?>/<?=$userId?>" method="post">
                      <input type="hidden" value="<?=$rx->id?>" name="ans_id" />
                      <textarea class="form-control" name="answer<?=$rx->id?>" rows="20" id="tans<?=$rx->id?>"></textarea>
                      <script>
                       /*ClassicEditor
                        .create( document.querySelector( '#ans<?=$rx->id?>' ) )
                        .catch( error => {
                            console.error( error );
                        } );*/
                     </script>
                     
                     <script>
						tinymce.init({
						  selector: '#tans<?=$rx->id?>',
						  plugins: 'a11ychecker advcode casechange formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
						  toolbar: 'a11ycheck addcomment showcomments casechange checklist code formatpainter pageembed permanentpen table',
						  toolbar_mode: 'floating',
						  tinycomments_mode: 'embedded',
						  tinycomments_author: 'Author name',
						});
					  </script>
                      <?php //if($this->session->userdata('id')!='') { ?>
                      <button type="submit" id="submit1" style="border: none;">Submit</button>
                      <?php /*} else { ?>
                              <button type="button" id="submit1" data-toggle="modal"  data-target="#cusModal" 
                              style="border: none;">Submit</button>
                             <?php }*/?>
                    </form>
                      </div>
                    </div>
                  </div>
                  <h5>Comments</h5>
                  <div id="reldet">
                 <?php
                  $this->db->order_by('id', 'DESC');
                  $comment2 =$this->db->get_where('answer_comment',array('answer_id'=>$rx->id));
                  $cntnum = $comment2->num_rows();
                  $k = 0;
                  
                  if($cntnum!=0) {
                  foreach($comment2->result() as $rec)
                  {
					$comId = $rec->id;
					$authorcom = $rec->user_id;
					
					$username = $this->db->get_where('user_master',array('id'=>$rec->user_id))->row();
					$exdate = explode('-', $rec->post_date);
					$postdate = mktime(12,0,0, $exdate[1],$exdate[2],$exdate[0]);
					$date = date("F j, Y", $postdate);
					
					$cvt = $this->db->query("select sum(upvote) as upvot from `comment_up_down` where `comment_id` = '".$rec->id."'")->row();
					$cupv = $cvt->upvot;  
				
					$cvt2 = $this->db->query("select sum(downvote) as downvot from `comment_up_down` where `comment_id` = '".$rec->id."'")->row();
					$cdwv = $cvt2->downvot;
                ?>
                    <div class="detial-new-comon reply-div">
                      <div class="comment-show-top-new">
                        <figure>
                          <?php 
                              if($username->id=="Admin")
                              {
                            ?>
                          <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" 
                                   style="border-radius:50%; width:30px; height:30px;">
                          <?php
							 }
							 else
							 {
							   if($username->profile_picture!="")
							   {
						  ?>
                          <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                                   style="border-radius:50%; width:30px; height:30px;">
                          <?php 
							   } 
							  else
							   {
						   ?>
                          <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                          <?php 
						    }
						   }
						 ?>
                        </figure>
                        <figcaption>
                          <?=$username->name?>
                          Commented on
                          <?=$date?>
                        </figcaption>
                      </div>
                      <p id="com_1<?=$comId?>">
                        <?=stripslashes(str_replace("%20"," ",$rec->comment))?>
                      </p>
                      <div id="com_edit<?=$comId?>" class="comment-sec-d1">
                        <div class="detail-comment-sec2 new-dt-sec">
                          <form name="frm<?=$comId?>" action="<?php echo base_url();?>problems/editcomment2/<?=$comId?>" method="post">
                            <input type="hidden" name="ques_id" value="<?=$qId?>" />
                            <div class="form-group">
                              <div class="coment-area-dv">
                                <div class="col-md-1 text-right">
                                  <?php
                                     if($username->profile_picture!="")
                                     {  
                                    ?>
                                  <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" 
                                      style="border-radius:50%; width:20px; height:20px;">
                                  <?php } else {?>
                                  <i class="fa fa-user" aria-hidden="true"></i>
                                  <?php }?>
                                </div>
                                <div class="col-md-9 px-0">
                                  <input type="text" name="cedit2<?=$comId?>" class="form-control" style="font-size:13px;" 
                                     value="<?=stripslashes(str_replace("%20"," ",$rec->comment))?>">
                                </div>
                                <div class="col-md-3">
                                  <button type="submit" id="e_comment2<?=$comId?>" class="comon-dv-bn" onclick="javascript:updatecomment2(<?=$comId?>);"> Update </button>
                                  <button type="button" id="d_comment2<?=$comId?>" class="comon-dv-bn" onclick="javascript:comcancel2(<?=$comId?>);"> Cancel </button>
                                </div>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                      <? /////////////////////////  Reply for comments /////////////////////////////// ?>
                      <div class="comment-sec-bottom1">
                        <ul>
                          <li class="d-flex"> 
                          <a class="reply-box" id="show-d2<?=$rec->id?>" onclick="javascript:replyshow2(<?=$rec->id?>);"> 
                          <i class="fa fa-reply"></i> Reply 
                          </a> 
                          <a class="reply-box" id="hide-d2<?=$rec->id?>" onclick="javascript:replyhide2(<?=$rec->id?>);" style="display:none;">
                          <i class="fa fa-reply"></i> Reply 
                          </a>
                            <?php if($this->session->userdata('id')!="") {?>
                            <a href="javascript:comupvote2(<?=$rec->id?>,<?=$userId?>)" class="up"> <i class="far fa-thumbs-up"></i><span id="demoox<?=$rec->id?>">
                            <?=$cupv?>
                            </span> </a> <a href="javascript:comdownvote2(<?=$rec->id?>,<?=$userId?>)" class="up"> <i class="far fa-thumbs-down"></i><span id="demoox2<?=$rec->id?>">
                            <?=$cdwv?>
                            </span> </a>
                            <?php } else { ?>
                            <a href="javascript:void(0);" class="up"> <i class="far fa-thumbs-up"></i><span>
                            <?=$cupv?>
                            </span> </a> 
                            <a href="javascript:void(0)" class="up">
                             <i class="far fa-thumbs-down"></i><span> <?=$cdwv?></span> 
                            </a>
                            <?php }?>
                            <?php if($this->session->userdata('id')== $authorcom) {?>
                            <div class="dropdown detail-dp1">
                             <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-ellipsis-h"></i> </a>
                              <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton"> 
                              <a class="dropdown-item" href="javascript:editcomment2(<?=$rec->id?>);"> Edit </a> 
                              <a class="dropdown-item" href="javascript:removecomment2(<?=$rec->id?>);"> Delete </a>
                                <?php //} else { ?>
                              </div>
                            </div>
                            <?php }?>
                          </li>
                        </ul>
                      </div>
                        <form name="frmreply<?=$rec->id?>" action="<?php echo base_url();?>problems/submitreply/<?=$qId?>/<?=$userId?>" method="post">
                        <input type="hidden" name="comment_id" value="<?=$comId?>" />
                        <div class="chat-sec-1" id="chat-d2<?=$rec->id?>" style="display:none;">
                          <div class="comment-area2">
                            <div class="form-group">
                              <textarea name="reply<?=$rec->id?>" class="form-control" style="font-size:13px;" required></textarea>
                            </div>
                            <?php if($this->session->userdata('id')!='') { ?>
                            <button type="button" class="rely-dv-bn" id="hide-d2<?=$rec->id?>" 
                            onclick="javascript:insertcomment2(<?=$rec->id?>,<?=$qId?>,<?=$userId?>)">Reply</button>
                            <?php } else { ?>
                            <button type="button" class="rely-dv-bn" id="hide-d2<?=$rec->id?>" data-toggle="modal" data-target="#cusModal">Reply</button>
                            <?php }?>
                          </div>
                          <hr>
                        </div>
                      </form>
                      <? /////////////////////////// End Reply //////////////////////////////////////// ?>
                      <?php
                          $reply =$this->db->get_where('reply_master',array('comment_id'=>$rec->id));
                          $x = 0;
                          
                          foreach($reply->result() as $rex)
                          {
                            $authorrep = $rex->user_id;
                            $uname = $this->db->get_where('user_master',array('id'=>$rex->user_id))->row();
                            $exdt = explode('-', $rex->post_date);
                            $postdt = mktime(12,0,0, $exdt[1],$exdt[2],$exdt[0]);
                            $dt = date("F j, Y", $postdt);
                            
                            $rcvt = $this->db->query("select sum(upvote) as upvot from `reply_up_down` where 
                                                    `reply_id` = '".$rex->id."'")->row();
                            $rcupv = $rcvt->upvot;  
                        
                            $rcvt2 = $this->db->query("select sum(downvote) as downvot from `reply_up_down` where 
                                                     `reply_id` = '".$rex->id."'")->row();
                            $rcdwv = $rcvt2->downvot;
                       ?>
                      <div class="comment-show-top-new">
                        <figure>
                          <?php 
                              if($uname->id=="Admin")
                              {
                            ?>
                          <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" width="30" height="30">
                          <?php
                             }
                             else
                             {
                               if($uname->profile_picture!="")
                               {
                             ?>
                          <img src="<?php echo base_url();?>uploads/<?=$uname->profile_picture?>" alt="user" 
                                   style="border-radius:50%; width:30px; height:30px;">
                          <?php 
                               } 
                              else
                               {
                            ?>
                          <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                          <?php 
                               }
                             }
                            ?>
                        </figure>
                        <figcaption>
                          <?=$uname->name?>
                          Replied on
                          <?=$dt?>
                        </figcaption>
                      </div>
                      <p style="padding-left:10px; line-height:20px;" id="rep2<?=$rex->id?>">
                        <?=stripslashes($rex->reply)?>
                      </p>
                      <div class="chat-sec-1" id="rep-d2<?=$rex->id?>" style="display:none;">
                        <form name="frmedit" action="<?php echo base_url();?>problems/editreply/<?=$rex->id?>" method="post">
                          <input type="hidden" name="ques_id" value="<?=$qId?>" />
                          <div class="comment-area2">
                            <div class="form-group">
                              <input type="text" name="redit<?=$rex->id?>" class="form-control" style="font-size:13px;" 
                                       value="<?=stripslashes($rex->reply)?>" required>
                            </div>
                            <button type="submit" class="rely-dv-bn" id="hide-d<?=$rex->id?>">Update</button>
                            <button type="button" class="rely-dv-bn" onclick="javascript:reveditreply2(<?=$rex->id?>);">Cancel</button>
                          </div>
                        </form>
                        <hr>
                      </div>
                      <?php  ///////////////////////////// Reply over reply /////////////////////////////// ?>
                      <div class="comment-sec-bottom1">
                        <ul>
                          <li class="d-flex"> 
                          <a class="reply-box" id="show-d2_1<?=$rex->id?>" onclick="javascript:replyshow2_1(<?=$rex->id?>);"> 
                          <i class="fa fa-reply"></i> Reply </a> 
                          <a class="reply-box" id="hide-d2_1<?=$rex->id?>" onclick="javascript:replyhide2_1(<?=$rex->id?>);" style="display:none;">
                          <i class="fa fa-reply"></i> Reply </a> <a href="javascript:replyupvote2_1(<?=$rex->id?>)" class="up"> 
                          <i class="far fa-thumbs-up"></i><span id="demooxr<?=$rex->id?>">
                            <?=$rcupv?>
                            </span> </a> 
                            <a href="javascript:replydownvote2_1(<?=$rex->id?>)" class="up"> <i class="far fa-thumbs-down"></i><span id="demoox2r<?=$rex->id?>">
                            <?=$rcdwv?>
                            </span> </a>
                            <?php if($this->session->userdata('id')== $authorrep) {?>
                            <div class="dropdown detail-dp1"> 
                            <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             <i class="fas fa-ellipsis-h"></i> 
                            </a>
                              <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                               <a class="dropdown-item" href="javascript:editreply2(<?=$rex->id?>)"> Edit </a> 
                               <a class="dropdown-item" href="javascript:removereply2(<?=$rex->id?>)"> Delete </a>
                                <?php //} else { ?>
                              </div>
                            </div>
                            <?php }?>
                          </li>
                        </ul>
                      </div>
                      <form name="frmreply<?=$rex->id?>" action="<?php echo base_url();?>problems/submitreply/<?=$qId?>/<?=$userId?>" method="post">
                        <input type="hidden" name="comment_id" value="<?=$comId?>" />
                        <div class="chat-sec-1" id="chat-d2_1<?=$rex->id?>" style="display:none;">
                          <div class="comment-area2">
                            <div class="form-group">
                              <textarea name="reply<?=$comId?>" class="form-control" style="font-size:13px;" required></textarea>
                            </div>
                            <?php if($this->session->userdata('id')!='') { ?>
                            <button type="submit" class="rely-dv-bn" id="hide-d2<?=$rex->id?>">Reply</button>
                            <?php } else { ?>
                            <button type="button" class="rely-dv-bn" id="hide-d2<?=$rex->id?>" data-toggle="modal" 
                                           data-target="#cusModal">Reply</button>
                            <?php }?>
                          </div>
                          <hr>
                        </div>
                      </form>
                      <? /////////////////////////////// End Reply over reply ////////////////////////// ?>
                      <?php
						  }
					   ?>
                      <hr />
                    </div>
                    <?php
                        } // End comment loop for related
                     }
                     else
                     {
                    ?>
                    <div align="center">No Comments Found!</div>
                    <?php
                      }
                     ?>
                  </div>
                  <div id="reldet2"></div>
                </div>
              </div>
              <a class="comon-more-bn1" id="moreless-button-new3_<?=$rx->id?>" onclick="javascript:readmore2(<?=$rx->id?>)">Read more</a> 
              <a class="comon-more-bn1" id="moreless-button-new3c_<?=$rx->id?>" onclick="javascript:readless2(<?=$rx->id?>)" style="display:none;">Read less</a> 
            </div>
          </div>
          <?php 
              } // End answer loop
            }
           else
           {
        ?>
          <div class="card-header collapsed" id="cx<?=$qId?>"> <a class="card-title new-cp"> 
             <div class="bottom-div net-btm">
                <p> No answer yet </p>
                <?php if($this->session->userdata('id')!='') { ?>
                 <button type="button" class="default-btn relbtn" id="bx<?=$qId?>"><i class="far fa-edit"></i>Answer</button>
                <?php } else { ?>
                  <button type="button" class="default-btn" data-toggle="modal"  data-target="#cusModal"><i class="far fa-edit"></i>Answer</button>
				<?php } ?>
             </div>
          </a> 
         </div>
         
         <div style="padding:10px; display:none;" id="x<?=$qId?>">
         <form name="frm<?=$qId?>" action="<?php echo base_url();?>problems/submitproblemanswer/<?=$qId?>/<?=$userId?>" method="post">
          <textarea class="form-control" name="answer<?=$qId?>" rows="20" id="ans<?=$qId?>"></textarea>
		  
		  <script>
                tinymce.init({
                  selector: '#ans<?=$qId?>',
                  plugins: 'a11ychecker advcode casechange formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
                  toolbar: 'a11ycheck addcomment showcomments casechange checklist code formatpainter pageembed permanentpen table',
                  toolbar_mode: 'floating',
                  tinycomments_mode: 'embedded',
                  tinycomments_author: 'Author name',
                });
          </script>
         
          <?php //if($this->session->userdata('id')!='') { ?>
          <button type="submit" id="submit1" style="border: none;">Submit</button>
          <button type="button" class="btncancel" id="rc<?=$qId?>" style="border: none;">Cancel</button>
          <?php /*} else { ?>
                  <button type="button" id="submit1" data-toggle="modal"  data-target="#cusModal" 
                  style="border: none;">Submit</button>
                 <?php }*/?>
        </form>
         </div>
          <?php
              }
            ?>
        </div>
      </div>
    </div>
    <?php
          }
        }  // end main question foreach
    ?>
    <script>
	    $(document).ready(function(){
			$(".relbtn").on('click', function() {
			  var clickId = $(this).attr('id');	
			  var attrId = clickId.substr(2, 2);

			  $("#x"+attrId).show();
			  $("#cx"+attrId).hide();
			});
			
			$(".btncancel").on('click', function(){
				var canId = $(this).attr('id');	
				var res = canId.substr(2, 2);
				$("#x"+res).hide();
				$("#cx"+res).show();
			});
		});
		
		
        function readmore2(id)
        {
             document.getElementById("rq"+id).classList.remove("detail-dv-textarea");
             document.getElementById("rq"+id).classList.add("detail-dv-textarea-next");
             document.getElementById("moreless-button-new3_"+id).style.display='none';
             document.getElementById("moreless-button-new3c_"+id).style.display='block'; 
        }
        
        function readless2(id)
        {
             document.getElementById("rq"+id).classList.add("detail-dv-textarea");
             document.getElementById("rq"+id).classList.remove("detail-dv-textarea-next");
             document.getElementById("moreless-button-new3_"+id).style.display='block';
             document.getElementById("moreless-button-new3c_"+id).style.display='none';
        }
        
        function replyshow2(id)
        {
             document.getElementById("chat-d2"+id).style.display='block';
             document.getElementById("show-d2"+id).style.display='none';
             document.getElementById("hide-d2"+id).style.display='block';
        }
        
        function replyhide2(id)
        {
             document.getElementById("chat-d2"+id).style.display='none';
             document.getElementById("show-d2"+id).style.display='block';
             document.getElementById("hide-d2"+id).style.display='none';
        }
        
        function replyshow2_1(id)
        {
             document.getElementById("chat-d2_1"+id).style.display='block';
             document.getElementById("show-d2_1"+id).style.display='none';
             document.getElementById("hide-d2_1"+id).style.display='block';
        }
        
        function replyhide2_1(id)
    
        {
             document.getElementById("chat-d2_1"+id).style.display='none';
             document.getElementById("show-d2_1"+id).style.display='block';
             document.getElementById("hide-d2_1"+id).style.display='none';
        }
        
        function addcomment2(id)
        {
           document.getElementById("ad2"+id).style.display='block';
           document.getElementById("ans2"+id).style.display='none';
        }
        
        function insertcomment2(aid,qid,uid)
        {
          var xhttp = new XMLHttpRequest();
          var content = document.getElementById('com2'+aid).value;
          xhttp.open("GET", "<?php echo base_url();?>problems/addcomment2/"+aid+"/"+qid+"/"+uid+"/"+content, false);
          xhttp.send();
          
          document.getElementById("reldet").style.display = 'none';
          document.getElementById("reldet2").innerHTML = xhttp.responseText;
          document.getElementById('com2'+aid).value = '';
        }
        
        function addanswer2(id)
        {
           document.getElementById("ad2"+id).style.display='none';
           document.getElementById("ans2"+id).style.display='block';
        }
        
        function hidecomment2(id)
        {
           document.getElementById("btcom"+id).style.display='block';
           document.getElementById("hbtcom"+id).style.display='none';
           
           document.getElementById("ad2"+id).style.display='none';
        }
        
        function hideanswer2(id)
        {
           document.getElementById("hbtans"+id).style.display='none';
           document.getElementById("btans"+id).style.display='block';
           
           document.getElementById("ans2"+id).style.display='none';
        }
        
        function ansedit2(id)
        {
           document.getElementById("qans2"+id).style.display='none';
           document.getElementById("edit2"+id).style.display='block';
        }
        
        function revansedit2(id)
        {
           document.getElementById("qans2"+id).style.display='block';
           document.getElementById("edit2"+id).style.display='none';
        }
        
        function editcomment2(id)
        {
           document.getElementById("com_1"+id).style.display='none';
           document.getElementById("com_edit"+id).style.display='block';
        }
        
        function comcancel2(id)
        {
           document.getElementById("com_1"+id).style.display='block';
           document.getElementById("com_edit"+id).style.display='none';
        }
        
        function editreply2(id)
        {
           document.getElementById("rep-d2"+id).style.display='block';
           document.getElementById("rep2"+id).style.display='none';
        }
        
        function reveditreply2(id)
        {
           document.getElementById("rep-d2"+id).style.display='none';
           document.getElementById("rep2"+id).style.display='block';
        }
        
    </script> 
    <script>
        function upvote2(id,userid) {
          var xhttp = new XMLHttpRequest();
          xhttp.open("GET", "<?php echo base_url();?>vote/ansupvote/"+id+"/"+userid, false);
          xhttp.send();
          document.getElementById("demi"+id).innerHTML = xhttp.responseText;
        }
        
        function downvote2(id,userid) {
          var xhttp = new XMLHttpRequest();
          xhttp.open("GET", "<?php echo base_url();?>vote/ansdownvote/"+id+"/"+userid, false);
          xhttp.send();
          document.getElementById("demi2"+id).innerHTML = xhttp.responseText;
        }
        
        function comupvote2(id,userid) {
          var xhttp = new XMLHttpRequest();
          xhttp.open("GET", "<?php echo base_url();?>vote/comupvote/"+id+"/"+userid, false);
          xhttp.send();
          document.getElementById("demoox"+id).innerHTML = xhttp.responseText;
        }
        
        function comdownvote2(id,userid) {
          var xhttp = new XMLHttpRequest();
          xhttp.open("GET", "<?php echo base_url();?>vote/comdownvote/"+id+"/"+userid, false);
          xhttp.send();
          document.getElementById("demoox2"+id).innerHTML = xhttp.responseText;
        }
        
        function replyupvote2_1(id,userid) {
          var xhttp = new XMLHttpRequest();
          xhttp.open("GET", "<?php echo base_url();?>vote/replyupvote/"+id+"/"+userid, false);
          xhttp.send();
          document.getElementById("demooxr"+id).innerHTML = xhttp.responseText;
        }
        
        function replydownvote2_1(id,userid) {
          var xhttp = new XMLHttpRequest();
          xhttp.open("GET", "<?php echo base_url();?>vote/replydownvote/"+id+"/"+userid, false);
          xhttp.send();
          document.getElementById("demoox2r"+id).innerHTML = xhttp.responseText;
        }
        
        function ansdelete2(id) {
          var xhttp = new XMLHttpRequest();
          xhttp.open("GET", "<?php echo base_url();?>problems/reldeleteanswer/"+id, false);
          xhttp.send();
          /*xhttp.responseText;*/
          
          location.reload(true);
        }
        
        function updatecomment2(id)
        {
          var content = document.getElementById('cedit2'+id).value;
          /*alert(content);*/
          var xhttp = new XMLHttpRequest();
          xhttp.open("GET", "<?php echo base_url();?>problems/editcomment/"+id+"/"+content, false);
          xhttp.send();
          location.reload(true);
        }
        
        function removecomment2(id) {
              var xhttp = new XMLHttpRequest();
              xhttp.open("GET", "<?php echo base_url();?>problems/deletecomment/"+id, false);
              xhttp.send();
              /*xhttp.responseText;*/
              location.reload(true);
        }
        
        function updatereply2(id)
        {
              var content = document.getElementById('redit2'+id).value;
              var xhttp = new XMLHttpRequest();
              xhttp.open("GET", "<?php echo base_url();?>problems/editreply/"+id+"/"+content, false);
              xhttp.send();
              
              location.reload(true);
        }
        
        function removereply2(id) {
              var xhttp = new XMLHttpRequest();
              xhttp.open("GET", "<?php echo base_url();?>problems/deletereply/"+id, false);
              xhttp.send();
              /*xhttp.responseText;*/
              location.reload(true);
        }
        </script> 
  </div>
</div>
<? ########################## End Related Questions ############################## ?>
<!--------------- End -------------------> 