<?php  
  $user_qry=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
  $time=date("H:i:s");
?>
<style>
select { height:38px!important; line-height:14px!important; font-size:11px!important; }
body {
	overflow:auto;
	min-height:660px;
}
</style>


<section class="total-bd-area sp-scroll-bar">

<div class="container-fluid">
<div class="row">
<div class="col-md-12">
<div class="supporters-podium-wrap">
<div class="supporters-podium-top-part">
<div class="row">
<div class="col-md-12">
<h6 class="mt-1 mb-3">Meet Geeks</h6>
<p class="mb-4">Here you can find Fixers who can help you fix your problem using Remote Access Assistance, Screen Sharing & Voice Chat or Text Chat Support. If however, you're a Fixer, you can find Geeks who need fix for their problems as well by clicking Asker Geeks tab.</p>
<ul class="nav nav-pills" id="pills-tab" role="tablist">
<li class="nav-item">
  <a class="nav-link default-btn active"  id="pills-home-tab1" data-toggle="pill" role="tab" aria-controls="pills-home" aria-selected="true">Fixer Geeks</a>
</li>
<li class="nav-item">
  <a class="nav-link default-btn" id="pills-profile-tab1"  data-toggle="pill" role="tab" aria-controls="pills-profile" aria-selected="false">Asker Geeks</a>
</li>
</ul>
</div>
</div>
</div>
<!--<hr>-->
<div class="supporters-podium-bottom-part sbrt2 mx-lg-3">
<div class="row">
<div class="col-md-12">
<div class="tab-content" id="pills-tabContent">
<div class="fixer-users-tab show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
  <div class="fixer-users-tab-top">
       <form action="<?php echo base_url();?>podium/searchfixergeek" method="post" id="searchfixergeek">
          <div class="form-group">
              <div class="row sn">
                  <div class="comon-fild1">
                      <div class="td-search">
                            <!--<label for="exampleInputEmail1">Search</label>
                           <input type="text" class="form-control subrata-das1"  aria-describedby="emailHelp"> -->
                      </div>
                  </div>
                  
                  <div class="comon-fild1">
                   <div class="cnm-area">
                      <div class="col-md-3">
                          <div class="row ">
                              <div class="col-md-4 pr-0 my-auto">
                                  <label for="exampleFormControlSelect1">Filter by
                                  </label>
                              </div>
                              <div class="col-md-8 pl-0" id="comon-d1">
                                  <select class="form-control" name="score" id="score">
                                    <option value="">Geek Score</option>
                                    <option value="2.0">2.0</option>
                                    <option value="2.5">2.5</option>
                                    <option value="3.0">3.0</option>
                                    <option value="3.5">3.5</option>
                                    <option value="4.0">4.0</option>
                                    <option value="4.5">4.5</option>
                                    <option value="5.0">5.0</option>
                                  </select>
                              </div>
                          </div>
                      </div>
                      <div class="col-md-6">
                          <div class="row">
                              <div class="col-md-2 pr-0 my-auto">
                                  <label for="exampleFormControlSelect1">Availability</label>
                              </div>
                              <div class="col-md-3 pr-0" id="comon-d1">
                                <select class="form-control" name="start_time" id="starttime">
                                  <option>Start time</option>
                                  <option value="12:00 AM">12:00 AM</option>
                                  <option value="12:30 AM">12:30 AM</option>
                                  <option value="1:00 AM">1:00 AM</option>
                                  <option value="1:30 AM">1:30 AM</option>
                                  <option value="2:00 AM">2:00 AM</option>
                                  <option value="2:30 AM">2:30 AM</option>
                                  <option value="3:00 AM">3:00 AM</option>
                                  <option value="3:30 AM">3:30 AM</option>
                                  <option value="4:00 AM">4:00 AM</option>
                                  <option value="4:30 AM">4:30 AM</option>
                                  <option value="5:00 AM">5:00 AM</option>
                                  <option value="5:30 AM">5:30 AM</option>
                                  <option value="6:00 AM">6:00 AM</option>
                                  <option value="6:30 AM">6:30 AM</option>
                                  <option value="7:00 AM">7:00 AM</option>
                                  <option value="7:30 AM">7:30 AM</option>
                                  <option value="8:00 AM">8:00 AM</option>
                                  <option value="8:30 AM">8:30 AM</option>
                                  <option value="9:00 AM">9:00 AM</option>
                                  <option value="9:30 AM">9:30 AM</option>
                                  <option value="10:00 AM">10:00 AM</option>
                                  <option value="10:30 AM">10:30 AM</option>
                                  <option value="11:00 AM">11:00 AM</option>
                                  <option value="11:30 AM">11:30 AM</option>
                                  <option value="12:00 PM">12:00 PM</option>
                                  <option value="12:30 PM">12:30 PM</option>
                                  <option value="1:00 PM">1:00 PM</option>
                                  <option value="1:30 PM">1:30 PM</option>
                                  <option value="2:00 PM">2:00 PM</option>
                                  <option value="2:30 PM">2:30 PM</option>
                                  <option value="3:00 PM">3:00 PM</option>
                                  <option value="3:30 PM">3:30 PM</option>
                                  <option value="4:00 PM">4:00 PM</option>
                                  <option value="4:30 PM">4:30 PM</option>
                                  <option value="5:00 PM">5:00 PM</option>
                                  <option value="5:30 PM">5:30 PM</option>
                                  <option value="6:00 PM">6:00 PM</option>
                                  <option value="6:30 PM">6:30 PM</option>
                                  <option value="7:00 PM">7:00 PM</option>
                                  <option value="7:30 PM">7:30 PM</option>
                                  <option value="8:00 PM">8:00 PM</option>
                                  <option value="8:30 PM">8:30 PM</option>
                                  <option value="9:00 PM">9:00 PM</option>
                                  <option value="9:30 PM">9:30 PM</option>
                                  <option value="10:00 PM">10:00 PM</option>
                                  <option value="10:30 PM">10:30 PM</option>
                                  <option value="11:00 PM">11:00 PM</option>
                                  <option value="11:30 PM">11:30 PM</option>
                                </select>
                              </div>

                              <div class="col-md-3 " id="comon-d1">
                                  <select class="form-control" name="end_time" id="endtime">
                                  <option>End time</option>
                                  <option value="12:00 AM">12:00 AM</option>
                                  <option value="12:30 AM">12:30 AM</option>
                                  <option value="1:00 AM">1:00 AM</option>
                                  <option value="1:30 AM">1:30 AM</option>
                                  <option value="2:00 AM">2:00 AM</option>
                                  <option value="2:30 AM">2:30 AM</option>
                                  <option value="3:00 AM">3:00 AM</option>
                                  <option value="3:30 AM">3:30 AM</option>
                                  <option value="4:00 AM">4:00 AM</option>
                                  <option value="4:30 AM">4:30 AM</option>
                                  <option value="5:00 AM">5:00 AM</option>
                                  <option value="5:30 AM">5:30 AM</option>
                                  <option value="6:00 AM">6:00 AM</option>
                                  <option value="6:30 AM">6:30 AM</option>
                                  <option value="7:00 AM">7:00 AM</option>
                                  <option value="7:30 AM">7:30 AM</option>
                                  <option value="8:00 AM">8:00 AM</option>
                                  <option value="8:30 AM">8:30 AM</option>
                                  <option value="9:00 AM">9:00 AM</option>
                                  <option value="9:30 AM">9:30 AM</option>
                                  <option value="10:00 AM">10:00 AM</option>
                                  <option value="10:30 AM">10:30 AM</option>
                                  <option value="11:00 AM">11:00 AM</option>
                                  <option value="11:30 AM">11:30 AM</option>
                                  <option value="12:00 PM">12:00 PM</option>
                                  <option value="12:30 PM">12:30 PM</option>
                                  <option value="1:00 PM">1:00 PM</option>
                                  <option value="1:30 PM">1:30 PM</option>
                                  <option value="2:00 PM">2:00 PM</option>
                                  <option value="2:30 PM">2:30 PM</option>
                                  <option value="3:00 PM">3:00 PM</option>
                                  <option value="3:30 PM">3:30 PM</option>
                                  <option value="4:00 PM">4:00 PM</option>
                                  <option value="4:30 PM">4:30 PM</option>
                                  <option value="5:00 PM">5:00 PM</option>
                                  <option value="5:30 PM">5:30 PM</option>
                                  <option value="6:00 PM">6:00 PM</option>
                                  <option value="6:30 PM">6:30 PM</option>
                                  <option value="7:00 PM">7:00 PM</option>
                                  <option value="7:30 PM">7:30 PM</option>
                                  <option value="8:00 PM">8:00 PM</option>
                                  <option value="8:30 PM">8:30 PM</option>
                                  <option value="9:00 PM">9:00 PM</option>
                                  <option value="9:30 PM">9:30 PM</option>
                                  <option value="10:00 PM">10:00 PM</option>
                                  <option value="10:30 PM">10:30 PM</option>
                                  <option value="11:00 PM">11:00 PM</option>
                                  <option value="11:30 PM">11:30 PM</option>
                                </select>
                              </div>

                              <div class="col-md-3 pl-0" id="comon-d1">
                              <select class="form-control" name="timezone" id="zone">
                                  <option>Timezone</option>
                                  <option value="UTC-12:00">UTC-12:00</option>
                                  <option value="UTC-11:00">UTC-11:00</option>
                                  <option value="UTC-10:00">UTC-10:00</option>
                                  <option value="UTC-9:00">UTC-9:00</option>
                                  <option value="UTC-8:00">UTC-8:00</option>
                                  <option value="UTC-7:00">UTC-7:00</option>
                                  <option value="UTC-6:00">UTC-6:00</option>
                                  <option value="UTC-5:00">UTC-5:00</option>
                                  <option value="UTC-4:00">UTC-4:00</option>
                                  <option value="UTC-3:00">UTC-3:00</option>
                                  <option value="UTC-2:00">UTC-2:00</option>
                                  <option value="UTC-1:00">UTC-1:00</option>
                                  <option value="UTC+0:00">UTC+0:00</option>
                                  <option value="UTC+1:00">UTC+1:00</option>
                                  <option value="UTC+2:00">UTC+2:00</option>
                                  <option value="UTC+3:00">UTC+3:00</option>
                                  <option value="UTC+3:30">UTC+3:30</option>
                                  <option value="UTC+4:00">UTC+4:00</option>
                                  <option value="UTC+4:30">UTC+4:30</option>
                                  <option value="UTC+5:00">UTC+5:00</option>
                                  <option value="UTC+5:30">UTC+5:30</option>
                                  <option value="UTC+5:45">UTC+5:45</option>
                                  <option value="UTC+6:00">UTC+6:00</option>
                                  <option value="UTC+6:30">UTC+6:30</option>
                                  <option value="UTC+7:00">UTC+7:00</option>
                                  <option value="UTC+8:00">UTC+8:00</option>
                                  <option value="UTC+8:45">UTC+8:45</option>
                                  <option value="UTC+9:00">UTC+9:00</option>
                                  <option value="UTC+9:30">UTC+9:30</option>
                                  <option value="UTC+10:00">UTC+10:00</option>
                                  <option value="UTC+10:30">UTC+10:30</option>
                                  <option value="UTC+11:00">UTC+11:00</option>
                                  <option value="UTC+12:00">UTC+12:00</option>
                                  <option value="UTC+12:45">UTC+12:45</option>
                                  <option value="UTC+13:00">UTC+13:00</option>
                                  <option value="UTC+14:00">UTC+14:00</option>
                              </select>
                              </div>
                          </div>
                      </div>
                      <div class="col-md-3 p-0 new-add-flter">
                          <ul class="host-section-left-list-ul">
                              <li class="list-non-active li-scroll dropdown fixes nav-item new-after">
                                  <a class="dropdown-toggle nav-link modal-link border-right-1 position-relative" href="#" id="plus-mode2">Select Category</a>
                                  <input type="hidden" name="category" class="searchcategory">
                                  
                                  <ul class=" dropdown-menu2 dropdown_menu20 subrata-das host-section-left-list-ul ul-scroll" aria-labelledby="navbarDropdown" id="table-mode2">
                                  <?php 
                                    $cat_qry=  $this->db->query('Select * from `category_master` order by ordering')->result();
                                    foreach ($cat_qry as $cat) 
									{
                                  ?>
                                  <li class="list-non-active li-scroll">
                                  <a class="nav-link dropdown-toggle topic-dp" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">              
                                    <?=$cat->category_name?>  <b class="caret"></b>
                                  </a>
                                  <ul class="dropdown-menu slider-dp-menu1 category-scroll" aria-labelledby="navbarDropdownMenuLink">
                                  <?php 
                                  $subcat = $this->db->query("select * from `sub_category_master` where cat_id = '".$cat->id."'");
                                  foreach($subcat->result() as $row) 
                                  {
                                  ?>
                                  <li class="dropdown-submenu sb-topic1 li-scroll">
                                  <a href="#" class="dropdown-item dropdown-toggle topic-sub1"><?=$row->sub_category_name?></a>
                                  <ul class="dropdown-menu sb-topic2">
                                  <?php
                                  $mcat = $this->db->query("select * from `sub_sub_category_master` where sub_cat_id = '".$row->id."'");
                                  foreach($mcat->result() as $rec) 
                                  { 
                                  ?>
                                  <li>  
                                  <div class="form-group srbt new-flex form-group-2 my-2 mx-2">
                                    <input type="checkbox" name="cat" id="cat<?=$rec->id?>"  value="<?=$rec->sub_sub_category_name?>"
                                     class="srvt form-control">           						
                                    <label for="table1"><?=$rec->sub_sub_category_name?></label>
                                  </div>
                                  </li>
                                  <?php } ?>
                                  </ul>
                                  </li>
                                  <?php } ?>
                                  </ul>
                                  </li>
                                  <?php } ?>
                                  </ul>
                              </li>
                          </ul>
                       </div>
                    </div>   
                  </div>
              </div>
          </div>
   </form>
  </div>
  <div class="fixer-users-tab-bottom">
    <div class="mv-view">
      <table id="example2" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th width="6%">Online</th>
                <th width="12%">Geek Name</th>
                <th width="6%">Score</th>
                <th width="12%">Availability</th>
                <th width="9%">Timezone</th>
                <th width="11%">Problems Fixed</th>
                <th width="29%">Categories (Expert in)</th>
                <th width="15%">View/Hire</th>
            </tr>
        </thead>
        <tbody>
          <?php
          //$this->db->select('user_id');
          //$this->db->distinct();
          //$fixer_qry=$this->db->get_where('fixergeek_master',array('user_id!='=>$user_qry->id))->result();
          
		  $fixer_qry=$this->db->query("select * from `fixergeek_master`");
		  
		  foreach($fixer_qry->result() as $fixer)
          {
		      $val = $this->db->get_where('review_master',array('id'=>$fixer->fixer_id))->row();
			  $avg = ($val->conduct+$val->timing+$val->literacy+$val->knowledge+$val->pchandle+$val->type_speed)/6;
			  
			  $user=$this->db->get_where('user_master',array('id'=>$fixer->user_id))->row();
			  $start_time=date_create($user->start_time);
			  $end_time=date_create($user->end_time);
			  
			    $review=$this->db->get_where('review_master',array('fixer_id'=>$fixer->user_id));
				$stat=$this->db->get_where('review_master',array('fixer_id'=>$fixer->user_id , 'status'=>'Fixed'));
				$stat2=$this->db->get_where('review_master',array('fixer_id'=>$fixer->user_id , 'status'=>'Not Fixed'));
				
				$score = $review->row();
				$tot = ($score->conduct+$score->timing+$score->literacy+$score->knowledge+$score->pchandle+$score->type_speed) / 6;
				$fixes = $stat->num_rows();
				$nonfixes = $stat2->num_rows();
          ?>
           <tr class="fixer">
              <td>
			      <?php if($user->status=="online"){?>
                  <div class="on-bn"><span style="display:none;">Online</span></div>
                  <?php }if($user->status=="offline"){ ?>
                  <div class="on-bn2"><span style="display:none;">Offline</span></div>
                  <?php } ?>
              </td>
              <td>
               <div class="dropdown td-view-d1">
                  <a href="#" class="pro-view dropdown-toggle" id="dropdownMenuButton" 
                  data-toggle="dropdown" data-hover="dropdown"> 
                  <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" border="0"  />
				          <?=ucwords($user->geek_name)?> 
                  </a>
                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> 
                    <div class="profile-hover-details profile-hover-details3">
                      <div class="com-div">
                        <h6>
                        <span class="podiusm-us-pic">
                          <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" border="0"  />
                         <?=ucwords($user->geek_name)?>
                        </span></h6>
                      </div>
                      <div class="com-div"> <span class="de-ancor-color">Geek Score: <?=$avg?>   &nbsp;&nbsp;&nbsp;&nbsp;   <a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$user->id;?>">View Score</a></span> </div>
                      <div class="com-div">
                        <p>Availability: <?=$fixer->start_time;?> to <?=$fixer->end_time;?></p>
                      </div>
                      <div class="com-div">
                        <p>Timezone: Eastern Standard Time (<?=$fixer->timezone?>)</p>
                      </div>
                      <div class="com-div">
                        <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> <?=$fixes?> Problems Fixed</p>
                      </div>
                      <div class="com-div">
                        <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> <?=$nonfixes?> Problems Not Fixed</p>
                      </div>
                      <div class="com-div">
                        <div class="new-sec">
                          <div class="profile-hover-list">
                            <p>Categories (Expert in): </p>
                             <?php 
                             /*$sub_qry=$this->db->get_where('fixergeek_master',array('user_id'=>$fixer->user_id))->result();
                             foreach($sub_qry as $sub)
                             {
                              $cat=$this->db->get_where('sub_sub_category_master',array('id'=>$sub->sub_sub_cat_id))->row();
                              ?>
                              <a href="#"><?=$cat->sub_sub_category_name?></a> 
                           <?php }*/ ?>
                           
                            <?php
                              $fixer=$this->db->get_where('fixergeek_master',array('user_id'=>$fixer->user_id))->row();
                              $expert = explode(",",$fixer->sub_sub_cat_id);
                              $slice = array_slice($expert, 0,3);
                              
                              foreach($slice as $val)
                              {
                              $item = $this->db->get_where('sub_sub_category_master',array('id'=>$val))->row();
                            ?>
                                   <a href="<?php echo base_url();?>category/show/<?=(str_replace("&","-",str_replace(" ","_",$item->sub_sub_category_name)))?>"><?php echo $item->sub_sub_category_name;?></a> 
                            <?php
                              }
                            ?> 
                          <span style="font-size:11px;"> 
                            <a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$user->id;?>">
                            <?php if(count($expert) > 3) { echo (count($expert) - 3)." more..."; } ?></a>
                          </span>
                            
                          </div>
                        </div>
                      </div>
                      <div class="com-div">
                        <div class="al-bn"> 
                            <a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$user->id;?>">Read Full Profile</a> 
                            <a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$user->id;?>">Hire Fixer</a>
                        </div>
                      </div>
                    </div>
                  </div>
               </div>
                
              </td>
              <td><?=number_format($tot,1)?></td>
              <td><?php if($fixer->end_time!="") { echo $fixer->start_time." to ".$fixer->end_time; } else { echo 'N/A';}?></td>
              <td><?php if($user->timezone!="") { echo $user->timezone; } else { echo 'N/A';}?></td>
              <td><i class="fas fa-check"></i> <?=$fixes?></td>
              <td class="new-style2 fixertd">
              <ul class="an-lin">
			  <?php
				  $fixer = $this->db->get_where('fixergeek_master',array('user_id'=>$fixer->user_id))->row();
				  $expert = explode(",",$fixer->sub_sub_cat_id);
				  
				  $citrus = array_slice($expert, 0, 3);
				  
				  $x=0;
				  foreach($citrus as $val)
				  {
					 $item = $this->db->get_where('sub_sub_category_master',array('id'=>$val))->row();
					 
				 ?>
				   <li class="cat">
                       <a href="<?php echo base_url();?>category/show/<?=(str_replace("&","-",str_replace(" ","_",$item->sub_sub_category_name)))?>">
                         <?php echo $item->sub_sub_category_name;?>
                       </a>
                   </li>
				 <?php
				  }
         ?>
         <a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$user->id;?>">
         <?php 
				  if(count($expert) > 3) { echo (count($expert) - 3)." more..."; }
				?></a>
                <!-- <li><a class="toggle-more2" id="toggle-more2">More...</a></li>-->
              </ul>
                <!--<ul class="more-list2" id="more-list2">

                <?php
				  /*$fixer=$this->db->get_where('fixergeek_master',array('user_id'=>$fixer->user_id))->row();
				  $expert = explode(",",$fixer->sub_sub_cat_id);
				  foreach($expert as $val)
				  {
					 $item = $this->db->get_where('sub_sub_category_master',array('id'=>$val))->row();
				 ?>
				  <li><a href="#"><?php echo $item->sub_sub_category_name;?></a></li> 
				 <?php
				  }*/
				?>
                
                </ul>-->
              </td>
              <td><ul class="an-link2">
                  <li><a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$user->id;?>">View Profile</a></li>
                  <li><a href="<?php echo base_url();?>supporterspodiumprofile/view/<?=$user->id;?>"> Hire Fixer</a></li>
                </ul></td>
            </tr>
          <?php } ?>
        </tbody>
    </table>
    </div>
  </div>
</div>


<div class="just-a-user-tab" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
  <div class="just-a-user-tab-top">
      <form action="<?php echo base_url();?>podium/searchaskergeek" method="post" id="searchaskergeek">
          <div class="form-group">
              <div class="row">
                  <div class="col-md-3">
                      <div class="row">
                         <!--  <div class="col-md-2 pr-0 my-auto">
                              <label for="exampleInputEmail1">Search</label>
                          </div>
                          <div class="col-md-10">
                              <input type="text" class="form-control subrata-das1" aria-describedby="emailHelp">
                          </div> -->
                      </div>
                  </div>
                  <div class="col-md-2">
                      <div class="row">
                          <div class="col-md-5 pr-0 my-auto">
                              <label for="exampleFormControlSelect1" class="ask-label">Filter by</label>
                          </div>
                          <div class="col-md-7 pl-0">
                              <select class="form-control" name="status" id="status">
                                  <option value="">--Select--</option>
                                  <option value="online">Online</option>
                                  <option value="offline">Offline</option>
                              </select>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-2">
                      <div class="row">
                          <div class="col-md-10">
                              <select class="form-control" name="level" id="level">
                                  <option>Level Required</option>
                                  <option value="1">Chatter (Level 1)</option>
                                  <option value="2">Helper (Level 2)</option>
                                  <option value="3">Fixer (Level 3)</option>
                              </select>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </form>
  </div>
  <div class="just-a-user-tab-bottom fixer-users-tab-bottom">
      <table id="example3" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th class="text-center" scope="col">Online</th>
                <th class="text-center" scope="col">Geek Name</th>
                <th class="text-center" scope="col">Level Required</th>
                <th class="text-center" scope="col">Current Problem</th>
                <th class="text-center" scope="col">Problems Fixed</th>
                <th class="text-center" scope="col">Problems Not Fixed</th>
                <th class="text-center" scope="col">View/Fix</th>
            </tr>
        </thead>
        <tbody>
           <?php
             $asker_qry=$this->db->get_where('user_master',array('id!='=>$user_qry->id))->result();
             foreach($asker_qry as $asker)
             {
			    $start_time=date_create($asker->start_time);
			    $end_time=date_create($asker->end_time);
				
				$question=$this->db->get_where('questions_master',array('user_id'=>$asker->id))->row();
				
				if($question->level==3) { $level = 'Fixer (Level 3)'; }
				if($question->level==2) { $level = 'Helper (Level 2)'; }
				if($question->level==1) { $level = 'Chatter (Level 1)'; }
				
				$assign = $this->db->get_where('questions_assign_master',array('assigned_by'=>$asker->id, 'status'=>'Fixed'));
				$assign2 = $this->db->get_where('questions_assign_master',array('assigned_by'=>$asker->id, 'status'=>'Not Fixed'));
				
				$fix = $assign->num_rows();
				$notfix = $assign2->num_rows();
            ?>
              
             <tr class="asker">
                <td class="text-center" scope="row" align="center">
                <?php if($asker->status=="online") { ?>
                <i class="fa fa-circle online" aria-hidden="true"></i> <span style="display:none;">online</span>
                <?php } else if($asker->status=="offline") { ?>
                <i class="fa fa-circle offline" aria-hidden="true"></i> <span style="display:none;">offline</span>
                <?php } ?>
                </td>
                <td class="nt-special-a"> <a href="#" class="pro-view">
				<img src="<?php echo base_url();?>uploads/<?=$asker->profile_picture?>" border="0"  /><?=ucwords($asker->geek_name);?></a></td>
                <td class="text-center"><?php if($question->level!=NULL){ echo $level; } else { echo '<i class="fa fa-times" aria-hidden="true"></i>'; }?></td>
                <td>
                   <?php if($question->question) {
                     echo $question->question;
                    } else { 
					  echo 'No Problem Found!';
					}?>
                </td>
                <td class="text-center"><i class="fa fa-check" aria-hidden="true"></i> <?=$fix?></td>
                <td class="text-center"><i class="fa fa-times" aria-hidden="true"></i> <?=$notfix?></td>
                <td class="text-center new-style-add-2">
                    <a href="<?php echo base_url();?>askerprofile/view/<?=$asker->id?>">View Profile</a>
                    <a href="<?php echo base_url();?>podium">Fix this Problem</a>
                </td>
            </tr>
              
           <?php
		    } 
		   ?> 
        </tbody>
    </table>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="clearfix"></div>
</div>

</section>
<script>
  $(document).ready(function() {
   $('#pills-home-tab1').click(function(){
     $('#pills-home').show();
     $('#pills-profile').hide();
   });
    $('#pills-profile-tab1').click(function(){
     $('#pills-home').hide();
     $('#pills-profile').show();
   });
    
  // var hash = window.location.hash;
  // hash && $('ul.nav a[href="' + hash + '"]').tab('show');

  // $('.nav-tabs a').click(function (e) {
  //   $(this).tab('show');
  // });
});

$(document).ready(function(){
      /// Asker Sorting
	  $("#status").change(function(){
		var value = $(this).val().toLowerCase();
		$("#example3 .asker").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  }); 
	  
	  $("#level").change(function(){
		var value = $(this).val().toLowerCase();
		$("#example3 .asker").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  }); 
	  
	  /// Fixer Sorting
	  $("#score").change(function(){
		var value = $(this).val().toLowerCase();
		$("#example2 .fixer").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  }); 
	  
	   $("#zone").change(function(){
		var value = $(this).val().toLowerCase();
		$("#example2 .fixer").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  }); 
	  
	  $("#starttime").on("keyup",function(){
		var value = $(this).val().toLowerCase();
		$("#example2 .fixer").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  }); 
	  
	  $("#endtime").on("keyup",function(){
		var value = $(this).val().toLowerCase();
		$("#example2 .fixer").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
});

$(document).ready(function(){
  $('input[id^="cat"]').on('click', function() 
  {  
    //alert(this.id); // Get the ID
   // alert($(this).attr('value')); // Get the value attribute
		var favorite = [];
		$.each($("input[name='cat']:checked"), function(){
			favorite.push($(this).val());
		});
		//alert(favorite.join(", "));
		var category = favorite.join(", ");
		var numbersArray = category.split(',');
		
		var nums = numbersArray.length;
		var rest = (nums-2)+'more';
		
		if(category!="") {
		   /*if(nums <= 2)
		   {
		     $("#plus-mode2").html(category);
		   }
		   else
		   {
		     $("#plus-mode2").html(category +rest);
		   }*/
		   
		   $("#plus-mode2").html(category);
		}
		else
		{
		  $("#plus-mode2").html('Select Category');
		  
		}
  });
});
</script>