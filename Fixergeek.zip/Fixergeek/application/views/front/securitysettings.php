<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<?php 
$id = $this->session->userdata('id');
$user=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
$country=$this->db->get_where('country_master',array('iso'=>$user->country))->row();

$master=$this->db->query("select * from `user_master` where `id`!='".$id."' order by geek_name ASC");

$blocked = $this->db->get_where('user_block_master', array('user_id'=>$id));

$query = $this->db->query("select * from `fixergeek_master` where `user_id` = '".$this->session->userdata('id')."'");
$numrow = $query->num_rows();
?>
<section class="total-bd-area">
  <div class="container-fluid">
    <div class="row">
      <div class="new-add-sec">
          <div class="col-md-3 col-lg-3">
            <div class="left-slidber-area sp-height">
              <div class="host-section-left-list">
                <?php $this->load->view('inc/left-navigation-supporters');?>
              </div>
            </div>
          </div>
          <div class="col-md-9 col-lg-9 pl-0">
            <div class="bod-area">
              <div class="text-part-sec home-inside-d1">
                <div class="security-settings-wrap">
                  <!-- <h6 class="mt-3 mb-3 security-settings-page-heading"> Change Password </h6>
                  <div class="security-password-div">
                    <form>
                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-8">
                            <div class="row mb-3">
                              <div class="col-md-4 my-auto">
                                <label for="exampleInputPassword1">Current Password</label>
                              </div>
                              <div class="col-md-8">
                                <input type="password" class="form-control" id="exampleInputPassword1">
                              </div>
                            </div>
                            <div class="row mb-3">
                              <div class="col-md-4 my-auto">
                                <label for="exampleInputPassword1">New Password</label>
                              </div>
                              <div class="col-md-8">
                                <input type="password" class="form-control" id="exampleInputPassword1">
                              </div>
                            </div>
                            <div class="row mb-3">
                              <div class="col-md-4 my-auto">
                                <label for="exampleInputPassword1">Confirm New Password</label>
                              </div>
                              <div class="col-md-8">
                                <input type="password" class="form-control" id="exampleInputPassword1">
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div> -->
                  <h6 class="mt-2 mb-3 security-settings-page-heading"> Block/Unblock Geek </h6>
                  <div class="block-user-form-part mb-4">
                    <form>
                      <div class="form-group">
                        <div class="row justify-content-center mb-3">
                          <div class="col-md-3 my-auto">
                            <label for="exampleInputEmail1">Block Geek</label>
                          </div>
                          <div class="col-md-7">
                            <input type="text" class="form-control" id="geek" aria-describedby="emailHelp" placeholder="Enter Geek Name" style="height:38px;">
                          </div>
                          <div class="col-md-2 pl-0">
                            <button type="submit" id="btngeek" class="btn btn-primary default-btn">Block</button>
                          </div>
                        </div>
                      </div>
                    </form>
                    <div class="row justify-content-end mb-5">
                      <div class="col-md-9">
                        <ul class="blocked-list">
                          <?php 
                             foreach($blocked->result() as $rec) 
                             {
                          ?>
                            <li><?=$rec->block_ids?> (<a href="javascript:unblock(<?=$rec->id?>)">Unblock</a>)</li>
                          <?php }?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  
                  <div class="account-deactivation pt-3">
                     <ul>
                        <li> <a class="mb-3" href="<?php echo base_url();?>profile/changepassword">Change Password</a></li>
                        
                        <?php if($numrow==0) {?>
                        <li> <a class="mb-3" href="<?php echo base_url();?>profile/account">
                        <?php if($user->account=="Activate"){ echo "Deactivate Account"; } else { echo "Activate Account";}?> 
                        </a> </li>     
                        <?php }?>        
                       <li> <a class="mb-3" href="<?php echo base_url();?>profile/accountdelete">Delete Account</a>  </li>
                    </ul>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
      </div>
          
      <div class="sd1 new-spc new-special-home"> 
          <div class="new-right-sec-add-howit">
             <h3> How it works </h3>
             <a data-toggle="modal" data-target="#exampleModal-vieo">
                <img src="<?php echo base_url();?>assets2/images/imgpsh_fullsize_anim.png" alt="user">
             </a>
          </div>
          <div class="ads-new-1">
            <a href="#">Advertisement</a>
          </div>
      </div>
    </div>
  </div>
</section>

<script>
  $( function() {
    var availableTags = [
	  <?php foreach($master->result() as $row) {?>
      "<?php echo $row->geek_name;?>",
      <?php } ?>
    ];
    $( "#geek" ).autocomplete({
      source: availableTags
    });
  } );
</script>
  
<script>
$(document).ready(function()
	{
	 //////////////////////////////////////////
	  $("#btngeek").click(function()
	  {
		  var geek = $("#geek").val();
			   
		  if(geek=='')
		  {
			 swal("Sorry!! Put the geek name to block.");
		  }
		  else
		  {
			 $.ajax({url: "<?php echo base_url();?>securitysettings/block/"+geek, success: function(result){
				 location.reload(true);
			  }});
		  }
	 });
	 
   });
   
   function unblock(id)
	{
	  var con = window.confirm("Are you sure to unblock this geek?");
	  if(con==true)
	  {
		  var xhttp = new XMLHttpRequest();
		  xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			 location.reload(true);
			}
		  };
		  xhttp.open("GET", "<?php echo base_url();?>securitysettings/unblock/"+id, true);
		  xhttp.send();
		 }
	  }
 </script>  
  