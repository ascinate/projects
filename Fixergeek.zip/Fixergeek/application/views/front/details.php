<?php 
$qus_id=$this->uri->segment(3);
$question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
$user=$this->db->get_where('user_master',array('id'=>$question->user_id))->row();
$date=date_create($question->post_date);   
$user_qry=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
?>
<section class="total-bd-area">
    <div class="container-fluid">
           <div class="row">
                <div class="col-md-3 col-lg-2 pr-md-0">
                      <div class="left-slidber-area">
                        <div class="host-section-left-list">
                          <?php $this->load->view('inc/left-navigation-supporters');?>
                      </div>
                      </div>
                 </div>
                <div class="col-md-9 col-lg-10">
                    <div class="bod-area">
                        
                        <div class="text-part-sec2">                                                  
                           
                            
                            <div class="host-section-mid-profile-box">
                              <div class="comon-border-new1">
                                <div class="ask-area-middle-n2">
                                   <div class="post-area">
                                      <div class="middle-post-area">
                                          <div class="left-sec-post p-0">
                                             <div class="user-pic">
                                               <?php if($question->user_id=="Admin"){?>
                                                  <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user">
                                                <?php }else{?>
                                                  <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" alt="user">
                                                <?php } ?>
                                             </div>
                                             <div class="post-adte">
                                                <?php if($question->user_id=='Admin'){echo"Administrator";}else{
                                                    echo $user->name;
                                                  }?>, <?php echo date_format($date,"j F ,Y");?> <br> <?=$question->topics?>
                                             </div>
                                          </div>
                                          <div class="right-sec-post">
                                             <?php
                                            if($this->session->userdata('id')!='')
                                            {
                                            ?>
                                               <a href="#"> <i class="fas fa-user-check"></i> </a>
                                            <?php } ?>
                                          </div>
                                      </div>
                                      <div class="last-post-area">
                                          <div class="left-sec-post">
                                              <div class="post-adte">
                                                <h6><?=$question->question;?></h6>
                                               <div class="read_less">
                                                   <p><?=substr($question->content,0,200);?>...</p> 
                                                  </div>
                                                <div class="moretext">
                                                   <div class="text-area">
                                                     <p><?=$question->content?></p>
                                                   </div>
                                                  </div>
                                                <a id="moretext" style="cursor: pointer;color: blue;">Read more</a>
                                             </div>
                                              <div class="user-pic">
                                                  
                                                  <img src="<?php echo base_url();?>uploads/<?=$question->uploaded_files?>" alt="user">
                                               
                                               </div>
                                          </div>
                                      </div>
                                      <div class="footer-post-sec">
                                        <!--right-fot-->
                                        <!-- <ul class="left-fot">
                                          <li> <a href="#"> </a> </li>
                                          <li class="dropdown show share-bn"> 
                                             <a class="btn btn-secondary dropdown-toggle padding-off" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                             <i class="fas fa-share"></i> </a> 
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                              <a class="dropdown-item" href="#">Facebook</a>
                                              <a class="dropdown-item" href="#">Twitter</a>
                                               <a class="dropdown-item" href="#">Copy link</a>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#exampleModal-new">Embed Answer</a>
                                            </div>
                                          </li>
                                          <li class="dropdown show share-bn"> 
                                             <a class="btn btn-secondary dropdown-toggle padding-off" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-ellipsis-v"></i> </a> 
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                              <a class="dropdown-item" href="#">Bookmark</a>
                                              <a class="dropdown-item" href="#">Suggest</a>
                                              <a class="dropdown-item" href="#">Report</a>
                                              <a class="dropdown-item" href="#"> Edit Question and Source </a>
                                              <a class="dropdown-item" href="#"> Thanks </a>
                                              <a class="dropdown-item" href="#"> Downvote Answer </a>
                                              <a class="dropdown-item" href="#"> Downvote Question </a>
                                              <a class="dropdown-item" href="#"> Report </a>
                                            </div>
                                          </li>
                                        </ul>--><!--left-fot-->
                                        
                                        </div><!--footer-post-sec-->
                                        <a class="up"> <i class="fas fa-arrow-up"></i> 4.8k</a>
                                        <a id="hide2-new" class="show"> <i class="far fa-comment"></i> 4.8k</a> 
                                        <?php 
                                        if($this->session->userdata('id')!='')
                                        {?>
                                        <div class="chat2-new">
                                           <div class="comment-area">
                                                <form action="<?php echo base_url()?>details/submitcomment/<?=$user_qry->id?>/<?=$qus_id?>" method="post">
                                                     <figure>
                                                      <img src="<?php echo base_url();?>uploads/<?=$user_qry->profile_picture?>" alt="user">
                                                     </figure>
                                                     <div class="form-group">
                                                        <input type="text" name="comment" placeholder="" class="form-control">
                                                     </div>
                                                
                                                 <button type="submit" class="comment-bn" id="hide2-new"> Add comments </button>
                                              </form>
                                           </div>
                                      </div>
                                    <?php } ?>
                                   </div>
                                   <!--  -->
                                   <hr class="mt-2 clearfix" style="clear: both;">
                                   <?php 
                                   $this->db->order_by('id','desc');
                                   $comment_qry=$this->db->get_where('comment_master',array('question_id'=>$qus_id))->result();
                                   foreach($comment_qry as $val)
                                   {
                                   $date2=date_create($val->post_date);
                                   $us=$this->db->get_where('user_master',array('id'=>$val->user_id))->row();
                                   ?>
                                   <div class="post-area mt-2 contentt">
                                      <div class="middle-post-area">
                                          <div class="left-sec-post p-0">
                                             <div class="user-pic">
                                               <?php if($val->user_id=="Admin"){?>
                                                  <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user">
                                                <?php }else{?>
                                                  <img src="<?php echo base_url();?>uploads/<?=$us->profile_picture?>" alt="user">
                                                <?php } ?>
                                             </div>
                                             <div class="post-adte">
                                                <?php if($val->user_id=='Admin'){echo"Administrator";}else{
                                                    echo $us->name;
                                                  }?><br> <?php echo date_format($date2,"j F ,Y");?>
                                             </div>
                                          </div>
                                         
                                      </div>
                                      <div class="last-post-area">
                                          <div class="left-sec-post">
                                              <div class="post-adte">
                                                <p><?=$val->comments;?></p>
                                                
                                                <a class="moreless-button-d1 comon-bn-detials">(More)</a>
                                             </div>
                                          </div>
                                        <div class="footer-post-sec reply-div">
                                        <ul class="right-fot">
                                          <li> <a class="pr-2 pl-1 mx-1 reply-box"> <i class="fa fa-reply"></i>Reply</a> </li>
                                          <li> <a href="#" class="pr-2 pl-1 mx-1"><i class="fa fa-arrow-up"></i>Upvote</a> </li>
                                          <li> <a href="#" id="hide2-new" class="pr-2 pl-1 mx-1"><i class="fa fa-arrow-down"></i>Downvote</a> </li>
                                        </ul>
                                        <ul class="left-fot">
                                          
                                          <li class="dropdown show share-bn"> 
                                             <a class="btn btn-secondary dropdown-toggle padding-off" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-ellipsis-v"></i> </a> 
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                              <a class="dropdown-item" href="#"> Report </a>
                                            </div>
                                          </li>
                                        </ul>                                   
                                        </div><!--footer-post-sec-->
                                        <div class="chat2-new2 mt-2 chat-box-open" style="display: none;">
                                           <div class="comment-area2">
                                                <form action="<?php echo base_url()?>details/submitreply/<?=$val->user_id?>/<?=$val->question_id?>/<?=$val->id?>" method="post">
                                                   
                                                     <div class="form-group">
                                                        <textarea name="reply<?=$val->id?>" placeholder="" class="form-control" required></textarea>
                                                     </div>
                                                
                                                 <button type="submit" class="comment-bn" id="hide2-new">Reply </button>
                                              </form>
                                           </div>
                                           <hr>
                                        </div>
                                      </div>                                     
                                   </div>
                                  <?php } ?>
                                   <a id="loadMore">View More Comments</a>
                                   <!--  -->
                                </div>
                              </div>
                            </div>
                           </div>
                        
                        <div class="sd2"> 
                               <div class="lef-separate">
                                 <div class="related">
                                   <h5> Related Questions </h5>
                                   <ul class="list-realted">
                                     <li> <a href="#"> What are some good examples of progressive web apps (PWA)? </a> </li>
                                     <li> <a href="#"> How do I implement PWA in my eCommerce site? </a> </li>
                                     <li> <a href="#"> Is it worth using PWA? </a> </li>
                                     <li> <a href="#"> Which one is better for SEO ranking, AMP or PWA? </a> </li>
                                     <li> <a href="#"> What are the benefits of making your website a PWA (progressive web app)? </a> </li>
                                   </ul>
                                   <a href="#" class="ask" data-toggle="modal" data-target="#ask-Modal"> Ask Question </a>
                                 </div>
                              </div>
                              <div class="ads-sec-new">
                                 <a href="#"> Advertisement </a>
                              </div>
                               
                         </div>  
                          
                     </div>
                </div>
           </div>
        </div>
 </section>
