<section class="total-bd-area">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3 col-lg-2 pr-md-0">
        <div class="left-slidber-area">
          <div class="host-section-left-list">
            <?php $this->load->view('inc/left-navigation-supporters');?>
          </div>
        </div>
      </div>
      <div class="col-md-9 col-lg-10">
        <div class="bod-area">
          <div class="text-part-sec2">
            <div class="thank-you-total-area">
              <div class="top-sec-thanks-you">
                <figure> <img src="<?php echo base_url();?>assets2/images/thank-you.png" alt="th"> </figure>
                <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. </p>
                <a href="#" class="default-btn new-thanks-bn"> View my gide now </a> </div>
            </div>
          </div>
          <div class="sd1"> <a href="#"> Advertisement </a> </div>
        </div>
      </div>
    </div>
  </div>
</section>
