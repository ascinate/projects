<?php
  $userid = $this->session->userdata('id');
  
  /*$problems = $this->db->get_where('questions_assign_master', array('assigned_by' => $userid, 'status' => 'Not Fixed'));
  $fixes = $this->db->get_where('questions_assign_master', array('assigned_by' => $userid, 'status' => 'Fixed'));
  $pcnt = $problems->num_rows();
  $fcnt = $fixes->num_rows();*/
  
  $question_qry = $this->db->get_where('questions_master', array('user_id' => $userid));
  $cnt = $question_qry->num_rows();
?>
<section class="total-bd-area">
  <div class="container-fluid">
    <div class="row">
       <div class="new-add-sec">
          <div class="col-md-3 col-lg-3 pr-md-0">
            <div class="left-slidber-area">
              <div class="host-section-left-list">
                <?php $this->load->view('inc/left-navigation-supporters');?>
              </div>
            </div>
          </div>
          <div class="col-md-9 col-lg-9">
            <div class="bod-area">
              <div class="text-part-sec home-inside-d1 p-0">
                <div class="sub-page">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="problems-wrap mb-3">
                        <h6 class="mb-3"><b>Your Problems:</b></h6>
                        <div class="ancor"> 
                        <?php
                           if($cnt==0) 
                           {
                             echo 'No problems found.';
                           }
                           else
                           {
                             foreach($question_qry->result() as $res)
                             {
							      $title = str_replace(" ","-",trim($res->question));
								  $title_1 = str_replace("?-","",$title);
								  $title_1 = str_replace("-?","",$title);
								  $title_1 = str_replace("-?-","",$title);
								  $title_2 = str_replace("?","",$title_1);
                        ?>
                            <a href="<?php echo base_url();?>details/show/<?=$title_2?>" class="mb-1"><?=$title_2?></a> 
                         <?php
                             }
                           }
                         ?>
                        </div>
                      </div>
                      <div class="fixes-wrap mb-3">
                        <div class="ancor">
                          <h6 class="mb-3"><b>Your Fixes:</b></h6>
                          <?php
						    $answer_qry = $this->db->get_where('answers_master', array('user_id' => $userid));
						    $count = $answer_qry->num_rows();
							
                           if($count==0) 
                           {
                             echo 'No fixes found.';
                           }
						   
                           else
                           {
                               foreach($answer_qry->result() as $val)
								{
								  $record = $this->db->get_where('questions_master',array('id'=>$val->question_id))->row();
								 
								  $title = str_replace(" ","-",trim($record->question));
								  $title_1 = str_replace("?-","",$title);
								  $title_1 = str_replace("-?","",$title);
								  $title_1 = str_replace("-?-","",$title);
								  $title_2 = str_replace("?","",$title_1);
                          ?>
                            <a href="<?php echo base_url();?>details/show/<?=$title_2?>" class="mb-1"><?=$record->question?></a> 
                           <?php
                               }
                           }
                         ?>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
       </div>
          
       <div class="sd1 new-spc new-special-home"> 
          <div class="new-right-sec-add-howit">
             <h3> How it works </h3>
             <a data-toggle="modal" data-target="#exampleModal-vieo">
                <img src="<?php echo base_url();?>assets2/images/imgpsh_fullsize_anim.png" alt="user">
             </a>
          </div>
          <div class="ads-new-1">
            <a href="#">Advertisement</a>
          </div>
       </div>   
    </div>
  </div>
</section>