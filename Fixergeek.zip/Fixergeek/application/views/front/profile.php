<!--host-account-section-start-->
<section class="total-bd-area ">
  <div class="container-fluid">
    <div class="row">
      <div class="new-add-sec">
          <div class="col-md-3 col-lg-3 pr-md-0">
            <div class="left-slidber-area">
              <div class="host-section-left-list">
                    <?php $this->load->view('inc/left-navigation-supporters');?>
              </div>
            </div>
          </div>
          
          <div class="col-md-9 col-lg-9">
            <div class="bod-area">
              <div class="text-part-sec new-width-spa home-inside-d1">
                <div class="row justify-content-center p-2">
                  <div class="col-md-12 text-center">
                    <p style="color: green;"><?php echo $this->session->flashdata('msg');?></p>
                  </div>
                </div>
                <div class="account-profile-form">
                  <?php 
                     if($this->session->userdata('id')=="")
                     {
                        redirect('/');
                     }
                     
                     foreach($profile as $row) 
                     { 
                      
                      $ex = explode('-', $row->date_of_birth);
                  ?>
                  <input type="hidden" id="u_id" value="<?=$this->session->userdata('id')?>">
                  <form name="frm" action="<?php echo base_url();?>profile/editownprofile" method="post" enctype="multipart/form-data">
                    <div class="form-group">

                      
                      <div class="row mb-3">
                        <div class="col-md-3 my-auto">
                          <label for="exampleInputEmail1">Geek Name</label>
                        </div>
                        <div class="col-md-9">
                         <input type="text" name="geek_name" value="<?=$row->geek_name?>" class="form-control" aria-describedby="emailHelp" required>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-3 my-auto">
                          <label for="exampleInputEmail1">Email Address</label>
                        </div>
                        <div class="col-md-9">
                          <input type="email" name="email" value="<?=$row->email?>" class="form-control" aria-describedby="emailHelp" required>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-3 my-auto">
                          <label for="exampleInputEmail1">Full Name</label>
                        </div>
                        <div class="col-md-9">
                          <input type="text" name="name" value="<?=$row->name?>" class="form-control" aria-describedby="emailHelp" required>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-3 my-auto">
                          <label for="exampleFormControlSelect1">Date of Birth</label>
                        </div>
                        <div class="col-md-3">
                          <select name="month" class="form-control" required>
                            <option value="01"<? if($ex[1]=='01') { echo 'selected'; }?>>January</option>
                            <option value="02"<? if($ex[1]=='02') { echo 'selected'; }?>>February</option>
                            <option value="03"<? if($ex[1]=='03') { echo 'selected'; }?>>March</option>
                            <option value="04"<? if($ex[1]=='04') { echo 'selected'; }?>>April</option>
                            <option value="05"<? if($ex[1]=='05') { echo 'selected'; }?>>May</option>
                            <option value="06"<? if($ex[1]=='06') { echo 'selected'; }?>>June</option>
                            <option value="07"<? if($ex[1]=='07') { echo 'selected'; }?>>July</option>
                            <option value="08"<? if($ex[1]=='08') { echo 'selected'; }?>>August</option>
                            <option value="09"<? if($ex[1]=='09') { echo 'selected'; }?>>September</option>
                            <option value="10"<? if($ex[1]=='10') { echo 'selected'; }?>>October</option>
                            <option value="11"<? if($ex[1]=='11') { echo 'selected'; }?>>November</option>
                            <option value="12"<? if($ex[1]=='12') { echo 'selected'; }?>>December</option>
                          </select>
                        </div>
                        <div class="col-md-3 px-0">
                          <select name="day" class="form-control" required>
                            <?php for($i=1;$i<=31;$i++){?>
                            <option value="<?=$i?>"<? if($i==$ex[2]) { echo 'selected'; }?>><?=$i?></option>
                            <?php }?>
                          </select>
                        </div>
                        <div class="col-md-3">
                          <select name="year" class="form-control" required>
                            <?php for($i=1980;$i<=2002;$i++){?>
                            <option value="<?=$i?>"<? if($i==$ex[0]) { echo 'selected'; }?>><?=$i?></option>
                            <?php }?>
                          </select>
                        </div>
                      </div>

                      <div class="row mb-3">
                        <div class="col-md-3 my-auto">
                          <label for="exampleFormControlSelect1">Gender</label>
                        </div>
                        <div class="col-md-4">
                          <select name="gender" class="form-control" required>
                            <option value="Male"<? if($row->gender=='Male') { echo 'selected'; }?>>Male</option>
                            <option value="Female"<? if($row->gender=='Female') { echo 'selected'; }?>>Female</option>
                          </select>
                        </div>
                      </div>


                      <div class="row mb-3">
                      <div class="col-md-3 my-auto pb-md-0 pb-2">
                          <label for="exampleFormControlFile1"> Select Profile Picture</label>
                      </div>
                      <div class="col-md-9">
                         
                         <div class="pic-sec-delect">
                         
                          <?php for($x=1;$x<=15;$x++) {?>
                           <div class="comon-sec-picker">
                              <input type="radio" name="profile_picture" id="av<?=$x?>" class="input-hidden" value="avatar<?=$x?>.png" <?php if($row->profile_picture=='avatar'.$x.'.png') { echo 'checked';}?> />
                              <label for="av<?=$x?>">
                                <img src="<?php echo base_url();?>uploads/avatar<?=$x?>.png" alt="avatar <?=$x?>" />
                              </label>
                           </div>
						  <?php }?>
                          
                         </div>
                      </div>
                  </div>

                 <div class="row mb-3">
                        <div class="col-md-3 my-auto">
                          <label for="exampleFormControlSelect1">Country</label>
                        </div>
                        <div class="col-md-9">
                          <select name="country" class="form-control" required>
                            <?php 
                               $query = $this->db->query("select * from `country_master`");
                               foreach($query->result() as $res)
                               {
                            ?>
                               <option value="<?=$res->iso?>"<?php if($row->country==$res->iso){echo "selected";}?>><?=$res->nicename?></option>
                            <?php } ?>
                          </select>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-3 my-auto">
                          <label for="exampleFormControlSelect1">Phone</label>
                        </div>
                        <div class="col-md-9">
                          <input id="phone" type="tel" name="phone" value="<?=$row->phone?>" required>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-3 my-auto">
                          <label for="exampleFormControlSelect1">Educational Level</label>
                        </div>
                        <div class="col-md-9">
                          <select name="qualification" class="form-control" required>
                            <option value="BCA"<? if($row->qualification=='BCA') { echo 'selected'; }?>>BCA</option>
                            <option value="MCA"<? if($row->qualification=='MCA') { echo 'selected'; }?>>MCA</option>
                          </select>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-12 mb-3 new-fm-style">
                          <label for="exampleFormControlTextarea1">About You</label>
                          <textarea name="about_me" class="form-control" rows="4"><?=$row->about_me?></textarea>
                        </div>
                        <div class="col-md-12">
                           <button type="submit" name="btnsubmit" class="submit-bn-add" style="border:none;"> Submit </button>
                        </div>
                        <div class="col-md-12 clearfix-add">
                          <div class="line-add"></div>
                        </div>
                      </div>
                      <div class="row mb-3 profile-socal">
                        <div class="col-md-12 mb-3">
                          <label>Connect With:</label>
                        </div>
                        <div class="col-md-12">
                          <?php if($row->google_connect=="No"){?>
                          <div style="display: none;" class="g-signin2 g-connect" data-onsuccess="onConnectIn" data-theme="dark"></div>
                          <?php } ?>
                          <ul class="account-profile-form-list">
                            <li class="spl-linkedin"> <i class="fab fa-linkedin-in"></i><br>
                              <a href="#">LinkedIn</a></li>
                              <?php if($row->google_connect=="No"){?>
                            <li class="spl-google google_connect"><?php } if($row->google_connect=="Yes"){?><li class="spl-google connected"><?php } ?><i class="fab fa-google-plus-g"></i> <br>
                              <a href="#">Google</a></li>
                            <li class="spl-facebook"> <i class="fab fa-facebook-square"></i><br>
                              <a href="#">Facebook</a></li>
                            <li class="spl-microsoft"> <i class="fab fa-windows"></i> <br>
                              <a href="#">Microsoft</a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </form>
                  <?php } ?>
                  
                </div>
              </div>
              
            </div>
          </div>
      </div>
      
      
      
      <div class="sd1 new-spc new-special-home"> 
          <div class="new-right-sec-add-howit">
             <h3> How it works </h3>
             <a data-toggle="modal" data-target="#exampleModal-vieo">
                <img src="<?php echo base_url();?>assets2/images/imgpsh_fullsize_anim.png" alt="user">
             </a>
          </div>
          <div class="ads-new-1">
            <a href="#">Advertisement</a>
          </div> 
      </div>
      
    </div>
  </div>
</section>
<!--    host-account-section-end-->
