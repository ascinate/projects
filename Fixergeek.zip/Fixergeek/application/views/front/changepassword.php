<!--    host-account-section-start-->
<section class="total-bd-area ">
  <div class="container-fluid">
    <div class="row">
     <div class="new-add-sec">
          <div class="col-md-3 col-lg-3 pr-md-0">
            <div class="left-slidber-area">
              <div class="host-section-left-list">
                          <?php $this->load->view('inc/left-navigation-supporters');?>
              </div>
            </div>
          </div>
          <div class="col-md-9 col-lg-9">
            <div class="bod-area">
              <div class="text-part-sec incrise-pd home-inside-d1 p-0">
                <div class="row justify-content-center p-2">
                  <div class="col-md-12 text-center">
                    <p style="color: green;"><?php echo $this->session->flashdata('msg');?></p>
                  </div>
                </div>
                <div class="account-profile-form">
                  <?php 
                     if($this->session->userdata('id')=="")
                     {
                        redirect('/');
                     }
                     $row=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
                    ?>
                  <form name="frm" action="<?php echo base_url();?>profile/editpassword/<?=$this->session->userdata('id')?>" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                       <div class="row mb-3">
                        <div class="col-md-4 my-auto">
                          <label for="exampleInputEmail1">Change Password</label>
                        </div>
                      </div>
                     <hr>
                      
                      <div class="row mb-3">
                        <div class="col-md-3 my-auto">
                          <label for="exampleInputEmail1">Old Password</label>
                        </div>
                        <div class="col-md-9">
                         <input type="password" name="password" id="old_pass" value="<?=$row->pass?>" class="form-control" aria-describedby="emailHelp" required style="position: relative;">
                         <i class="fa fa-eye-slash" onclick="showpass1()"></i>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-3 my-auto">
                          <label for="exampleInputEmail1">New Password</label>
                        </div>
                        <div class="col-md-9">
                          <input type="password" id="new_pass" name="new_password" class="form-control" aria-describedby="emailHelp" required style="position: relative;">
                          <i class="fa fa-eye-slash" onclick="showpass2()"></i>
                        </div>
                      </div>
                      <div class="row mb-3">
                        <div class="col-md-3 my-auto">
                          <label for="exampleInputEmail1">Confirm Password</label>
                        </div>
                        <div class="col-md-9">
                          <input type="password" id="con_pass"  class="form-control" aria-describedby="emailHelp" required style="position: relative;">
                          <i class="fa fa-eye-slash" onclick="showpass3()"></i>
                        </div>
                      </div>
                  
                      <div class="row mb-3">
                       
                        <div class="col-md-12">
                           <button type="submit" onclick="return Validate()" name="btnsubmit" class="submit-bn-add"> Submit </button>
                        </div>
                        <div class="col-md-12 clearfix-add">
                          <div class="line-add"></div>
                        </div>
                      </div>
                  
                    </div>
                  </form>
                              
                </div>
              </div>
              
            </div>
          </div>
     </div>
     <div class="sd1 new-sd3 right-space"> <a href="#">Advertisement</a> </div>
    </div>
  </div>
</section>
<!--    host-account-section-end-->
<style type="text/css">
  .fa-eye-slash
  {
    margin-top: -21px;
    right: 28px;
    position: absolute;
  } 
</style>
<script>
   function showpass1()
        {
       
        var x =document.getElementById('old_pass');
        if (x.type === "password") 
        {
         x.type = "text";
        } else {
        x.type = "password";
        }
     
       }
        function showpass2()
        {
       
        var x =document.getElementById('new_pass');
        if (x.type === "password") 
        {
         x.type = "text";
        } else {
        x.type = "password";
        }
     
       }
        function showpass3()
        {
       
        var x =document.getElementById('con_pass');
        if (x.type === "password") 
        {
         x.type = "text";
        } else {
        x.type = "password";
        }
     
       }
     function Validate() {
        var password = document.getElementById("new_pass").value;
        var confirmPassword = document.getElementById("con_pass").value;
        if (password == '') {
            swal("New Password can not be blank.");
            return false;
        }
        if (password != confirmPassword) {
            swal("New Password and Confirm Password do not match.");
            return false;
        }
        
        return true;
    }
</script>