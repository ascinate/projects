<?php 
$qus_id=$this->uri->segment(3);
$question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
 
$user_qry=$this->db->get_where('user_master',array('id'=>$this->session->userdata('id')))->row();
$category=$this->db->get_where('category_master',array('id'=>$question->category_name))->row();
$sub_cat=$this->db->get_where('sub_category_master',array('id'=>$question->sub_cat_id))->row();
$sub_sub_cat=$this->db->get_where('sub_sub_category_master',array('id'=>$question->sub_sub_cat_id))->row();
?>
 <section class="total-bd-area">
    <div class="container-fluid">
           <div class="row problems">
                
                <div class="col-md-12 col-lg-12">
                    <div class="bod-area">
                        
                        <div class="text-part-sec2">
                             
                             <div class="details-top-area">
                               <div class="edite-sec-top">
                                 
                               </div>
                               <h5> <?=$question->question?></h5>
                               <div class="edit-bottom-area">
                                  <ul class="left-edit1">
                                    <li> <?php if($this->session->userdata('id')!=''){?> <a href="#" class="give_answer" id="show-one"> <i class="far fa-edit"></i> Answer</a><?php } ?> </li>
                                    <!-- <li class="follow"> <a href="#"> <i class="fas fa-wifi"></i> Follow . 4 </a> </li> -->
                                    <!-- <li> <a href="#" data-toggle="modal" data-target="#requestModal"> 
          
                                      <i class="fas fa-chalkboard-teacher"></i> Request </a>
                                    </li> -->
                                  </ul>
                                  <!-- <ul class="right-edit1">
                                      <li> <a  id="show-new">  <i class="far fa-comment"></i> </a> </li>
                                      <li class="download"> <a href="#"> <i class="fas fa-arrow-up"></i> </a> </li>
                                      <li class="dropdown show share-bn"> 
                                         <a class="btn-new1 dropdown-toggle padding-off" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                         <i class="fas fa-share"></i> </a> 
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                          <a class="dropdown-item" href="#">Facebook</a>
                                          <a class="dropdown-item" href="#">Twitter</a>
                                           <a class="dropdown-item" href="#">Copy link</a>
                                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#exampleModal-new">Embed Answer</a>
                                        </div>
                                      </li>
                                      <li class="dropdown show share-bn"> 
                                         <a class="btn-new1 dropdown-toggle padding-off" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-ellipsis-v"></i> </a> 
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                          <a class="dropdown-item" href="#">Bookmark</a>
                                          <a class="dropdown-item" href="#">Suggest</a>
                                          <a class="dropdown-item" href="#">Report</a>
                                          <a class="dropdown-item" href="#"> Edit Question and Source </a>
                                          <a class="dropdown-item" href="#"> Thanks </a>
                                          <a class="dropdown-item" href="#"> Downvote Answer </a>
                                          <a class="dropdown-item" href="#"> Downvote Question </a>
                                          <a class="dropdown-item" href="#"> Report </a>
                                        </div>
                                      </li>
          
                                  </ul> -->
                                  
                               </div>
                               <?php if($this->session->userdata('id')!=''){?>
                                <div class="new-sec-div1" id="answer">
                                <figure>
                                 <img src="<?php echo base_url();?>uploads/<?=$user_qry->profile_picture?>" alt="user">
                                </figure> 
                                <h2> <?=$user_qry->name;?>, can you answer this question?</h2>
                                <p>People are searching for an answer to this question. </p>
                                <button id="give_answer" class="give_answer default-btn ans-2bn"><i class="far fa-edit"></i> Answer </button>
                                </div>
                               
                                <div class="chat-new" id="submit_ans">
                                   <div class="comment-area editore-sec">
                                    <form action="<?php echo base_url();?>problems/submitanswer/<?=$qus_id?>/<?=$user_qry->id?>" method="post">
                                    <textarea  class="form-control" name="answer<?=$qus_id?>" rows="20" placeholder="Message..."></textarea>
                                    <script>
                                    CKEDITOR.replace('answer<?=$qus_id?>');
                                    </script>
                                    <button type="submit" class="default-btn ans-2bn mt-2" style="border: none;">Submit</button>

                                    </form>
                                   </div>
                                </div>
                              <?php } ?>
                            </div>

                            
                            <div class="email-text">
                               <textarea id="emailBody" class="form-control" rows="20" placeholder="Message..."></textarea>
                               <a id="submit1"> Submit </a>
                            </div>
                            <?php 
                            $this->db->order_by('id','desc');
                            $answer_qry=$this->db->get_where('answers_master',array('question_id'=>$qus_id))->result();
                            foreach($answer_qry as $val)
                            {
                              $user=$this->db->get_where('user_master',array('id'=>$val->user_id))->row();
                              $date=date_create($val->post_date);  
                            ?>                         
                            
                            <div class="host-section-mid-profile-box">
                              <div class="comon-border-new1">
                                <div class="ask-area-middle-n2">
                                   <div class="post-area">
                                      <div class="middle-post-area p-0">
                                          <div class="left-sec-post p-0">
                                             <div class="user-pic">
                                               
                                                  <?php if($val->user_id=="Admin"){?>
                                                  <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user">
                                                  <?php }else{?>
                                                  <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" alt="user">
                                                  <?php } ?>
                                             </div>
                                             <div class="post-adte">
                                              <?php if($val->user_id=='Admin'){echo"Administrator";}else{
                                              echo $user->name;
                                              }?>, <?php echo date_format($date,"j F ,Y");?> <br> <?=$question->topics?>
                                             </div>
                                          </div>
                                          <?php 
                                          if($this->session->userdata('id')!='')
                                          {?>
                                          <div class="right-sec-post">
                                             <a href="#"> <i class="fas fa-user-check"></i> </a>
                                          </div>
                                        <?php } ?>
                                      </div>
                                      <div class="last-post-area">
                                          <div class="left-sec-post">
                                              <div class="post-adte">
                                                
                                                <p><?=$val->answer;?> </p>
                                                
                                             </div>
                                             
                                          </div>
                                      </div>
                                      <div class="footer-post-sec">
                                        <ul class="right-fot">
                                          <li> <a class="up"> <i class="fas fa-arrow-up"></i> 4.8k</a> </li>
                                          <li> <a id="hide2-new"> <i class="far fa-comment"></i> 4.8k</a> </li>
                                        </ul><!--right-fot-->
                                        <!-- <ul class="left-fot">
                                          <li> <a href="#"> </a> </li>
                                          <li class="dropdown show share-bn"> 
                                             <a class="btn btn-secondary dropdown-toggle padding-off" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                             <i class="fas fa-share"></i> </a> 
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                              <a class="dropdown-item" href="#">Facebook</a>
                                              <a class="dropdown-item" href="#">Twitter</a>
                                               <a class="dropdown-item" href="#">Copy link</a>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#exampleModal-new">Embed Answer</a>
                                            </div>
                                          </li>
                                          <li class="dropdown show share-bn"> 
                                             <a class="btn btn-secondary dropdown-toggle padding-off" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-ellipsis-v"></i> </a> 
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                              <a class="dropdown-item" href="#">Bookmark</a>
                                              <a class="dropdown-item" href="#">Suggest</a>
                                              <a class="dropdown-item" href="#">Report</a>
                                              <a class="dropdown-item" href="#"> Edit Question and Source </a>
                                              <a class="dropdown-item" href="#"> Thanks </a>
                                              <a class="dropdown-item" href="#"> Downvote Answer </a>
                                              <a class="dropdown-item" href="#"> Downvote Question </a>
                                              <a class="dropdown-item" href="#"> Report </a>
                                            </div>
                                          </li>
                                        </ul> --><!--left-fot-->
                                        
                                        </div><!--footer-post-sec-->
                                        <?php 
                                        if($this->session->userdata('id')!='')
                                        {?>
                                        <div class="chat2-new">
                                           <div class="comment-area">
                                                <form action="<?php echo base_url();?>problems/submitcomment/<?=$val->id?>/<?=$qus_id?>" method="post">
                                                     <figure>
                                                      <img src="<?php echo base_url();?>uploads/<?=$user_qry->profile_picture?>" alt="user">
                                                     </figure>
                                                     <div class="form-group">
                                                        <input type="text" name="comment<?=$val->id?>" placeholder="" class="form-control">
                                                     </div>
                                                
                                                 <button type="submit" class="comment-bn" id="hide2-new"> Add comments </button>
                                              </form>
                                           </div>
                                      </div>
                                    <?php } ?>
                                   </div>
                                </div>
                              </div>
                            </div>
                          <?php } ?>          
                        </div>
                      
                        <div class="sd1"> <a href="#">Advertisement</a> </div>
                          
                     </div>
                </div>
           </div>
        </div>
 </section>
 <script>
  $(document).ready(function(){
   $(".give_answer").click(function(){
      $("#answer").hide();
      $("#submit_ans").show(); 
         
        });
    });
</script>