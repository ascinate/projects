<section class="total-bd-area2">
  <div class="offline_website_ask position-relative host-section-wrap pt-2 mb-5 pb-5">
    <div class="container-fluid">
      <div class="offline_website_ask_head breadcrumb-1"> 
       <a class="breadcrumb1-anchor nt-spl-anchor anchor-brc-1" href="#">Categories</a>
        <!--<i class="fa fa-angle-right px-2" aria-hidden="true"></i>-->
        <a class="breadcrumb1-anchor nt-spl-anchor" href="#">Special Apps</a>
        <!--<i class="fa fa-angle-right px-2" aria-hidden="true"></i>-->
        <li class="nav-item dropdown dropdown1"> 
        <a class="breadcrumb1-anchor nav-link Profile-pad active dropdown-toggle button" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <span>Gaming</span> </a>
          <div class="dropdown-menu drop-menu-new dropdown-menu1" aria-labelledby="navbarDropdown"> 
              <a class="dropdown-item" href="#">GAMESTORES</a> 
              <a class="dropdown-item" href="#">XBOX</a> 
              <a class="dropdown-item" href="#">STEAM</a> 
              <a class="dropdown-item" href="#">EMULATORS</a> 
              <a class="dropdown-item" href="#">RETROARCH</a> 
              <a class="dropdown-item" href="#">LAUNCHBOX</a> 
              <a class="dropdown-item" href="#">DOLPHIN</a> 
          </div>
        </li>
      </div>
      <hr class="my-2">
      <div class="row">
        <div class="col-xl-9 pr-xl-0 pr-3">
          <div class="row">
            <div class="col-12 pr-xl-0 pr-3">
              <div class="accordian-part mt-3">
                <div class="main">
                  <div id="accordion" class="accordion">
                    <div class="card mb-0">
                      <div class="card-header collapsed" data-toggle="collapse" href="#collapseOne"> <a class="card-title"> How do I play Metal Slug on RetroArch? </a> </div>
                      <div id="collapseOne" class="collapse show" data-parent="#accordion" >
                        <div class="card-body">
                          <div class="comon-text-area comon-space">
                            <p> I recommend you the following:Go to </p>
                            <p>http://www.retroarch.com  
                              and download the latest version of Retroacrch
                              and follow these steps </p>
                            <div class="steps1">
                              <h5 class="bold-text">Step 1:</h5>
                              <p> Run RetroArch and click Settings</p>
                            </div>
                            <div class="steps1">
                              <h5 class="bold-text">Step 2:</h5>
                              <p> Click the Bios button </p>
                            </div>
                            <div class="steps1">
                              <h5 class="bold-text">Step 3:</h5>
                              <p> Choose the bios file windl.bios from the list in the Bios menu. </p>
                            </div>
                            <div class="more-text1">
                              <p class="mt-3 steps"><b>Step 4:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <p class="mt-3 steps"><b>Step 5:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <p class="mt-3 steps"><b>Step 6:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <br>
                              <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                              <hr>
                              <form class="my-4">
                                <div class="form-group">
                                  <div class="comment-section-comon">
                                    <div class="left-icon-user"> <i class="fa fa-user" aria-hidden="true"></i> </div>
                                    <div class="comment-area1">
                                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" 
                                                                              placeholder="Add a comment..."></textarea>
                                    </div>
                                    <div class="comment-submit">
                                      <button class="default-btn">Add Comment<br>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </form>
                            </div>
                            <div class="bn-area"> <a class="moreless-button1" >Read more</a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="card-header collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"> <a class="card-title"> How can I play any ROM? </a> </div>
                      <div id="collapseTwo" class="collapse" data-parent="#accordion" >
                        <div class="card-body">
                          <div class="comon-text-area comon-space">
                            <p> I recommend you the following:Go to </p>
                            <p>http://www.retroarch.com 
                              and download the latest version of Retroacrch
                              and follow these steps </p>
                            <div class="steps1">
                              <h5 class="bold-text">Step 1:</h5>
                              <p> Run RetroArch and click Settings</p>
                            </div>
                            <div class="steps1">
                              <h5 class="bold-text">Step 2:</h5>
                              <p> Click the Bios button </p>
                            </div>
                            <div class="steps1">
                              <h5 class="bold-text">Step 3:</h5>
                              <p> Choose the bios file windl.bios from the list in the Bios menu. </p>
                            </div>
                            <div class="more-text2">
                              <p class="mt-3 steps"><b>Step 4:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <p class="mt-3 steps"><b>Step 5:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <p class="mt-3 steps"><b>Step 6:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <br>
                              <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                              <hr>
                              <form class="my-4">
                                <div class="form-group">
                                  <div class="comment-section-comon">
                                    <div class="left-icon-user"> <i class="fa fa-user" aria-hidden="true"></i> </div>
                                    <div class="comment-area1">
                                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" 
                                                                              placeholder="Add a comment..."></textarea>
                                    </div>
                                    <div class="comment-submit">
                                      <button class="default-btn">Add Comment<br>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </form>
                            </div>
                            <div class="bn-area"> <a class="moreless-button2" >Read more</a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="card-header collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree"> <a class="card-title"> Where can I find RetroArch? </a> </div>
                      <div id="collapseThree" class="collapse" data-parent="#accordion" >
                        <div class="card-body">
                          <div class="comon-text-area comon-space">
                            <p> I recommend you the following:Go to </p>
                            <p> http://www.retroarch.com 
                              and download the latest version of Retroacrch
                              and follow these steps </p>
                            <div class="steps1">
                              <h5 class="bold-text">Step 1:</h5>
                              <p> Run RetroArch and click Settings</p>
                            </div>
                            <div class="steps1">
                              <h5 class="bold-text">Step 2:</h5>
                              <p> Click the Bios button </p>
                            </div>
                            <div class="steps1">
                              <h5 class="bold-text">Step 3:</h5>
                              <p> Choose the bios file windl.bios from the list in the Bios menu. </p>
                            </div>
                            <div class="more-text3">
                              <p class="mt-3 steps"><b>Step 4:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <p class="mt-3 steps"><b>Step 5:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <p class="mt-3 steps"><b>Step 6:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <br>
                              <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                              <hr>
                              <form class="my-4">
                                <div class="form-group">
                                  <div class="comment-section-comon">
                                    <div class="left-icon-user"> <i class="fa fa-user" aria-hidden="true"></i> </div>
                                    <div class="comment-area1">
                                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" 
                                                                              placeholder="Add a comment..."></textarea>
                                    </div>
                                    <div class="comment-submit">
                                      <button class="default-btn">Add Comment<br>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </form>
                            </div>
                            <div class="bn-area"> <a class="moreless-button3" >Read more</a> </div>
                          </div>
                        </div>
                      </div>
                      <div class="card-header collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapsefour"> <a class="card-title"> I want to play metal slug arcade game </a> </div>
                      <div id="collapsefour" class="collapse" data-parent="#accordion" >
                        <div class="card-body">
                          <div class="comon-text-area comon-space">
                            <p> I recommend you the following:Go to </p>
                            <p> http://www.retroarch.com 
                              and download the latest version of Retroacrch
                              and follow these steps </p>
                            <div class="steps1">
                              <h5 class="bold-text">Step 1:</h5>
                              <p> Run RetroArch and click Settings</p>
                            </div>
                            <div class="steps1">
                              <h5 class="bold-text">Step 2:</h5>
                              <p> Click the Bios button </p>
                            </div>
                            <div class="steps1">
                              <h5 class="bold-text">Step 3:</h5>
                              <p> Choose the bios file windl.bios from the list in the Bios menu. </p>
                            </div>
                            <div class="more-text4">
                              <p class="mt-3 steps"><b>Step 4:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <p class="mt-3 steps"><b>Step 5:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <p class="mt-3 steps"><b>Step 6:</b></p>
                              <span class="steps-span">Click the Bios button</span>
                              <!--  -->
                              <br>
                              <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                              <hr>
                              <form class="my-4">
                                <div class="form-group">
                                  <div class="comment-section-comon">
                                    <div class="left-icon-user"> <i class="fa fa-user" aria-hidden="true"></i> </div>
                                    <div class="comment-area1">
                                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" 
                                                                              placeholder="Add a comment..."></textarea>
                                    </div>
                                    <div class="comment-submit">
                                      <button class="default-btn">Add Comment<br>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </form>
                            </div>
                            <div class="bn-area"> <a class="moreless-button4" >Read more</a> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- col-9 -->
        <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
          <div class="right-fixed-box mt-3">
            <div class="host-section-right-offline-box host-section-right-box">
              <div class="host-offline-heading-box mb-2"> <span class="text-center inactive-span"><i class="fa fa-circle" aria-hidden="true"></i> <b>No Fixers available</b></span> </div>
              <div class="host-middle-box">
                <div class="row mb-2">
                  <div class="col-md-9 my-auto">
                    <p>Currently there are no Fixer Geeks who can fix this problem for you by remotely connecting to your PC.</p>
                  </div>
                  <div class="col-md-3 pl-xl-1"> <img src="<?php echo base_url();?>assets2/images/no-fixer.png" alt=""> </div>
                </div>
                <div class="row">
                  <div class="col-sm-7"> <a href="#">Become a Fixer Geek</a> </div>
                  <div class="col-sm-5 pl-0 text-right"> <a href="#">Find Availability</a> </div>
                </div>
              </div>
              <hr>
              <div class="host-bottom-box">
                <div class="row">
                  <div class="col-md-12 text-center mb-2">
                    <h6><b>Ask a Troubleshooting Question</b></h6>
                  </div>
                  <div class="col-md-12">
                    <div class="row">
                      <div class="col-md-9 my-auto">
                        <p>We will find someone who can reply, if we can’t, we’ll try to find a Fixer who can fix this problem for you now.</p>
                      </div>
                      <div class="col-md-3 pl-xl-1 my-auto"> <img src="<?php echo base_url();?>assets2/images/troubleshoot.png" alt=""> </div>
                    </div>
                  </div>
                  <div class="col-md-12 mt-3">
                    <form>
                      <div class="form-group">
                        <div class="row">
                          <div class="col-md-12 my-auto">
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="6" placeholder="Type here..."></textarea>
                          </div>
                          <div class="col-md-12 text-right mt-3">
                            <button type="button" class="btn btn-primary default-btn">Ask</button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
            <div class="host-section-right-box spl-right-box mt-3"> <a href="#">Advertisement</a> </div>
          </div>
        </div>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</section>
