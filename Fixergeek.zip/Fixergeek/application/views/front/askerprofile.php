<?php
error_reporting(0);
$id=$this->uri->segment(3);
$user=$this->db->get_where('user_master',array('id'=>$id))->row();

$country=$this->db->get_where('country_master',array('iso'=>$user->country))->row();
$fixergeek=$this->db->get_where('fixergeek_master',array('user_id'=>$id))->row();
$items = $this->db->get_where('sub_sub_category_master',array('id'=>$fixergeek->sub_sub_cat_id));
$review=$this->db->get_where('review_master',array('asker_id'=>$id));
$stat=$this->db->get_where('review_master',array('asker_id'=>$id , 'status'=>'Fixed'));

$reviewcount = $review->num_rows();

$score = $review->row();
$tot = ($score->conduct+$score->timing+$score->literacy+$score->knowledge+$score->pchandle+$score->type_speed) / 6;
$fixes = $stat->num_rows();

$question=$this->db->get_where('questions_master',array('user_id'=>$id))->row();

if($question->level==3) { $level = 'Fixer (Level 3)'; }
if($question->level==2) { $level = 'Helper (Level 2)'; }
if($question->level==1) { $level = 'Chatter (Level 1)'; }

?>
<style>
.red_user {
    color: #FF0000 !important;
    font-size: 12px !important;
}
.icc
{
  border-radius:50%;
  width:50px;
  height:50px;
}
</style>
<section class="total-bd-area">

        <div class="host-section-wrap supporter_podium_Profile supporter_podium_Profile_1 mx-4">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-9 col-12">
                        <div class="row mx-0">
                            <div class="col-12">
                                <div class="supporter_podium_Profile_pic d-flex">
                                    <!--<i class="far fa-user-circle"></i>-->
                                    <?php if($user->profile_picture==""){?>
                                    <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user">
                                    <?php }else{?>
                                    <img src="<?php echo base_url();?>uploads/<?=$user->profile_picture?>" alt="user" class="icc">
                                    <?php } ?>
                                    <div class="user_name pl-2 pt-2">
                                        <h4><?=ucwords($user->geek_name)?></h4>
                                        <p>
                                         <?php if($user->status=="online"){?>
                                          <i class="fa fa-circle green_user"></i> Online 
                                         <?php } else { ?>
                                         <i class="fa fa-circle red_user"></i> Offline 
                                         <?php }?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!--  -->
                            <div class="col-md-9">
                                <div class="grey_PODIUM_bg grey_PODIUM_bg-1 mt-3">
                                    <h6><b>Current Problem:</b></h6>
                                    <p class="mt-3"><?=$question->question?></p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="user_podium_btn mt-3">
                                    <button class="btn btn-primary w-100 default-btn">Fix This Problem</button>
                                    <?php if($this->session->userdata('id')=='') { ?>
                                    <button class="btn btn-primary mt-2 w-100 default-btn" data-toggle="modal" data-target="#cusModal">Send Message</button>
                                    <?php } else { ?>
                                    <button class="btn btn-primary mt-2 w-100 default-btn" data-toggle="modal" data-target="#msgModal">Send Message</button>
                                    <?php }?>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="categories-1 mt-3">
                                    <ul>
                                        <li><b>Level Required:</b></li>
                                        <li><?=$level?></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="user_podium_info mt-4">
                                    <h6><b><?=$user->name?>'s Profile:</b></h6>
                                    <p class="pt-2"><b>Gender: </b> <?=$user->gender?></p>
                                    <p class="pt-1"><b>Country: </b><?=$country->nicename?></p>
                                    <p class="pt-1"><b>Educational Level: </b><?=strtoupper($user->qualification)?></p>
                                    <p class="pt-1"><b>About <?=$user->name?>: </b> <?=$user->about_me?></p>
                                </div>
                            </div>
                            <hr class="mt-3 w-100">
                            <!--  -->
                            <div class="col-md-7 mt-2">
                                <div class="user_podium_info_2 mt-4">
                                    <h6><b>Score & Comments given by <?=$user->name?>:</b></h6>
                                    <div class="row">
                                        <div class="offset-lg-1 col-sm-4">
                                            <div class="user_podium_score py-4 text-center">
                                                <h5><?=number_format($tot,1);?></h5>
                                                <div class="user_podium_score_fixed pt-4">
                                                    <p class="green_user-1"><i class="fa fa-check"></i><?=$fixes?> Problems Fixed</p>
                                                    <p class="red_user-1"><i class="fa fa-times"></i>0 Problem Not Fixed</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- table -->
                            <div class="col-md-5 mt-4">
                                <!--<div class="scoreboard">
                                    <table class="table table12">
                                        <tbody>
                                            <tr>
                                                <td>Conduct</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Timing/Speed</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>English Literacy</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Technical Knowledge</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Pc Handeling</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Typing Speed</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr class="total">
                                                <td>Total</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>-->
                            </div>

							<?php
							  if($reviewcount!=0)
							  {
								  foreach($review->result() as $val){
								  $question=$this->db->get_where('questions_master',array('id'=>$val->question_id))->row();
								  
								  $avg = ($val->conduct+$val->timing+$val->literacy+$val->knowledge+$val->pchandle+$val->type_speed) / 6;
								  $fixer=$this->db->get_where('user_master',array('id'=>$val->fixer_id))->row();
							?>
                            <hr class="mb-3 w-100">
                            <!-- col-12-fnish -->

                            <!-- new-col-start -->
                            <div class="col-md-7 mt-2">
                                <div class="Problem-details">
                                    <ul>
                                        <li><b>Problem:</b> <span><?=$question->question;?></span></li>
                                        <li><b>Price:</b> <span>$<?=$val->price?></span></li>
                                        <li class="user_podium_score_fixed"><b>Outcome:</b>
                                        <span class="green_user-1"><i class="fa fa-check "></i><?=$val->status?></span></li>
                                        <li><b>Level: <?=$question->level?></b> <span>(Fixer)</span></li>
                                        <li><b>Comment:</b> <span class="problems_details_para"><?=stripslashes($val->feedback)?> </span></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-5 mt-3">
                                <div class="scoreboard">
                                    <p class="mb-2"><b><?=$fixer->name?>'s Score & Comments:</b></p>
                                    <table class="table table12">
                                        <tbody>
                                            <tr>
                                                <td>Conduct</td>
                                                <td class="end"><?=$val->conduct?></td>
                                            </tr>
                                            <tr>
                                                <td>Timing/Speed</td>
                                                <td class="end"><?=$val->timing?></td>
                                            </tr>
                                            <tr>
                                                <td>English Literacy</td>
                                                <td class="end"><?=$val->literacy?></td>
                                            </tr>
                                            <tr>
                                                <td>Technical Knowledge</td>
                                                <td class="end"><?=$val->knowledge?></td>
                                            </tr>
                                            <tr>
                                                <td>Pc Handeling</td>
                                                <td class="end"><?=$val->pchandle?></td>
                                            </tr>
                                            <tr>
                                                <td>Typing Speed</td>
                                                <td class="end"><?=$val->type_speed?></td>
                                            </tr>
                                            <tr class="total">
                                                <td>Total</td>
                                                <td class="end"><?=number_format($avg,1)?></td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                            <?php 
							    }
							  }
							  else
							  {
							?>
                               <hr class="mb-3 w-100">
                              <div class="col-md-12 mt-2" align="center">No Reviews Found!</div>
                              <hr class="mb-3 w-100">
                            <?php
							 }
							 ?>
                            <!-- 1st-part-table -->
                        </div>
                    </div>
                </div>
                
                <!-- row-finish -->
                <!--<div class="row justify-content-end mt-4">
                    <div class="col-12 text-right">
                        <div class="user_po_pegination">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">Previous</a></li>
                                    <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">Next</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>-->
                
            </div>
        </div>

    </section>
    
   <?php  /**************************** Customer Modal *****************************/  ?>
  
  <div class="modal fade exampleModalask" id="cusModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header ask-modal modal-header-1"> <img src="<?php echo base_url();?>assets2/images/logo-head.png" alt="">
        <h5 class="modal-title" id="exampleModalLabel">Fixer Geek</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      
      <div id="authbox" class="modal-body modal-body1">
       <span id="txt" class="text-center" style="color:#FF0000;"></span>
        <div class="head-form head-form2x" id="next_hide">
          <div class="form-dp">
            <div class="top-sec-dp">
                <div class="form-group">
                  <label> User Name</label>
                  <input type="text" placeholder="" id="user_name2" class="form-control" value="" required>
                </div>
                <div class="form-group">
                  <label> Password </label>
                  <input type="password" placeholder="" id="password2" class="form-control" value="" required>
                </div>
                <button type="button" id="login_btn_comment2" class="btn default-btn login">Log In</button>
            </div>
          </div>
          <div class="col-md-4">&nbsp;</div>
          <div class="col-12">
            <div class="header-drop-links-first">
              <p>Or Login With</p>
              <ul class="socal-media">
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i>
                  <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                  <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                  <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                  <span> Linkedin</span></a></li>
              </ul>
              
              <div class="sub-link">
                 <a href="#">Lost Password </a> or <a href="#"> User Name</a>
              </div>
            </div>
          </div>
          <div class="col-12 mt-4">
            <div class="header-drop-links-second">
              <p>Or Sign Up With</p>
              <hr class="my-2">
              <ul class="socal-media">
                <li><a class="icon-new" href="#"> <i class="fas fa-envelope"></i>
                  <span>Email</span></a></li>
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i>
                  <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                  <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                  <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                  <span> Linkedin</span></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      <form name="frm" action="<?php echo base_url();?>messages/insert" method="post">
      <input type="hidden" name="receiver_id" value="<?=$this->uri->segment(3)?>" />
      <input type="hidden" name="sender_id" id="asker_id" value="" />
      
      <div id="msgbox" class="modal-body modal-body1" style="display:none;">
        <div class="head-form head-form2x" id="next_hide">
          <div class="form-dp">
            <div class="top-sec-dp">
               <div class="col-md-12 mb-3">
                  <label for="exampleFormControlTextarea1">Type message below.</label>
                  <div class="form-group">
                  <input type="text" id="msg" class="form-control" name="message" value="" style="width:350px;" required>
                  </div>
                  <button type="submit" id="login_btn_comment2" class="btn default-btn login">Send</button>
                </div>
                
            </div>
          </div>
          <div class="col-md-4">&nbsp;</div>
        </div>
      </div>
     </form> 
      
    
    </div>
  </div>
</div>

<?php  /**********************************************/ ?>

  <div class="modal fade exampleModalask" id="msgModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    
      <div class="modal-header ask-modal modal-header-1"> <img src="<?php echo base_url();?>assets2/images/logo-head.png" alt="">
        <h5 class="modal-title" id="exampleModalLabel">Message Box</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      
      <form name="frm2" action="<?php echo base_url();?>messages/insert" method="post">
      <input type="hidden" name="receiver_id" value="<?=$this->uri->segment(3)?>" />
      <input type="hidden" name="sender_id" value="<?=$this->session->userdata('id')?>" />
      
      <div id="msgbox2" class="modal-body modal-body1">
        <div class="head-form head-form2x" id="next_hide">
          <div class="form-dp">
            <div class="top-sec-dp">
               <div class="col-md-12 mb-3">
                  <label for="exampleFormControlTextarea1">Type message below.</label>
                  <div class="form-group">
                  <input type="text" id="msg" class="form-control" name="message" value="" style="width:350px;" required>
                  </div>
                  <button type="submit" name="btn2" id="login_btn_comment2" class="btn default-btn login">Send</button>
                </div>
                
            </div>
          </div>
          <div class="col-md-4">&nbsp;</div>
        </div>
      </div>
      </form> 
      
      </div>
   </div>
   </div>
   
   <script>
    $(document).ready(function()
	{
	 //////////////////////////////////////////
	  $("#login_btn_comment2").click(function()
	  {
		  var user_name = $("#user_name2").val();
		  var password = $("#password2").val();
			   
		  if(password=='' || user_name=='')
		  {
			 swal("Sorry!! Insert Your Login Data");
		  }
		  else
		  {
			 $.ajax({url: "<?php echo base_url();?>home/login/"+user_name+"/"+password, success: function(result){
				 /*if(result==success)
				 {*/
				  // location.reload(true);
				/* }
				 else
				 {
				   $("#txt").html("Wrong username or password!");
				 }*/
				 
				    $("#authbox").hide();
				    $("#msgbox").show();
					$("#asker_id").val(result);
				 
			  }});
		  }
	 });
   });
</script>