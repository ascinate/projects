<?php
  $id = $this->uri->segment(3);
  
  $record = $this->db->get_where('answers_master', array('id' => $id))->row();
  echo $record->answer;
?>