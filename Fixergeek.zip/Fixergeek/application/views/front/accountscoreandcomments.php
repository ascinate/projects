<?php
    $id = $this->session->userdata('id');
    $review=$this->db->get_where('review_master',array('fixer_id'=>$id));
	$stat=$this->db->get_where('review_master',array('fixer_id'=>$id , 'status'=>'Fixed'));
	$user=$this->db->get_where('user_master',array('id'=>$id))->row();
	$fixergeek=$this->db->get_where('fixergeek_master',array('user_id'=>$id))->row();
	$stat=$this->db->get_where('review_master',array('fixer_id'=>$id , 'status'=>'Fixed'));
	$stat2 =$this->db->get_where('review_master',array('fixer_id'=>$id , 'status'=>'Not Fixed'));
	
	$score = $review->row();
	$tot = ($score->conduct+$score->timing+$score->literacy+$score->knowledge+$score->pchandle+$score->type_speed) / 6;
	$fixes = $stat->num_rows();
	$notfix = $stat2->num_rows();
?>
<section class="total-bd-area">
  <div class="container-fluid">
    <div class="row">
     <div class="new-add-sec">
        <div class="col-md-3 col-lg-3 pr-md-0">
          <div class="left-slidber-area">
            <div class="host-section-left-list">
              <?php $this->load->view('inc/left-navigation-supporters');?>
            </div>
          </div>
        </div>
        <!--  -->
        <div class="col-md-9 col-lg-9">
          <div class="bod-area">
            <div class="text-part-sec home-inside-d1 p-0">
              <div class="sub-page">
                <div class="acoount_coment_wrap-1">
                  <div class="row">
                    <div class="col-lg-4">
                      <div class="acoount_coment_score text-center">
                        <h4 class="mb-2">Your Score</h4>
                        <h1 class="mb-3"><?=number_format($tot,1)?></h1>
                        <div class="fixed_not_fixed text-center">
                          <p class="green_user-1"><i class="fa fa-check"></i><?=$fixes?> problems fixed</p>
                          <p class="red_user-1"><i class="fa fa-times"></i><?=$notfix?> problems not fixed</p>
                        </div>
                      </div>
                    </div>
                    <!--  -->
                    <div class="offset-lg-3 col-lg-5">
                      <div class="scoreboard">
                        <p class="mb-2"><b>Maxbrayne's Score:</b></p>
                        <table class="table table12">
                          <tbody>
                            <tr>
                              <td>Conduct</td>
                              <td class="end">4.0</td>
                            </tr>
                            <tr>
                              <td>Timing/Speed</td>
                              <td class="end">4.0</td>
                            </tr>
                            <tr>
                              <td>English Literacy</td>
                              <td class="end">4.0</td>
                            </tr>
                            <tr>
                              <td>Technical Knowledge</td>
                              <td class="end">4.0</td>
                            </tr>
                            <tr>
                              <td>Pc Handeling</td>
                              <td class="end">4.0</td>
                            </tr>
                            <tr>
                              <td>Typing Speed</td>
                              <td class="end">4.0</td>
                            </tr>
                            <tr class="total">
                              <td>Total</td>
                              <td class="end">4.0</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                  
                  <?php
                    foreach($review->result() as $val)
                    {
                    
                    $question=$this->db->get_where('questions_master',array('id'=>$val->question_id))->row();
                    
                    $avg = ($val->conduct+$val->timing+$val->literacy+$val->knowledge+$val->pchandle+$val->type_speed) / 6;
                  ?>
                  <hr class="my-3">
                  
                  <div class="comon-part-sec-subpage">
                    <div class="col-md-7 pl-md-0">
                      <div class="Problem-details">
                        <ul>
                          <li><b>Problem:</b> <span><?=$question->question;?></span></li>
                          <li><b>Price:</b> <span>$<?=$val->price?></span></li>
                          <li><b>Outcome:</b> <span class="green_user-1"><i class="fa fa-check"></i><?=$val->status?></span></li>
                          <li><b>Level: <?=$fixergeek->level?></b> <span>(Fixer)</span></li>
                          <li><b>Comment:</b> <span class="problems_details_para"><?=stripslashes($val->feedback)?></span></li>
                        </ul>
                      </div>
                    </div>
                    <div class="col-md-5 pr-md-0">
                      <div class="scoreboard">
                        <p class="mb-2"><b><?=$user->name?>'s Score:</b></p>
                        <table class="table table12">
                          <tbody>
                            <tr>
                              <td>Conduct</td>
                              <td class="end"><?=$val->conduct?></td>
                            </tr>
                            <tr>
                              <td>Timing/Speed</td>
                              <td class="end"><?=$val->timing?></td>
                            </tr>
                            <tr>
                              <td>English Literacy</td>
                              <td class="end"><?=$val->literacy?></td>
                            </tr>
                            <tr>
                              <td>Technical Knowledge</td>
                              <td class="end"><?=$val->knowledge?></td>
                            </tr>
                            <tr>
                              <td>Pc Handeling</td>
                              <td class="end"><?=$val->pchandle?></td>
                            </tr>
                            <tr>
                              <td>Typing Speed</td>
                              <td class="end"><?=$val->type_speed?></td>
                            </tr>
                            <tr class="total">
                              <td>Total</td>
                              <td class="end"><?=number_format($avg,1)?></td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                   <?php }?>
                  <!--  -->
                  <hr class="my-0">
                  <!-- row-finish -->
                  
                  <!--  -->
  
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
      <div class="sd1 new-spc new-special-home"> 
         <div class="new-right-sec-add-howit">
             <h3> How it works </h3>
             <a data-toggle="modal" data-target="#exampleModal-vieo">
                <img src="<?php echo base_url();?>assets2/images/imgpsh_fullsize_anim.png" alt="user">
             </a>
          </div>
          <div class="ads-new-1">
            <a href="#">Advertisement</a>
          </div> 
      </div>
    </div>
  </div>
</section>
