 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

    <!--    ask-modal-dropdown-js-->
    <script src="js/modal-dropdown.js"></script>


    <script>
        $(".show-details1").hover(function() {
            // $("#sidebar-dropdown-li-2").toggle();
            $(".profile-hover-carousel1").show();
            $(".profile-hover-carousel2").hide();
            $(".profile-hover-carousel3").hide();

        });

        $(".show-details2").hover(function() {
            // $("#sidebar-dropdown-li-2").toggle();
            $(".profile-hover-carousel2").show();
            $(".profile-hover-carousel1").hide();
            $(".profile-hover-carousel3").hide();
        });

        $(".show-details3").hover(function() {
            // $("#sidebar-dropdown-li-2").toggle();
            $(".profile-hover-carousel3").show();
            $(".profile-hover-carousel1").hide();
            $(".profile-hover-carousel2").hide();
        });
        $(".hide-details").hover(function() {
            // $("#sidebar-dropdown-li-2").toggle();
            $(".profile-hover-details").hide();

        });

    </script>


    <script>
        $('.owl-carousel').owlCarousel({
            loop: true,
            margin: 10,
            video: true,
            nav: true,
            lazyLoad: true,
            autoplay: true,
            autoplayTimeout: 6000,
            navText: [
                "<i class='fa fa-caret-left'></i>",
                "<i class='fa fa-caret-right'></i>"
            ],
            autoplayHoverPause: true,
            responsive: {
                0: {
                    items: 1
                },
                480: {
                    items: 1
                },
                560: {
                    items: 1
                },
                760: {
                    items: 1
                },
                990: {
                    items: 1
                },
                1200: {
                    items: 1
                },
                1500: {
                    items: 1
                }
            }
        })

    </script>


    <script type="text/javascript">
        $(window).scroll(function() {
            if ($(this).scrollTop() > 1) {
                $('header').addClass("sticky");
            } else {
                $('header').removeClass("sticky");
            }
        });

    </script>


    <script type="text/javascript">
        (function($) {
            $('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
                if (!$(this).next().hasClass('show')) {
                    $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
                }
                var $subMenu = $(this).next(".dropdown-menu");
                $subMenu.toggleClass('show');

                $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
                    $('.dropdown-submenu .show').removeClass("show");
                });

                return false;
            });
        })(jQuery)

    </script>



    <script>
        $(document).ready(function() {

            $("#plus-mode").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();

                $("#modal-mode").toggle();
            });
            $("#sidebar-dropdown-li-2").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-list-3").hide();
                $("#sidebar-list-5").hide();
                $("#sidebar-list-4").hide();
                $("#sidebar-list-2").toggle();
            });
            ////////////////////////
            $("#sidebar-dropdown-li-8").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-dropdown-li-10").hide();
                $("#sidebar-list-8").toggle();
                if ($("#sidebar-dropdown-li-8").hasClass('active')) {
                    $("#sidebar-dropdown-li-8").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-8").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-13").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-13").toggle();
                if ($("#sidebar-dropdown-li-13").hasClass('active')) {
                    $("#sidebar-dropdown-li-13").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-13").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-14").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-14").toggle();
                if ($("#sidebar-dropdown-li-14").hasClass('active')) {
                    $("#sidebar-dropdown-li-14").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-14").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-15").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-15").toggle();
                if ($("#sidebar-dropdown-li-15").hasClass('active')) {
                    $("#sidebar-dropdown-li-15").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-15").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-16").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").toggle();
                if ($("#sidebar-dropdown-li-16").hasClass('active')) {
                    $("#sidebar-dropdown-li-16").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-16").addClass('active');


                }
            });

        });

    </script>
    <script>
        $(document).ready(function() {
            $("#sidebar-dropdown-li-3").click(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-list-2").hide();
                $("#sidebar-list-5").hide();
                $("#sidebar-list-3").toggle();
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id").hover(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-list-2").hide();
                $("#sidebar-list-3").hide();
                $("#sidebar-list-5").hide();
                $("#sidebar-list-4").hide();
                $("#sidebar-list-6").hide();
            });
            /////////////////////////////////////////////////////////////////
            $("#sidebar-dropdown-li-9").click(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-8").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-9").toggle();
                if ($("#sidebar-dropdown-li-9").hasClass('active')) {
                    $("#sidebar-dropdown-li-9").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-9").addClass('active');

                }
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id2").hover(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
            });
        });

    </script>
    <script>
        $(document).ready(function() {
            $("#sidebar-dropdown-li-4").click(function() {
                $("#sidebar-list-4").toggle();
            });
            //////////////////////
            $("#sidebar-dropdown-li-5").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-list-3").hide();
                $("#sidebar-list-2").hide();
                $("#sidebar-list-5").toggle();
            });
            /////////////////////////////
            $("#sidebar-dropdown-li-6").click(function() {
                $("#sidebar-list-6").toggle();
            });
            /////////////////////////////

            /////////////////////////////////////////
            $("#sidebar-dropdown-li-10").click(function() {
                // $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-10").toggle();
                if ($("#sidebar-dropdown-li-10").hasClass('active')) {
                    $("#sidebar-dropdown-li-10").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-10").addClass('active');

                }
            });
            //////////////////////
            $("#sidebar-dropdown-li-11").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-11").toggle();
                if ($("#sidebar-dropdown-li-11").hasClass('active')) {
                    $("#sidebar-dropdown-li-11").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-11").addClass('active');

                }
            });
            /////////////////////////////
            $("#sidebar-dropdown-li-12").click(function() {
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                // $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-12").toggle();
                if ($("#sidebar-dropdown-li-12").hasClass('active')) {
                    $("#sidebar-dropdown-li-12").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-12").addClass('active');

                }
            });
        });

    </script>


    <!-- new -->
    <!-- new -->










    <script>
        class Accordion {
            constructor({
                element,
                active = null,
                multi = false
            }) {
                this.el = element;
                this.activePanel = active;
                this.multi = multi;

                this.init();
            }

            cacheDOM() {
                this.panels = this.el.querySelectorAll(".expansion-panel");
                this.headers = this.el.querySelectorAll(".expansion-panel-header");
                this.bodies = this.el.querySelectorAll(".expansion-panel-body");
            }

            init() {
                this.cacheDOM();
                this.setSize();
                this.initialExpand();
                this.attachEvents();
            }

            // Remove "active" class from all expansion panels.
            collapseAll() {
                for (const h of this.headers) {
                    h.closest(".expansion-panel").classList.remove("active");
                }
            }

            // Add "active" class to the parent expansion panel.
            expand(idx) {
                this.panels[idx].classList.add("active");
            }

            // Toggle "active" class to the parent expansion panel.
            toggle(idx) {
                this.panels[idx].classList.toggle("active");
            }

            // Get the height of each panel body and store it in attribute
            // for the CSS transition.
            setSize() {
                this.bodies.forEach((b, idx) => {
                    const bound = b
                        .querySelector(".expansion-panel-body-content")
                        .getBoundingClientRect();
                    b.setAttribute("style", `--ht:auto`);
                });
            }

            initialExpand() {
                if (this.activePanel > 0 && this.activePanel < this.panels.length) {
                    // Add the "active" class to the correct panel
                    this.panels[this.activePanel - 1].classList.add("active");
                    // Fix the current active panel index "zero based index"
                    this.activePanel = this.activePanel - 1;
                }
            }

            attachEvents() {
                this.headers.forEach((h, idx) => {
                    h.addEventListener("click", (e) => {
                        if (!this.multi) {
                            // Check if there is an active panel and close it before opening another one.
                            // If there is no active panel, close all the panels.
                            if (this.activePanel === idx) {
                                this.collapseAll();
                                this.activePanel = null;
                            } else {
                                this.collapseAll();
                                this.expand(idx);
                                this.activePanel = idx;
                            }
                        } else {
                            this.toggle(idx);
                        }
                    });
                });

                // Recalculate the panel body height and store it on resizing the window.
                addEventListener("resize", this.setSize.bind(this));
            }
        }

        // element: The expansion panels parent.
        // active: The active panel index.
        // multi: Open more than one panel at once.
        const myAccordion = new Accordion({
            element: document.querySelector(".accordion"),
            active: 1,
            multi: false
        });

    </script>









    <script>
        $(document).ready(function() {
            $("#toggle").click(function() {
                var elem = $("#toggle").text();
                if (elem == "Read More") {
                    //Stuff to do when btn is in the read more state
                    $("#toggle").text("Read Less");
                    $("#text").slideDown();
                } else {
                    //Stuff to do when btn is in the read less state
                    $("#toggle").text("Read More");
                    $("#text").slideUp();
                }
            });
        });

    </script>

    <script>
        $(document).ready(function() {
            $("#toggle2").click(function() {
                var elem = $("#toggle2").text();
                if (elem == "Read More") {
                    //Stuff to do when btn is in the read more state
                    $("#toggle2").text("Read Less");
                    $("#text2").slideDown();
                } else {
                    //Stuff to do when btn is in the read less state
                    $("#toggle2").text("Read More");
                    $("#text2").slideUp();
                }
            });
        });

    </script>

    <script>
        $(document).ready(function() {
            $("#toggle3").click(function() {
                var elem = $("#toggle3").text();
                if (elem == "Read More") {
                    //Stuff to do when btn is in the read more state
                    $("#toggle3").text("Read Less");
                    $("#text3").slideDown();
                } else {
                    //Stuff to do when btn is in the read less state
                    $("#toggle3").text("Read More");
                    $("#text3").slideUp();
                }
            });
        });

    </script>

    <script>
        $(document).ready(function() {
            $("#toggle4").click(function() {
                var elem = $("#toggle4").text();
                if (elem == "Read More") {
                    //Stuff to do when btn is in the read more state
                    $("#toggle4").text("Read Less");
                    $("#text4").slideDown();
                } else {
                    //Stuff to do when btn is in the read less state
                    $("#toggle4").text("Read More");
                    $("#text4").slideUp();
                }
            });
        });

    </script>


</body>

</html>