<!-- Optional JavaScript -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" crossorigin="anonymous"></script>

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>



<!--    ask-modal-dropdown-js-->
<!-- ***===================
        modal js

    ******===================== -->
<script type="text/javascript">
  $(document).ready(function() {
      $("#modal-btn-1").click(function() {
          $("#modal-no-1").hide();
          $("#modal-no-2").show();
      });
      $("#modal-btn-2").click(function() {
          $("#modal-no-2").hide();
          $("#modal-no-3").show();
      });
      $("#modal-btn-3").click(function() {
          $("#modal-no-3").hide();
          $("#modal-no-4").show();
      });
      $("#modal-btn-4").click(function() {
          $("#modal-no-4").hide();
          $("#modal-no-5").show();
      });
      $("#modal-btn-5").click(function() {
          $("#modal-no-5").hide();
          $("#modal-no-6").show();
      });
      $("#modal-btn-6").click(function() {
          $("#modal-no-6").hide();
          $("#modal-no-7").show();
      });
      $("#modal-btn-7").click(function() {
          $("#modal-no-7").hide();
          $("#modal-no-8").show();
      });
      $("#modal-btn-8").click(function() {
          $("#modal-no-8").hide();
          $("#modal-no-10").show();
      });
      $("#modal-btn-10").click(function() {
          $("#modal-no-10").hide();
          $("#modal-no-11").show();
      });
      $("#modal-btn-11").click(function() {
          $("#modal-no-11").hide();
          $("#modal-no-12").show();
      });
      $("#modal-btn-12").click(function() {
          $("#modal-no-12").hide();
          $("#modal-no-13").show();
      });
      $("#modal-btn-13").click(function() {
          $("#modal-no-13").hide();
          $("#modal-no-14").show();
      });
      $("#modal-btn-14").click(function() {
          $("#modal-no-14").hide();
          $("#modal-no-15").show();
      });
      $("#modal-btn-15").click(function() {
          $("#modal-no-15").hide();
          $("#modal-no-16").show();
      });
      $("#modal-btn-16").click(function() {
          $("#modal-no-16").hide();
          $("#modal-no-17").show();
      });
      $("#modal-btn-17").click(function() {
          $("#modal-no-17").hide();
          $("#modal-no-18").show();
      });
      $("#modal-btn-18").click(function() {
          $("#modal-no-18").hide();
          $("#modal-no-19").show();
      });
      $("#modal-btn-19").click(function() {
          $("#modal-no-19").hide();
          $("#modal-no-20").show();
      });
      $("#modal-btn-20").click(function() {
          $("#modal-no-20").hide();
          $("#modal-no-21").show();
      });
      $("#modal-btn-21").click(function() {
          $("#modal-no-21").hide();
          $("#modal-no-22").show();
      });
      $("#modal-btn-22").click(function() {
          $("#modal-no-22").hide();
          $("#modal-no-23").show();
      });
      $("#modal-btn-23").click(function() {
          $("#modal-no-23").hide();
          $("#modal-no-24").show();
      });
      $("#modal-btn-24").click(function() {
          $("#modal-no-24").hide();
          $("#modal-no-34").show();
      });
      $("#modal-btn-34").click(function() {
          $("#modal-no-34").hide();
          $("#modal-no-35").show();
      });
      $("#modal-btn-35").click(function() {
          $("#modal-no-35").hide();
          $("#modal-no-36").show();
      });
      $("#modal-btn-36").click(function() {
          $("#modal-no-36").hide();
          $("#modal-no-37").show();
      });
  });

</script>
<!-- modal-dropdown2 -->
<script>
  $(document).ready(function() {

      $("#plus-mode3").click(function() {
          // $("#modalbar2-dropdown-li-3").toggle();

          $("#modal-mode3").toggle();
      });

      ////////////////////////
      $("#modalbar2-dropdown-li-8").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#modalbar2-dropdown-li-9").removeClass('active');
          $("#modalbar2-dropdown-li-11").removeClass('active');
          $("#modalbar2-dropdown-li-10").removeClass('active');
          $("#modalbar2-dropdown-li-12").removeClass('active');
          $("#modalbar2-dropdown-li-13").removeClass('active');
          $("#modalbar2-dropdown-li-14").removeClass('active');
          $("#modalbar2-dropdown-li-15").removeClass('active');
          $("#modalbar2-dropdown-li-16").removeClass('active');
          $("#modalbar2-list-9").hide();
          $("#modalbar2-list-10").hide();
          $("#modalbar2-list-11").hide();
          $("#modalbar2-list-15").hide();
          $("#modalbar2-list-16").hide();
          $("#modalbar2-list-13").hide();
          $("#modalbar2-list-12").hide();
          $("#modalbar2-list-14").hide();
          $("#modalbar2-dropdown-li-10").hide();
          $("#modalbar2-list-8").toggle();
          if ($("#modalbar2-dropdown-li-8").hasClass('active')) {
              $("#modalbar2-dropdown-li-8").removeClass('active');
          } else {
              $("#modalbar2-dropdown-li-8").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar2-dropdown-li-13").click(function() {
          // $("#modalbar2-dropdown-li-3").toggle();
          $("#modalbar2-dropdown-li-9").removeClass('active');
          $("#modalbar2-dropdown-li-11").removeClass('active');
          $("#modalbar2-dropdown-li-10").removeClass('active');
          $("#modalbar2-dropdown-li-12").removeClass('active');
          $("#modalbar2-dropdown-li-14").removeClass('active');
          $("#modalbar2-dropdown-li-8").removeClass('active');
          $("#modalbar2-dropdown-li-15").removeClass('active');
          $("#modalbar2-dropdown-li-16").removeClass('active');
          $("#modalbar2-list-9").hide();
          $("#modalbar2-list-11").hide();
          $("#modalbar2-list-14").hide();
          $("#modalbar2-list-15").hide();
          $("#modalbar2-list-12").hide();
          $("#modalbar2-list-16").hide();
          $("#modalbar2-list-8").hide();
          $("#modalbar2-list-10").hide();
          $("#modalbar2-list-13").toggle();
          if ($("#modalbar2-dropdown-li-13").hasClass('active')) {
              $("#modalbar2-dropdown-li-13").removeClass('active');
          } else {
              $("#modalbar2-dropdown-li-13").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar2-dropdown-li-14").click(function() {
          // $("#modalbar2-dropdown-li-3").toggle();
          $("#modalbar2-dropdown-li-9").removeClass('active');
          $("#modalbar2-dropdown-li-11").removeClass('active');
          $("#modalbar2-dropdown-li-10").removeClass('active');
          $("#modalbar2-dropdown-li-12").removeClass('active');
          $("#modalbar2-dropdown-li-13").removeClass('active');
          $("#modalbar2-dropdown-li-15").removeClass('active');
          $("#modalbar2-dropdown-li-16").removeClass('active');
          $("#modalbar2-dropdown-li-8").removeClass('active');
          $("#modalbar2-list-9").hide();
          $("#modalbar2-list-11").hide();
          $("#modalbar2-list-13").hide();
          $("#modalbar2-list-15").hide();
          $("#modalbar2-list-12").hide();
          $("#modalbar2-list-16").hide();
          $("#modalbar2-list-8").hide();
          $("#modalbar2-list-14").toggle();
          if ($("#modalbar2-dropdown-li-14").hasClass('active')) {
              $("#modalbar2-dropdown-li-14").removeClass('active');
          } else {
              $("#modalbar2-dropdown-li-14").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar2-dropdown-li-15").click(function() {
          // $("#modalbar2-dropdown-li-3").toggle();
          $("#modalbar2-dropdown-li-9").removeClass('active');
          $("#modalbar2-dropdown-li-11").removeClass('active');
          $("#modalbar2-dropdown-li-10").removeClass('active');
          $("#modalbar2-dropdown-li-12").removeClass('active');
          $("#modalbar2-dropdown-li-14").removeClass('active');
          $("#modalbar2-dropdown-li-13").removeClass('active');
          $("#modalbar2-dropdown-li-16").removeClass('active');
          $("#modalbar2-dropdown-li-8").removeClass('active');
          $("#modalbar2-list-9").hide();
          $("#modalbar2-list-11").hide();
          $("#modalbar2-list-8").hide();
          $("#modalbar2-list-10").hide();
          $("#modalbar2-list-12").hide();
          $("#modalbar2-list-13").hide();
          $("#modalbar2-list-14").hide();
          $("#modalbar2-list-16").hide();
          $("#modalbar2-list-15").toggle();
          if ($("#modalbar2-dropdown-li-15").hasClass('active')) {
              $("#modalbar2-dropdown-li-15").removeClass('active');
          } else {
              $("#modalbar2-dropdown-li-15").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar2-dropdown-li-16").click(function() {
          // $("#modalbar2-dropdown-li-3").toggle();
          $("#modalbar2-dropdown-li-9").removeClass('active');
          $("#modalbar2-dropdown-li-11").removeClass('active');
          $("#modalbar2-dropdown-li-10").removeClass('active');
          $("#modalbar2-dropdown-li-8").removeClass('active');
          $("#modalbar2-dropdown-li-12").removeClass('active');
          $("#modalbar2-dropdown-li-13").removeClass('active');
          $("#modalbar2-dropdown-li-14").removeClass('active');
          $("#modalbar2-dropdown-li-15").removeClass('active');
          $("#modalbar2-list-9").hide();
          $("#modalbar2-list-11").hide();
          $("#modalbar2-list-10").hide();
          $("#modalbar2-list-8").hide();
          $("#modalbar2-list-12").hide();
          $("#modalbar2-list-13").hide();
          $("#modalbar2-list-14").hide();
          $("#modalbar2-list-15").hide();
          $("#modalbar2-list-16").toggle();
          if ($("#modalbar2-dropdown-li-16").hasClass('active')) {
              $("#modalbar2-dropdown-li-16").removeClass('active');
          } else {
              $("#modalbar2-dropdown-li-16").addClass('active');


          }
      });

  });

</script>
<script>
  $(document).ready(function() {

      $("#modalbar2-dropdown-li-9").click(function() {
          // $("#modalbar2-dropdown-li-2").toggle();
          $("#modalbar2-dropdown-li-8").removeClass('active');
          $("#modalbar2-dropdown-li-11").removeClass('active');
          $("#modalbar2-dropdown-li-10").removeClass('active');
          $("#modalbar2-dropdown-li-12").removeClass('active');
          $("#modalbar2-dropdown-li-13").removeClass('active');
          $("#modalbar2-dropdown-li-14").removeClass('active');
          $("#modalbar2-dropdown-li-15").removeClass('active');
          $("#modalbar2-dropdown-li-16").removeClass('active');
          $("#modalbar2-list-8").hide();
          $("#modalbar2-list-11").hide();
          $("#modalbar2-list-13").hide();
          $("#modalbar2-list-14").hide();
          $("#modalbar2-list-15").hide();
          $("#modalbar2-list-16").hide();
          $("#modalbar2-list-9").toggle();
          if ($("#modalbar2-dropdown-li-9").hasClass('active')) {
              $("#modalbar2-dropdown-li-9").removeClass('active');
          } else {
              $("#modalbar2-dropdown-li-9").addClass('active');

          }
      });
      // ///////////////////////////////////////////////////////
      $(".fix_id4").hover(function() {
          // $("#modalbar2-dropdown-li-2").toggle();
          $("#modalbar2-list-8").hide();
          $("#modalbar2-list-9").hide();
          $("#modalbar2-list-11").hide();
          $("#modalbar2-list-10").hide();
          $("#modalbar2-list-12").hide();
          $("#modalbar2-list-13").hide();
          $("#modalbar2-list-14").hide();
          $("#modalbar2-list-15").hide();
          $("#modalbar2-list-16").hide();
          $("#modalbar2-dropdown-li-8").removeClass('active');
          $("#modalbar2-dropdown-li-9").removeClass('active');
          $("#modalbar2-dropdown-li-11").removeClass('active');
          $("#modalbar2-dropdown-li-10").removeClass('active');
          $("#modalbar2-dropdown-li-12").removeClass('active');
          $("#modalbar2-dropdown-li-13").removeClass('active');
          $("#modalbar2-dropdown-li-14").removeClass('active');
          $("#modalbar2-dropdown-li-15").removeClass('active');
          $("#modalbar2-dropdown-li-16").removeClass('active');
      });
  });

</script>
<script>
  $(document).ready(function() {

      /////////////////////////////////////////
      $("#modalbar2-dropdown-li-10").click(function() {
          // $("#modalbar2-dropdown-li-8").removeClass('active');
          $("#modalbar2-dropdown-li-9").removeClass('active');
          $("#modalbar2-dropdown-li-11").removeClass('active');
          $("#modalbar2-dropdown-li-12").removeClass('active');
          $("#modalbar2-dropdown-li-13").removeClass('active');
          $("#modalbar2-dropdown-li-14").removeClass('active');
          $("#modalbar2-dropdown-li-15").removeClass('active');
          $("#modalbar2-dropdown-li-16").removeClass('active');
          $("#modalbar2-list-10").toggle();
          if ($("#modalbar2-dropdown-li-10").hasClass('active')) {
              $("#modalbar2-dropdown-li-10").removeClass('active');
          } else {
              $("#modalbar2-dropdown-li-10").addClass('active');

          }
      });
      //////////////////////
      $("#modalbar2-dropdown-li-11").click(function() {
          // $("#modalbar2-dropdown-li-3").toggle();
          $("#modalbar2-dropdown-li-8").removeClass('active');
          $("#modalbar2-dropdown-li-9").removeClass('active');
          $("#modalbar2-dropdown-li-10").removeClass('active');
          $("#modalbar2-dropdown-li-12").removeClass('active');
          $("#modalbar2-dropdown-li-13").removeClass('active');
          $("#modalbar2-dropdown-li-14").removeClass('active');
          $("#modalbar2-dropdown-li-15").removeClass('active');
          $("#modalbar2-dropdown-li-16").removeClass('active');
          $("#modalbar2-list-9").hide();
          $("#modalbar2-list-13").hide();
          $("#modalbar2-list-14").hide();
          $("#modalbar2-list-15").hide();
          $("#modalbar2-list-16").hide();
          $("#modalbar2-list-8").hide();
          $("#modalbar2-list-11").toggle();
          if ($("#modalbar2-dropdown-li-11").hasClass('active')) {
              $("#modalbar2-dropdown-li-11").removeClass('active');
          } else {
              $("#modalbar2-dropdown-li-11").addClass('active');

          }
      });
      /////////////////////////////
      $("#modalbar2-dropdown-li-12").click(function() {
          $("#modalbar2-dropdown-li-8").removeClass('active');
          $("#modalbar2-dropdown-li-9").removeClass('active');
          // $("#modalbar2-dropdown-li-11").removeClass('active');
          $("#modalbar2-dropdown-li-10").removeClass('active');
          $("#modalbar2-dropdown-li-13").removeClass('active');
          $("#modalbar2-dropdown-li-14").removeClass('active');
          $("#modalbar2-dropdown-li-15").removeClass('active');
          $("#modalbar2-dropdown-li-16").removeClass('active');
          $("#modalbar2-list-12").toggle();
          if ($("#modalbar2-dropdown-li-12").hasClass('active')) {
              $("#modalbar2-dropdown-li-12").removeClass('active');
          } else {
              $("#modalbar2-dropdown-li-12").addClass('active');

          }
      });
  });

</script>
<!-- finishing modaldropdown2 -->
<!-- modal-dropdown3 -->
<script>
  $(document).ready(function() {

      $("#plus-mode4").click(function() {
          // $("#modalbar2-dropdown-li-3").toggle();

          $("#modal-mode4").toggle();
      });

      ////////////////////////
      $("#modalbar3-dropdown-li-8").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#modalbar3-dropdown-li-9").removeClass('active');
          $("#modalbar3-dropdown-li-11").removeClass('active');
          $("#modalbar3-dropdown-li-10").removeClass('active');
          $("#modalbar3-dropdown-li-12").removeClass('active');
          $("#modalbar3-dropdown-li-13").removeClass('active');
          $("#modalbar3-dropdown-li-14").removeClass('active');
          $("#modalbar3-dropdown-li-15").removeClass('active');
          $("#modalbar3-dropdown-li-16").removeClass('active');
          $("#modalbar3-list-9").hide();
          $("#modalbar3-list-10").hide();
          $("#modalbar3-list-11").hide();
          $("#modalbar3-list-15").hide();
          $("#modalbar3-list-16").hide();
          $("#modalbar3-list-13").hide();
          $("#modalbar3-list-12").hide();
          $("#modalbar3-list-14").hide();
          $("#modalbar3-dropdown-li-10").hide();
          $("#modalbar3-list-8").toggle();
          if ($("#modalbar3-dropdown-li-8").hasClass('active')) {
              $("#modalbar3-dropdown-li-8").removeClass('active');
          } else {
              $("#modalbar3-dropdown-li-8").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar3-dropdown-li-13").click(function() {
          // $("#modalbar3-dropdown-li-3").toggle();
          $("#modalbar3-dropdown-li-9").removeClass('active');
          $("#modalbar3-dropdown-li-11").removeClass('active');
          $("#modalbar3-dropdown-li-10").removeClass('active');
          $("#modalbar3-dropdown-li-12").removeClass('active');
          $("#modalbar3-dropdown-li-14").removeClass('active');
          $("#modalbar3-dropdown-li-8").removeClass('active');
          $("#modalbar3-dropdown-li-15").removeClass('active');
          $("#modalbar3-dropdown-li-16").removeClass('active');
          $("#modalbar3-list-9").hide();
          $("#modalbar3-list-11").hide();
          $("#modalbar3-list-14").hide();
          $("#modalbar3-list-15").hide();
          $("#modalbar3-list-12").hide();
          $("#modalbar3-list-16").hide();
          $("#modalbar3-list-8").hide();
          $("#modalbar3-list-10").hide();
          $("#modalbar3-list-13").toggle();
          if ($("#modalbar3-dropdown-li-13").hasClass('active')) {
              $("#modalbar3-dropdown-li-13").removeClass('active');
          } else {
              $("#modalbar3-dropdown-li-13").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar3-dropdown-li-14").click(function() {
          // $("#modalbar3-dropdown-li-3").toggle();
          $("#modalbar3-dropdown-li-9").removeClass('active');
          $("#modalbar3-dropdown-li-11").removeClass('active');
          $("#modalbar3-dropdown-li-10").removeClass('active');
          $("#modalbar3-dropdown-li-12").removeClass('active');
          $("#modalbar3-dropdown-li-13").removeClass('active');
          $("#modalbar3-dropdown-li-15").removeClass('active');
          $("#modalbar3-dropdown-li-16").removeClass('active');
          $("#modalbar3-dropdown-li-8").removeClass('active');
          $("#modalbar3-list-9").hide();
          $("#modalbar3-list-11").hide();
          $("#modalbar3-list-13").hide();
          $("#modalbar3-list-15").hide();
          $("#modalbar3-list-12").hide();
          $("#modalbar3-list-16").hide();
          $("#modalbar3-list-8").hide();
          $("#modalbar3-list-14").toggle();
          if ($("#modalbar3-dropdown-li-14").hasClass('active')) {
              $("#modalbar3-dropdown-li-14").removeClass('active');
          } else {
              $("#modalbar3-dropdown-li-14").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar3-dropdown-li-15").click(function() {
          // $("#modalbar3-dropdown-li-3").toggle();
          $("#modalbar3-dropdown-li-9").removeClass('active');
          $("#modalbar3-dropdown-li-11").removeClass('active');
          $("#modalbar3-dropdown-li-10").removeClass('active');
          $("#modalbar3-dropdown-li-12").removeClass('active');
          $("#modalbar3-dropdown-li-14").removeClass('active');
          $("#modalbar3-dropdown-li-13").removeClass('active');
          $("#modalbar3-dropdown-li-16").removeClass('active');
          $("#modalbar3-dropdown-li-8").removeClass('active');
          $("#modalbar3-list-9").hide();
          $("#modalbar3-list-11").hide();
          $("#modalbar3-list-8").hide();
          $("#modalbar3-list-10").hide();
          $("#modalbar3-list-12").hide();
          $("#modalbar3-list-13").hide();
          $("#modalbar3-list-14").hide();
          $("#modalbar3-list-16").hide();
          $("#modalbar3-list-15").toggle();
          if ($("#modalbar3-dropdown-li-15").hasClass('active')) {
              $("#modalbar3-dropdown-li-15").removeClass('active');
          } else {
              $("#modalbar3-dropdown-li-15").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar3-dropdown-li-16").click(function() {
          // $("#modalbar3-dropdown-li-3").toggle();
          $("#modalbar3-dropdown-li-9").removeClass('active');
          $("#modalbar3-dropdown-li-11").removeClass('active');
          $("#modalbar3-dropdown-li-10").removeClass('active');
          $("#modalbar3-dropdown-li-8").removeClass('active');
          $("#modalbar3-dropdown-li-12").removeClass('active');
          $("#modalbar3-dropdown-li-13").removeClass('active');
          $("#modalbar3-dropdown-li-14").removeClass('active');
          $("#modalbar3-dropdown-li-15").removeClass('active');
          $("#modalbar3-list-9").hide();
          $("#modalbar3-list-11").hide();
          $("#modalbar3-list-10").hide();
          $("#modalbar3-list-8").hide();
          $("#modalbar3-list-12").hide();
          $("#modalbar3-list-13").hide();
          $("#modalbar3-list-14").hide();
          $("#modalbar3-list-15").hide();
          $("#modalbar3-list-16").toggle();
          if ($("#modalbar3-dropdown-li-16").hasClass('active')) {
              $("#modalbar3-dropdown-li-16").removeClass('active');
          } else {
              $("#modalbar3-dropdown-li-16").addClass('active');


          }
      });

  });

</script>
<script>
  $(document).ready(function() {

      $("#modalbar3-dropdown-li-9").click(function() {
          // $("#modalbar3-dropdown-li-2").toggle();
          $("#modalbar3-dropdown-li-8").removeClass('active');
          $("#modalbar3-dropdown-li-11").removeClass('active');
          $("#modalbar3-dropdown-li-10").removeClass('active');
          $("#modalbar3-dropdown-li-12").removeClass('active');
          $("#modalbar3-dropdown-li-13").removeClass('active');
          $("#modalbar3-dropdown-li-14").removeClass('active');
          $("#modalbar3-dropdown-li-15").removeClass('active');
          $("#modalbar3-dropdown-li-16").removeClass('active');
          $("#modalbar3-list-8").hide();
          $("#modalbar3-list-11").hide();
          $("#modalbar3-list-13").hide();
          $("#modalbar3-list-14").hide();
          $("#modalbar3-list-15").hide();
          $("#modalbar3-list-16").hide();
          $("#modalbar3-list-9").toggle();
          if ($("#modalbar3-dropdown-li-9").hasClass('active')) {
              $("#modalbar3-dropdown-li-9").removeClass('active');
          } else {
              $("#modalbar3-dropdown-li-9").addClass('active');

          }
      });
      // ///////////////////////////////////////////////////////
      $(".fix_id5").hover(function() {
          // $("#modalbar3-dropdown-li-2").toggle();
          $("#modalbar3-list-8").hide();
          $("#modalbar3-list-9").hide();
          $("#modalbar3-list-11").hide();
          $("#modalbar3-list-10").hide();
          $("#modalbar3-list-12").hide();
          $("#modalbar3-list-13").hide();
          $("#modalbar3-list-14").hide();
          $("#modalbar3-list-15").hide();
          $("#modalbar3-list-16").hide();
          $("#modalbar3-dropdown-li-8").removeClass('active');
          $("#modalbar3-dropdown-li-9").removeClass('active');
          $("#modalbar3-dropdown-li-11").removeClass('active');
          $("#modalbar3-dropdown-li-10").removeClass('active');
          $("#modalbar3-dropdown-li-12").removeClass('active');
          $("#modalbar3-dropdown-li-13").removeClass('active');
          $("#modalbar3-dropdown-li-14").removeClass('active');
          $("#modalbar3-dropdown-li-15").removeClass('active');
          $("#modalbar3-dropdown-li-16").removeClass('active');
      });
  });

</script>
<script>
  $(document).ready(function() {

      /////////////////////////////////////////
      $("#modalbar3-dropdown-li-10").click(function() {
          // $("#modalbar3-dropdown-li-8").removeClass('active');
          $("#modalbar3-dropdown-li-9").removeClass('active');
          $("#modalbar3-dropdown-li-11").removeClass('active');
          $("#modalbar3-dropdown-li-12").removeClass('active');
          $("#modalbar3-dropdown-li-13").removeClass('active');
          $("#modalbar3-dropdown-li-14").removeClass('active');
          $("#modalbar3-dropdown-li-15").removeClass('active');
          $("#modalbar3-dropdown-li-16").removeClass('active');
          $("#modalbar3-list-10").toggle();
          if ($("#modalbar3-dropdown-li-10").hasClass('active')) {
              $("#modalbar3-dropdown-li-10").removeClass('active');
          } else {
              $("#modalbar3-dropdown-li-10").addClass('active');

          }
      });
      //////////////////////
      $("#modalbar3-dropdown-li-11").click(function() {
          // $("#modalbar3-dropdown-li-3").toggle();
          $("#modalbar3-dropdown-li-8").removeClass('active');
          $("#modalbar3-dropdown-li-9").removeClass('active');
          $("#modalbar3-dropdown-li-10").removeClass('active');
          $("#modalbar3-dropdown-li-12").removeClass('active');
          $("#modalbar3-dropdown-li-13").removeClass('active');
          $("#modalbar3-dropdown-li-14").removeClass('active');
          $("#modalbar3-dropdown-li-15").removeClass('active');
          $("#modalbar3-dropdown-li-16").removeClass('active');
          $("#modalbar3-list-9").hide();
          $("#modalbar3-list-13").hide();
          $("#modalbar3-list-14").hide();
          $("#modalbar3-list-15").hide();
          $("#modalbar3-list-16").hide();
          $("#modalbar3-list-8").hide();
          $("#modalbar3-list-11").toggle();
          if ($("#modalbar3-dropdown-li-11").hasClass('active')) {
              $("#modalbar3-dropdown-li-11").removeClass('active');
          } else {
              $("#modalbar3-dropdown-li-11").addClass('active');

          }
      });
      /////////////////////////////
      $("#modalbar3-dropdown-li-12").click(function() {
          $("#modalbar3-dropdown-li-8").removeClass('active');
          $("#modalbar3-dropdown-li-9").removeClass('active');
          // $("#modalbar3-dropdown-li-11").removeClass('active');
          $("#modalbar3-dropdown-li-10").removeClass('active');
          $("#modalbar3-dropdown-li-13").removeClass('active');
          $("#modalbar3-dropdown-li-14").removeClass('active');
          $("#modalbar3-dropdown-li-15").removeClass('active');
          $("#modalbar3-dropdown-li-16").removeClass('active');
          $("#modalbar3-list-12").toggle();
          if ($("#modalbar3-dropdown-li-12").hasClass('active')) {
              $("#modalbar3-dropdown-li-12").removeClass('active');
          } else {
              $("#modalbar3-dropdown-li-12").addClass('active');

          }
      });
  });

</script>
<!-- finishing modaldropdown3 -->
<!-- modal-dropdown4 -->
<script>
  $(document).ready(function() {

      $("#plus-mode5").click(function() {
          // $("#modalbar2-dropdown-li-3").toggle();

          $("#modal-mode5").toggle();
      });

      ////////////////////////
      $("#modalbar4-dropdown-li-8").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#modalbar4-dropdown-li-9").removeClass('active');
          $("#modalbar4-dropdown-li-11").removeClass('active');
          $("#modalbar4-dropdown-li-10").removeClass('active');
          $("#modalbar4-dropdown-li-12").removeClass('active');
          $("#modalbar4-dropdown-li-13").removeClass('active');
          $("#modalbar4-dropdown-li-14").removeClass('active');
          $("#modalbar4-dropdown-li-15").removeClass('active');
          $("#modalbar4-dropdown-li-16").removeClass('active');
          $("#modalbar4-list-9").hide();
          $("#modalbar4-list-10").hide();
          $("#modalbar4-list-11").hide();
          $("#modalbar4-list-15").hide();
          $("#modalbar4-list-16").hide();
          $("#modalbar4-list-13").hide();
          $("#modalbar4-list-12").hide();
          $("#modalbar4-list-14").hide();
          $("#modalbar4-dropdown-li-10").hide();
          $("#modalbar4-list-8").toggle();
          if ($("#modalbar4-dropdown-li-8").hasClass('active')) {
              $("#modalbar4-dropdown-li-8").removeClass('active');
          } else {
              $("#modalbar4-dropdown-li-8").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar4-dropdown-li-13").click(function() {
          // $("#modalbar4-dropdown-li-3").toggle();
          $("#modalbar4-dropdown-li-9").removeClass('active');
          $("#modalbar4-dropdown-li-11").removeClass('active');
          $("#modalbar4-dropdown-li-10").removeClass('active');
          $("#modalbar4-dropdown-li-12").removeClass('active');
          $("#modalbar4-dropdown-li-14").removeClass('active');
          $("#modalbar4-dropdown-li-8").removeClass('active');
          $("#modalbar4-dropdown-li-15").removeClass('active');
          $("#modalbar4-dropdown-li-16").removeClass('active');
          $("#modalbar4-list-9").hide();
          $("#modalbar4-list-11").hide();
          $("#modalbar4-list-14").hide();
          $("#modalbar4-list-15").hide();
          $("#modalbar4-list-12").hide();
          $("#modalbar4-list-16").hide();
          $("#modalbar4-list-8").hide();
          $("#modalbar4-list-10").hide();
          $("#modalbar4-list-13").toggle();
          if ($("#modalbar4-dropdown-li-13").hasClass('active')) {
              $("#modalbar4-dropdown-li-13").removeClass('active');
          } else {
              $("#modalbar4-dropdown-li-13").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar4-dropdown-li-14").click(function() {
          // $("#modalbar4-dropdown-li-3").toggle();
          $("#modalbar4-dropdown-li-9").removeClass('active');
          $("#modalbar4-dropdown-li-11").removeClass('active');
          $("#modalbar4-dropdown-li-10").removeClass('active');
          $("#modalbar4-dropdown-li-12").removeClass('active');
          $("#modalbar4-dropdown-li-13").removeClass('active');
          $("#modalbar4-dropdown-li-15").removeClass('active');
          $("#modalbar4-dropdown-li-16").removeClass('active');
          $("#modalbar4-dropdown-li-8").removeClass('active');
          $("#modalbar4-list-9").hide();
          $("#modalbar4-list-11").hide();
          $("#modalbar4-list-13").hide();
          $("#modalbar4-list-15").hide();
          $("#modalbar4-list-12").hide();
          $("#modalbar4-list-16").hide();
          $("#modalbar4-list-8").hide();
          $("#modalbar4-list-14").toggle();
          if ($("#modalbar4-dropdown-li-14").hasClass('active')) {
              $("#modalbar4-dropdown-li-14").removeClass('active');
          } else {
              $("#modalbar4-dropdown-li-14").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar4-dropdown-li-15").click(function() {
          // $("#modalbar4-dropdown-li-3").toggle();
          $("#modalbar4-dropdown-li-9").removeClass('active');
          $("#modalbar4-dropdown-li-11").removeClass('active');
          $("#modalbar4-dropdown-li-10").removeClass('active');
          $("#modalbar4-dropdown-li-12").removeClass('active');
          $("#modalbar4-dropdown-li-14").removeClass('active');
          $("#modalbar4-dropdown-li-13").removeClass('active');
          $("#modalbar4-dropdown-li-16").removeClass('active');
          $("#modalbar4-dropdown-li-8").removeClass('active');
          $("#modalbar4-list-9").hide();
          $("#modalbar4-list-11").hide();
          $("#modalbar4-list-8").hide();
          $("#modalbar4-list-10").hide();
          $("#modalbar4-list-12").hide();
          $("#modalbar4-list-13").hide();
          $("#modalbar4-list-14").hide();
          $("#modalbar4-list-16").hide();
          $("#modalbar4-list-15").toggle();
          if ($("#modalbar4-dropdown-li-15").hasClass('active')) {
              $("#modalbar4-dropdown-li-15").removeClass('active');
          } else {
              $("#modalbar4-dropdown-li-15").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar4-dropdown-li-16").click(function() {
          // $("#modalbar4-dropdown-li-3").toggle();
          $("#modalbar4-dropdown-li-9").removeClass('active');
          $("#modalbar4-dropdown-li-11").removeClass('active');
          $("#modalbar4-dropdown-li-10").removeClass('active');
          $("#modalbar4-dropdown-li-8").removeClass('active');
          $("#modalbar4-dropdown-li-12").removeClass('active');
          $("#modalbar4-dropdown-li-13").removeClass('active');
          $("#modalbar4-dropdown-li-14").removeClass('active');
          $("#modalbar4-dropdown-li-15").removeClass('active');
          $("#modalbar4-list-9").hide();
          $("#modalbar4-list-11").hide();
          $("#modalbar4-list-10").hide();
          $("#modalbar4-list-8").hide();
          $("#modalbar4-list-12").hide();
          $("#modalbar4-list-13").hide();
          $("#modalbar4-list-14").hide();
          $("#modalbar4-list-15").hide();
          $("#modalbar4-list-16").toggle();
          if ($("#modalbar4-dropdown-li-16").hasClass('active')) {
              $("#modalbar4-dropdown-li-16").removeClass('active');
          } else {
              $("#modalbar4-dropdown-li-16").addClass('active');


          }
      });

  });

</script>
<script>
  $(document).ready(function() {

      $("#modalbar4-dropdown-li-9").click(function() {
          // $("#modalbar4-dropdown-li-2").toggle();
          $("#modalbar4-dropdown-li-8").removeClass('active');
          $("#modalbar4-dropdown-li-11").removeClass('active');
          $("#modalbar4-dropdown-li-10").removeClass('active');
          $("#modalbar4-dropdown-li-12").removeClass('active');
          $("#modalbar4-dropdown-li-13").removeClass('active');
          $("#modalbar4-dropdown-li-14").removeClass('active');
          $("#modalbar4-dropdown-li-15").removeClass('active');
          $("#modalbar4-dropdown-li-16").removeClass('active');
          $("#modalbar4-list-8").hide();
          $("#modalbar4-list-11").hide();
          $("#modalbar4-list-13").hide();
          $("#modalbar4-list-14").hide();
          $("#modalbar4-list-15").hide();
          $("#modalbar4-list-16").hide();
          $("#modalbar4-list-9").toggle();
          if ($("#modalbar4-dropdown-li-9").hasClass('active')) {
              $("#modalbar4-dropdown-li-9").removeClass('active');
          } else {
              $("#modalbar4-dropdown-li-9").addClass('active');

          }
      });
      // ///////////////////////////////////////////////////////
      $(".fix_id6").hover(function() {
          // $("#modalbar4-dropdown-li-2").toggle();
          $("#modalbar4-list-8").hide();
          $("#modalbar4-list-9").hide();
          $("#modalbar4-list-11").hide();
          $("#modalbar4-list-10").hide();
          $("#modalbar4-list-12").hide();
          $("#modalbar4-list-13").hide();
          $("#modalbar4-list-14").hide();
          $("#modalbar4-list-15").hide();
          $("#modalbar4-list-16").hide();
          $("#modalbar4-dropdown-li-8").removeClass('active');
          $("#modalbar4-dropdown-li-9").removeClass('active');
          $("#modalbar4-dropdown-li-11").removeClass('active');
          $("#modalbar4-dropdown-li-10").removeClass('active');
          $("#modalbar4-dropdown-li-12").removeClass('active');
          $("#modalbar4-dropdown-li-13").removeClass('active');
          $("#modalbar4-dropdown-li-14").removeClass('active');
          $("#modalbar4-dropdown-li-15").removeClass('active');
          $("#modalbar4-dropdown-li-16").removeClass('active');
      });
  });

</script>
<script>
  $(document).ready(function() {

      /////////////////////////////////////////
      $("#modalbar4-dropdown-li-10").click(function() {
          // $("#modalbar4-dropdown-li-8").removeClass('active');
          $("#modalbar4-dropdown-li-9").removeClass('active');
          $("#modalbar4-dropdown-li-11").removeClass('active');
          $("#modalbar4-dropdown-li-12").removeClass('active');
          $("#modalbar4-dropdown-li-13").removeClass('active');
          $("#modalbar4-dropdown-li-14").removeClass('active');
          $("#modalbar4-dropdown-li-15").removeClass('active');
          $("#modalbar4-dropdown-li-16").removeClass('active');
          $("#modalbar4-list-10").toggle();
          if ($("#modalbar4-dropdown-li-10").hasClass('active')) {
              $("#modalbar4-dropdown-li-10").removeClass('active');
          } else {
              $("#modalbar4-dropdown-li-10").addClass('active');

          }
      });
      //////////////////////
      $("#modalbar4-dropdown-li-11").click(function() {
          // $("#modalbar4-dropdown-li-3").toggle();
          $("#modalbar4-dropdown-li-8").removeClass('active');
          $("#modalbar4-dropdown-li-9").removeClass('active');
          $("#modalbar4-dropdown-li-10").removeClass('active');
          $("#modalbar4-dropdown-li-12").removeClass('active');
          $("#modalbar4-dropdown-li-13").removeClass('active');
          $("#modalbar4-dropdown-li-14").removeClass('active');
          $("#modalbar4-dropdown-li-15").removeClass('active');
          $("#modalbar4-dropdown-li-16").removeClass('active');
          $("#modalbar4-list-9").hide();
          $("#modalbar4-list-13").hide();
          $("#modalbar4-list-14").hide();
          $("#modalbar4-list-15").hide();
          $("#modalbar4-list-16").hide();
          $("#modalbar4-list-8").hide();
          $("#modalbar4-list-11").toggle();
          if ($("#modalbar4-dropdown-li-11").hasClass('active')) {
              $("#modalbar4-dropdown-li-11").removeClass('active');
          } else {
              $("#modalbar4-dropdown-li-11").addClass('active');

          }
      });
      /////////////////////////////
      $("#modalbar4-dropdown-li-12").click(function() {
          $("#modalbar4-dropdown-li-8").removeClass('active');
          $("#modalbar4-dropdown-li-9").removeClass('active');
          // $("#modalbar4-dropdown-li-11").removeClass('active');
          $("#modalbar4-dropdown-li-10").removeClass('active');
          $("#modalbar4-dropdown-li-13").removeClass('active');
          $("#modalbar4-dropdown-li-14").removeClass('active');
          $("#modalbar4-dropdown-li-15").removeClass('active');
          $("#modalbar4-dropdown-li-16").removeClass('active');
          $("#modalbar4-list-12").toggle();
          if ($("#modalbar4-dropdown-li-12").hasClass('active')) {
              $("#modalbar4-dropdown-li-12").removeClass('active');
          } else {
              $("#modalbar4-dropdown-li-12").addClass('active');

          }
      });
  });

</script>
<!-- finishing modaldropdown4 -->
<!-- modal-dropdown5 -->
<script>
  $(document).ready(function() {

      $("#plus-mode6").click(function() {
          // $("#modalbar2-dropdown-li-3").toggle();

          $("#modal-mode6").toggle();
      });

      ////////////////////////
      $("#modalbar5-dropdown-li-8").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#modalbar5-dropdown-li-9").removeClass('active');
          $("#modalbar5-dropdown-li-11").removeClass('active');
          $("#modalbar5-dropdown-li-10").removeClass('active');
          $("#modalbar5-dropdown-li-12").removeClass('active');
          $("#modalbar5-dropdown-li-13").removeClass('active');
          $("#modalbar5-dropdown-li-14").removeClass('active');
          $("#modalbar5-dropdown-li-15").removeClass('active');
          $("#modalbar5-dropdown-li-16").removeClass('active');
          $("#modalbar5-list-9").hide();
          $("#modalbar5-list-10").hide();
          $("#modalbar5-list-11").hide();
          $("#modalbar5-list-15").hide();
          $("#modalbar5-list-16").hide();
          $("#modalbar5-list-13").hide();
          $("#modalbar5-list-12").hide();
          $("#modalbar5-list-14").hide();
          $("#modalbar5-dropdown-li-10").hide();
          $("#modalbar5-list-8").toggle();
          if ($("#modalbar5-dropdown-li-8").hasClass('active')) {
              $("#modalbar5-dropdown-li-8").removeClass('active');
          } else {
              $("#modalbar5-dropdown-li-8").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar5-dropdown-li-13").click(function() {
          // $("#modalbar5-dropdown-li-3").toggle();
          $("#modalbar5-dropdown-li-9").removeClass('active');
          $("#modalbar5-dropdown-li-11").removeClass('active');
          $("#modalbar5-dropdown-li-10").removeClass('active');
          $("#modalbar5-dropdown-li-12").removeClass('active');
          $("#modalbar5-dropdown-li-14").removeClass('active');
          $("#modalbar5-dropdown-li-8").removeClass('active');
          $("#modalbar5-dropdown-li-15").removeClass('active');
          $("#modalbar5-dropdown-li-16").removeClass('active');
          $("#modalbar5-list-9").hide();
          $("#modalbar5-list-11").hide();
          $("#modalbar5-list-14").hide();
          $("#modalbar5-list-15").hide();
          $("#modalbar5-list-12").hide();
          $("#modalbar5-list-16").hide();
          $("#modalbar5-list-8").hide();
          $("#modalbar5-list-10").hide();
          $("#modalbar5-list-13").toggle();
          if ($("#modalbar5-dropdown-li-13").hasClass('active')) {
              $("#modalbar5-dropdown-li-13").removeClass('active');
          } else {
              $("#modalbar5-dropdown-li-13").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar5-dropdown-li-14").click(function() {
          // $("#modalbar5-dropdown-li-3").toggle();
          $("#modalbar5-dropdown-li-9").removeClass('active');
          $("#modalbar5-dropdown-li-11").removeClass('active');
          $("#modalbar5-dropdown-li-10").removeClass('active');
          $("#modalbar5-dropdown-li-12").removeClass('active');
          $("#modalbar5-dropdown-li-13").removeClass('active');
          $("#modalbar5-dropdown-li-15").removeClass('active');
          $("#modalbar5-dropdown-li-16").removeClass('active');
          $("#modalbar5-dropdown-li-8").removeClass('active');
          $("#modalbar5-list-9").hide();
          $("#modalbar5-list-11").hide();
          $("#modalbar5-list-13").hide();
          $("#modalbar5-list-15").hide();
          $("#modalbar5-list-12").hide();
          $("#modalbar5-list-16").hide();
          $("#modalbar5-list-8").hide();
          $("#modalbar5-list-14").toggle();
          if ($("#modalbar5-dropdown-li-14").hasClass('active')) {
              $("#modalbar5-dropdown-li-14").removeClass('active');
          } else {
              $("#modalbar5-dropdown-li-14").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar5-dropdown-li-15").click(function() {
          // $("#modalbar5-dropdown-li-3").toggle();
          $("#modalbar5-dropdown-li-9").removeClass('active');
          $("#modalbar5-dropdown-li-11").removeClass('active');
          $("#modalbar5-dropdown-li-10").removeClass('active');
          $("#modalbar5-dropdown-li-12").removeClass('active');
          $("#modalbar5-dropdown-li-14").removeClass('active');
          $("#modalbar5-dropdown-li-13").removeClass('active');
          $("#modalbar5-dropdown-li-16").removeClass('active');
          $("#modalbar5-dropdown-li-8").removeClass('active');
          $("#modalbar5-list-9").hide();
          $("#modalbar5-list-11").hide();
          $("#modalbar5-list-8").hide();
          $("#modalbar5-list-10").hide();
          $("#modalbar5-list-12").hide();
          $("#modalbar5-list-13").hide();
          $("#modalbar5-list-14").hide();
          $("#modalbar5-list-16").hide();
          $("#modalbar5-list-15").toggle();
          if ($("#modalbar5-dropdown-li-15").hasClass('active')) {
              $("#modalbar5-dropdown-li-15").removeClass('active');
          } else {
              $("#modalbar5-dropdown-li-15").addClass('active');


          }
      });
      ////////////////////////
      $("#modalbar5-dropdown-li-16").click(function() {
          // $("#modalbar5-dropdown-li-3").toggle();
          $("#modalbar5-dropdown-li-9").removeClass('active');
          $("#modalbar5-dropdown-li-11").removeClass('active');
          $("#modalbar5-dropdown-li-10").removeClass('active');
          $("#modalbar5-dropdown-li-8").removeClass('active');
          $("#modalbar5-dropdown-li-12").removeClass('active');
          $("#modalbar5-dropdown-li-13").removeClass('active');
          $("#modalbar5-dropdown-li-14").removeClass('active');
          $("#modalbar5-dropdown-li-15").removeClass('active');
          $("#modalbar5-list-9").hide();
          $("#modalbar5-list-11").hide();
          $("#modalbar5-list-10").hide();
          $("#modalbar5-list-8").hide();
          $("#modalbar5-list-12").hide();
          $("#modalbar5-list-13").hide();
          $("#modalbar5-list-14").hide();
          $("#modalbar5-list-15").hide();
          $("#modalbar5-list-16").toggle();
          if ($("#modalbar5-dropdown-li-16").hasClass('active')) {
              $("#modalbar5-dropdown-li-16").removeClass('active');
          } else {
              $("#modalbar5-dropdown-li-16").addClass('active');


          }
      });

  });

</script>
<script>
  $(document).ready(function() {

      $("#modalbar5-dropdown-li-9").click(function() {
          // $("#modalbar5-dropdown-li-2").toggle();
          $("#modalbar5-dropdown-li-8").removeClass('active');
          $("#modalbar5-dropdown-li-11").removeClass('active');
          $("#modalbar5-dropdown-li-10").removeClass('active');
          $("#modalbar5-dropdown-li-12").removeClass('active');
          $("#modalbar5-dropdown-li-13").removeClass('active');
          $("#modalbar5-dropdown-li-14").removeClass('active');
          $("#modalbar5-dropdown-li-15").removeClass('active');
          $("#modalbar5-dropdown-li-16").removeClass('active');
          $("#modalbar5-list-8").hide();
          $("#modalbar5-list-11").hide();
          $("#modalbar5-list-13").hide();
          $("#modalbar5-list-14").hide();
          $("#modalbar5-list-15").hide();
          $("#modalbar5-list-16").hide();
          $("#modalbar5-list-9").toggle();
          if ($("#modalbar5-dropdown-li-9").hasClass('active')) {
              $("#modalbar5-dropdown-li-9").removeClass('active');
          } else {
              $("#modalbar5-dropdown-li-9").addClass('active');

          }
      });
      // ///////////////////////////////////////////////////////
      $(".fix_id7").hover(function() {
          // $("#modalbar5-dropdown-li-2").toggle();
          $("#modalbar5-list-8").hide();
          $("#modalbar5-list-9").hide();
          $("#modalbar5-list-11").hide();
          $("#modalbar5-list-10").hide();
          $("#modalbar5-list-12").hide();
          $("#modalbar5-list-13").hide();
          $("#modalbar5-list-14").hide();
          $("#modalbar5-list-15").hide();
          $("#modalbar5-list-16").hide();
          $("#modalbar5-dropdown-li-8").removeClass('active');
          $("#modalbar5-dropdown-li-9").removeClass('active');
          $("#modalbar5-dropdown-li-11").removeClass('active');
          $("#modalbar5-dropdown-li-10").removeClass('active');
          $("#modalbar5-dropdown-li-12").removeClass('active');
          $("#modalbar5-dropdown-li-13").removeClass('active');
          $("#modalbar5-dropdown-li-14").removeClass('active');
          $("#modalbar5-dropdown-li-15").removeClass('active');
          $("#modalbar5-dropdown-li-16").removeClass('active');
      });
  });

</script>
<script>
  $(document).ready(function() {

      /////////////////////////////////////////
      $("#modalbar5-dropdown-li-10").click(function() {
          // $("#modalbar5-dropdown-li-8").removeClass('active');
          $("#modalbar5-dropdown-li-9").removeClass('active');
          $("#modalbar5-dropdown-li-11").removeClass('active');
          $("#modalbar5-dropdown-li-12").removeClass('active');
          $("#modalbar5-dropdown-li-13").removeClass('active');
          $("#modalbar5-dropdown-li-14").removeClass('active');
          $("#modalbar5-dropdown-li-15").removeClass('active');
          $("#modalbar5-dropdown-li-16").removeClass('active');
          $("#modalbar5-list-10").toggle();
          if ($("#modalbar5-dropdown-li-10").hasClass('active')) {
              $("#modalbar5-dropdown-li-10").removeClass('active');
          } else {
              $("#modalbar5-dropdown-li-10").addClass('active');

          }
      });
      //////////////////////
      $("#modalbar5-dropdown-li-11").click(function() {
          // $("#modalbar5-dropdown-li-3").toggle();
          $("#modalbar5-dropdown-li-8").removeClass('active');
          $("#modalbar5-dropdown-li-9").removeClass('active');
          $("#modalbar5-dropdown-li-10").removeClass('active');
          $("#modalbar5-dropdown-li-12").removeClass('active');
          $("#modalbar5-dropdown-li-13").removeClass('active');
          $("#modalbar5-dropdown-li-14").removeClass('active');
          $("#modalbar5-dropdown-li-15").removeClass('active');
          $("#modalbar5-dropdown-li-16").removeClass('active');
          $("#modalbar5-list-9").hide();
          $("#modalbar5-list-13").hide();
          $("#modalbar5-list-14").hide();
          $("#modalbar5-list-15").hide();
          $("#modalbar5-list-16").hide();
          $("#modalbar5-list-8").hide();
          $("#modalbar5-list-11").toggle();
          if ($("#modalbar5-dropdown-li-11").hasClass('active')) {
              $("#modalbar5-dropdown-li-11").removeClass('active');
          } else {
              $("#modalbar5-dropdown-li-11").addClass('active');

          }
      });
      /////////////////////////////
      $("#modalbar5-dropdown-li-12").click(function() {
          $("#modalbar5-dropdown-li-8").removeClass('active');
          $("#modalbar5-dropdown-li-9").removeClass('active');
          // $("#modalbar5-dropdown-li-11").removeClass('active');
          $("#modalbar5-dropdown-li-10").removeClass('active');
          $("#modalbar5-dropdown-li-13").removeClass('active');
          $("#modalbar5-dropdown-li-14").removeClass('active');
          $("#modalbar5-dropdown-li-15").removeClass('active');
          $("#modalbar5-dropdown-li-16").removeClass('active');
          $("#modalbar5-list-12").toggle();
          if ($("#modalbar5-dropdown-li-12").hasClass('active')) {
              $("#modalbar5-dropdown-li-12").removeClass('active');
          } else {
              $("#modalbar5-dropdown-li-12").addClass('active');

          }
      });
      $("select.form-control").selectpicker();
  });

</script>
<!-- finishing modaldropdown5 -->
<!-- modal-dropdown -->
<!-- ***===================
  modal js

******===================== -->
<script type="text/javascript">
  $(window).scroll(function() {
      if ($(this).scrollTop() > 1) {
          $('header').addClass("sticky");
      } else {
          $('header').removeClass("sticky");
      }
  });

</script>
<script type="text/javascript">
  (function($) {
      $('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
          if (!$(this).next().hasClass('show')) {
              $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
          }
          var $subMenu = $(this).next(".dropdown-menu");
          $subMenu.toggleClass('show');

          $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
              $('.dropdown-submenu .show').removeClass("show");
          });

          return false;
      });
  })(jQuery)

</script>
<script>
  $(document).ready(function() {

      $("#plus-mode").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();

          $("#modal-mode").toggle();
      });
	  
	   $("#sidebar-dropdown-li-3").click(function() {
	   	$("#sidebar-list-7").toggle();
	   }
	  
      $("#sidebar-dropdown-li-2").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#sidebar-list-3").hide();
          $("#sidebar-list-5").hide();
          $("#sidebar-list-4").hide();
          $("#sidebar-list-2").toggle();
      });
      ////////////////////////
      $("#sidebar-dropdown-li-8").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#sidebar-dropdown-li-9").removeClass('active');
          $("#sidebar-dropdown-li-11").removeClass('active');
          $("#sidebar-dropdown-li-10").removeClass('active');
          $("#sidebar-dropdown-li-12").removeClass('active');
          $("#sidebar-dropdown-li-13").removeClass('active');
          $("#sidebar-dropdown-li-14").removeClass('active');
          $("#sidebar-dropdown-li-15").removeClass('active');
          $("#sidebar-dropdown-li-16").removeClass('active');
          $("#sidebar-list-9").hide();
          $("#sidebar-list-10").hide();
          $("#sidebar-list-11").hide();
          $("#sidebar-list-15").hide();
          $("#sidebar-list-16").hide();
          $("#sidebar-list-13").hide();
          $("#sidebar-list-12").hide();
          $("#sidebar-list-14").hide();
          $("#sidebar-dropdown-li-10").hide();
          $("#sidebar-list-8").toggle();
          if ($("#sidebar-dropdown-li-8").hasClass('active')) {
              $("#sidebar-dropdown-li-8").removeClass('active');
          } else {
              $("#sidebar-dropdown-li-8").addClass('active');


          }
      });
      ////////////////////////
      $("#sidebar-dropdown-li-13").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#sidebar-dropdown-li-9").removeClass('active');
          $("#sidebar-dropdown-li-11").removeClass('active');
          $("#sidebar-dropdown-li-10").removeClass('active');
          $("#sidebar-dropdown-li-12").removeClass('active');
          $("#sidebar-dropdown-li-14").removeClass('active');
          $("#sidebar-dropdown-li-8").removeClass('active');
          $("#sidebar-dropdown-li-15").removeClass('active');
          $("#sidebar-dropdown-li-16").removeClass('active');
          $("#sidebar-list-9").hide();
          $("#sidebar-list-11").hide();
          $("#sidebar-list-14").hide();
          $("#sidebar-list-15").hide();
          $("#sidebar-list-12").hide();
          $("#sidebar-list-16").hide();
          $("#sidebar-list-8").hide();
          $("#sidebar-list-10").hide();
          $("#sidebar-list-13").toggle();
          if ($("#sidebar-dropdown-li-13").hasClass('active')) {
              $("#sidebar-dropdown-li-13").removeClass('active');
          } else {
              $("#sidebar-dropdown-li-13").addClass('active');


          }
      });
      ////////////////////////
      $("#sidebar-dropdown-li-14").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#sidebar-dropdown-li-9").removeClass('active');
          $("#sidebar-dropdown-li-11").removeClass('active');
          $("#sidebar-dropdown-li-10").removeClass('active');
          $("#sidebar-dropdown-li-12").removeClass('active');
          $("#sidebar-dropdown-li-13").removeClass('active');
          $("#sidebar-dropdown-li-15").removeClass('active');
          $("#sidebar-dropdown-li-16").removeClass('active');
          $("#sidebar-dropdown-li-8").removeClass('active');
          $("#sidebar-list-9").hide();
          $("#sidebar-list-11").hide();
          $("#sidebar-list-13").hide();
          $("#sidebar-list-15").hide();
          $("#sidebar-list-12").hide();
          $("#sidebar-list-16").hide();
          $("#sidebar-list-8").hide();
          $("#sidebar-list-14").toggle();
          if ($("#sidebar-dropdown-li-14").hasClass('active')) {
              $("#sidebar-dropdown-li-14").removeClass('active');
          } else {
              $("#sidebar-dropdown-li-14").addClass('active');


          }
      });
      ////////////////////////
      $("#sidebar-dropdown-li-15").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#sidebar-dropdown-li-9").removeClass('active');
          $("#sidebar-dropdown-li-11").removeClass('active');
          $("#sidebar-dropdown-li-10").removeClass('active');
          $("#sidebar-dropdown-li-12").removeClass('active');
          $("#sidebar-dropdown-li-14").removeClass('active');
          $("#sidebar-dropdown-li-13").removeClass('active');
          $("#sidebar-dropdown-li-16").removeClass('active');
          $("#sidebar-dropdown-li-8").removeClass('active');
          $("#sidebar-list-9").hide();
          $("#sidebar-list-11").hide();
          $("#sidebar-list-8").hide();
          $("#sidebar-list-10").hide();
          $("#sidebar-list-12").hide();
          $("#sidebar-list-13").hide();
          $("#sidebar-list-14").hide();
          $("#sidebar-list-16").hide();
          $("#sidebar-list-15").toggle();
          if ($("#sidebar-dropdown-li-15").hasClass('active')) {
              $("#sidebar-dropdown-li-15").removeClass('active');
          } else {
              $("#sidebar-dropdown-li-15").addClass('active');


          }
      });
      ////////////////////////
      $("#sidebar-dropdown-li-16").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#sidebar-dropdown-li-9").removeClass('active');
          $("#sidebar-dropdown-li-11").removeClass('active');
          $("#sidebar-dropdown-li-10").removeClass('active');
          $("#sidebar-dropdown-li-8").removeClass('active');
          $("#sidebar-dropdown-li-12").removeClass('active');
          $("#sidebar-dropdown-li-13").removeClass('active');
          $("#sidebar-dropdown-li-14").removeClass('active');
          $("#sidebar-dropdown-li-15").removeClass('active');
          $("#sidebar-list-9").hide();
          $("#sidebar-list-11").hide();
          $("#sidebar-list-10").hide();
          $("#sidebar-list-8").hide();
          $("#sidebar-list-12").hide();
          $("#sidebar-list-13").hide();
          $("#sidebar-list-14").hide();
          $("#sidebar-list-15").hide();
          $("#sidebar-list-16").toggle();
          if ($("#sidebar-dropdown-li-16").hasClass('active')) {
              $("#sidebar-dropdown-li-16").removeClass('active');
          } else {
              $("#sidebar-dropdown-li-16").addClass('active');


          }
      });

  });

</script>
<script>
  $(document).ready(function() {
      $("#sidebar-dropdown-li-3").click(function() {
          // $("#sidebar-dropdown-li-2").toggle();
          $("#sidebar-list-2").hide();
          $("#sidebar-list-5").hide();
          $("#sidebar-list-3").toggle();
      });
      // ///////////////////////////////////////////////////////
      $(".fix_id").hover(function() {
          // $("#sidebar-dropdown-li-2").toggle();
          $("#sidebar-list-2").hide();
          $("#sidebar-list-3").hide();
          $("#sidebar-list-5").hide();
          $("#sidebar-list-4").hide();
          $("#sidebar-list-6").hide();
      });
      /////////////////////////////////////////////////////////////////
      $("#sidebar-dropdown-li-9").click(function() {
          // $("#sidebar-dropdown-li-2").toggle();
          $("#sidebar-dropdown-li-8").removeClass('active');
          $("#sidebar-dropdown-li-11").removeClass('active');
          $("#sidebar-dropdown-li-10").removeClass('active');
          $("#sidebar-dropdown-li-12").removeClass('active');
          $("#sidebar-dropdown-li-13").removeClass('active');
          $("#sidebar-dropdown-li-14").removeClass('active');
          $("#sidebar-dropdown-li-15").removeClass('active');
          $("#sidebar-dropdown-li-16").removeClass('active');
          $("#sidebar-list-8").hide();
          $("#sidebar-list-11").hide();
          $("#sidebar-list-13").hide();
          $("#sidebar-list-14").hide();
          $("#sidebar-list-15").hide();
          $("#sidebar-list-16").hide();
          $("#sidebar-list-9").toggle();
          if ($("#sidebar-dropdown-li-9").hasClass('active')) {
              $("#sidebar-dropdown-li-9").removeClass('active');
          } else {
              $("#sidebar-dropdown-li-9").addClass('active');

          }
      });
      // ///////////////////////////////////////////////////////
      $(".fix_id2").hover(function() {
          // $("#sidebar-dropdown-li-2").toggle();
          $("#sidebar-list-8").hide();
          $("#sidebar-list-9").hide();
          $("#sidebar-list-11").hide();
          $("#sidebar-list-10").hide();
          $("#sidebar-list-12").hide();
          $("#sidebar-list-13").hide();
          $("#sidebar-list-14").hide();
          $("#sidebar-list-15").hide();
          $("#sidebar-list-16").hide();
          $("#sidebar-dropdown-li-8").removeClass('active');
          $("#sidebar-dropdown-li-9").removeClass('active');
          $("#sidebar-dropdown-li-11").removeClass('active');
          $("#sidebar-dropdown-li-10").removeClass('active');
          $("#sidebar-dropdown-li-12").removeClass('active');
          $("#sidebar-dropdown-li-13").removeClass('active');
          $("#sidebar-dropdown-li-14").removeClass('active');
          $("#sidebar-dropdown-li-15").removeClass('active');
          $("#sidebar-dropdown-li-16").removeClass('active');
      });
  });

</script>
<script>
  $(document).ready(function() {
      $("#sidebar-dropdown-li-4").click(function() {
          $("#sidebar-list-4").toggle();
      });
      //////////////////////
      $("#sidebar-dropdown-li-5").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#sidebar-list-3").hide();
          $("#sidebar-list-2").hide();
          $("#sidebar-list-5").toggle();
      });
      /////////////////////////////
      $("#sidebar-dropdown-li-6").click(function() {
          $("#sidebar-list-6").toggle();
      });
      /////////////////////////////

      /////////////////////////////////////////
      $("#sidebar-dropdown-li-10").click(function() {
          // $("#sidebar-dropdown-li-8").removeClass('active');
          $("#sidebar-dropdown-li-9").removeClass('active');
          $("#sidebar-dropdown-li-11").removeClass('active');
          $("#sidebar-dropdown-li-12").removeClass('active');
          $("#sidebar-dropdown-li-13").removeClass('active');
          $("#sidebar-dropdown-li-14").removeClass('active');
          $("#sidebar-dropdown-li-15").removeClass('active');
          $("#sidebar-dropdown-li-16").removeClass('active');
          $("#sidebar-list-10").toggle();
          if ($("#sidebar-dropdown-li-10").hasClass('active')) {
              $("#sidebar-dropdown-li-10").removeClass('active');
          } else {
              $("#sidebar-dropdown-li-10").addClass('active');

          }
      });
      //////////////////////
      $("#sidebar-dropdown-li-11").click(function() {
          // $("#sidebar-dropdown-li-3").toggle();
          $("#sidebar-dropdown-li-8").removeClass('active');
          $("#sidebar-dropdown-li-9").removeClass('active');
          $("#sidebar-dropdown-li-10").removeClass('active');
          $("#sidebar-dropdown-li-12").removeClass('active');
          $("#sidebar-dropdown-li-13").removeClass('active');
          $("#sidebar-dropdown-li-14").removeClass('active');
          $("#sidebar-dropdown-li-15").removeClass('active');
          $("#sidebar-dropdown-li-16").removeClass('active');
          $("#sidebar-list-9").hide();
          $("#sidebar-list-13").hide();
          $("#sidebar-list-14").hide();
          $("#sidebar-list-15").hide();
          $("#sidebar-list-16").hide();
          $("#sidebar-list-8").hide();
          $("#sidebar-list-11").toggle();
          if ($("#sidebar-dropdown-li-11").hasClass('active')) {
              $("#sidebar-dropdown-li-11").removeClass('active');
          } else {
              $("#sidebar-dropdown-li-11").addClass('active');

          }
      });
      /////////////////////////////
      $("#sidebar-dropdown-li-12").click(function() {
          $("#sidebar-dropdown-li-8").removeClass('active');
          $("#sidebar-dropdown-li-9").removeClass('active');
          // $("#sidebar-dropdown-li-11").removeClass('active');
          $("#sidebar-dropdown-li-10").removeClass('active');
          $("#sidebar-dropdown-li-13").removeClass('active');
          $("#sidebar-dropdown-li-14").removeClass('active');
          $("#sidebar-dropdown-li-15").removeClass('active');
          $("#sidebar-dropdown-li-16").removeClass('active');
          $("#sidebar-list-12").toggle();
          if ($("#sidebar-dropdown-li-12").hasClass('active')) {
              $("#sidebar-dropdown-li-12").removeClass('active');
          } else {
              $("#sidebar-dropdown-li-12").addClass('active');

          }
      });
  });

</script>

<script type="text/javascript">
    /*Dropdown Menu*/
    $('.dropdown-spl').click(function() {
        $(this).attr('tabindex', 1).focus();
        $(this).toggleClass('active');
        $(this).find('.dropdown-menu-spl').slideToggle(300);
    });
    $('.dropdown-spl').focusout(function() {
        $(this).removeClass('active');
        $(this).find('.dropdown-menu-spl').slideUp(300);
    });
    $('.dropdown-spl .dropdown-menu-spl li').click(function() {
        $(this).parents('.dropdown-spl').find('span').text($(this).text());
        $(this).parents('.dropdown-spl').find('input').attr('value', $(this).attr('id'));
    });
    /*End Dropdown Menu*/


    $('.dropdown-menu-spl li').click(function() {
        var input = '<strong>' + $(this).parents('.dropdown-spl').find('input').val() + '</strong>',
            msg = '<span class="msg">Hidden input value: ';
        $('.msg').html(msg + input + '</span>');
    });

</script>

<!-- new -->
</body>
</html>
