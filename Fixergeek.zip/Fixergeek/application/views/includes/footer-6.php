 <!-- Optional JavaScript -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>

    <!--    ask-modal-dropdown-js-->
    <script src="js/modal-dropdown.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/intlTelInput.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/intlTelInput.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/utils.js"></script>



    <script src="https://cdn.datatables.net/v/bs4/dt-1.10.20/datatables.min.js" type="text/javascript"></script>
    <script src="js/jquery.responsive-tables.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(function() {
            $('table').DataTable({
                pageLength: 10,
                lengthChange: false
            });
        });

    </script>


    <script type="text/javascript">
        $(window).scroll(function() {
            if ($(this).scrollTop() > 1) {
                $('header').addClass("sticky");
            } else {
                $('header').removeClass("sticky");
            }
        });

    </script>


    <script type="text/javascript">
        (function($) {
            $('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
                if (!$(this).next().hasClass('show')) {
                    $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
                }
                var $subMenu = $(this).next(".dropdown-menu");
                $subMenu.toggleClass('show');

                $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
                    $('.dropdown-submenu .show').removeClass("show");
                });

                return false;
            });
        })(jQuery)

    </script>



    <script>
        $(document).ready(function() {

            $("#plus-mode").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();

                $("#modal-mode").toggle();
            });
            $("#sidebar-dropdown-li-2").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-list-3").hide();
                $("#sidebar-list-5").hide();
                $("#sidebar-list-4").hide();
                $("#sidebar-list-2").toggle();
            });
            ////////////////////////
            $("#sidebar-dropdown-li-8").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-dropdown-li-10").hide();
                $("#sidebar-list-8").toggle();
                if ($("#sidebar-dropdown-li-8").hasClass('active')) {
                    $("#sidebar-dropdown-li-8").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-8").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-13").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-13").toggle();
                if ($("#sidebar-dropdown-li-13").hasClass('active')) {
                    $("#sidebar-dropdown-li-13").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-13").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-14").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-14").toggle();
                if ($("#sidebar-dropdown-li-14").hasClass('active')) {
                    $("#sidebar-dropdown-li-14").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-14").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-15").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-15").toggle();
                if ($("#sidebar-dropdown-li-15").hasClass('active')) {
                    $("#sidebar-dropdown-li-15").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-15").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-16").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").toggle();
                if ($("#sidebar-dropdown-li-16").hasClass('active')) {
                    $("#sidebar-dropdown-li-16").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-16").addClass('active');


                }
            });

        });

    </script>
    <script>
        $(document).ready(function() {
            $("#sidebar-dropdown-li-3").click(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-list-2").hide();
                $("#sidebar-list-5").hide();
                $("#sidebar-list-3").toggle();
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id").hover(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-list-2").hide();
                $("#sidebar-list-3").hide();
                $("#sidebar-list-5").hide();
                $("#sidebar-list-4").hide();
                $("#sidebar-list-6").hide();
            });
            /////////////////////////////////////////////////////////////////
            $("#sidebar-dropdown-li-9").click(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-8").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-9").toggle();
                if ($("#sidebar-dropdown-li-9").hasClass('active')) {
                    $("#sidebar-dropdown-li-9").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-9").addClass('active');

                }
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id2").hover(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
            });
        });

    </script>
    <script>
        $(document).ready(function() {
            $("#sidebar-dropdown-li-4").click(function() {
                $("#sidebar-list-4").toggle();
            });
            //////////////////////
            $("#sidebar-dropdown-li-5").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-list-3").hide();
                $("#sidebar-list-2").hide();
                $("#sidebar-list-5").toggle();
            });
            /////////////////////////////
            $("#sidebar-dropdown-li-6").click(function() {
                $("#sidebar-list-6").toggle();
            });
            /////////////////////////////

            /////////////////////////////////////////
            $("#sidebar-dropdown-li-10").click(function() {
                // $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-10").toggle();
                if ($("#sidebar-dropdown-li-10").hasClass('active')) {
                    $("#sidebar-dropdown-li-10").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-10").addClass('active');

                }
            });
            //////////////////////
            $("#sidebar-dropdown-li-11").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-11").toggle();
                if ($("#sidebar-dropdown-li-11").hasClass('active')) {
                    $("#sidebar-dropdown-li-11").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-11").addClass('active');

                }
            });
            /////////////////////////////
            $("#sidebar-dropdown-li-12").click(function() {
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                // $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-12").toggle();
                if ($("#sidebar-dropdown-li-12").hasClass('active')) {
                    $("#sidebar-dropdown-li-12").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-12").addClass('active');

                }
            });
        });

    </script>


    <!-- new -->




    <!-- table-shit-dropdown -->
    <script type="text/javascript">
        $(document).ready(function() {

            $("#plus-mode2").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();

                $("#table-mode2").toggle();
            });


            $("#table-dropdown-li-9").click(function() {
                // $("#table-dropdown-li-2").toggle();
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-8").hide();
                $("#table-list-11").hide();
                $("#table-list-13").hide();
                $("#table-list-14").hide();
                $("#table-list-15").hide();
                $("#table-list-16").hide();
                $("#table-list-9").toggle();
                if ($("#table-dropdown-li-9").hasClass('active')) {
                    $("#table-dropdown-li-9").removeClass('active');
                } else {
                    $("#table-dropdown-li-9").addClass('active');

                }
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id3").hover(function() {
                // $("#table-dropdown-li-2").toggle();
                $("#table-list-8").hide();
                $("#table-list-9").hide();
                $("#table-list-11").hide();
                $("#table-list-10").hide();
                $("#table-list-12").hide();
                $("#table-list-13").hide();
                $("#table-list-14").hide();
                $("#table-list-15").hide();
                $("#table-list-16").hide();
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
            });
        });

    </script>

    <!-- another one -->
    <script>
        $(document).ready(function() {
            $("#table-dropdown-li-10").click(function() {
                // $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-10").toggle();
                if ($("#table-dropdown-li-10").hasClass('active')) {
                    $("#table-dropdown-li-10").removeClass('active');
                } else {
                    $("#table-dropdown-li-10").addClass('active');

                }
            });
            //////////////////////
            $("#table-dropdown-li-11").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-13").hide();
                $("#table-list-14").hide();
                $("#table-list-15").hide();
                $("#table-list-16").hide();
                $("#table-list-8").hide();
                $("#table-list-11").toggle();
                if ($("#table-dropdown-li-11").hasClass('active')) {
                    $("#table-dropdown-li-11").removeClass('active');
                } else {
                    $("#table-dropdown-li-11").addClass('active');

                }
            });
            /////////////////////////////
            $("#table-dropdown-li-12").click(function() {
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-9").removeClass('active');
                // $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-12").toggle();
                if ($("#table-dropdown-li-12").hasClass('active')) {
                    $("#table-dropdown-li-12").removeClass('active');
                } else {
                    $("#table-dropdown-li-12").addClass('active');

                }
            });
        });

    </script>

    <!-- another one -->

    <script>
        $(document).ready(function() {
            $("#table-dropdown-li-8").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-10").hide();
                $("#table-list-11").hide();
                $("#table-list-15").hide();
                $("#table-list-16").hide();
                $("#table-list-13").hide();
                $("#table-list-12").hide();
                $("#table-list-14").hide();
                $("#table-dropdown-li-10").hide();
                $("#table-list-8").toggle();
                if ($("#table-dropdown-li-8").hasClass('active')) {
                    $("#table-dropdown-li-8").removeClass('active');
                } else {
                    $("#table-dropdown-li-8").addClass('active');


                }
            });
            ////////////////////////
            $("#table-dropdown-li-13").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-11").hide();
                $("#table-list-14").hide();
                $("#table-list-15").hide();
                $("#table-list-12").hide();
                $("#table-list-16").hide();
                $("#table-list-8").hide();
                $("#table-list-10").hide();
                $("#table-list-13").toggle();
                if ($("#table-dropdown-li-13").hasClass('active')) {
                    $("#table-dropdown-li-13").removeClass('active');
                } else {
                    $("#table-dropdown-li-13").addClass('active');


                }
            });
            ////////////////////////
            $("#table-dropdown-li-14").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-11").hide();
                $("#table-list-13").hide();
                $("#table-list-15").hide();
                $("#table-list-12").hide();
                $("#table-list-16").hide();
                $("#table-list-8").hide();
                $("#table-list-14").toggle();
                if ($("#table-dropdown-li-14").hasClass('active')) {
                    $("#table-dropdown-li-14").removeClass('active');
                } else {
                    $("#table-dropdown-li-14").addClass('active');


                }
            });
            ////////////////////////
            $("#table-dropdown-li-15").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-11").hide();
                $("#table-list-8").hide();
                $("#table-list-10").hide();
                $("#table-list-12").hide();
                $("#table-list-13").hide();
                $("#table-list-14").hide();
                $("#table-list-16").hide();
                $("#table-list-15").toggle();
                if ($("#table-dropdown-li-15").hasClass('active')) {
                    $("#table-dropdown-li-15").removeClass('active');
                } else {
                    $("#table-dropdown-li-15").addClass('active');


                }
            });
            ////////////////////////
            $("#table-dropdown-li-16").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-11").hide();
                $("#table-list-10").hide();
                $("#table-list-8").hide();
                $("#table-list-12").hide();
                $("#table-list-13").hide();
                $("#table-list-14").hide();
                $("#table-list-15").hide();
                $("#table-list-16").toggle();
                if ($("#table-dropdown-li-16").hasClass('active')) {
                    $("#table-dropdown-li-16").removeClass('active');
                } else {
                    $("#table-dropdown-li-16").addClass('active');


                }
            });
            $("select.form-control").selectpicker();
        });

    </script>

    <!-- table-shit-dropdown -->


    <!-- new -->

    <script>
        $(".profile-special1").hover(function() {
            // $("#sidebar-dropdown-li-2").toggle();
            $(".profile-hover-details1").show();
            $(".profile-hover-details2").hide();
            $(".profile-hover-details3").hide();
        });

        $(".profile-special2").hover(function() {
            // $("#sidebar-dropdown-li-2").toggle();
            $(".profile-hover-details2").show();
            $(".profile-hover-details1").hide();
            $(".profile-hover-details3").hide();
        });

        $(".profile-special3").hover(function() {
            // $("#sidebar-dropdown-li-2").toggle();
            $(".profile-hover-details3").show();
            $(".profile-hover-details1").hide();
            $(".profile-hover-details2").hide();
        });
        $(".profile-spl-anchor").hover(function() {
            // $("#sidebar-dropdown-li-2").toggle();
            $(".profile-hover-details").hide();

        });

    </script>





    <script>
        $(document).ready(function() {
            $("#toggle-more1").click(function() {
                var elem = $("#toggle-more1").text();
                if (elem == "More...") {
                    //Stuff to do when btn is in the read more state
                    $("#toggle-more1").text("Less...");
                    $("#more-list1").show();
                } else {
                    //Stuff to do when btn is in the read less state
                    $("#toggle-more1").text("More...");
                    $("#more-list1").hide();
                }
            });
        });

    </script>

    <script>
        $(document).ready(function() {
            $("#toggle-more2").click(function() {
                var elem = $("#toggle-more2").text();
                if (elem == "More...") {
                    //Stuff to do when btn is in the read more state
                    $("#toggle-more2").text("Less...");
                    $("#more-list2").show();
                } else {
                    //Stuff to do when btn is in the read less state
                    $("#toggle-more2").text("More...");
                    $("#more-list2").hide();
                }
            });
        });

    </script>

    <script>
        var telInput = $("#phone"),
            errorMsg = $("#error-msg"),
            validMsg = $("#valid-msg");

        // initialise plugin
        telInput.intlTelInput({

            allowExtensions: true,
            formatOnDisplay: true,
            autoFormat: true,
            autoHideDialCode: true,
            autoPlaceholder: true,
            defaultCountry: "auto",
            ipinfoToken: "yolo",

            nationalMode: false,
            numberType: "MOBILE",
            //onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
            preferredCountries: ['sa', 'ae', 'qa', 'om', 'bh', 'kw', 'ma'],
            preventInvalidNumbers: true,
            separateDialCode: true,
            initialCountry: "auto",
            geoIpLookup: function(callback) {
                $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
                    var countryCode = (resp && resp.country) ? resp.country : "";
                    callback(countryCode);
                });
            },
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/utils.js"
        });

        var reset = function() {
            telInput.removeClass("error");
            errorMsg.addClass("hide");
            validMsg.addClass("hide");
        };

        // on blur: validate
        telInput.blur(function() {
            reset();
            if ($.trim(telInput.val())) {
                if (telInput.intlTelInput("isValidNumber")) {
                    validMsg.removeClass("hide");
                } else {
                    telInput.addClass("error");
                    errorMsg.removeClass("hide");
                }
            }
        });

        // on keyup / change flag: reset
        telInput.on("keyup change", reset);

    </script>
<script>
    $(document).ready(function() {
        $.responsiveTables('991px');   
    });

</script>

</body>

</html>
