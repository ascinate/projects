    <!-- Modal -->
    <div class="modal fade exampleModalask" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header ask-modal modal-header-1">
                    <img src="<?php echo base_url();?>assets/images/logo-head.png" alt="">
                    <h5 class="modal-title" id="exampleModalLabel">Ask Question</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body modal-body1">
                    <div class="modal-blue-bg" id="clients-modal1">
                        <div class="row mb-2">
                            <div class="col-12">
                                <h5>Welcome!</h5>
                            </div>
                        </div>
                        <form class="checkbox_listing">
                            <div class="form-group">
                                <div class="row mb-3">
                                    <div class="col-md-12 mb-2">
                                        <label for="exampleFormControlTextarea1">Type below what troubleshooting problem you need fixed.</label>
                                    </div>
                                    <div class="col-md-12">
                                        <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Type your Question here..." rows="3"></textarea>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-4 pr-0 d-flex modal-spl-1">
                                        <label class="modal-link-label" for="exampleFormControlTextarea100">Choose Category</label>
                                    </div>
                                    <div class="col-md-8 pl-0">
                                        <ul>
                                            <li class="dropdown dropdown1-1 fixes nav-item">
                                                <a class="dropdown-toggle nav-link modal-link border-right-1 fix_id2 position-relative" href="#" id="plus-mode">Select Category</a>
                                                <ul class="dropdown-menu dropdown-menu2 dropdown_menu20" aria-labelledby="navbarDropdown" id="modal-mode">
                                                    <li><a id="sidebar-dropdown-li-11" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                            <div class="plus-minus"></div> Repairs & security
                                                        </a></li>
                                                    <div id="sidebar-list-11" class="fixes-drop">
                                                        <ul>
                                                            <li><a id="sidebar-dropdown-li-12" class="dropdown-li plus-mode-1 dropdown-toggle d-flex" href="#">
                                                                    <div class="plus-minus"></div>Operating System Issues
                                                                </a></li>
                                                            <div id="sidebar-list-12" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                                                                <ul>
                                                                    <li>
                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-1">
                                                                            <label for="modal-1">VIRUS </label>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-2">
                                                                            <label for="modal-2">spyware </label>
                                                                        </div>
                                                                    </li>
                                                                    <li>

                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-3">
                                                                            <label for="modal-3">ransomware </label>
                                                                        </div>
                                                                    </li>
                                                                    <li>

                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-4">
                                                                            <label for="modal-4">Phishing </label>
                                                                        </div>
                                                                    </li>
                                                                    <li>

                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-5">
                                                                            <label for="modal-5">Spam </label>
                                                                        </div>

                                                                    </li>
                                                                    <li>

                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-6">
                                                                            <label for="modal-6">Key logging </label>
                                                                        </div>
                                                                    </li>
                                                                    <li>

                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-7">
                                                                            <label for="modal-7">Firewall </label>
                                                                        </div>

                                                                    </li>
                                                                    <li>
                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-8">
                                                                            <label for="modal-8">identity Theft </label>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-9">
                                                                    <label for="modal-9">Device management & drivers </label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-10">
                                                                    <label for="modal-10">Disk Management</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-11">
                                                                    <label for="modal-11">Computer Management</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-12">
                                                                    <label for="modal-12">Command Line</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-13">
                                                                    <label for="modal-13">User controls & rights</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-14">
                                                                    <label for="modal-14">Network Issue</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-15">
                                                                    <label for="modal-15">Connection Issue Line</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-16">
                                                                    <label for="modal-16">File Explorer</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-17">
                                                                    <label for="modal-17">Start Menu & Taskbar</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-18">
                                                                    <label for="modal-18">Fu Users & Accounts</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-19">
                                                                    <label for="modal-19">Printing</label>
                                                                </div>

                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-20">
                                                                    <label for="modal-20">Output</label>
                                                                </div>

                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-21">
                                                                    <label for="modal-21">INput</label>
                                                                </div>

                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-22">
                                                                    <label for="modal-22">Miscellaneous</label>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <li>
                                                        <a id="sidebar-dropdown-li-13" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                            <div class="plus-minus"></div>Optimization & Customization
                                                        </a>
                                                    </li>
                                                    <div id="sidebar-list-13" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                                                        <ul>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-23">
                                                                    <label for="modal-23">Steam</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-24">
                                                                    <label for="modal-24">Emulators</label>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <li>
                                                        <a id="sidebar-dropdown-li-14" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                            <div class="plus-minus"></div>Apps & Features
                                                        </a>
                                                    </li>
                                                    <div id="sidebar-list-14" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                                                        <ul>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-25">
                                                                    <label for="modal-25">retroArch</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-26">
                                                                    <label for="modal-26">Xbox</label>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <li><a id="sidebar-dropdown-li-9" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                            <div class="plus-minus"></div>Essential Apps
                                                        </a></li>
                                                    <div id="sidebar-list-9" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                                                        <ul>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-27">
                                                                    <label for="modal-27">Steam</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-47">
                                                                    <label for="modal-47">Emulators</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-28">
                                                                    <label for="modal-28">Miscellaneous</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-29">
                                                                    <label for="modal-29">Dolphin</label>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <li><a id="sidebar-dropdown-li-8" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                            <div class="plus-minus"></div>Special Apps
                                                        </a></li>
                                                    <div id="sidebar-list-8" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                                                        <ul>

                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-30">
                                                                    <label for="modal-30">pRODUCTIVITY TOOLS</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-31">
                                                                    <label for="modal-31">password Management</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-32">
                                                                    <label for="modal-32">photos</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-33">
                                                                    <label for="modal-33">audio & music</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-34">
                                                                    <label for="modal-34">cd/dvd/blue ray</label>
                                                                </div>
                                                            </li>
                                                            <li><a id="sidebar-dropdown-li-10" class="dropdown-li dropdown-toggle plus-mode-1 d-flex " href="#">
                                                                    <div class="plus-minus"></div>Gaming
                                                                </a></li>
                                                            <div id="sidebar-list-10" class="checkbox_listing-1 checkbox_listing-2">
                                                                <ul>
                                                                    <li>
                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-35">
                                                                            <label for="modal-35">Game stores</label>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-36">
                                                                            <label for="modal-36">xbox</label>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-37">
                                                                            <label for="modal-37">Steam</label>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-38">
                                                                            <label for="modal-38">Emulators</label>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                            <input type="checkbox" id="modal-39">
                                                                            <label for="modal-39">Retroarch</label>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-40">
                                                                    <label for="modal-40">Virtualization</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-40">
                                                                    <label for="modal-40">Miscellaneous</label>
                                                                </div>

                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <li>
                                                        <a id="sidebar-dropdown-li-15" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                            <div class="plus-minus"></div>Files Data & Content
                                                        </a>
                                                    </li>
                                                    <div id="sidebar-list-15" class="checkbox_listing-1 checkbox_listing-2">
                                                        <ul>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-41">
                                                                    <label for="modal-41">User Controls & Rights</label>
                                                                </div>

                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-41">
                                                                    <label for="modal-41">NEtwork Issue</label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                    <input type="checkbox" id="modal-42">
                                                                    <label for="modal-42">Connection iSSUE</label>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <li>
                                                        <a id="sidebar-dropdown-li-16" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                                                            <div class="plus-minus"></div>Office Management & Security
                                                        </a>
                                                    </li>
                                                    <div id="sidebar-list-16" class="checkbox_listing-1 checkbox_listing-2">
                                                        <li>
                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                <input type="checkbox" id="modal-43">
                                                                <label for="modal-43">fIREWALL</label>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                                                <input type="checkbox" id="modal-44">
                                                                <label for="modal-44">identity theft</label>
                                                            </div>
                                                        </li>
                                                    </div>
                                                </ul>
                                            </li>
                                        </ul>
                                    </div>

                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-12 label-problem-div text-right">
                                    <label class="label-problem" for="exampleFormControlSelect1">Get it fixed</label>
                                    <select class="form-control form-control-modal position-relative" id="exampleFormControlSelect5">
                                        <option>By All Users</option>
                                        <option>By A Particular User</option>
                                    </select>
                                    <div class="select-drop-icon">

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group-1">
                                        <input type="checkbox" id="modal-check-1" checked>
                                        <label for="modal-check-1">Post it at our Website</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group-1">
                                        <input type="checkbox" id="modal-check-2" checked>
                                        <label for="modal-check-2">Find Users who can <span>Fix it right now</span></label>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-1" class="btn btn-primary default-btn ">Ask</button>
                        </div>
                    </div>
                    <!--======================== 
                             client-modal-2
                     =========================-->
                    <div id="clients-modal2" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-2">
                            <div class="col-12">
                                <h5>Please Choose One</h5>
                            </div>
                        </div>
                        <form class="checkbox_listing">
                            <div class="form-group">
                                <div class="row mb-2">
                                    <div class="col-5 my-auto pr-0">
                                        <div class="form-check">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios1010" value="option1" checked>
                                            <label class="form-check-label radio-modal-label-1" for="exampleRadios1010">
                                                Get a Problem Fixed
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-7 label-problem-div text-right">
                                        <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect5">
                                            <option>By A Particular User</option>
                                            <option>By All Users</option>
                                        </select>
                                        <div class="select-drop-icon">

                                        </div>
                                    </div>
                                </div>


                                <div class="row mb-3">
                                    <div class="col-4 my-auto pr-0">
                                        <div class="form-check">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios2101" value="option1">
                                            <label class="form-check-label radio-modal-label-1" for="exampleRadios2101">
                                                Fix Problem
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-8 label-problem-div text-right pl-6">
                                        <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect6">
                                            <option>Of Other users</option>
                                            <option>Of Particular users</option>
                                        </select>
                                        <div class="select-drop-icon">

                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-5">
                                    <div class="col-md-12">
                                        <div class="form-group-1">
                                            <input type="checkbox" id="mclient-check-5" checked>
                                            <label for="client-check-5">Using Remote Access Assistance</label>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group-1">
                                            <input type="checkbox" id="client-check-6">
                                            <label for="client-check-6">Using Screen Sharing & Voice Chat</label>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group-1">
                                            <input type="checkbox" id="client-check-7">
                                            <label for="client-check-7">Using Text Chat Support</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-12">
                                        <div class="modal-3-check">
                                            <div class="form-group form-group-1  my-2 mx-2">
                                                <input type="checkbox" id="modal-3-check-2">
                                                <label for="modal-3-check-2">I agree to the remote Support <a href="#">terms & condition</a></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-2" class="btn btn-primary default-btn">Next</button>
                        </div>
                    </div>

                    <!--======================== 
                             client-modal-3
                     =========================-->
                    <div id="clients-modal3" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-2">
                            <div class="col-12">
                                <h5>Please Choose One</h5>
                            </div>
                        </div>
                        <form class="checkbox_listing">
                            <div class="form-group">
                                <div class="row mb-2">
                                    <div class="col-5 my-auto pr-0">
                                        <div class="form-check">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios1010" value="option1" checked>
                                            <label class="form-check-label radio-modal-label-1" for="exampleRadios1010">
                                                Get a Problem Fixed
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-7 label-problem-div text-right">
                                        <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect7">
                                            <option>By A Particular User</option>
                                            <option>By All Users</option>
                                        </select>
                                        <div class="select-drop-icon">

                                        </div>
                                    </div>
                                </div>


                                <div class="row mb-3">
                                    <div class="col-4 my-auto pr-0">
                                        <div class="form-check">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios2101" value="option1">
                                            <label class="form-check-label radio-modal-label-1" for="exampleRadios2101">
                                                Fix Problem
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-8 label-problem-div text-right pl-6">
                                        <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect8">
                                            <option>Of a Particular users</option>
                                            <option>Of Other users</option>

                                        </select>
                                        <div class="select-drop-icon">

                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-12">
                                        <p class="mb-2"><b>Enter User Name</b></p>
                                    </div>
                                    <div class="col-3 modal2User_grp text-right my-auto pr-0">
                                        <p>User's Name</p>
                                    </div>
                                    <div class="col-9">
                                        <div class="form-group mb-0">
                                            <input type="email" class="form-control modal2from_grp" id="exampleFormControlInput1" placeholder="type here....">
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5 justify-content-center mb-3">
                                    <div class="col-11 modal-3-prblm">
                                        <h6 class="mb-2"><b>Get the problem fixed:</b></h6>
                                        <div class="form-check mb-1">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios100" value="option1" checked>
                                            <label class="form-check-label radio-modal-label-2" for="exampleRadios100">
                                                Using Remote Access Assistance
                                            </label>
                                        </div>
                                        <div class="form-check mb-1">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios700" value="option1">
                                            <label class="form-check-label radio-modal-label-2" for="exampleRadios700">
                                                Using Screen Sharing & Voice Chat
                                            </label>
                                        </div>
                                        <div class="form-check mb-1">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios800" value="option">
                                            <label class="form-check-label radio-modal-label-2" for="exampleRadios800">
                                                Using Text Chat Support
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ">
                                    <div class="col-12">
                                        <div class="modal-3-check">
                                            <div class="form-group form-group-1  my-2 mx-2">
                                                <input type="checkbox" id="modal-3-check-2">
                                                <label for="modal-3-check-2">I agree to the remote Support <a href="#">terms & condition</a></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-3" class="btn btn-primary default-btn">Next</button>
                        </div>
                    </div>

                    <!--======================== 
                             client-modal-4
                     =========================-->
                    <div id="clients-modal4" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-2">
                            <div class="col-12">
                                <h5>Fix Markshelby25's problem for a custom price</h5>
                            </div>
                        </div>
                        <form class="checkbox_listing">
                            <div class="form-group">
                                <div class="row justify-content-center mb-3">
                                    <div class="col-11">
                                        <p class="mb-2">Choose a price between $10 to $9,999.Enter only digits</p>
                                    </div>
                                    <div class="col-6 my-auto px-0">
                                        <label class="form-check-label radio-modal-label-1" for="exampleRadios1">
                                            Enter a custom price in USD
                                        </label>
                                    </div>
                                    <div class="col-3 my-auto label-problem-div px-0 text-right">
                                        <input type="text" class="form-control modal2from_grp" id="exampleFormControlInput1" placeholder="">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-12 mb-1">
                                        <label for="exampleFormControlTextarea1"><b>Write a Messege to Markshelby25</b></label>
                                    </div>
                                    <div class="col-md-12">
                                        <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Type your Question here..." rows="3"></textarea>
                                    </div>
                                </div>
                                <div class="row mb-5 justify-content-center mb-3">
                                    <div class="col-11 modal-3-prblm">
                                        <h6 class="mb-2"><b>Get the problem fixed:</b></h6>
                                        <div class="form-check mb-1">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios100" value="option1" checked>
                                            <label class="form-check-label radio-modal-label-2" for="exampleRadios100">
                                                Using Remote Access Assistance
                                            </label>
                                        </div>
                                        <div class="form-check mb-1">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios700" value="option1">
                                            <label class="form-check-label radio-modal-label-2" for="exampleRadios700">
                                                Using Screen Sharing & Voice Chat
                                            </label>
                                        </div>
                                        <div class="form-check mb-1">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios800" value="option">
                                            <label class="form-check-label radio-modal-label-2" for="exampleRadios800">
                                                Using Text Chat Support
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ">
                                    <div class="col-12">
                                        <div class="modal-3-check">
                                            <div class="form-group form-group-1  my-2 mx-2">
                                                <input type="checkbox" id="modal-3-check-2">
                                                <label for="modal-3-check-2">I agree to the remote Support <a href="#">terms & condition</a></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-4" class="btn btn-primary default-btn">Next</button>
                        </div>
                    </div>

                    <!--======================== 
                             client-modal-5
                     =========================-->

                    <div id="clients-modal5" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-3">
                            <div class="col-12 client1">
                                <h5>joeMartyjoe,Keep this app running !</h5>
                                <p class="mt-2">keep this application running or minimized eith online status to get request from users who need you users who need your help to fix their problems</p>
                            </div>
                        </div>
                        <form class="checkbox_listing">
                            <div class="form-group">
                                <div class="row mb-3">
                                    <div class="col-12">
                                        <p>Choose your status below:</p>
                                    </div>
                                    <div class="col-5 label-problem-div">
                                        <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect9">
                                            <option> <i class="fa fa-circle"></i> Online</option>
                                            <option> <i class="fa fa-circle"></i> Away</option>
                                            <option> <i class="fa fa-circle"></i> Offline</option>
                                        </select>
                                        <div class="select-drop-icon">

                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-2 justify-content-center mb-3">
                                    <div class="col-11 modal-3-prblm">
                                        <h6 class="mb-2"><b>Get the problem fixed:</b></h6>
                                        <div class="form-check mb-1">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios100" value="option1" checked>
                                            <label class="form-check-label radio-modal-label-2" for="exampleRadios100">
                                                Using Remote Access Assistance
                                            </label>
                                        </div>
                                        <div class="form-check mb-1">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios700" value="option1">
                                            <label class="form-check-label radio-modal-label-2" for="exampleRadios700">
                                                Using Screen Sharing & Voice Chat
                                            </label>
                                        </div>
                                        <div class="form-check mb-1">
                                            <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios800" value="option">
                                            <label class="form-check-label radio-modal-label-2" for="exampleRadios800">
                                                Using Text Chat Support
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row ">
                                    <div class="col-12">
                                        <p>Following users are currently looking for help in categories you are expert in.You can send offers to them or wait to get others.</p>
                                        <div class="table-modal-1-details table-modal-1-details1 mt-2">
                                            <table class="table-modal-part-2 table-client-part-3  checkbox_listing-1 checkbox_listing-2">
                                                <thead>
                                                    <tr>
                                                        <th scope="col" style="width: 20%;">User Name</th>
                                                        <th scope="col" style="width: 20%;">Categories</th>
                                                        <th scope="col">Problem</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                                                                <input type="checkbox" id="table-modal-45">
                                                                <label for="table-modal-45">JoeMartyjoe</label>
                                                            </div>
                                                        </td>
                                                        <td class="table-category">personalization</td>
                                                        <td>How do i install live wallpaper in windows 10?</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                                                                <input type="checkbox" id="table-modal-47">
                                                                <label for="table-modal-47">Shawn667</label>
                                                            </div>
                                                        </td>
                                                        <td class="table-category">Gaming</td>
                                                        <td>4.8</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                                                                <input type="checkbox" id="table-modal-46">
                                                                <label for="table-modal-46">Susan_2020</label>
                                                            </div>
                                                        </td>
                                                        <td class="table-category">Miscellaneous</td>
                                                        <td>4.1</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                                                                <input type="checkbox" id="table-modal-1">
                                                                <label for="table-modal-1">Simon525</label>
                                                            </div>
                                                        </td>
                                                        <td class="table-category">Memory</td>
                                                        <td>4.8</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                                                                <input type="checkbox" id="table-modal-2">
                                                                <label for="table-modal-2">Richard252</label>
                                                            </div>
                                                        </td>
                                                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                                                        <td>4.8</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-5" class="btn btn-primary default-btn">Next</button>
                        </div>
                    </div>

                    <!--======================== 
                             client-modal-6
                     =========================-->
                    <div id="clients-modal6" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-3">
                            <div class="col-12 client1">
                                <h5>joeMartyjoe,Keep this app running !</h5>
                                <p class="mt-2">keep this application running or minimized eith online status to get request from users who need you users who need your help to fix their problems</p>
                            </div>
                        </div>
                        <form class="checkbox_listing">
                            <div class="form-group">
                                <div class="row mb-3">
                                    <div class="col-12">
                                        <p class="mb-1">Choose your status below:</p>
                                    </div>
                                    <div class="col-5 label-problem-div">
                                        <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect10">
                                            <option> <i class="fa fa-circle"></i> Away</option>
                                            <option> <i class="fa fa-circle"></i> Online</option>
                                            <option> <i class="fa fa-circle"></i> Offline</option>
                                        </select>
                                        <div class="select-drop-icon">

                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-5 justify-content-center mb-3">
                                    <div class="col-md-12 mb-1">
                                        <label for="exampleFormControlTextarea1">Away Messege:</label>
                                    </div>
                                    <div class="col-md-12">
                                        <textarea class="form-control text-left exampleFormControlTextarea2" id="exampleFormControlTextarea" placeholder="" rows="3">I am busy! You can reach me from 5:00pm to 9:00pm EST.If it's something urgent,leave me messege.</textarea>
                                    </div>
                                </div>
                                
                            </div>

                        </form>
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-6" class="btn btn-primary default-btn">Next</button>
                        </div>
                    </div>
                    
                    <!--======================== 
                             client-modal-7
                     =========================-->
                    
                    <div id="clients-modal7" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-3">
                            <div class="col-12 client1">
                                <h5>joeMartyjoe,Keep this app running !</h5>
                                <p class="mt-2">keep this application running or minimized eith online status to get request from users who need you users who need your help to fix their problems</p>
                            </div>
                        </div>
                        <form class="checkbox_listing">
                            <div class="form-group">
                                <div class="row mb-3">
                                    <div class="col-12">
                                        <p class="mb-1">Choose your status below:</p>
                                    </div>
                                    <div class="col-5 label-problem-div">
                                        <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect11">
                                            <option> <i class="fa fa-circle"></i> Offline</option>
                                            <option> <i class="fa fa-circle"></i> Away</option>
                                            <option> <i class="fa fa-circle"></i> Online</option>
                                            
                                        </select>
                                        <div class="select-drop-icon">

                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-5 justify-content-center mb-3">
                                    <div class="col-md-12 mb-1">
                                        <label for="exampleFormControlTextarea1">Offline Messege:</label>
                                    </div>
                                    <div class="col-md-12">
                                        <textarea class="form-control text-left exampleFormControlTextarea2" id="exampleFormControlTextarea" placeholder="" rows="3">My regular timings are from 3:00pm to 6:00pm Weekdays.Leave me a messege</textarea>
                                    </div>
                                </div>
                                
                            </div>

                        </form>
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-7" class="btn btn-primary default-btn">Next</button>
                        </div>
                    </div>

                    <!--======================== 
                             client-modal-8
                     =========================-->

                     <div id="clients-modal8" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-4">
                            <div class="col-12 client1">
                                <h5>MarkShelby25 sent you a request for help!</h5>
                                <p class="mt-3">He wants to hire you as for the following problems:</p>
                                <p class="mt-3"><b>'How to install animated wallpaper im windows 10?'</b></p>
                                <p class="mt-1 green_user-1"><b><i class="fa fa-check"></i>You fixed this issue in the past for another User</b></p>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-12">
                                <p class="mb-1">Markselby25 needs help using the following method:</p>
                                <a href="#">Remote Access Asistance</a>
                            </div>
                        </div>
                        <form class="checkbox_listing">
                            <div class="form-group">
                                <div class="row mb-5 pb-">
                                    
                                    <div class="col-5 my-auto pr-0">
                                       <p><b>Please choose your price</b></p>
                                       <p>to work this problem</p> 
                                    </div>
                                
                                    <div class="col-3 pl-0 label-problem-div">
                                        <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect12">
                                            <option></option>
                                            <option></option>
                                            <option></option>
                                            
                                        </select>
                                        <div class="select-drop-icon">

                                        </div>
                                    </div>
                                    <div class="col-1 my-auto px-0 text-center">
                                        <p>US<br>Dollars</p>
                                    </div>

                                </div>

                                <div class="row mb-4 justify-content-center mb-3">
                                   <div class="col-12">
                                       <p><b>Markshelby25</b> is using <b>Windows 10, version 10.0940</b></p>
                                   </div>
                                </div>

                                <div class="row mb-5 clent-btn-grp-1 pb-3 justify-content-center">
                                   <div class="col-4  px-2">
                                      <button type="button" class="btn block-btn text-center w-100">Block User</button>
                                   </div>
                                   <div class="col-4 px-1">
                                      <button type="button" class="btn decline-btn text-center disabled w-100">Deny Asistance</button>
                                   </div>
                                   <div class="col-4 px-2">
                                      <button type="button" class="btn start-s-btn text-center disabled w-100">Send Offer</button>
                                   </div>
                                </div>
                                
                            </div>

                        </form>
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-8" class="btn btn-primary default-btn">Next</button>
                        </div>
                    </div>
                    
                    <!--======================== 
                             client-modal-9
                     =========================-->
                    <div id="clients-modal9" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-4">
                            <div class="col-12 client1">
                                <h5>MarkShelby25 has declined your offer</h5>
                                
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-12">
                                <p class="mb-2"><b>Decline Reason:</b></p>
                                <p>That ridicoulesly high rate.i wont pay $35 to just get an nimated wallpaper set on my desktop. Bye!</p>
                            </div>
                        </div>
                        
                         <div class="row mb-3">
                            <div class="col-12">
                                <p class="mb-2"><b>Want to send a conter offer:</b></p>
                                <p>Your last offer was $35, we suggest you to try again by lowering this price.</p>
                            </div>
                        </div>
                        
                        <form class="checkbox_listing">
                            <div class="form-group">
                                <div class="row mb-5 pb-5">
                                    
                                    <div class="col-5 my-auto pr-0">
                                       <p><b>Please choose your price</b></p>
                                       <p>to work this problem</p> 
                                    </div>
                                
                                    <div class="col-3 pl-0 label-problem-div">
                                        <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect13">
                                            <option></option>
                                            <option></option>
                                            <option></option>
                                            
                                        </select>
                                        <div class="select-drop-icon">

                                        </div>
                                    </div>
                                    <div class="col-1 my-auto px-0 text-center">
                                        <p>US<br>Dollars</p>
                                    </div>

                                </div>

                                <div class="row mb-3 clent-btn-grp-1 justify-content-center">
                                   <div class="col-5 px-2">
                                      <button type="button" class="btn start-s-btn text-center w-100">Send Counter Offer</button>
                                   </div>
                                </div>
                                
                            </div>

                        </form>
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-9" class="btn btn-primary default-btn">Next</button>
                        </div>
                    </div>
                    
                    <!--======================== 
                             client-modal-10
                     =========================-->
                    
                    <div id="clients-modal10" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-4">
                            <div class="col-12 client1">
                                <h5>Are you sure you want to deny assistance to Markshelby25?</h5>
                                <p class="mt-3">Describe breifly why you are denying assistance to this user this will be visible to the user who's requesting assistance.</p>
                            </div>
                        </div>
                        
                        
                        <form class="checkbox_listing">
                            <div class="form-group">
                                <div class="row mb-5 justify-content-center">
                                    <div class="col-md-12 mb-1">
                                        <label for="exampleFormControlTextarea1"><b>Reason For Denial</b></label>
                                    </div>
                                    <div class="col-md-12">
                                        <textarea class="form-control text-left exampleFormControlTextarea2" id="exampleFormControlTextarea" placeholder="" rows="3">I am not expert on this.i have no experience with animated wallpapers in windows 10.you can look for another user.Thank you for contacting me.</textarea>
                                    </div>
                                </div>

                                <div class="row mb-3 clent-btn-grp-1">
                                   <div class="col-4 px-2">
                                      <button type="button" class="btn float-left start-s-btn text-center">Cancel</button>
                                   </div>
                                   <div class="col-4"></div>
                                   <div class="col-4 text-right px-2">
                                      <button type="button" class="btn float-right block-btn text-center">Deny</button>
                                   </div>
                                </div>
                                
                            </div>

                        </form>
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-10" class="btn btn-primary default-btn">Next</button>
                        </div>
                    </div>
                    
                    <!--======================== 
                             client-modal-11
                     =========================-->
                    
                    <div id="clients-modal11" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-3">
                            <div class="col-12 client1">
                                <h5>Are you sure you want to block this user Markshelby25?</h5>
                                <p class="mt-3">Describe breifly why you are blocking this user.This will be visible to the user who's requesting assistance.</p>
                            </div>
                        </div>
                        
                        <form class="checkbox_listing">
                            <div class="form-group">
                                <div class="row mb-5 justify-content-center mb-3">
                                    <div class="col-md-12 mb-1">
                                        <label for="exampleFormControlTextarea1"><b>Reason For Denial:</b></label>
                                    </div>
                                    <div class="col-md-12">
                                        <textarea class="form-control text-left exampleFormControlTextarea2" id="exampleFormControlTextarea" placeholder="" rows="3">I have already told you multiple times that i am not an expert on this issue and you are contiously sending me request to handle this issue.please do not ping me again.</textarea>
                                    </div>
                                </div>

                                <div class="row mb-5">
                                    <div class="col-12">
                                        <p><b>NOTE:</b> you can Unblock any blocked user later by going to our website <i class="fa fa-chevron-right"></i>My acoount <i class="fa fa-chevron-right"></i>Security settings</p>
                                    </div>
                                </div>

                                <div class="row mb-3 clent-btn-grp-1">
                                   <div class="col-4 px-2">
                                      <button type="button" class="btn float-left start-s-btn text-center">Cancel</button>
                                   </div>
                                   <div class="col-4"></div>
                                   <div class="col-4 text-right px-2">
                                      <button type="button" class="btn float-right block-btn text-center">Block</button>
                                   </div>
                                </div>
                                
                            </div>

                        </form>
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-11" class="btn btn-primary default-btn">Next</button>
                        </div>
                    </div>
                    
                    <!--======================== 
                             client-modal-12
                     =========================-->
                    
                    <div id="clients-modal12" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-5 pb-5">
                            <div class="col-12 client1">
                                <h5>Waiting for Markshelby25 to accept your offer</h5>
                                <p class="mt-3">Make sure your microphones & Speakers are turned on.</p>
                            </div>
                        </div>

                        <div class="row justify-content-center">
                            <div class="col-4">
                                 <button type="button" class="btn float-right block-btn text-center">Block</button>
                            </div>
                        </div>
                        
                        <div class="text-center mt-4 blue-bg-under">
                            <button type="button" id="modal2-btn-12" class="btn btn-primary default-btn">Next</button>
                        </div>
                    </div>

                     <!--======================== 
                             client-modal-13
                     =========================-->

                     <div id="clients-modal13" class="modal-blue-bg" style="display: none;">
                        <div class="row mb-4 ">
                            <div class="col-12 client1">
                                <h5>Markshelby25 has been alerted to pay continue!</h5>
                                <p class="mt-2">After 5 minutes of free session.We Require users to make a payment to continue recieving help form you.</p>
                                <p class="mt-3">
                                    While Markshelby25 is deciding whether to pay you for work ,you access to his computer is paused.
                                </p>
                                <p class="mt-3">
                                    Once the transaction are successful,you will recieve payment you've set for this user.if you deny assistanceafter payment,we'll be alerted & may be stop your payment& blacklist you.
                                </p>
                            </div>
                            </div>
                            <div class="row mb-3 justify-content-end">
                                <div class="col-5">
                                    <p class="mb-1">Total Payment: <b>35 USD</b></p>
                                    <p class="mb-1">Our Commision: <b>20%</b></p>
                                    <p class="mb-1">Your Proceeds: <b>28 USD</b></p>
                                </div>
                            </div>
                            <div class="row mb-5">
                                <div class="col-12">
                                    <p>If you think you won't be able to fix this problem or aren't satisfied with this user For any reason,end this session now by clicking the button below.<span class="red_user-1">Note: you won"t be able to end session after payment,</span>only <b>Markshelby25</b>can</p>
                                </div>
                            </div>
                        

                        <div class="row mb-3 justify-content-center">
                            <div class="col-5">
                                 <button type="button" class="btn float-right block-btn text-center">End Session</button>
                            </div>
                        </div>
                        
                        
                    </div>
                    
                </div>

            </div>
        </div>
    </div>
    <!-- modal -->
