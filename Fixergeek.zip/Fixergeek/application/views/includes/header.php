<header class="header w-100">
  <div class="container">
    <nav class="navbar navbar-expand-lg navbar-light">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
      

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item dropdown  dropdown1">
          <a class="nav-link logo-link dropdown-toggle border-right-1" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
            <img src="<?php echo base_url();?>assets/images/logo.gif" alt=""> 
          </a>
            <div class="dropdown-menu logo-menu dropdown-menu1" aria-labelledby="navbarDropdown"> 
              <a class="dropdown-item" href="#">How it Works?</a> 
              <a class="dropdown-item" href="#">Privacy Policy</a> 
              <a class="dropdown-item" href="#">Terms Of Use</a> 
              <a class="dropdown-item" href="#">About Us</a> 
            </div>
          </li>
          <li class="dropdown dropdown1 fixes nav-item"> 
          <a class="dropdown-toggle nav-link border-right-1 fix_id" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">		Fixes</a>
            <ul class="dropdown-menu dropdown-menu1 dropdown-menu12" aria-labelledby="navbarDropdown">
              <li><a id="sidebar-dropdown-li-5" class="dropdown-li dropdown-toggle" href="#">Repairs & security</a></li>
              <div id="sidebar-list-5" class="fixes-drop">
                <ul>
                  <li><a id="sidebar-dropdown-li-6" class="dropdown-li dropdown-toggle" href="#">Operating System Issues</a></li>
                  <div id="sidebar-list-6" class="fixes-drop">
                    <ul>
                      <li><a href="#">Viruses</a></li>
                      <li><a href="#">Spyware</a></li>
                      <li><a href="#">Ransomware</a></li>
                      <li><a href="#">Phishing</a></li>
                      <li><a href="#">Spam</a></li>
                      <li><a href="#">Key Logging</a></li>
                      <li><a href="#">Firewall</a></li>
                      <li><a href="#">Identity Theft</a></li>
                    </ul>
                  </div>
                  <li><a href="#">Device Management & Drivers</a></li>
                  <li><a href="#">Disk Management</a></li>
                  
                  <li><a href="#">Computer Management</a></li>
                  <li><a href="#">Command Line</a></li>
                  <li><a href="#">User Control & Rights</a></li>
                  <li><a href="#">Network Issues</a></li>
                  <li><a href="#">Connection Issues</a></li>
                  <li><a href="#">File Explorer</a></li>
                  <li><a href="#">Start Menu & Taskbar</a></li>
                  <li><a href="#">Users & Accounts</a></li>
                  <li><a href="#">Printing</a></li>
                  <li><a href="#">Output</a></li>
                  <li><a href="#">Input</a></li>
                  <li><a href="#">Miscellaneous</a></li>
                </ul>
              </div>
              <li><a href="#" id="sidebar-dropdown-li-7" class="dropdown-li dropdown-toggle">Optimization & Customization</a></li>
              <div id="sidebar-list-7" class="fixes-drop">
                <ul>
                  <li><a href="#">Steam</a></li>
                  <li><a href="#">Emulators</a></li>
                  <li><a href="#">RetroArch</a></li>
                  <li><a href="#">Dolphin</a></li>
                </ul>
              </div>
              <li><a href="#">Apps & Features</a></li>
              <li><a id="sidebar-dropdown-li-3" class="dropdown-li dropdown-toggle" href="#">Essential Apps</a></li>
              <div id="sidebar-list-3" class="fixes-drop">
                <ul>
                  <li><a href="#">Steam</a></li>
                  <li><a href="#">Emulators</a></li>
                  <li><a href="#">RetroArch</a></li>
                  <li><a href="#">Dolphin</a></li>
                </ul>
              </div>
              <li><a id="sidebar-dropdown-li-2" class="dropdown-li dropdown-toggle" href="#">Special Apps</a></li>
              <div id="sidebar-list-2" class="fixes-drop">
                <ul>
                  <li><a href="#">Producitivity Tools</a></li>
                  <li><a href="#">Password Management</a></li>
                  <li><a href="#">Photo</a></li>
                  <li><a href="#">Audio & Music</a></li>
                  <li><a href="#">CD/DVD/Blue-Ray</a></li>
                  <li><a id="sidebar-dropdown-li-4" class="dropdown-li dropdown-toggle" href="#">Gaming</a></li>
                  <div id="sidebar-list-4">
                    <ul>
                      <li><a href="#">Game Stores</a></li>
                      <li><a href="#">Xbox</a></li>
                      <li><a href="#">Steam</a></li>
                      <li><a href="#">Emulators</a></li>
                      <li><a href="#">RetroArch</a></li>
                    </ul>
                  </div>
                  <li><a href="#">Virtualization</a></li>
                  <li><a href="#">Miscellaneous</a></li>
                </ul>
              </div>
              <li><a href="#">Files, Data & Content </a></li>
              <li><a href="#">Office Management & Security </a></li>
            </ul>
          </li>
          <li class="nav-item "> <a class="nav-link border-right-1" href="#">Problems</a> </li>
          <li class="nav-item mx-3">
          <form class="form-inline my-2 my-lg-0">
            <input class="form-control border header-search position-relative" type="search" placeholder="SEARCH..." aria-label="Search">
            <button class="btn btn-outline-success border header-search-btn my-sm-0" type="submit"><i class="fa fa-search"></i></button>
            <li class="nav-item header-dropdown po dropdown dropdown12">
            <a class="nav-link header_dropdown_content_link dropdown-toggle " href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> </a>
            <div class="dropdown-menu  header-dropdown-content" aria-labelledby="navbarDropdown" style="width: 340px;"> <a class="dropdown-item" href="#">FIXES</a> <a class="dropdown-item" href="#">PROBLEMS</a> <a class="dropdown-item" href="#">FIXER GEEKS</a> </div>
            </li>
          </form>
          </li>
          <li class="nav-item"> <a class="nav-link border-right-1 supporter-shadow border-left-1" href="#">Geek's Podium</a> </li>
          <li class="nav-item dropdown dropdown1"> <a class="nav-link Profile-pad active dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-user-circle-o" style="font-size: 25px;"></i> </a>
            <div class="dropdown-menu profile-dropdown" aria-labelledby="navbarDropdown">
              <div class="pro-drop-header">
                <p>Login to continue using Fixer Geek!</p>
              </div>
              <div class="row justify-content-end px-2 mt-3 pb-3">
                <div class="col-4 header-drop-form-head">
                  <p class="pt-2">User Name</p>
                </div>
                <div class="col-8 pl-0">
                  <div class="form-group">
                    <input type="text" class="form-control  header-drop-form" id="username" aria-describedby="emailHelp" placeholder="" autofocus>
                  </div>
                </div>
                <div class="col-4 header-drop-form-head">
                  <p class="pt-2">Password</p>
                </div>
                <div class="col-8 pl-0">
                  <div class="form-group">
                    <input type="Password" class="form-control header-drop-form" id="password" aria-describedby="emailHelp" placeholder="">
                  </div>
                </div>
                <div class="col-md-4">
                  <button type="button" class="btn btn-primary w-100 default-btn">Log In</button>
                </div>
                <div class="col-12">
                  <div class="header-drop-links-first">
                    <p>Or Login With</p>
                    <hr class="my-2">
                    <ul class="text-center">
                      <li><a class="spl-facebook" href="#"><i class="fa fa-facebook-official"></i><br>
                        <span>Facebook</span></a></li>
                      <li><a class="spl-google" href="#"><i class="fa fa-google"> </i><br>
                        <span>Google</span></a></li>
                      <li><a class="spl-windows" href="#"><i class="fa fa-windows" aria-hidden="true"></i> <br>
                        <span>Microsoft</span></a></li>
                      <li><a class="spl-linkedin" href="#"><i class="fa fa-linkedin-square" aria-hidden="true"></i><br>
                        <span> Linkedin</span></a></li>
                    </ul>
                    <h6 class="password-change pt-3"><a href="#">Lost Password </a>or<a href="#"> User Name</a></h6>
                  </div>
                </div>
                <div class="col-12 mt-4">
                  <div class="header-drop-links-second">
                    <p>Or Sign Up With</p>
                    <hr class="my-2">
                    <ul class="text-center">
                      <li>
                        <a href="#">
                          <i class="fa fa-envelope" aria-hidden="true"></i><br>
                          <span>E-mail</span>
                       </a>
                      </li>
                      <li><a class="spl-facebook" href="#"><i class="fa fa-facebook-official"></i><br>
                        <span>Facebook</span></a></li>
                      <li><a class="spl-google" href="#"><i class="fa fa-google"> </i><br>
                        <span>Google</span></a></li>
                      <li><a class="spl-windows" href="#"><i class="fa fa-windows" aria-hidden="true"></i> <br>
                        <span>Microsoft</span></a></li>
                      <li><a class="spl-linkedin" href="#"><i class="fa fa-linkedin-square" aria-hidden="true"></i><br>
                        <span> Linkedin</span></a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li class="nav-item "> 
            <a class="nav-link border-right-1 bg-green-1" href="#" data-toggle="modal" data-target="#exampleModal">Ask Question</a> 
          </li>
        </ul>
      </div>
    </nav>
    <div class="clearfix"></div>
  </div>
</header>