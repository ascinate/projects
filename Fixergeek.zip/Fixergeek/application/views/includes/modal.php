<!-- Modal -->
<div class="modal fade exampleModalask" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header ask-modal modal-header-1"> <img src="<?php echo base_url();?>assets/images/logo-head.png" alt="">
        <h5 class="modal-title" id="exampleModalLabel">Ask Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      <div id="modal-spl-26" class="modal-body modal-body1">
        <div id="modal-no-1" class="modal-blue-bg">
          <div class="row mb-2">
            <div class="col-12">
              <h5>Welcome!</h5>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-3">
                <div class="col-md-12 mb-2">
                  <label for="exampleFormControlTextarea1">Type below what troubleshooting problem you need fixed.</label>
                </div>
                <div class="col-md-12">
                  <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Type your Question here..." rows="3"></textarea>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-4 pr-0 d-flex modal-spl-1">
                  <label class="modal-link-label" for="exampleFormControlTextarea100">Choose Category</label>
                </div>
                <div class="col-md-8 pl-0">
                  <ul>
                    <li class="dropdown dropdown1-1 fixes nav-item"> <a class="dropdown-toggle nav-link modal-link border-right-1 fix_id2 position-relative" href="#" id="plus-mode">Select Category</a>
                      <ul class="dropdown-menu dropdown-menu2 dropdown_menu20" aria-labelledby="navbarDropdown" id="modal-mode">
                        <li><a id="sidebar-dropdown-li-11" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Repairs & security </a></li>
                        <div id="sidebar-list-11" class="fixes-drop">
                          <ul>
                            <li><a id="sidebar-dropdown-li-12" class="dropdown-li plus-mode-1 dropdown-toggle d-flex" href="#">
                              <div class="plus-minus"></div>
                              Operating System Issues </a></li>
                            <div id="sidebar-list-12" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                              <ul>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-1">
                                    <label for="modal-1">VIRUS </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-2">
                                    <label for="modal-2">spyware </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-3">
                                    <label for="modal-3">ransomware </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-4">
                                    <label for="modal-4">Phishing </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-5">
                                    <label for="modal-5">Spam </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-6">
                                    <label for="modal-6">Key logging </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-7">
                                    <label for="modal-7">Firewall </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-8">
                                    <label for="modal-8">identity Theft </label>
                                  </div>
                                </li>
                              </ul>
                            </div>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-9">
                                <label for="modal-9">Device management & drivers </label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-10">
                                <label for="modal-10">Disk Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-11">
                                <label for="modal-11">Computer Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-12">
                                <label for="modal-12">Command Line</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-13">
                                <label for="modal-13">User controls & rights</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-14">
                                <label for="modal-14">Network Issue</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-15">
                                <label for="modal-15">Connection Issue Line</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-16">
                                <label for="modal-16">File Explorer</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-17">
                                <label for="modal-17">Start Menu & Taskbar</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-18">
                                <label for="modal-18">Fu Users & Accounts</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-19">
                                <label for="modal-19">Printing</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-20">
                                <label for="modal-20">Output</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-21">
                                <label for="modal-21">INput</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-22">
                                <label for="modal-22">Miscellaneous</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="sidebar-dropdown-li-13" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Optimization & Customization </a> </li>
                        <div id="sidebar-list-13" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-23">
                                <label for="modal-23">Steam</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-24">
                                <label for="modal-24">Emulators</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="sidebar-dropdown-li-14" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Apps & Features </a> </li>
                        <div id="sidebar-list-14" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-25">
                                <label for="modal-25">retroArch</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-26">
                                <label for="modal-26">Xbox</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li><a id="sidebar-dropdown-li-9" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Essential Apps </a></li>
                        <div id="sidebar-list-9" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-27">
                                <label for="modal-27">Steam</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-47">
                                <label for="modal-47">Emulators</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-28">
                                <label for="modal-28">Miscellaneous</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-29">
                                <label for="modal-29">Dolphin</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li><a id="sidebar-dropdown-li-8" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Special Apps </a></li>
                        <div id="sidebar-list-8" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-30">
                                <label for="modal-30">pRODUCTIVITY TOOLS</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-31">
                                <label for="modal-31">password Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-32">
                                <label for="modal-32">photos</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-33">
                                <label for="modal-33">audio & music</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-34">
                                <label for="modal-34">cd/dvd/blue ray</label>
                              </div>
                            </li>
                            <li><a id="sidebar-dropdown-li-10" class="dropdown-li dropdown-toggle plus-mode-1 d-flex " href="#">
                              <div class="plus-minus"></div>
                              Gaming </a></li>
                            <div id="sidebar-list-10" class="checkbox_listing-1 checkbox_listing-2">
                              <ul>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-35">
                                    <label for="modal-35">Game stores</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-36">
                                    <label for="modal-36">xbox</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-37">
                                    <label for="modal-37">Steam</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-38">
                                    <label for="modal-38">Emulators</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="modal-39">
                                    <label for="modal-39">Retroarch</label>
                                  </div>
                                </li>
                              </ul>
                            </div>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-40">
                                <label for="modal-40">Virtualization</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-40">
                                <label for="modal-40">Miscellaneous</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="sidebar-dropdown-li-15" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Files Data & Content </a> </li>
                        <div id="sidebar-list-15" class="checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-41">
                                <label for="modal-41">User Controls & Rights</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-41">
                                <label for="modal-41">NEtwork Issue</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-42">
                                <label for="modal-42">Connection iSSUE</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="sidebar-dropdown-li-16" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Office Management & Security </a> </li>
                        <div id="sidebar-list-16" class="checkbox_listing-1 checkbox_listing-2">
                          <li>
                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                              <input type="checkbox" id="modal-43">
                              <label for="modal-43">fIREWALL</label>
                            </div>
                          </li>
                          <li>
                            <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                              <input type="checkbox" id="modal-44">
                              <label for="modal-44">identity theft</label>
                            </div>
                          </li>
                        </div>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="row mb-3">
              <div class="col-md-12 label-problem-div text-right">
                <label class="label-problem" for="exampleFormControlSelect1">Get it fixed</label>
                <select class="form-control form-control-modal position-relative" id="exampleFormControlSelect16">
                  <option>By All Users</option>
                  <option>By A Particular User</option>
                </select>
                <div class="select-drop-icon"> </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group-1">
                  <input type="checkbox" id="modal-check-1" checked>
                  <label for="modal-check-1">Post it at our Website</label>
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group-1">
                  <input type="checkbox" id="modal-check-2" checked>
                  <label for="modal-check-2">Find Users who can <span>Fix it right now</span></label>
                </div>
              </div>
            </div>
          </form>
          <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal-btn-1" class="btn btn-primary default-btn ">Ask</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-2-next  

                         ***===============-->
        <div id="modal-no-2" class="modal-blue-bg" style="display: none;">
          <div class="row mb-2">
            <div class="col-12">
              <h5>Please Choose One</h5>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-2">
                <div class="col-5 my-auto pr-0">
                  <div class="form-check">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                    <label class="form-check-label radio-modal-label-1" for="exampleRadios1"> Get a Problem Fixed </label>
                  </div>
                </div>
                <div class="col-7 label-problem-div text-right">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect2">
                    <option>By A Particular User</option>
                    <option>By All Users</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-3 modal2User_grp text-right my-auto pr-0">
                  <p>User's Name</p>
                </div>
                <div class="col-9">
                  <div class="form-group mb-0">
                    <input type="email" class="form-control modal2from_grp" id="exampleFormControlInput1" placeholder="type here....">
                  </div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-12 mb-2">
                  <label for="exampleFormControlTextarea1">Type below what troubleshooting problem you need fixed.</label>
                </div>
                <div class="col-md-12">
                  <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Type your Question here..." rows="3"></textarea>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-4 pr-0 d-flex modal-spl-1">
                  <label class="modal-link-label" for="exampleFormControlTextarea100">Choose Category</label>
                </div>
                <div class="col-md-8 pl-0">
                  <ul>
                    <li class="dropdown dropdown1-1 fixes nav-item"> <a class="dropdown-toggle nav-link modal-link border-right-1 fix_id4 position-relative" href="#" id="plus-mode3">Select Category</a>
                      <ul class="dropdown-menu dropdown-menu2 dropdown_menu20" aria-labelledby="navbarDropdown" id="modal-mode3">
                        <li><a id="modalbar2-dropdown-li-11" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Repairs & security </a></li>
                        <div id="modalbar2-list-11" class="fixes-drop">
                          <ul>
                            <li><a id="modalbar2-dropdown-li-12" class="dropdown-li plus-mode-1 dropdown-toggle d-flex" href="#">
                              <div class="plus-minus"></div>
                              Operating System Issues </a></li>
                            <div id="modalbar2-list-12" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                              <ul>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-1">
                                    <label for="m-1">VIRUS </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-2">
                                    <label for="m-2">spyware </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-3">
                                    <label for="m-3">ransomware </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-4">
                                    <label for="m-4">Phishing </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-5">
                                    <label for="m-5">Spam </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-6">
                                    <label for="m-6">Key logging </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-7">
                                    <label for="m-7">Firewall </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-8">
                                    <label for="m-8">identity Theft </label>
                                  </div>
                                </li>
                              </ul>
                            </div>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-9">
                                <label for="m-9">Device management & drivers </label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-10">
                                <label for="m-10">Disk Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-11">
                                <label for="m-11">Computer Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-12">
                                <label for="m-12">Command Line</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-13">
                                <label for="m-13">User controls & rights</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-14">
                                <label for="m-14">Network Issue</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-15">
                                <label for="m-15">Connection Issue Line</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-16">
                                <label for="m-16">File Explorer</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-17">
                                <label for="m-17">Start Menu & Taskbar</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-18">
                                <label for="m-18">Fu Users & Accounts</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-19">
                                <label for="m-19">Printing</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-20">
                                <label for="m-20">Output</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-21">
                                <label for="m-21">INput</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-22">
                                <label for="m-22">Miscellaneous</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar2-dropdown-li-13" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Optimization & Customization </a> </li>
                        <div id="modalbar2-list-13" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-23">
                                <label for="m-23">Steam</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-24">
                                <label for="m-24">Emulators</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar2-dropdown-li-14" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Apps & Features </a> </li>
                        <div id="modalbar2-list-14" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-25">
                                <label for="m-25">retroArch</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-26">
                                <label for="m-26">Xbox</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li><a id="modalbar2-dropdown-li-9" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Essential Apps </a></li>
                        <div id="modalbar2-list-9" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-27">
                                <label for="m-27">Steam</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-47">
                                <label for="m-47">Emulators</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-28">
                                <label for="m-28">Miscellaneous</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-29">
                                <label for="m-29">Dolphin</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li><a id="modalbar2-dropdown-li-8" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Special Apps </a></li>
                        <div id="modalbar2-list-8" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-30">
                                <label for="m-30">pRODUCTIVITY TOOLS</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-31">
                                <label for="m-31">password Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-32">
                                <label for="m-32">photos</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-33">
                                <label for="m-33">audio & music</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-34">
                                <label for="m-34">cd/dvd/blue ray</label>
                              </div>
                            </li>
                            <li><a id="modalbar2-dropdown-li-10" class="dropdown-li dropdown-toggle plus-mode-1 d-flex " href="#">
                              <div class="plus-minus"></div>
                              Gaming </a></li>
                            <div id="modalbar2-list-10" class="checkbox_listing-1 checkbox_listing-2">
                              <ul>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-35">
                                    <label for="m-35">Game stores</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-36">
                                    <label for="m-36">xbox</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-37">
                                    <label for="m-37">Steam</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-38">
                                    <label for="m-38">Emulators</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="m-39">
                                    <label for="m-39">Retroarch</label>
                                  </div>
                                </li>
                              </ul>
                            </div>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-40">
                                <label for="m-40">Virtualization</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-40">
                                <label for="m-40">Miscellaneous</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar2-dropdown-li-15" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Files Data & Content </a> </li>
                        <div id="modalbar2-list-15" class="checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-41">
                                <label for="m-41">User Controls & Rights</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-42">
                                <label for="m-42">NEtwork Issue</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-43">
                                <label for="m-43">Connection iSSUE</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar2-dropdown-li-16" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Office Management & Security </a> </li>
                        <div id="modalbar2-list-16" class="checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="modal-44">
                                <label for="modal-44">fIREWALL</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="m-45">
                                <label for="m-45">identity theft</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-md-12">
                  <div class="form-group-1">
                    <input type="checkbox" id="modal-check-5">
                    <label for="modal-check-5">Post it at our Website to get a<span>reply from this user</span></label>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group-1">
                    <input type="checkbox" id="modal-check-6" checked>
                    <label for="modal-check-6">Request this user to <span>fix it right now</span></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-4 my-auto pr-0">
                  <div class="form-check">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios21" value="option1">
                    <label class="form-check-label radio-modal-label-1" for="exampleRadios21"> Fix Problem </label>
                  </div>
                </div>
                <div class="col-8 label-problem-div text-right pl-6">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect3">
                    <option>Of Other users</option>
                    <option>By All Users</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
            </div>
          </form>
          <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal-btn-2" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-3-next  

                         ***===============-->
        <div id="modal-no-3" class="modal-blue-bg" style="display: none;">
          <div class="row mb-4">
            <div class="col-12">
              <h5>Get problem fixed by joeMartyjoe</h5>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row justify-content-center mb-3">
                <div class="col-11">
                  <p class="mb-2">Choose a price between $10 to $9,999.Enter only digits</p>
                </div>
                <div class="col-5 my-auto px-0">
                  <label class="form-check-label radio-modal-label-1" for="exampleRadios1"> Requested Price in USD: </label>
                </div>
                <div class="col-4 my-auto label-problem-div px-0 text-right">
                  <input type="text" class="form-control modal2from_grp" id="exampleFormControlInput1" placeholder="">
                </div>
              </div>
              <div class="row mb-4">
                <div class="col-12">
                  <div class="modal-3-prblm">
                    <h6><b>Problem you want to fixed:</b></h6>
                    <p>How do i play Metal Slug on Retroarch Emulator?</p>
                  </div>
                </div>
              </div>
              <div class="row mb-5 justify-content-center mb-3">
                <div class="col-11 modal-3-prblm">
                  <h6 class="mb-2"><b>Get the problem fixed:</b></h6>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios1"> Using Remote Access Assistance </label>
                  </div>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios7" value="option1">
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios7"> Using Screen Sharing & Voice Chat </label>
                  </div>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios8" value="option">
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios8"> Using Text Chat Support </label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-12">
                  <div class="modal-3-check">
                    <div class="form-group form-group-1  my-2 mx-2">
                      <input type="checkbox" id="modal-3-check-1">
                      <label for="modal-3-check-1">I agree to the remote Support <a href="#">terms & condition</a></label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
          <div class="text-center mt-2 blue-bg-under">
            <button type="button" id="modal-btn-3" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-4-next  

                         ***===============-->
        <div id="modal-no-4" class="modal-blue-bg" style="display: none;">
          <div class="row mb-2">
            <div class="col-12">
              <h5>Welcome!</h5>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-2">
                <div class="col-5 my-auto pr-0">
                  <div class="form-check">
                    <label class="form-check-label radio-modal-label-1" for="exampleRadios1"> Get a Problem Fixed </label>
                  </div>
                </div>
                <div class="col-7 label-problem-div text-right">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect4">
                    <option>By All Users</option>
                    <option>By A Particular User</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-md-12 mb-2">
                  <label for="exampleFormControlTextarea1">Type below what troubleshooting problem you need fixed.</label>
                </div>
                <div class="col-md-12">
                  <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Type your Question here..." rows="3"></textarea>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-md-4 pr-0 d-flex modal-spl-1">
                  <label class="modal-link-label" for="exampleFormControlTextarea100">Choose Category</label>
                </div>
                <div class="col-md-8 pl-0">
                  <ul>
                    <li class="dropdown dropdown1-1 fixes nav-item"> <a class="dropdown-toggle nav-link modal-link border-right-1 fix_id5 position-relative" href="#" id="plus-mode4">Select Category</a>
                      <ul class="dropdown-menu dropdown-menu2 dropdown_menu20" aria-labelledby="navbarDropdown" id="modal-mode4">
                        <li><a id="modalbar3-dropdown-li-11" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Repairs & security </a></li>
                        <div id="modalbar3-list-11" class="fixes-drop">
                          <ul>
                            <li><a id="modalbar3-dropdown-li-12" class="dropdown-li plus-mode-1 dropdown-toggle d-flex" href="#">
                              <div class="plus-minus"></div>
                              Operating System Issues </a></li>
                            <div id="modalbar3-list-12" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                              <ul>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-1">
                                    <label for="mno-1">VIRUS </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-2">
                                    <label for="mno-2">spyware </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-3">
                                    <label for="mno-3">ransomware </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-4">
                                    <label for="mno-4">Phishing </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-5">
                                    <label for="mno-5">Spam </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-6">
                                    <label for="mno-6">Key logging </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-7">
                                    <label for="mno-7">Firewall </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-8">
                                    <label for="mno-8">identity Theft </label>
                                  </div>
                                </li>
                              </ul>
                            </div>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-9">
                                <label for="mno-9">Device management & drivers </label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-10">
                                <label for="mno-10">Disk Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-11">
                                <label for="mno-11">Computer Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-12">
                                <label for="mno-12">Command Line</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-13">
                                <label for="mno-13">User controls & rights</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-14">
                                <label for="mno-14">Network Issue</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-15">
                                <label for="mno-15">Connection Issue Line</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-16">
                                <label for="mno-16">File Explorer</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-17">
                                <label for="mno-17">Start Menu & Taskbar</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-18">
                                <label for="mno-18">Fu Users & Accounts</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-19">
                                <label for="mno-19">Printing</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-20">
                                <label for="mno-20">Output</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-21">
                                <label for="mno-21">INput</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-22">
                                <label for="mno-22">Miscellaneous</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar3-dropdown-li-13" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Optimization & Customization </a> </li>
                        <div id="modalbar3-list-13" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-23">
                                <label for="mno-23">Steam</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-24">
                                <label for="mno-24">Emulators</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar3-dropdown-li-14" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Apps & Features </a> </li>
                        <div id="modalbar3-list-14" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-25">
                                <label for="mno-25">retroArch</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-26">
                                <label for="mno-26">Xbox</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li><a id="modalbar3-dropdown-li-9" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Essential Apps </a></li>
                        <div id="modalbar3-list-9" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-27">
                                <label for="mno-27">Steam</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-47">
                                <label for="mno-47">Emulators</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-28">
                                <label for="mno-28">Miscellaneous</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-29">
                                <label for="mno-29">Dolphin</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li><a id="modalbar3-dropdown-li-8" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Special Apps </a></li>
                        <div id="modalbar3-list-8" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-30">
                                <label for="mno-30">pRODUCTIVITY TOOLS</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-31">
                                <label for="mno-31">password Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-32">
                                <label for="mno-32">photos</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-33">
                                <label for="mno-33">audio & music</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-34">
                                <label for="mno-34">cd/dvd/blue ray</label>
                              </div>
                            </li>
                            <li><a id="modalbar3-dropdown-li-10" class="dropdown-li dropdown-toggle plus-mode-1 d-flex " href="#">
                              <div class="plus-minus"></div>
                              Gaming </a></li>
                            <div id="modalbar3-list-10" class="checkbox_listing-1 checkbox_listing-2">
                              <ul>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-35">
                                    <label for="mno-35">Game stores</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-36">
                                    <label for="mno-36">xbox</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-37">
                                    <label for="mno-37">Steam</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-38">
                                    <label for="mno-38">Emulators</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mno-39">
                                    <label for="mno-39">Retroarch</label>
                                  </div>
                                </li>
                              </ul>
                            </div>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-40">
                                <label for="mno-40">Virtualization</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-41">
                                <label for="mno-41">Miscellaneous</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar3-dropdown-li-15" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Files Data & Content </a> </li>
                        <div id="modalbar3-list-15" class="checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-42">
                                <label for="mno-42">User Controls & Rights</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-43">
                                <label for="mno-43">NEtwork Issue</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-44">
                                <label for="mno-44">Connection iSSUE</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar3-dropdown-li-16" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Office Management & Security </a> </li>
                        <div id="modalbar3-list-16" class="checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-45">
                                <label for="mno-45">fIREWALL</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-46">
                                <label for="mno-46">identity theft</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="row mb-4">
                <div class="col-12 modal-3-prblm">
                  <h6 class="mb-1"><b>Related Fixes</b></h6>
                  <a href="#" class="d-block">How do i run an animated gif file on my windows background? (5 fixes)</a> <a href="#" class="d-block">Is there way i can have animated wallpaper on my windows 10? (4 fixes)</a> <a href="#" class="d-block">Why Microsoft doesn't have a feature of having animated wallpaper in Windows? (2 fixes)</a>
                  <h3 class="mt-2"><span class="red_user-1">The Problem is already fixed.</span>Find related Fixes above</h3>
                </div>
              </div>
              <div class="row">
                <div class="col-12">
                  <p>Alternatively,click'find users' to find users who can fix this problem for you right now.</p>
                </div>
              </div>
            </div>
          </form>
          <div class="text-center mt-2 blue-bg-under" id="modal-4-blue-bg-under">
            <button type="button" id="modal-btn-4" class="btn btn-primary default-btn">Find Users</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-5-next  

                         ***===============-->
        <div id="modal-no-5" class="modal-blue-bg" style="display: none;">
          <div class="row mb-2">
            <div class="col-12">
              <h5>Welcome!</h5>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-2">
                <div class="col-5 my-auto pr-0">
                  <div class="form-check">
                    <label class="form-check-label radio-modal-label-1" for="exampleRadios1"> Get a Problem Fixed </label>
                  </div>
                </div>
                <div class="col-7 label-problem-div text-right">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect14">
                    <option>By All Users</option>
                    <option>By A Particular User</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-md-12 mb-2">
                  <label for="exampleFormControlTextarea1">Type below what troubleshooting problem you need fixed.</label>
                </div>
                <div class="col-md-12">
                  <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Type your Question here..." rows="3"></textarea>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-md-4 pr-0 d-flex modal-spl-1">
                  <label class="modal-link-label" for="exampleFormControlTextarea100">Choose Category</label>
                </div>
                <div class="col-md-8 pl-0">
                  <ul>
                    <li class="dropdown dropdown1-1 fixes nav-item"> <a class="dropdown-toggle nav-link modal-link border-right-1 fix_id6 position-relative" href="#" id="plus-mode5">Select Category</a>
                      <ul class="dropdown-menu dropdown-menu2 dropdown_menu20" aria-labelledby="navbarDropdown" id="modal-mode5">
                        <li><a id="modalbar4-dropdown-li-11" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Repairs & security </a></li>
                        <div id="modalbar4-list-11" class="fixes-drop">
                          <ul>
                            <li><a id="modalbar4-dropdown-li-12" class="dropdown-li plus-mode-1 dropdown-toggle d-flex" href="#">
                              <div class="plus-minus"></div>
                              Operating System Issues </a></li>
                            <div id="modalbar4-list-12" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                              <ul>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-1">
                                    <label for="mnop-1">VIRUS </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-2">
                                    <label for="mnop-2">spyware </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-3">
                                    <label for="mnop-3">ransomware </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-4">
                                    <label for="mnop-4">Phishing </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-5">
                                    <label for="mnop-5">Spam </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-6">
                                    <label for="mnop-6">Key logging </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-7">
                                    <label for="mnop-7">Firewall </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-8">
                                    <label for="mnop-8">identity Theft </label>
                                  </div>
                                </li>
                              </ul>
                            </div>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-9">
                                <label for="mnop-9">Device management & drivers </label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-10">
                                <label for="mnop-10">Disk Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-11">
                                <label for="mnop-11">Computer Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-12">
                                <label for="mnop-12">Command Line</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-13">
                                <label for="mnop-13">User controls & rights</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-14">
                                <label for="mnop-14">Network Issue</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-15">
                                <label for="mnop-15">Connection Issue Line</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-16">
                                <label for="mnop-16">File Explorer</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-17">
                                <label for="mnop-17">Start Menu & Taskbar</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-18">
                                <label for="mnop-18">Fu Users & Accounts</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-19">
                                <label for="mnop-19">Printing</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-20">
                                <label for="mnop-20">Output</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-21">
                                <label for="mnop-21">INput</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-22">
                                <label for="mnop-22">Miscellaneous</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar4-dropdown-li-13" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Optimization & Customization </a> </li>
                        <div id="modalbar4-list-13" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-23">
                                <label for="mnop-23">Steam</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-24">
                                <label for="mnop-24">Emulators</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar4-dropdown-li-14" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Apps & Features </a> </li>
                        <div id="modalbar4-list-14" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-25">
                                <label for="mnop-25">retroArch</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-26">
                                <label for="mnop-26">Xbox</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li><a id="modalbar4-dropdown-li-9" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Essential Apps </a></li>
                        <div id="modalbar4-list-9" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-27">
                                <label for="mnop-27">Steam</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-47">
                                <label for="mnop-47">Emulators</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-28">
                                <label for="mnop-28">Miscellaneous</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-29">
                                <label for="mnop-29">Dolphin</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li><a id="modalbar4-dropdown-li-8" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Special Apps </a></li>
                        <div id="modalbar4-list-8" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-30">
                                <label for="mnop-30">pRODUCTIVITY TOOLS</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-31">
                                <label for="mnop-31">password Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-32">
                                <label for="mnop-32">photos</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-33">
                                <label for="mnop-33">audio & music</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-34">
                                <label for="mnop-34">cd/dvd/blue ray</label>
                              </div>
                            </li>
                            <li><a id="modalbar4-dropdown-li-10" class="dropdown-li dropdown-toggle plus-mode-1 d-flex " href="#">
                              <div class="plus-minus"></div>
                              Gaming </a></li>
                            <div id="modalbar4-list-10" class="checkbox_listing-1 checkbox_listing-2">
                              <ul>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-35">
                                    <label for="mnop-35">Game stores</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-36">
                                    <label for="mnop-36">xbox</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-37">
                                    <label for="mnop-37">Steam</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-38">
                                    <label for="mnop-38">Emulators</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnop-39">
                                    <label for="mnop-39">Retroarch</label>
                                  </div>
                                </li>
                              </ul>
                            </div>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-40">
                                <label for="mnop-40">Virtualization</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-41">
                                <label for="mnop-41">Miscellaneous</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar4-dropdown-li-15" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Files Data & Content </a> </li>
                        <div id="modalbar4-list-15" class="checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-42">
                                <label for="mnop-42">User Controls & Rights</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-43">
                                <label for="mnop-43">NEtwork Issue</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnop-44">
                                <label for="mnop-44">Connection iSSUE</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar4-dropdown-li-16" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Office Management & Security </a> </li>
                        <div id="modalbar4-list-16" class="checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-45">
                                <label for="mno-45">fIREWALL</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mno-46">
                                <label for="mno-46">identity theft</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="row mb-5">
                <div class="col-12 modal-3-prblm">
                  <h6 class="mb-1"><b>Related Fixes</b></h6>
                  <a href="#" class="d-block">How do i run an animated gif file on my windows background? (5 fixes)</a> </div>
              </div>
              <div class="row mb-5">
                <div class="col-12">
                  <p>Click 'Ask' to post this problem on our Website. Sorry, there are no users online at this time.</p>
                </div>
              </div>
            </div>
          </form>
          <div class="text-center mt-4 blue-bg-under" id="modal-4-blue-bg-under">
            <button type="button" id="modal-btn-5" class="btn btn-primary default-btn">Ask</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-6-next  

                         ***===============-->
        <div id="modal-no-6" class="modal-blue-bg" style="display: none;">
          <div class="row mb-2">
            <div class="col-12">
              <h5>Welcome!</h5>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-2">
                <div class="col-5 my-auto pr-0">
                  <div class="form-check">
                    <label class="form-check-label radio-modal-label-1" for="exampleRadios1"> Get a Problem Fixed </label>
                  </div>
                </div>
                <div class="col-7 label-problem-div text-right">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect15">
                    <option>By All Users</option>
                    <option>By A Particular User</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-md-12 mb-2">
                  <label for="exampleFormControlTextarea1">Type below what troubleshooting problem you need fixed.</label>
                </div>
                <div class="col-md-12">
                  <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Type your Question here..." rows="3"></textarea>
                </div>
              </div>
              <div class="row mb-2">
                <div class="col-md-4 pr-0 d-flex modal-spl-1">
                  <label class="modal-link-label" for="exampleFormControlTextarea100">Choose Category</label>
                </div>
                <div class="col-md-8 pl-0">
                  <ul>
                    <li class="dropdown dropdown1-1 fixes nav-item"> <a class="dropdown-toggle nav-link modal-link border-right-1 fix_id7 position-relative" href="#" id="plus-mode6">Select Category</a>
                      <ul class="dropdown-menu dropdown-menu2 dropdown_menu20" aria-labelledby="navbarDropdown" id="modal-mode6">
                        <li><a id="modalbar5-dropdown-li-11" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Repairs & security </a></li>
                        <div id="modalbar5-list-11" class="fixes-drop">
                          <ul>
                            <li><a id="modalbar5-dropdown-li-12" class="dropdown-li plus-mode-1 dropdown-toggle d-flex" href="#">
                              <div class="plus-minus"></div>
                              Operating System Issues </a></li>
                            <div id="modalbar5-list-12" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                              <ul>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-1">
                                    <label for="mnopq-1">VIRUS </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-2">
                                    <label for="mnopq-2">spyware </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-3">
                                    <label for="mnopq-3">ransomware </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-4">
                                    <label for="mnopq-4">Phishing </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-5">
                                    <label for="mnopq-5">Spam </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-6">
                                    <label for="mnopq-6">Key logging </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-7">
                                    <label for="mnopq-7">Firewall </label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-8">
                                    <label for="mnopq-8">identity Theft </label>
                                  </div>
                                </li>
                              </ul>
                            </div>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-9">
                                <label for="mnopq-9">Device management & drivers </label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-10">
                                <label for="mnopq-10">Disk Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-11">
                                <label for="mnopq-11">Computer Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-12">
                                <label for="mnopq-12">Command Line</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-13">
                                <label for="mnopq-13">User controls & rights</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-14">
                                <label for="mnopq-14">Network Issue</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-15">
                                <label for="mnopq-15">Connection Issue Line</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-16">
                                <label for="mnopq-16">File Explorer</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-17">
                                <label for="mnopq-17">Start Menu & Taskbar</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-18">
                                <label for="mnopq-18">Fu Users & Accounts</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-19">
                                <label for="mnopq-19">Printing</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-20">
                                <label for="mnopq-20">Output</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-21">
                                <label for="mnopq-21">Input</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-22">
                                <label for="mnopq-22">Miscellaneous</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar5-dropdown-li-13" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Optimization & Customization </a> </li>
                        <div id="modalbar5-list-13" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-23">
                                <label for="mnopq-23">Steam</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-24">
                                <label for="mnopq-24">Emulators</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar5-dropdown-li-14" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Apps & Features </a> </li>
                        <div id="modalbar5-list-14" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-25">
                                <label for="mnopq-25">retroArch</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-26">
                                <label for="mnopq-26">Xbox</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li><a id="modalbar5-dropdown-li-9" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Essential Apps </a></li>
                        <div id="modalbar5-list-9" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-27">
                                <label for="mnopq-27">Steam</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-47">
                                <label for="mnopq-47">Emulators</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-28">
                                <label for="mnopq-28">Miscellaneous</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-29">
                                <label for="mnopq-29">Dolphin</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li><a id="modalbar5-dropdown-li-8" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Special Apps </a></li>
                        <div id="modalbar5-list-8" class="fixes-drop checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-30">
                                <label for="mnopq-30">pRODUCTIVITY TOOLS</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-31">
                                <label for="mnopq-31">password Management</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-32">
                                <label for="mnopq-32">photos</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-33">
                                <label for="mnopq-33">audio & music</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-34">
                                <label for="mnopq-34">cd/dvd/blue ray</label>
                              </div>
                            </li>
                            <li><a id="modalbar5-dropdown-li-10" class="dropdown-li dropdown-toggle plus-mode-1 d-flex " href="#">
                              <div class="plus-minus"></div>
                              Gaming </a></li>
                            <div id="modalbar5-list-10" class="checkbox_listing-1 checkbox_listing-2">
                              <ul>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-35">
                                    <label for="mnopq-35">Game stores</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-36">
                                    <label for="mnopq-36">xbox</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-37">
                                    <label for="mnopq-37">Steam</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-38">
                                    <label for="mnopq-38">Emulators</label>
                                  </div>
                                </li>
                                <li>
                                  <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                    <input type="checkbox" id="mnopq-39">
                                    <label for="mnopq-39">Retroarch</label>
                                  </div>
                                </li>
                              </ul>
                            </div>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-40">
                                <label for="mnopq-40">Virtualization</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-41">
                                <label for="mnopq-41">Miscellaneous</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar5-dropdown-li-15" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Files Data & Content </a> </li>
                        <div id="modalbar5-list-15" class="checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-42">
                                <label for="mnopq-42">User Controls & Rights</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-43">
                                <label for="mnopq-43">NEtwork Issue</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-44">
                                <label for="mnopq-44">Connection iSSUE</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                        <li> <a id="modalbar5-dropdown-li-16" class="dropdown-li dropdown-toggle plus-mode-1 d-flex" href="#">
                          <div class="plus-minus"></div>
                          Office Management & Security </a> </li>
                        <div id="modalbar5-list-16" class="checkbox_listing-1 checkbox_listing-2">
                          <ul>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-45">
                                <label for="mnopq-45">fIREWALL</label>
                              </div>
                            </li>
                            <li>
                              <div class="form-group form-group-1 form-group-2 my-2 mx-2">
                                <input type="checkbox" id="mnopq-46">
                                <label for="mnopq-46">identity theft</label>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="row mb-4">
                <div class="col-12 modal-3-prblm">
                  <h6 class="mb-1"><b>Related Fixes</b></h6>
                  <a href="#" class="d-block">How do i run an animated gif file on my windows background? (5 fixes)</a> <a href="#" class="d-block">Is there way i can have animated wallpaper on my windows 10? (4 fixes)</a> <a href="#" class="d-block">Why Microsoft doesn't have a feature of having animated wallpaper in Windows? (2 fixes)</a>
                  <h3 class="mt-2"><span class="red_user-1">The Problem is already fixed.</span>Find related Fixes above</h3>
                </div>
              </div>
              <div class="row mb-4">
                <div class="col-12">
                  <p>Sorry,there are no users online at this time as well.</p>
                </div>
              </div>
            </div>
          </form>
          <div class="text-center mt-0 blue-bg-under">
            <button type="button" id="modal-btn-6" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-7-next  

                         ***===============-->
        <div id="modal-no-7" class="modal-blue-bg" style="display: none;">
          <div class="row mb-3">
            <div class="col-12 online1">
              <h5>Online <br>
                Finding relevant Users for You... </h5>
              <h6 class="mt-2"><b>Keep this window Running or minimized</b> to get offers</h6>
            </div>
          </div>
          <div class="row">
            <div class="col-12 ">
              <div class="table-modal-1">
                <p class="mb-2">Alternatively, you can ask the following users for help</p>
                <div class="table-modal-1-details table-modal-1-details1">
                  <table class="table-modal-part-2 table-modal-part-3 w-100 checkbox_listing-1 checkbox_listing-2">
                    <thead>
                      <tr>
                        <th scope="col" style="width: 45%;">User Name</th>
                        <th scope="col">Expert In</th>
                        <th scope="col">Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-45">
                            <label for="table-modal-45">JoeMartyjoe</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.2</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-47">
                            <label for="table-modal-47">Shawn667</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.8</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-46">
                            <label for="table-modal-46">Susan_2020</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.1</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-1">
                            <label for="table-modal-1">Simon525</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.8</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-2">
                            <label for="table-modal-2">Richard252</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.8</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <div class="row mt-2 mb-5 pb-3 justify-content-end">
            <div class="col-md-5 modaltable_btn">
              <button type="button" class="btn  disabled text-center w-100 default-btn">Send Request</button>
            </div>
          </div>
          <div class="text-center blue-bg-under">
            <button type="button" id="modal-btn-7" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-8-next  

                     ***===============-->
        <div id="modal-no-8" class="modal-blue-bg" style="display: none;">
          <div class="row mb-3">
            <div class="col-12 online1">
              <h5>Online <br>
                Finding relevant Users for You... </h5>
              <h6 class="mt-2"><b>Keep this window Running or minimized</b> to get offers</h6>
            </div>
          </div>
          <div class="row">
            <div class="col-12 ">
              <div class="table-modal-1">
                <p class="mb-2">Alternatively, you can ask the following users for help</p>
                <div class="table-modal-1-details">
                  <table class="table-modal-part-2 w-100 checkbox_listing-1 checkbox_listing-2">
                    <thead>
                      <tr>
                        <th scope="col" style="width: 45%;">User Name</th>
                        <th scope="col">Expert In</th>
                        <th scope="col">Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-2 mx-0">
                            <input type="checkbox" id="table-modal-45" checked>
                            <label for="table-modal-45">JoeMartyjoe</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.2</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-47" checked>
                            <label for="table-modal-47">Shawn667</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.8</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-46">
                            <label for="table-modal-46">Susan_2020</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.1</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-1" checked>
                            <label for="table-modal-1">Simon525</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.8</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-2">
                            <label for="table-modal-2">Richard252</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.8</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <div class="row mt-2 mb-2  justify-content-end">
            <div class="col-md-5 modaltable_btn">
              <button type="button" class="btn  disabled text-center w-100 default-btn">Send Request</button>
            </div>
          </div>
          <div class="row justify-content-end mb-3">
            <div class="col-12">
              <div class="modal-3-prblm-1">
                <h6><b>Notify other users to reply to your problem</b></h6>
              </div>
            </div>
            <div class="col-12 mt-3">
              <div class="table-modal-1">
                <p class="mb-2">Alternatively, you can ask the following users for help</p>
                <div class="table-modal-1-details">
                  <table class="table-modal-part-2 w-100 checkbox_listing-1 checkbox_listing-2">
                    <thead>
                      <tr>
                        <th scope="col" style="width: 45%;">User Name</th>
                        <th scope="col">Expert In</th>
                        <th scope="col">Score</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-2 mx-0">
                            <input type="checkbox" id="table-modal-450">
                            <label for="table-modal-450">JoeMartyjoe</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.2</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-471">
                            <label for="table-modal-471">Shawn667</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.8</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-461">
                            <label for="table-modal-461">Susan_2020</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.1</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-11">
                            <label for="table-modal-11">Simon525</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.8</td>
                      </tr>
                      <tr>
                        <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                            <input type="checkbox" id="table-modal-21">
                            <label for="table-modal-21">Richard252</label>
                          </div></td>
                        <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                        <td>4.8</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <div class="text-center blue-bg-under">
            <button type="button" id="modal-btn-8" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-10-next  

                     ***===============-->
        <div id="modal-no-10" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-12">
              <h5 class="mb-4">JoeMartyJoe has accepted to fix your problem</h5>
              <h6 class="mb-2"><b>JoeMartyJoe's</b> price for <a href="#">Remote Access Assistance</a> to fix your problem is:</h6>
              <h3 class="text-center my-3"><b>$35</b></h3>
              <h6 class="mt-2">If you're comfortable at this price then click 'Start Session' button to let him work on your Computer remotely. Otherwise, Decline this offer or Block this User</h6>
            </div>
          </div>
          <div class="modal-btn-box-10 mt-5 pt-4 mb-3">
            <div class="row justify-content-center">
              <button type="button" class="btn block-btn">Block User</button>
              <button type="button" class="btn decline-btn">Decline Offer</button>
              <button type="button" class="btn start-s-btn">Start Session for $35</button>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-10" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-11-next  

                     ***===============-->
        <div id="modal-no-11" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-12">
              <h5 class="mb-4">JoeMartyJoe has sent you a counter offer...</h5>
              <h6 class="mb-2"><b>JoeMartyJoe's</b> new price for <a href="#">Remote Access Assistance</a> to fix your problem is:</h6>
              <h3 class="text-center my-3"><b>$25</b></h3>
              <h6 class="mt-2">If you're comfortable at this price then click 'Start Session' button to let him work on your Computer remotely. Otherwise, Decline this offer or Block this User</h6>
            </div>
          </div>
          <div class="modal-btn-box-10 mt-5 pt-4 mb-3">
            <div class="row justify-content-center">
              <button type="button" class="btn block-btn">Block User</button>
              <button type="button" class="btn decline-btn">Decline Offer</button>
              <button type="button" class="btn start-s-btn">Start Session for $25</button>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-11" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-12-next  

                     ***===============-->
        <div id="modal-no-12" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-12">
              <h5 class="mb-4">JoeMartyJoe has sent you a custom offer...</h5>
              <h6 class="mb-2"><b>JoeMartyJoe's</b> price for <a href="#">Remote Access Assistance</a> to fix your problem is:</h6>
              <h3 class="text-center my-3"><b>$15</b></h3>
              <h6 class="mt-2">If you're comfortable at this price then click 'Start Session' button to let him work on your Computer remotely. Otherwise, Decline this offer or Block this User</h6>
              <h6 class="mt-3"><b>JoeMartyJoe's Message:</b></h6>
              <h6 class="mt-1">Okay! I reduced the price for you even more. It's hard work.</h6>
            </div>
          </div>
          <div class="modal-btn-box-10 mt-5 mb-3">
            <div class="row justify-content-center">
              <button type="button" class="btn block-btn">Block User</button>
              <button type="button" class="btn decline-btn">Decline Offer</button>
              <button type="button" class="btn start-s-btn">Start Session for $15</button>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-12" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-13-next  

                     ***===============-->
        <div id="modal-no-13" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-12">
              <h5 class="mb-4">Are you sure you want to block JoeMartyJoe?</h5>
              <h6 class="mb-4">Please choose a reason why you are blocking JoeMartyJoe?</h6>
              <form>
                <div class="form-group mb-0">
                  <div class="row mb-3">
                    <div class="col-md-12 mb-1">
                      <label for="exampleFormControlTextarea1"><b>Block Reason:</b></label>
                    </div>
                    <div class="col-md-12">
                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="5">Don't send me any more offers. I have declined your offer but you are continuously sending me offers with reduced prices. I am genuinely not interested so I am blocking you.</textarea>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="modal-btn-box-10 mt-5 mb-3">
            <div class="row justify-content-center">
              <div class="col-md-12">
                <button type="button" class="btn start-s-btn float-left">Cancel Block</button>
                <button type="button" class="btn block-btn float-right">Confirm Block</button>
              </div>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-13" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-14-next  

                     ***===============-->
        <div id="modal-no-14" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-md-12">
              <h5 class="mb-4">JoeMartyJoe has blocked you...</h5>
              <h6 class="mb-1"><b>Reason for Blocking:</b></h6>
              <h6 class="mb-4">I have already told you multiple times that I am not an expert on this issue and you are continuously sending me requests to handle this issue. Please do not ping me again.</h6>
            </div>
            <div class="col-md-12">
              <form>
                <div class="form-group mb-0">
                  <div class="row mb-4">
                    <div class="col-md-12">
                      <h6 class="mb-2"><b>Find another User:</b></h6>
                    </div>
                    <div class="col-md-3 pr-0 my-auto text-right">
                      <label for="exampleInputEmail1">User's Name</label>
                    </div>
                    <div class="col-md-9">
                      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Type here...">
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div class="col-md-12">
              <h6 class="mb-1"><b>Our Recommendation:</b></h6>
              <h6 class="mb-4">Search for similar fix/problem that addresses your issue to find another geek who is online.</h6>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-14" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-15-next  

                     ***===============-->
        <div id="modal-no-15" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5">
            <div class="col-md-12">
              <h5 class="mb-4">JoeMartyJoe has blocked you...</h5>
              <h6 class="mb-1"><b>Reason for Blocking:</b></h6>
              <h6 class="mb-4">I have already told you multiple times that I am not an expert on this issue and you are continuously sending me requests to handle this issue. Please do not ping me again.</h6>
            </div>
            <div class="col-md-12">
              <h6 class="mb-1"><b>Choose Another User:</b></h6>
              <h6 class="mb-4">There are other users online that can solve this problem. Click 'Choose Another User' to look for them.</h6>
            </div>
            <div class="col-md-12">
              <h6 class="mb-1"><b>Our Recommendation:</b></h6>
              <h6 class="mb-4">Search for similar fix/problem that addresses your issue to find another geek who is online.</h6>
            </div>
          </div>
          <div class="text-center mb-3 blue-bg-under">
            <button type="button" class="btn btn-primary default-btn ">Choose Another User</button>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-15" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-16-next  

                     ***===============-->
        <div id="modal-no-16" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-md-12">
              <h5 class="mb-4">JoeMartyJoe has denied assistance to you...</h5>
              <h6 class="mb-1"><b>Reason for Denial:</b></h6>
              <h6 class="mb-4">I am not an expert on this. I have no experience with animated Wallpapers in Windows 10. You can look for another geek. Thank you for contacting me!</h6>
            </div>
            <div class="col-md-12">
              <form>
                <div class="form-group mb-0">
                  <div class="row mb-4">
                    <div class="col-md-12">
                      <h6 class="mb-2"><b>Find another User:</b></h6>
                    </div>
                    <div class="col-md-3 pr-0 my-auto text-right">
                      <label for="exampleInputEmail1">User's Name</label>
                    </div>
                    <div class="col-md-9">
                      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Type here...">
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div class="col-md-12">
              <h6 class="mb-1"><b>Our Recommendation:</b></h6>
              <h6 class="mb-4">Search for similar fix/problem that addresses your issue to find another user who is online.</h6>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-16" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!-- /**********====== 

                           modal-17-next  

                     ***===============-->
        <div id="modal-no-17" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5">
            <div class="col-md-12">
              <h5 class="mb-4">JoeMartyJoe has denied assistance to you...</h5>
              <h6 class="mb-1"><b>Reason for Denial:</b></h6>
              <h6 class="mb-4">I am not an expert on this. I have no experience with animated Wallpapers in Windows 10. You can look for another geek. Thank you for contacting me!</h6>
            </div>
            <div class="col-md-12">
              <h6 class="mb-1"><b>Choose Another User:</b></h6>
              <h6 class="mb-4">There are other users online that can solve this problem. Click 'Choose Another User' to look for them.</h6>
            </div>
            <div class="col-md-12">
              <h6 class="mb-1"><b>Our Recommendation:</b></h6>
              <h6 class="mb-4">Search for similar fix/problem that addresses your issue to find another geek who is online.</h6>
            </div>
          </div>
          <div class="text-center mb-3 blue-bg-under">
            <button type="button" class="btn btn-primary default-btn ">Choose Another User</button>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-17" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--  modal-no-18 -->
        <div id="modal-no-18" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-12">
              <h5 class="mb-4">Are you sure you want to decline JoeMartyJoe?</h5>
              <h6 class="mb-4">Please choose a reason why you declined JoeMartyJoe for this task?</h6>
              <form>
                <div class="form-group mb-0">
                  <div class="row mb-3">
                    <div class="col-md-12 mb-1">
                      <label for="exampleFormControlTextarea1"><b>Decline Reason:</b></label>
                    </div>
                    <div class="col-md-12">
                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="5">That's ridiculously high rate. I won't pay $35 to just get an animated Wallpaper set on my desktop. Bye!
                                                </textarea>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="modal-btn-box-10 mt-5 mb-3">
            <div class="row justify-content-center">
              <div class="col-md-12">
                <button type="button" class="btn start-s-btn float-left">Cancel Decline</button>
                <button type="button" class="btn block-btn float-right">Confirm Decline</button>
              </div>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-18" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--  modal-no-19 -->
        <div id="modal-no-19" class="modal-blue-bg" style="display: none;">
          <div class="row mb-4">
            <div class="col-md-12">
              <h5 class="mb-3">JoeMartyJoe is assisting another user...</h5>
              <h6 class="mb-1"><b>Away Message:</b></h6>
              <h6 class="mb-3">I am going to be available by 5:00 pm. Please wait and send me request after 5:00 pm. You can leave me a message.</h6>
            </div>
            <div class="col-md-12">
              <h6 class="mb-1"><b>User's Time Slot:</b></h6>
              <h6 class="mb-3">JoeMartyJoe is online 5:00 pm to 7.30 pm every weekday.</h6>
            </div>
            <div class="col-md-12">
              <form>
                <div class="form-group mb-0">
                  <div class="row mb-3">
                    <div class="col-md-12">
                      <h6 class="mb-2"><b>Message this User:</b></h6>
                    </div>
                    <div class="col-md-12 mb-2">
                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>
                    </div>
                    <div class="col-md-12 text-right">
                      <button type="button" class="btn btn-primary default-btn btn-no-1">Send</button>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <h6 class="mb-2"><b>Find another User:</b></h6>
                    </div>
                    <div class="col-md-3 pr-0 my-auto text-right">
                      <label for="exampleInputEmail1">User's Name</label>
                    </div>
                    <div class="col-md-7 pr-0">
                      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Type here...">
                    </div>
                    <div class="col-md-2 pl-0">
                      <button type="button" class="btn btn-primary default-btn btn-no-2">Go</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-19" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--  modal-no-20 -->
        <div id="modal-no-20" class="modal-blue-bg" style="display: none;">
          <div class="row mb-4">
            <div class="col-md-12">
              <h5 class="mb-3">JoeMartyJoe is offline right now...</h5>
              <h6 class="mb-1"><b>Offline Message:</b></h6>
              <h6 class="mb-3">My regular working hours are from 3:00 pm to 6:00 pm. You can leave me a message.</h6>
            </div>
            <div class="col-md-12">
              <h6 class="mb-1"><b>User's Time Slot:</b></h6>
              <h6 class="mb-3">JoeMartyJoe is online 5:00 pm to 7.30 pm every weekday.</h6>
            </div>
            <div class="col-md-12">
              <form>
                <div class="form-group mb-0">
                  <div class="row mb-3">
                    <div class="col-md-12">
                      <h6 class="mb-2"><b>Message this User:</b></h6>
                    </div>
                    <div class="col-md-12 mb-2">
                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>
                    </div>
                    <div class="col-md-12 text-right">
                      <button type="button" class="btn btn-primary default-btn btn-no-1">Send</button>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <h6 class="mb-2"><b>Find another User:</b></h6>
                    </div>
                    <div class="col-md-3 pr-0 my-auto text-right">
                      <label for="exampleInputEmail1">User's Name</label>
                    </div>
                    <div class="col-md-7 pr-0">
                      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Type here...">
                    </div>
                    <div class="col-md-2 pl-0">
                      <button type="button" class="btn btn-primary default-btn btn-no-2">Go</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-20" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--  modal-no-21 -->
        <div id="modal-no-21" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-12">
              <h5 class="mb-4">Download and Run</h5>
              <h6 class="mb-4">You MUST download &amp; run <span>Remote Support App</span> to be able to receive <a href="#">Remote Access Assistance</a> from your chosen User.</h6>
              <h6 class="mb-4">Once you run it on your computer, the App will automatically continue your session with <b>JoeMartyJoe</b>.</h6>
            </div>
          </div>
          <div class="modal-btn-box-10 mt-5 pt-4 mb-3">
            <div class="row justify-content-center">
              <div class="col-md-12 text-center">
                <button type="button" class="btn start-s-btn">Download Now!</button>
              </div>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-21" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--  modal-no-22 -->
        <div id="modal-no-22" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-12">
              <h5 class="mb-4">Run Remote Support App</h5>
              <h6 class="mb-4">To continue with <a href="#">Remote Access Assistance,</a> you must run <span>Remote Support App.</span> You already have it in your computer.</h6>
              <h6 class="mb-4">Find <b>Remote-Support-gc.exe</b> in your browser's <b>Downloads folder.</b> If you can't locate it, download App again using button below.</h6>
              <h6 class="mb-4">Once you run it on your computer, the App will automatically continue your session with <b>JoeMartyJoe</b>.</h6>
            </div>
          </div>
          <div class="modal-btn-box-10 mt-5 mb-3">
            <div class="row justify-content-center">
              <div class="col-md-12 text-center">
                <button type="button" class="btn start-s-btn">Download Now!</button>
              </div>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-22" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--  modal-no-23 -->
        <div id="modal-no-23" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-12">
              <h5 class="mb-4">JoeMartyJoe can help you!</h5>
            </div>
            <div class="col-md-12 mb-5">
              <h6 class="mb-2">Choose a method you want <b>JoeMartyJoe</b> to use:</h6>
              <div class="form-check mb-1">
                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                <label class="form-check-label" for="exampleRadios1"> <b>Remote Access Assistance</b> to fix this problem </label>
              </div>
              <div class="form-check mb-1">
                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2">
                <label class="form-check-label" for="exampleRadios2"> <b>Screen Sharing &amp; Voice Chat</b> to fix this problem </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="option3">
                <label class="form-check-label" for="exampleRadios3"> <b>Text Chat Support</b> to fix this problem </label>
              </div>
            </div>
            <div class="col-md-12">
              <h6 class="mb-2">Would you like to install this app ?</h6>
              <div class="form-group-1">
                <input type="checkbox" id="modal-check-1088">
                <label for="modal-check-1088">Create Shortcuts on Desktop and Start Menu.</label>
              </div>
            </div>
          </div>
          <div class="modal-btn-box-10 mt-5 pt-2 mb-3">
            <div class="row justify-content-center">
              <div class="col-md-12 text-center">
                <button type="button" class="btn start-s-btn">Start Session</button>
              </div>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-23" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--  modal-no-24 -->
        <div id="modal-no-24" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-12">
              <h5 class="mb-4">Waiting for JoeMartyJoe to accept your session...</h5>
              <h6 class="mb-5 pb-5">Make sure your microphone &amp; speakers are turned on.</h6>
            </div>
          </div>
          <div class="modal-btn-box-10 mt-5 pt-5 mb-5">
            <div class="row justify-content-center">
              <div class="col-md-12 text-center">
                <!--                                    <button type="button" class="btn start-s-btn">Download Now!</button>-->
              </div>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-24" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--  modal-no-34 -->
        <div id="modal-no-34" class="modal-blue-bg" style="display: none;">
          <div class="row">
            <div class="col-md-12">
              <h5 class="mb-3">Your session has ended!</h5>
              <h6 class="mb-2">You were Charged <Span>35 USD total</Span></h6>
            </div>
            <div class="col-md-12 mb-2">
              <div class="row">
                <div class="col-md-7 pr-0 my-auto">
                  <h6><b>Did this User solve your issue?</b></h6>
                </div>
                <div class="col-md-5">
                  <div class="row problem-solve-btn">
                    <div class="col-md-6 pr-0">
                      <button type="button" class="btn start-s-btn w-100">Yes</button>
                    </div>
                    <div class="col-md-6 pl-0">
                      <button type="button" class="btn block-btn w-100">No</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <h6 class="mb-1">How would you rate this user?</h6>
              <div class="row mb-1">
                <div class="col-md-7 my-auto">
                  <h6>Conduct</h6>
                </div>
                <div class="col-md-5">
                  <fieldset class="rating">
                  <input type="radio" id="star5" name="rating" value="5" />
                  <label class="full" for="star5" title="Awesome - 5 stars"></label>
                  <input type="radio" id="star4half" name="rating" value="4.5" />
                  <label class="half" for="star4half" title="Pretty good - 4.5 stars"></label>
                  <input type="radio" id="star4" name="rating" value="4" />
                  <label class="full" for="star4" title="Pretty good - 4 stars"></label>
                  <input type="radio" id="star3half" name="rating" value="3.5" />
                  <label class="half" for="star3half" title="Meh - 3.5 stars"></label>
                  <input type="radio" id="star3" name="rating" value="3" />
                  <label class="full" for="star3" title="Meh - 3 stars"></label>
                  <input type="radio" id="star2half" name="rating" value="2.5" />
                  <label class="half" for="star2half" title="Kinda bad - 2.5 stars"></label>
                  <input type="radio" id="star2" name="rating" value="2" />
                  <label class="full" for="star2" title="Kinda bad - 2 stars"></label>
                  <input type="radio" id="star1half" name="rating" value="1.5" />
                  <label class="half" for="star1half" title="Meh - 1.5 stars"></label>
                  <input type="radio" id="star1" name="rating" value="1" />
                  <label class="full" for="star1" title="Sucks big time - 1 star"></label>
                  <input type="radio" id="starhalf" name="rating" value="0.5" />
                  <label class="half" for="starhalf" title="Sucks big time - 0.5 stars"></label>
                  </fieldset>
                </div>
              </div>
              <div class="row mb-1">
                <div class="col-md-7 my-auto">
                  <h6>Timing/Speed</h6>
                </div>
                <div class="col-md-5">
                  <fieldset class="rating">
                  <input type="radio" id="star5-2" name="rating2" value="5" />
                  <label class="full" for="star5-2" title="Awesome - 5 stars"></label>
                  <input type="radio" id="star4half-2" name="rating2" value="4.5" />
                  <label class="half" for="star4half-2" title="Pretty good - 4.5 stars"></label>
                  <input type="radio" id="star4-2" name="rating2" value="4" />
                  <label class="full" for="star4-2" title="Pretty good - 4 stars"></label>
                  <input type="radio" id="star3half-2" name="rating2" value="3.5" />
                  <label class="half" for="star3half-2" title="Meh - 3.5 stars"></label>
                  <input type="radio" id="star3-2" name="rating2" value="3" />
                  <label class="full" for="star3-2" title="Meh - 3 stars"></label>
                  <input type="radio" id="star2half-2" name="rating2" value="2.5" />
                  <label class="half" for="star2half-2" title="Kinda bad - 2.5 stars"></label>
                  <input type="radio" id="star2-2" name="rating2" value="2" />
                  <label class="full" for="star2-2" title="Kinda bad - 2 stars"></label>
                  <input type="radio" id="star1half-2" name="rating2" value="1.5" />
                  <label class="half" for="star1half-2" title="Meh - 1.5 stars"></label>
                  <input type="radio" id="star1-2" name="rating2" value="1" />
                  <label class="full" for="star1-2" title="Sucks big time - 1 star"></label>
                  <input type="radio" id="starhalf-2" name="rating2" value="0.5" />
                  <label class="half" for="starhalf-2" title="Sucks big time - 0.5 stars"></label>
                  </fieldset>
                </div>
              </div>
              <div class="row mb-1">
                <div class="col-md-7 my-auto">
                  <h6>English Literacy</h6>
                </div>
                <div class="col-md-5">
                  <fieldset class="rating">
                  <input type="radio" id="star5-3" name="rating3" value="5" />
                  <label class="full" for="star5-3" title="Awesome - 5 stars"></label>
                  <input type="radio" id="star4half-3" name="rating3" value="4.5" />
                  <label class="half" for="star4half-3" title="Pretty good - 4.5 stars"></label>
                  <input type="radio" id="star4-3" name="rating3" value="4" />
                  <label class="full" for="star4-3" title="Pretty good - 4 stars"></label>
                  <input type="radio" id="star3half-3" name="rating3" value="3.5" />
                  <label class="half" for="star3half-3" title="Meh - 3.5 stars"></label>
                  <input type="radio" id="star3-3" name="rating3" value="3" />
                  <label class="full" for="star3-3" title="Meh - 3 stars"></label>
                  <input type="radio" id="star2half-3" name="rating3" value="2.5" />
                  <label class="half" for="star2half-3" title="Kinda bad - 2.5 stars"></label>
                  <input type="radio" id="star2-3" name="rating3" value="2" />
                  <label class="full" for="star2-3" title="Kinda bad - 2 stars"></label>
                  <input type="radio" id="star1half-3" name="rating3" value="1.5" />
                  <label class="half" for="star1half-3" title="Meh - 1.5 stars"></label>
                  <input type="radio" id="star1-3" name="rating3" value="1" />
                  <label class="full" for="star1-3" title="Sucks big time - 1 star"></label>
                  <input type="radio" id="starhalf-3" name="rating3" value="0.5" />
                  <label class="half" for="starhalf-3" title="Sucks big time - 0.5 stars"></label>
                  </fieldset>
                </div>
              </div>
              <div class="row mb-1">
                <div class="col-md-7 my-auto">
                  <h6>Technical Knowledge</h6>
                </div>
                <div class="col-md-5">
                  <fieldset class="rating">
                  <input type="radio" id="star54" name="rating4" value="5" />
                  <label class="full" for="star54" title="Awesome - 5 stars"></label>
                  <input type="radio" id="star4half4" name="rating4" value="4.5" />
                  <label class="half" for="star4half4" title="Pretty good - 4.5 stars"></label>
                  <input type="radio" id="star44" name="rating4" value="4" />
                  <label class="full" for="star44" title="Pretty good - 4 stars"></label>
                  <input type="radio" id="star3half4" name="rating4" value="3.5" />
                  <label class="half" for="star3half4" title="Meh - 3.5 stars"></label>
                  <input type="radio" id="star34" name="rating4" value="3" />
                  <label class="full" for="star34" title="Meh - 3 stars"></label>
                  <input type="radio" id="star2half4" name="rating4" value="2.5" />
                  <label class="half" for="star2half4" title="Kinda bad - 2.5 stars"></label>
                  <input type="radio" id="star24" name="rating4" value="2" />
                  <label class="full" for="star24" title="Kinda bad - 2 stars"></label>
                  <input type="radio" id="star1half4" name="rating4" value="1.5" />
                  <label class="half" for="star1half4" title="Meh - 1.5 stars"></label>
                  <input type="radio" id="star14" name="rating4" value="1" />
                  <label class="full" for="star14" title="Sucks big time - 1 star"></label>
                  <input type="radio" id="starhalf4" name="rating4" value="0.5" />
                  <label class="half" for="starhalf4" title="Sucks big time - 0.5 stars"></label>
                  </fieldset>
                </div>
              </div>
              <div class="row mb-1">
                <div class="col-md-7 my-auto">
                  <h6>Typing Speed</h6>
                </div>
                <div class="col-md-5">
                  <fieldset class="rating">
                  <input type="radio" id="star5-5" name="rating-5" value="5" />
                  <label class="full" for="star5-5" title="Awesome - 5 stars"></label>
                  <input type="radio" id="star4half-5" name="rating-5" value="4.5" />
                  <label class="half" for="star4half-5" title="Pretty good - 4.5 stars"></label>
                  <input type="radio" id="star4-5" name="rating-5" value="4" />
                  <label class="full" for="star4-5" title="Pretty good - 4 stars"></label>
                  <input type="radio" id="star3half-5" name="rating-5" value="3.5" />
                  <label class="half" for="star3half-5" title="Meh - 3.5 stars"></label>
                  <input type="radio" id="star3-5" name="rating-5" value="3" />
                  <label class="full" for="star3-5" title="Meh - 3 stars"></label>
                  <input type="radio" id="star2half-5" name="rating-5" value="2.5" />
                  <label class="half" for="star2half-5" title="Kinda bad - 2.5 stars"></label>
                  <input type="radio" id="star2-5" name="rating-5" value="2" />
                  <label class="full" for="star2-5" title="Kinda bad - 2 stars"></label>
                  <input type="radio" id="star1half-5" name="rating-5" value="1.5" />
                  <label class="half" for="star1half-5" title="Meh - 1.5 stars"></label>
                  <input type="radio" id="star1-5" name="rating-5" value="1" />
                  <label class="full" for="star1-5" title="Sucks big time - 1 star"></label>
                  <input type="radio" id="starhalf-5" name="rating-5" value="0.5" />
                  <label class="half" for="starhalf-5" title="Sucks big time - 0.5 stars"></label>
                  </fieldset>
                </div>
              </div>
              <div class="row mb-1">
                <div class="col-md-7 my-auto">
                  <h6>PC Handling</h6>
                </div>
                <div class="col-md-5">
                  <fieldset class="rating">
                  <input type="radio" id="star56" name="rating6" value="5" />
                  <label class="full" for="star56" title="Awesome - 5 stars"></label>
                  <input type="radio" id="star4half6" name="rating6" value="4.5" />
                  <label class="half" for="star4half6" title="Pretty good - 4.5 stars"></label>
                  <input type="radio" id="star46" name="rating6" value="4" />
                  <label class="full" for="star46" title="Pretty good - 4 stars"></label>
                  <input type="radio" id="star3half6" name="rating6" value="3.5" />
                  <label class="half" for="star3half6" title="Meh - 3.5 stars"></label>
                  <input type="radio" id="star36" name="rating6" value="3" />
                  <label class="full" for="star36" title="Meh - 3 stars"></label>
                  <input type="radio" id="star2half6" name="rating6" value="2.5" />
                  <label class="half" for="star2half6" title="Kinda bad - 2.5 stars"></label>
                  <input type="radio" id="star26" name="rating6" value="2" />
                  <label class="full" for="star26" title="Kinda bad - 2 stars"></label>
                  <input type="radio" id="star1half6" name="rating6" value="1.5" />
                  <label class="half" for="star1half6" title="Meh - 1.5 stars"></label>
                  <input type="radio" id="star16" name="rating6" value="1" />
                  <label class="full" for="star16" title="Sucks big time - 1 star"></label>
                  <input type="radio" id="starhalf6" name="rating6" value="0.5" />
                  <label class="half" for="starhalf6" title="Sucks big time - 0.5 stars"></label>
                  </fieldset>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <form>
                <div class="form-group mb-0">
                  <div class="row mb-2">
                    <div class="col-md-12">
                      <h6 class="mb-2"><b>Leave a review:</b></h6>
                    </div>
                    <div class="col-md-12 mb-2">
                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="text-center mb-2 blue-bg-under">
            <button type="button" class="btn btn-primary default-btn ">Submit</button>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-34" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--  modal-no-35 -->
        <div id="modal-no-35" class="modal-blue-bg" style="display: none;">
          <div class="row">
            <div class="col-12">
              <h5 class="mb-3">Do you want to Audit this case?</h5>
              <p class="mb-3">If you want us to audit this case, you may submit the form below which would initiate the arbitary process. Based on this process, in the best case you'll get your money back and the worst case you <span>may loose your account with us forever.</span></p>
            </div>
            <div class="col-md-12 mb-2">
              <div class="row">
                <div class="col-md-8 pr-0 my-auto">
                  <h6>Did the user tried his best to fix the problem?</h6>
                </div>
                <div class="col-md-4 pl-0">
                  <div class="row problem-solve-btn">
                    <div class="col-md-6 pr-0">
                      <button type="button" class="btn start-s-btn w-100">Yes</button>
                    </div>
                    <div class="col-md-6 pl-0">
                      <button type="button" class="btn block-btn w-100">No</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12 mb-2">
              <div class="row">
                <div class="col-md-8 pr-0 my-auto">
                  <h6>Did the user disconnected in the middle?</h6>
                </div>
                <div class="col-md-4 pl-0">
                  <div class="row problem-solve-btn">
                    <div class="col-md-6 pr-0">
                      <button type="button" class="btn start-s-btn w-100">Yes</button>
                    </div>
                    <div class="col-md-6 pl-0">
                      <button type="button" class="btn block-btn w-100">No</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12 mb-2">
              <div class="row">
                <div class="col-md-8 pr-0 my-auto">
                  <h6>Was the problem so unique that fix wasn't possible?</h6>
                </div>
                <div class="col-md-4 pl-0">
                  <div class="row problem-solve-btn">
                    <div class="col-md-6 pr-0">
                      <button type="button" class="btn start-s-btn w-100">Yes</button>
                    </div>
                    <div class="col-md-6 pl-0">
                      <button type="button" class="btn block-btn w-100">No</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12 mb-2">
              <div class="row">
                <div class="col-md-8 pr-0 my-auto">
                  <h6>Was User rude, suspecious or tried to scam?</h6>
                </div>
                <div class="col-md-4 pl-0">
                  <div class="row problem-solve-btn">
                    <div class="col-md-6 pr-0">
                      <button type="button" class="btn start-s-btn w-100">Yes</button>
                    </div>
                    <div class="col-md-6 pl-0">
                      <button type="button" class="btn block-btn w-100">No</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12 mt-2">
              <form>
                <div class="form-group mb-0">
                  <div class="row mb-2">
                    <div class="col-md-12">
                      <h6 class="mb-2">Type briefly what exactly happened for us to investigate:</h6>
                    </div>
                    <div class="col-md-12 mb-2">
                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="modal-btn-box-10 mb-2">
            <div class="row justify-content-center">
              <div class="col-md-12">
                <button type="button" class="btn start-s-btn float-left">I don't have a Claim</button>
                <button type="button" class="btn block-btn float-right">Submit Claim</button>
              </div>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-35" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--  modal-no-36 -->
        <div id="modal-no-36" class="modal-blue-bg" style="display: none;">
          <div class="row">
            <div class="col-12">
              <h5 class="mb-2">JoeMartyJoe has remote access to your PC</h5>
            </div>
            <div class="col-md-12 mb-2">
              <div class="row">
                <div class="col-md-7">
                  <ul class="modal-36-list">
                    <li class="mb-1 spl-modal-li"><b>Access Granted</b></li>
                    <li class="mb-1"><a class="unfix-p" href="#"><i class="fa fa-times" aria-hidden="true"></i> Cursor</a></li>
                    <li class="mb-1"><a class="unfix-p" href="#"><i class="fa fa-times" aria-hidden="true"></i> Keyboard</a></li>
                    <li class="mb-1"><a class="unfix-p" href="#"><i class="fa fa-times" aria-hidden="true"></i> File Transfer</a></li>
                    <li class="mb-1"><a class="unfix-p" href="#"><i class="fa fa-times" aria-hidden="true"></i> Screen</a></li>
                    <li class="mb-1"><a class="unfix-p" href="#"><i class="fa fa-times" aria-hidden="true"></i> Voice</a></li>
                    <li><a class="fix-p" href="#"><i class="fa fa-caret-down" aria-hidden="true"></i> Chat</a></li>
                  </ul>
                </div>
                <div class="col-md-5">
                  <h6>Elapsed Time: <b>3:12</b></h6>
                </div>
              </div>
            </div>
            <div class="col-md-12 mb-1">
              <div class="modal-chat-box">
                <div class="row mx-0">
                  <div class="col-md-12">
                    <h6 class="mb-1"><span>JoeMartyJoe:</span> Hi, Can I transfer a file to your PC for diagnosis?</h6>
                    <h6 class="mb-1"><span>MarkShelby:</span> No, what software is that?</h6>
                    <h6 class="typing-h6">JoeMartyJoe is typing...</h6>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12 mt-2">
              <form>
                <div class="form-group mb-0">
                  <div class="row mb-2">
                    <div class="col-md-12 mb-2">
                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Type here..."></textarea>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="modal-btn-box-10 mb-2">
            <div class="row justify-content-center">
              <div class="col-md-12">
                <button type="button" class="btn block-btn float-left">End Session now!</button>
                <button type="button" class="btn start-s-btn float-right">Send</button>
              </div>
            </div>
          </div>
          <div class="text-center my-2 modal-bg-under blue-bg-under">
            <button type="button" id="modal-btn-36" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--  modal-no-37 -->
        <div id="modal-no-37" class="modal-blue-bg" style="display: none;">
          <div class="row mb-3">
            <div class="col-12 payemnt_modal">
              <h5>Pay now is continue.Your free session is over</h5>
              <h6 class="mt-2">After 5 minutes of free session,you are required to make a payment to continue</h6>
              <p class="mt-2 red_user-1"><b>joeMartyjoe can"t see this payment window and his remote access to your computer is locked.</b></p>
              <p class="mt-3">If you are not satisfied with <b>joeMartyjoe</b>click 'End Session' joeMartyjoe will be notified about it.Once payment is accepted, joeMartyjoe will continue where he left.</p>
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-5 modal2User_grp text-right my-auto pr-0">
              <p>Name On Card</p>
            </div>
            <div class="col-7">
              <div class="form-group mb-0">
                <input type="text" class="form-control modal2from_grp" id="exampleFormControlInput1" placeholder="">
              </div>
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-5 modal2User_grp text-right my-auto pr-0">
              <p>Credit Card Number</p>
            </div>
            <div class="col-7">
              <div class="form-group mb-0">
                <input type="text" class="form-control modal2from_grp" id="exampleFormControlInput1" placeholder="">
              </div>
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-7 pr-0">
              <div class="row mx-0">
                <div class="col-6 px-0 text-right modal2User_grp my-auto">
                  <p>Expiration Date</p>
                </div>
                <div class="col-6 pr-0 modal2User_grp my-auto">
                  <div class="form-group mb-0">
                    <input type="date" class="form-control modal2from_grp" id="exampleFormControlInput1" placeholder="">
                  </div>
                </div>
              </div>
            </div>
            <div class="col-5">
              <div class="row mx-0">
                <div class="col-5 px-0  text-right modal2User_grp my-auto">
                  <p>CVC</p>
                </div>
                <div class="col-7 pr-0 modal2User_grp my-auto">
                  <div class="form-group mb-0">
                    <input type="text" class="form-control modal2from_grp" id="exampleFormControlInput1" placeholder="">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col-7">
              <div class="pay-lock">
                <p>This transaction is SSL <i class="fa fa-lock"></i> secured</p>
              </div>
            </div>
            <div class="col-5 text-right">
              <p>Your Charge: <b>35 USD</b></p>
            </div>
          </div>
          <div class="row justify-content-start mb-4">
            <div class="col-7">
              <div class="payment-img">
                <ul>
                  <li><img src="<?php echo base_url();?>assets/images/mastercard_PNG13.png" width="15" alt=""></li>
                  <li><img src="<?php echo base_url();?>assets/images/_visa-png-verified-by-visa-logo-png.png" width="15" alt=""></li>
                  <li><img src="<?php echo base_url();?>assets/images/mastercard_PNG13.png" width="15" alt=""></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="modal-btn-box-10 mb-5">
            <div class="row justify-content-center">
              <div class="col-md-12">
                <button type="button" class="btn block-btn float-left">End Session now!</button>
                <button type="button" class="btn start-s-btn float-right">Send</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>