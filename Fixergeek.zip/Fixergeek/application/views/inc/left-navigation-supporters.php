<?php
   error_reporting(0);
   
   if($this->session->userdata('id')=="")
   {
	  $this->load->view('inc/leftpanel');
   }
   
   else
   {
      $query = $this->db->query("select * from `fixergeek_master` where `user_id` = '".$this->session->userdata('id')."'");
	  $numrow = $query->num_rows();

	  if($numrow!=0)
	  {
	    $this->load->view('inc/fixergeekleftpanel');
	  }
	  else
	  {
	    $this->load->view('inc/askerleftpanel');
	  }
   }
   
 ?> 