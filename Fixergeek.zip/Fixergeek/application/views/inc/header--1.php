<?php
    $geek = $this->db->query("select * from `fixergeek_master` where `user_id` = '".$this->session->userdata('id')."'");
    $numrow = $geek->num_rows();
	
	$record = $this->db->query("select * from `user_master` where `id` = '".$this->session->userdata('id')."'")->row();
 
	// PHP code to obtain country, city,  
	// continent, etc using IP Address 
	  
	$ip = $_SERVER['REMOTE_ADDR']; 
	  
	 // Use JSON encoded string and converts 
	 // it into a PHP variable 
	 $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip)); 
	 $country = $ipdat->geoplugin_countryName;  
?> 
<!--header-start-->
<header>
  <div class="total-menu">
    <nav class="navbar navbar-expand-lg navbar-light">
      <div class="container">
          <!-- logo-->
          <div class="navbar-brand dropdown logo">
              <button class="ns" type="button" id="dropdownMenuButton" 
              onclick="window.location.href='<?php echo base_url();?>'" />
                <img src="<?php echo base_url();?>assets2/images/fixergeek_logo1.gif" border="0" alt=""> 
              </button>
              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item" href="<?php echo base_url();?>"> Go To Home </a>
                <a class="dropdown-item" href="<?php echo base_url();?>howitworks"> How it Works? </a>
                <a class="dropdown-item" href="<?php echo base_url();?>privacy">Privacy Policy</a>
                <a class="dropdown-item" href="<?php echo base_url();?>terms">Terms Of Use</a>
                <a class="dropdown-item" href="<?php echo base_url();?>about">About Us</a>
              </div>
          </div>
      
       <!-- logo ends --> 
        
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" 
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> 
            <span class="navbar-toggler-icon"></span> 
          </button>
          
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
             <ul class="navbar-nav ml-auto main-menu">
                  <li class="nav-item dropdown ds">
                <a class="nav-link dropdown-toggle fix_id" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Fixes <b class="caret"></b>
                </a>
                <ul class="dropdown-menu menu-mobile1" aria-labelledby="navbarDropdownMenuLink">
                    <?php
                       $query = $this->db->query('Select * from `category_master` order by ordering');
				  	    foreach($query->result() as $res)
	                     {
				    ?>
                     <li class="dropdown-submenu <?php if($res->id==1){?>main-dw<?php } else {?>new-2<? }?>">
                     	<a class="dropdown-item dropdown-toggle" href="#"><?=$res->category_name?></a>
                          <ul class="dropdown-menu new-1">
						    <?php 
                                 $subcat = $this->db->query("select * from `sub_category_master` where cat_id = '".$res->id."'");
                                 foreach($subcat->result() as $row) 
                                 {
                             ?>
                              <li class="dropdown-submenu">
                              <a class="dropdown-item dropdown-toggle" href="#"><?=$row->sub_category_name?></a>
                                  <ul class="dropdown-menu sub-new-1 margin-space">
                                     <?php
										  $mcat = $this->db->query("select * from `sub_sub_category_master` where sub_cat_id = '".$row->id."'");
										  foreach($mcat->result() as $rec) 
                                          { 
                  					 ?>
                                     <li>
                                 <a class="dropdown-item" href="<?php echo base_url();?>category/show/<?=(str_replace("&","-",str_replace(" ","_",$rec->sub_sub_category_name)))?>">
								  <?=$rec->sub_sub_category_name?>
                                 </a>
                                     </li>
                                   <?php
										} 
								   ?>
                                  </ul>
                              </li>
                            <?php 
								}
							  ?>
                          </ul>
                     </li>
                   <?php
                      }
				  ?>
                </ul>
              </li>
                  <li class="nav-item">
                    <a class="nav-link " href="<?php echo base_url();?>problems">Problems</a>
                  </li>
                  <li class="nav-item spa-padding">
                    <div class="search-area menu-mobile2">
                      
                     <form action="<?php echo base_url();?>details/search" method="post" class="form-inline my-2 my-lg-0" id="search_form">
                     
                                <div class="searchable">
                                <input class="form-control border header-search position-relative" type="text" placeholder="SEARCH FIXES" name="category" value="<?=$this->input->post('category');?>" onkeyup="filterFunction(this,event)" id="category" autocomplete="off">
                               
                                <!--<ul style="display: none;">
                                <?php 
									/*$sub_qry=$this->db->get('sub_sub_category_master')->result();
									foreach ($sub_qry as $sub) 
									{
                                ?>
                                   <li><?=$sub->sub_sub_category_name?></li>
                                <?php
								    } */
								 ?>

                                </ul>-->
                                </div>
                                <button class="btn btn-outline-success border header-search-btn my-sm-0" type="submit">
                                <i class="fa fa-search"></i></button>
                                <div class="nav-item header-dropdown po dropdown dropdown12 search-dropdown-sp" id="select_designatfirst">
                                <a class="nav-link header_dropdown_content_link dropdown-toggle" href="#" id="navbarDropdown2" 
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                </a>
                                <div class="dropdown-menu serach-div  header-dropdown-content" aria-labelledby="navbarDropdown2">
                                    <a style="cursor: pointer;" class="dropdown-item" id="fixex">SEARCH FIXES</a>
                                    <a style="cursor: pointer;" class="dropdown-item" id="problems">SEARCH PROBLEMS</a>
                                   <!-- <a style="cursor: pointer;" class="dropdown-item" id="fixer_geek">FIXER GEEKS</a>-->
                               </div>
                          </div>
                        </form>
                    </div>
                     
                  </li>
                  <li class="nav-item dropdown gek-dp">
                    <a class="nav-link dropdown-toggle" href="<?php echo base_url();?>podium" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Download App </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown2">
                       <li> <a class="dropdown-item" href="#"> For Windows </a> </li>
                       <li> <a class="dropdown-item" href="#"> For Mac </a> </li>
                       <li> <a class="dropdown-item" href="#"> For ios </a> </li>
                       <li> <a class="dropdown-item" href="#"> For Android </a> </li>
                    </ul>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link " href="<?php echo base_url();?>podium"> Meet Geeks </a>
                  </li>
                  
                  <li class="nav-item dropdown sp-drop">
                    <a class="nav-link dropdown-toggle special-user-avtar" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                     <?php if($this->session->userdata('id')=="") {?>
                       <i class="far fa-user-circle"></i> 
                     <?php } else { ?>
                       <img src="<?php echo base_url();?>uploads/<?=$record->profile_picture?>" border="0">
                     <?php }?>
                    </a>
                    
                    <?php if($this->session->userdata('id')=="") {?>
                    <div class="dropdown-menu sign-up-section">
                      <div class="head-form">
                          <div class="head-form">
                            <div class="pro-drop-header">
                              <p>Fixer Geek!</p>
                            </div>
                            <div class="new-add-text-login">
                              <h4> Welcome to fixer geek! </h4>
                              <p> To continue, please login</p>
                            </div>
                            <form action="<?php echo base_url();?>signin/login_user" method="post" name="frm" id="loginfrm" autocomplete="off"> 
                            <div class="form-dp">
                              <div class="top-sec-dp new-login-div">
                                  <h4> Login </h4>
                                  <div class="form-group">
                                    <label> User Name</label>
                                  <input type="text" name="geek_name" id="user_name" placeholder="" class="form-control">
                                  </div>
                                  <div class="form-group">
                                    <label> Password </label>
                                    <input type="password" name="password" id="password" placeholder="" class="form-control" required>
                                  </div>
                                  
                                  <div class="header-drop-links-first">
                                    <div class="log-with-box">
                                      <div class="login-text-new">
                                         <p>Or Login With</p>
                                       </div>
                                       <div class="forget-sec">
                                        <ul class="socal-media">
                                          <li>
                                            <a class="spl-facebook facebook icon-new"  href="#"><i class="fab fa-facebook-square"></i>
                                            </a>
                                          
                                            <!--<fb:login-button id="facebook"
                                              scope="public_profile,email"
                                              onlogin="checkLoginState();">
                                            </fb:login-button>
                                             <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v7.0&appId=571891813717008&autoLogAppEvents=1" nonce="ONsqo05N"></script>-->
                                             
                                          </li>
                                          <li>
                                          <a class="spl-google google_login icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                                           </a></li>
                                          <li>
                                          <a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                                           </a>
                                           </li>
                                          <li>
                                          <a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                                           </a></li>
                                        </ul>
                                        
                                        <div class="sub-link">
                                           <a href="#">Lost Password </a> or <a href="#"> User Name</a>
                                        </div>
                                       </div>
                                    </div>
                                   
                                   <div class="signup-sec-add">
                                      <h4> Aren'ta Geek yet? </h4>
                                      <a href="#" class="signup-bn-login"> Signup now </a>
                                   </div>
                                   <button type="button" id="login_btn3" class="btn default-btn login">Log In</button>   
                                 </div>
                                  
                                  
                              </div>
                            </div>
                            </form>
                            
                          </div>
                      </div>
                    </div>
                    <?php } else { ?>
                    
                     <ul class="dropdown-menu sign-up-section" style="width:200px; margin-top:5px;">
                       <?php if($numrow!=0) { ?>
                          <li><a href="<?php echo base_url();?>fixeroverview">Overview</a></li>
                          <li><a href="<?php echo base_url();?>profile">Profile</a></li>
                          <li><a href="<?php echo base_url();?>accountsettings">Account Settings</a></li>
                          <li><a href="<?php echo base_url();?>accountscoreandcomments">Score & Comments</a></li>
                          <li><a href="<?php echo base_url();?>accountsupportersettings">Fixer Geek Settings</a></li>
                          <li><a href="<?php echo base_url();?>fixerproblems">Your Fixes & Problems</a></li>
                          <li><a href="<?php echo base_url();?>messages">Messages</a></li>
                          <li><a href="<?php echo base_url();?>notifications">Notifications</a></li>
                          <li><a href="<?php echo base_url();?>securitysettings">Security Settings</a></li>
                        <?php } else { ?>
                          <li><a href="<?php echo base_url();?>askeroverview">Overview</a></li>
                          <li><a href="<?php echo base_url();?>profile">Profile</a></li>
                          <li><a href="<?php echo base_url();?>becomeasupporter">Become a fixer</a></li>
                          <li><a href="<?php echo base_url();?>askerproblems">Your fixes & problems</a></li>
                          <li><a href="<?php echo base_url();?>messages">Messages</a></li>
                          <li><a href="<?php echo base_url();?>notifications">Notifications</a></li>
                          <li><a href="<?php echo base_url();?>askersettings">Account Settings</a></li>
                          <li><a href="<?php echo base_url();?>securitysettings">Security Settings</a></li>
                        <?php }?>
                        <li><a href="<?php echo base_url();?>signin/user_logout" onclick="signOut();">Log Out</a></li>
                      </ul>
                    
                    <?php } ?>
                  </li>
                  
                  <li class="nav-item">
                        <?php
						  if($numrow!=0)
						  {
						  ?>
						  <a class="nav-link border-right-1 bg-green-1" href="#" data-toggle="modal"  data-target="#comon-page-Modal">Ask Question</a>
						  <?php
						   }
						   else
						   {
						  ?>
						  <a class="nav-link border-right-1 bg-green-1" href="#" data-toggle="modal"  data-target="#exampleModal">Ask Question</a> 
					  <?php
					   }
					 ?>
                  </li>
                </ul>
          </div>
       </div>
    </nav>
  </div>
</header>

<script>
  $(document).ready(function(){
   $("#fixex").click(function(){
      //$("#category").val($(this).text());
	  $("#category").attr("placeholder", "SEARCH FIXES");
      $("#search_form").attr('action', '<?php echo base_url();?>category'); 
    });
    $("#problems").click(function(){
       //$("#category").val($(this).text());
	   $("#category").attr("placeholder", "SEARCH PROBLEMS");
       $("#search_form").attr('action', '<?php echo base_url();?>problems');
        });
     $("#fixer_geek").click(function(){
       $("#category").val($(this).text());
       $("#search_form").attr('action', '<?php echo base_url();?>podium');
        });
     $("#category").click(function(){
       $("#search_form").attr('action', '<?php echo base_url();?>details/search');
         
        });
     $('.google_login').click(function() {

     $('.abcRioButtonContentWrapper').click();

      });

    });
</script>
<script>
  $(document).ready(function(){
    $('.facebook').click(function() {
      $('._51mx').click();
      });

    });
</script>

<script>
    $(document).ready(function()
	{
		 /*$("#login_btn3").click(function(){
		  var user_name = $("#user_name").val();
		  var password = $("#password").val();
			   
		  if(password=='' || user_name=='')
		  {
			 swal("Sorry!! Insert Your Login Data");
		  }
		  else
		  {
			$.ajax({
			url:'<?php //echo base_url();?>home/login',
			type:'post',
			data:{user_name:user_name,password:password},
			success:function(data)
			{
			  if(data=='success')
			  {
				location.reload(true);
			  }
			  else
			  {
			   $('#txt').html("Wrong username or password!");
			  }
			}
		  });
		  }
	   
		 });*/
		 
		  $("#login_btn3").click(function()
			{
			  var user_name = $("#user_name").val();
			  var password = $("#password").val();
				   
			  if(password=='' || user_name=='')
			  {
				 swal("Sorry!! Insert Your Login Data");
			  }
			  else
			  {
			    // var url = "<?php //echo base_url();?>home/login/"+user_name+"/"+password;
				 
				 //$.ajax({url: "<?php //echo base_url();?>signin/login_user/"+user_name+"/"+password, success: function(result){
					 //location.reload(true);
				 // }});
				 
				 $("#loginfrm").submit();
			  }
			});
   });
</script>