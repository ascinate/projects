<!DOCTYPE html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Fixer Geek</title>
<meta name="google-signin-client_id" content="228221605755-5kcu9jjf5gqcapka3r4rqa0s817jb1o8.apps.googleusercontent.com">

<link rel="icon" href="<?php echo base_url();?>assets2/images/favicon.png" sizes="16x16" type="image/png">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?php echo base_url();?>assets2/css/flag-dropdown.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets2/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets2/css/bootstrap-select.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets2/css/dataTables.bootstrap4.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.3/css/selectize.bootstrap3.min.css"
type="text/css" media="all">

<link href="<?php echo base_url();?>assets2/css/datepicker.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>assets2/css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>assets2/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
<!-- fonts--->
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet">

<!-- custom-css-->
<link rel="stylesheet" href="<?php echo base_url();?>assets2/css/datatables.min.css" type="text/css">

<!--owl slider----->
<link href="<?php echo base_url();?>assets2/css/owl.carousel.min.css" rel="stylesheet" media="all">
<link href="<?php echo base_url();?>assets2/css/owl.theme.default.min" rel="stylesheet" media="all">

<!-- my custom-css-->
<link rel="stylesheet" href="<?php echo base_url();?>assets2/css/header.css" type="text/css">
<link rel="stylesheet" href="<?php echo base_url();?>assets2/css/style2.css" type="text/css">
<link href="<?php echo base_url();?>assets2/css/style.css" rel="stylesheet" media="all">
<link href="<?php echo base_url();?>assets2/css/mobile.css" rel="stylesheet" media="all">
<!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css"> -->
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<!-- bootsratp js-->
<!--<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>-->
<!--<script src="https://cdn.ckeditor.com/4.11.2/standard/ckeditor.js"></script>-->

<!--<script src="https://cdn.ckeditor.com/ckeditor5/23.0.0/classic/ckeditor.js"></script>-->

<script src="<?php echo base_url();?>assets2/js/jquery-3.4.1.min.js"></script>
<script src="<?php echo base_url();?>assets2/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets2/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets2/js/bootstrap-select.min.js"></script>

<!-- <script src="<?php echo base_url();?>assets2/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets2/js/datatables.min.js" type="text/javascript"></script> -->

<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>assets2/js/newdataTables.bootstrap4.min.js"></script>
<script src="https://apis.google.com/js/platform.js" async defer></script>

<script src="https://cdn.tiny.cloud/1/6onzquwrj53griyp5ze592appo6q1yxjy2t14l4uakhqkc5t/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
  $( function() {
    var availableTags = [
       <?php 
			$sub_qry=$this->db->get('sub_sub_category_master')->result();
			foreach ($sub_qry as $sub) 
			{
				echo '"'.$sub->sub_sub_category_name.'",';
			}
		?>
    ];
    $( "#category" ).autocomplete({
      source: availableTags
    });
  } );
</script>

<style>
#ui-id-1 li { text-transform:uppercase;}
</style>
</head>
<body>
