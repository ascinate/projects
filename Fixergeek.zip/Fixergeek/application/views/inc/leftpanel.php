<ul class="host-section-left-list-ul topic-list-n1">
<li class="list-non-active">
  <a href="http://fixergeek.com/staging/category" class="nav-link sp-class-link"> All categories </a>
</li>
<?php 

$cat_qry = $this->db->query('Select * from `category_master` order by ordering')->result();
foreach ($cat_qry as $cat) {
?>
<li class="list-non-active">
<a class="nav-link dropdown-toggle topic-dp" href="#" 
data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-weight:600;">              
<!-- <i class="fa fa-circle"></i> --> <?=$cat->category_name?>  <b class="caret"></b>
</a>
<ul class="dropdown-menu slider-dp-menu1" aria-labelledby="navbarDropdownMenuLink">
<?php 
$subcat = $this->db->query("select * from `sub_category_master` where cat_id = '".$cat->id."'");
foreach($subcat->result() as $row) 
{
?>
<li class="dropdown-submenu sb-topic1">

<a class="dropdown-item dropdown-toggle topic-sub1" href="#"><?=$row->sub_category_name?></a>
<ul class="dropdown-menu sb-topic2">
<?php
$mcat = $this->db->query("select * from `sub_sub_category_master` where sub_cat_id = '".$row->id."'");
foreach($mcat->result() as $rec) 
{ 
?>
<li> <a class="dropdown-item topic-sub2" href="<?php echo base_url();?>category/show/<?=(str_replace("&","-",str_replace(" ","_",$rec->sub_sub_category_name)))?>">
<?=$rec->sub_sub_category_name?>
</a></li>
<?php } ?>
</ul>
</li>
<?php } ?>
</ul>
</li>
<?php } ?>
</ul>
