<div class="modal fade exampleModalask" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header ask-modal modal-header-1"> <img src="<?php echo base_url();?>assets2/images/logo-head.png" alt="">
        <h5 class="modal-title" id="exampleModalLabel">Fixer Geek</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      
      <div id="modal-spl-26" class="modal-body modal-body1">
        <div class="head-form head-form2x" id="next_hide">
          <span class="m-head">Welcome to Fixer Geek!</span>
          <div class="form-dp">
           <p>To continue, please login</p>
           <p><strong>Login</strong></p>
           
            <div class="top-sec-dp">
                <div class="form-group">
                  <label> Geek Name</label>
                  <input type="text" id="user" class="form-control" value="" required>
                </div>
                <div class="form-group">
                  <label> Password </label>
                  <input type="password" id="pw" class="form-control" value="" required>
                </div>
                <button type="button" id="auth_btn" class="btn default-btn login">Log In</button>
            </div>
          </div>

          <div class="col-md-4">&nbsp;</div>
          
          <div class="col-12">
            <div class="header-drop-links-first">
              <p>Or Login With</p>
              <ul class="socal-media">
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i>
                  <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                  <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                  <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                  <span> Linkedin</span></a></li>
              </ul>
              
              <div class="sub-link">
                 <a href="#">Lost Password </a> or <a href="#"> User Name</a>
              </div>
            </div>
          </div>
          <div class="col-12 mt-4">
            <div class="header-drop-links-second">
              <p>Or Sign Up With</p>
              <hr class="my-2">
              <ul class="socal-media">
                <li><a class="icon-new" href="#"> <i class="fas fa-envelope"></i>
                  <span>Email</span></a></li>
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i>
                  <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                  <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                  <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                  <span> Linkedin</span></a></li>
              </ul>
            </div>
          </div>
          </div>

      
      </div>
   </div>
 </div>
</div>