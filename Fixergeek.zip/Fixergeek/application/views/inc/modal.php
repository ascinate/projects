<?php
      error_reporting(0);

      $query = $this->db->query("select * from `fixergeek_master` where `user_id` = '".$this->session->userdata('id')."'");
	  $numrow = $query->num_rows();

	  if($numrow!=0)
	  {
	  	$this->load->view('inc/modal2');
	   
	  }
	  else
	  {
	    // $this->load->view('inc/modal1');
		 $this->load->view('inc/modal-3');
	  }
   
  ?>