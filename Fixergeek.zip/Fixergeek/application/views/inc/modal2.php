<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
 <script>
  $( function() {
    var availableTags = [
	   <?php 
		 $this->db->order_by('id','desc');
		 $topic_qry=$this->db->get('topics_master')->result();
		 foreach ($topic_qry as $topic) {
	   ?>
	  
      "<?=$topic->topic?>",
       <?php }?>
    ];
    $( "#tags" ).autocomplete({
      source: availableTags
    });
  } );
  </script>

<div class="modal fade exampleModalask" id="comon-page-Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    
      <div class="modal-header ask-modal modal-header-1"> <img src="<?php echo base_url();?>assets2/images/logo-head.png" alt="">
        <h5 class="modal-title" id="exampleModalLabel">Ask Question</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      
      <div class="modal-body modal-body1">
      
        <div class="modal-blue-bg" id="clients-modal1">
          <!--  -->
          <?php if($this->session->userdata('id')=="") { ?>
          <div class="head-form head-form2x" id="next_hide">
                                     
          <div class="form-dp">
            <div class="top-sec-dp">
                <div class="form-group">
                  <label> User Name</label>
                  <input type="text" placeholder="" id="user_name" class="form-control" required>
                </div>
                <div class="form-group">
                  <label> Password </label>
                  <input type="password" placeholder="" id="password" class="form-control" required>
                </div>
                <button type="button" id="login_btn" class="btn default-btn login">Log In</button>
            </div>
          </div>

          <div class="col-md-4">
            
          </div>
          <div class="col-12">
            <div class="header-drop-links-first">
              <p>Or Login With</p>
              <ul class="socal-media">
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i>
                  <span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i> 
                  <span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i> 
                  <span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i> 
                  <span> Linkedin</span></a></li>
              </ul>
              
              <div class="sub-link">
                 <a href="#">Lost Password </a> or <a href="#"> User Name</a>
              </div>
            </div>
          </div>
          <div class="col-12 mt-4">
            <div class="header-drop-links-second">
              <p>Or Sign Up With</p>
              <hr class="my-2">
              <ul class="socal-media">
                <li><a class="icon-new" href="#"> <i class="fas fa-envelope"></i><span>Email</span></a></li>
                <li><a class="spl-facebook icon-new" href="#"><i class="fab fa-facebook-square"></i><span>Facebook</span></a></li>
                <li><a class="spl-google icon-new" href="#"><i class="fab fa-google-plus-g"></i><span>Google</span></a></li>
                <li><a class="spl-windows icon-new" href="#"> <i class="fab fa-windows"></i><span>Microsoft</span></a></li>
                <li><a class="spl-linkedin icon-new" href="#"> <i class="fab fa-linkedin"></i><span>Linkedin</span></a></li>
              </ul>
            </div>
          </div>
          </div>
        <?php }?>
          <!--  -->

          <?php if($this->session->userdata('id')==""){?>
          <div id="next_show" style="display: none;">
          <?php } if($this->session->userdata('id')!=""){?>
          <div id="next_show">
          <?php } ?>
           <div class="row mb-2">
            <div class="col-12">
              <h5>Please Choose One</h5>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-2">
                <div class="col-5 my-auto pr-0">
                  <div class="form-check">
                    <input class="form-check-input radio-modal-input" type="radio" name="opts" id="exampleRadios1010" value="1">
                    <label class="form-check-label radio-modal-label-1" for="exampleRadios1010"> Get a Problem Fixed </label>
                  </div>
                </div>
                <div class="col-7 label-problem-div text-right">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect1">
                    <option>By A Particular User</option>
                    <option>By All Users</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-4 my-auto pr-0">
                  <div class="form-check">
                    <input class="form-check-input radio-modal-input" type="radio" name="opts" id="exampleRadios2101" value="2" checked>
                    <label class="form-check-label radio-modal-label-1" for="exampleRadios2101"> Fix Problem </label>
                  </div>
                </div>
                <div class="col-8 label-problem-div text-right pl-6">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect1">
                    <option>Of Other users</option>
                    <option>Of Particular users</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              
              
              <div class="row mb-5" id="note">
                <div class="col-md-12">
                   <p>&nbsp;</p>
                   <p style="font-size:11px;">Since you're a Fixer Geek, you MUST download & run <a href="#" style="color:#37a000; text-decoration:none;">Fixer Geek App</a> to be able to fix problems of other Geeks and get payed.</p>
                   <p>&nbsp;</p>
                   <p style="font-size:11px;">Download <a href="#" style="color:#37a000; text-decoration:none;">Fixer Geek App</a> from the button below.</p>
                </div>
              </div>
              
              <div class="row mb-5" id="cha" style="display:none;">
                <div class="col-md-12">
                  <div class="form-group-1">
                    <input type="checkbox" name="remote" id="mclient-check-5" checked>
                    <label for="client-check-5">Using Remote Access Assistance</label>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group-1">
                    <input type="checkbox" name="video" id="client-check-6">
                    <label for="client-check-6">Using Screen Sharing & Voice Chat</label>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group-1">
                    <input type="checkbox" name="chat" id="client-check-7">
                    <label for="client-check-7">Using Text Chat Support</label>
                  </div>
                </div>
              </div>
              
              <div class="row mt-3" id="tt" style="display:none;">
                <div class="col-12">
                  <div class="modal-3-check">
                    <div class="form-group form-group-1  my-2 mx-2">
                      <input type="checkbox" name="terms" id="modal-3-check-2">
                      <label for="modal-3-check-2">I agree to the remote Support <a href="#">terms & condition</a></label>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
          </form>
          
          <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-download" class="btn btn-primary default-btn ">Download</button>
            <button type="button" id="modal2-btn-3" class="btn btn-primary default-btn" style="display:none;">Ask</button>
          </div>
          
          </div>
        </div>
        
        <!--======================== 
              clients-modal5               client-modal-2
        =========================-->
        <div id="clients-modal2" class="modal-blue-bg" style="display: none;">
         
          <div class="row mb-2">
            <div class="col-12">
              <h5>Please Choose One</h5>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-2">
                <div class="col-5 my-auto pr-0">
                  <div class="form-check">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios1010" value="option1" checked>
                    <label class="form-check-label radio-modal-label-1" for="exampleRadios1010">Get a Problem Fixed </label>
                  </div>
                </div>
                <div class="col-7 label-problem-div text-right">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect1">
                    <option>By A Particular User</option>
                    <option>By All Users</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-4 my-auto pr-0">
                  <div class="form-check">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios2101" value="option1">
                    <label class="form-check-label radio-modal-label-1" for="exampleRadios2101"> Fix Problem </label>
                  </div>
                </div>
                <div class="col-8 label-problem-div text-right pl-6">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect1">
                    <option>Of Other users</option>
                    <option>Of Particular users</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-5">
                <div class="col-md-12">
                  <div class="form-group-1">
                    <input type="checkbox" id="mclient-check-5" checked>
                    <label for="client-check-5">Using Remote Access Assistance</label>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group-1">
                    <input type="checkbox" id="client-check-6">
                    <label for="client-check-6">Using Screen Sharing & Voice Chat</label>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group-1">
                    <input type="checkbox" id="client-check-7">
                    <label for="client-check-7">Using Text Chat Support</label>
                  </div>
                </div>
              </div>
              <!--<div class="row mt-3">
                <div class="col-12">
                  <div class="modal-3-check">
                    <div class="form-group form-group-1  my-2 mx-2">
                      <input type="checkbox" id="modal-3-check-2">
                      <label for="modal-3-check-2">I agree to the remote Support <a href="#">terms & condition</a></label>
                    </div>
                  </div>
                </div>
              </div>-->
            </div>
          </form>
          <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-2" class="btn btn-primary default-btn">Next</button>
          </div>
                
        </div>
        <!--======================== 
                             client-modal-3
                     =========================-->
        <div id="clients-modal3" class="modal-blue-bg" style="display: none;">
          <div class="row mb-2">
            <div class="col-12">
              <h5>Please Choose One</h5>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-2">
                <div class="col-5 my-auto pr-0">
                  <div class="form-check">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios1010" value="option1" checked>
                    <label class="form-check-label radio-modal-label-1" for="exampleRadios1010"> Get a Problem Fixed </label>
                  </div>
                </div>
                <div class="col-7 label-problem-div text-right">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect1">
                    <option>By A Particular User</option>
                    <option>By All Users</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-4 my-auto pr-0">
                  <div class="form-check">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios2101" value="option1">
                    <label class="form-check-label radio-modal-label-1" for="exampleRadios2101"> Fix Problem </label>
                  </div>
                </div>
                <div class="col-8 label-problem-div text-right pl-6">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect1">
                    <option>Of a Particular users</option>
                    <option>Of Other users</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-12">
                  <p class="mb-2"><b>Enter User Name</b></p>
                </div>
                <div class="col-3 modal2User_grp text-right my-auto pr-0">
                  <p>User's Name</p>
                </div>
                <div class="col-9">
                  <div class="form-group mb-0">
                    <input type="email" class="form-control modal2from_grp" id="exampleFormControlInput1" placeholder="type here....">
                  </div>
                </div>
              </div>
              <div class="row mb-5 justify-content-center mb-3">
                <div class="col-11 modal-3-prblm">
                  <h6 class="mb-2"><b>Get the problem fixed:</b></h6>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios100" value="option1" checked>
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios100"> Using Remote Access Assistance </label>
                  </div>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios700" value="option1">
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios700"> Using Screen Sharing & Voice Chat </label>
                  </div>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios800" value="option">
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios800"> Using Text Chat Support </label>
                  </div>
                </div>
              </div>
              <div class="row ">
                <div class="col-12">
                  <div class="modal-3-check">
                    <div class="form-group form-group-1  my-2 mx-2">
                      <input type="checkbox" id="modal-3-check-2">
                      <label for="modal-3-check-2">I agree to the remote Support <a href="#">terms & condition</a></label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
          <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-3" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--======================== 
                             client-modal-4
                     =========================-->
        <div id="clients-modal4" class="modal-blue-bg" style="display: none;">
          <div class="row mb-2">
            <div class="col-12">
              <h5>Fix Markshelby25's problem for a custom price</h5>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row justify-content-center mb-3">
                <div class="col-11">
                  <p class="mb-2">Choose a price between $10 to $9,999.Enter only digits</p>
                </div>
                <div class="col-6 my-auto px-0">
                  <label class="form-check-label radio-modal-label-1" for="exampleRadios1"> Enter a custom price in USD </label>
                </div>
                <div class="col-3 my-auto label-problem-div px-0 text-right">
                  <input type="text" class="form-control modal2from_grp" id="exampleFormControlInput1" placeholder="">
                </div>
              </div>
              <div class="row mb-3">
                <div class="col-md-12 mb-1">
                  <label for="exampleFormControlTextarea1"><b>Write a Messege to Markshelby25</b></label>
                </div>
                <div class="col-md-12">
                  <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Type your Question here..." rows="3"></textarea>
                </div>
              </div>
              <div class="row mb-5 justify-content-center mb-3">
                <div class="col-11 modal-3-prblm">
                  <h6 class="mb-2"><b>Get the problem fixed:</b></h6>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios100" value="option1" checked>
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios100"> Using Remote Access Assistance </label>
                  </div>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios700" value="option1">
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios700"> Using Screen Sharing & Voice Chat </label>
                  </div>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios800" value="option">
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios800"> Using Text Chat Support </label>
                  </div>
                </div>
              </div>
              <div class="row ">
                <div class="col-12">
                  <div class="modal-3-check">
                    <div class="form-group form-group-1  my-2 mx-2">
                      <input type="checkbox" id="modal-3-check-2">
                      <label for="modal-3-check-2">I agree to the remote Support <a href="#">terms & condition</a></label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
          <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-4" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--======================== 
                             client-modal-5
                     =========================-->
        <div id="clients-modal5" class="modal-blue-bg" style="display: none;">
          <div class="row mb-3">
            <div class="col-12 client1">
              <h5>joeMartyjoe,Keep this app running !</h5>
              <p class="mt-2">
              keep this application running or minimized eith online status to get request from users who need you users who need your help to fix their problems
              </p>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-3">
                <div class="col-12">
                  <p>Choose your status below:</p>
                </div>
                <div class="col-5 label-problem-div">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect1">
                    <option> <i class="fa fa-circle"></i> Online</option>
                    <option> <i class="fa fa-circle"></i> Away</option>
                    <option> <i class="fa fa-circle"></i> Offline</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-2 justify-content-center mb-3">
                <div class="col-11 modal-3-prblm">
                  <h6 class="mb-2"><b>Get the problem fixed:</b></h6>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios100" value="option1" checked>
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios100"> Using Remote Access Assistance </label>
                  </div>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios700" value="option1">
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios700"> Using Screen Sharing & Voice Chat </label>
                  </div>
                  <div class="form-check mb-1">
                    <input class="form-check-input radio-modal-input" type="radio" name="exampleRadios" id="exampleRadios800" value="option">
                    <label class="form-check-label radio-modal-label-2" for="exampleRadios800"> Using Text Chat Support </label>
                  </div>
                </div>
              </div>
              <div class="row ">
                <div class="col-12">
                  <p>Following users are currently looking for help in categories you are expert in.You can send offers to them or wait to get others.</p>
                  <div class="table-modal-1-details table-modal-1-details1 mt-2">
                    <table class="table-modal-part-2 table-client-part-3  checkbox_listing-1 checkbox_listing-2">
                      <thead>
                        <tr>
                          <th scope="col" style="width: 20%;">User Name</th>
                          <th scope="col" style="width: 20%;">Categories</th>
                          <th scope="col">Problem</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                              <input type="checkbox" id="table-modal-45">
                              <label for="table-modal-45">JoeMartyjoe</label>
                            </div></td>
                          <td class="table-category">personalization</td>
                          <td>How do i install live wallpaper in windows 10?</td>
                        </tr>
                        <tr>
                          <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                              <input type="checkbox" id="table-modal-47">
                              <label for="table-modal-47">Shawn667</label>
                            </div></td>
                          <td class="table-category">Gaming</td>
                          <td>4.8</td>
                        </tr>
                        <tr>
                          <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                              <input type="checkbox" id="table-modal-46">
                              <label for="table-modal-46">Susan_2020</label>
                            </div></td>
                          <td class="table-category">Miscellaneous</td>
                          <td>4.1</td>
                        </tr>
                        <tr>
                          <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                              <input type="checkbox" id="table-modal-1">
                              <label for="table-modal-1">Simon525</label>
                            </div></td>
                          <td class="table-category">Memory</td>
                          <td>4.8</td>
                        </tr>
                        <tr>
                          <td><div class="form-group form-group-1 form-grp-3 my-1 mx-0">
                              <input type="checkbox" id="table-modal-2">
                              <label for="table-modal-2">Richard252</label>
                            </div></td>
                          <td class="table-category">Category <i class="fa fa-caret-down"></i></td>
                          <td>4.8</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </form>
          <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-5" class="btn btn-primary default-btn">Next</button>
          </div>
        </div>
        <!--======================== 
                             client-modal-6
                     =========================-->
        <div id="clients-modal6" class="modal-blue-bg" style="display: none;">
          <div class="row mb-3">
            <div class="col-12 client1">
              <h5>joeMartyjoe,Keep this app running !</h5>
              <p class="mt-2">keep this application running or minimized eith online status to get request from users who need you users who need your help to fix their problems</p>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-3">
                <div class="col-12">
                  <p class="mb-1">Choose your status below:</p>
                </div>
                <div class="col-5 label-problem-div">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect1">
                    <option> <i class="fa fa-circle"></i> Away</option>
                    <option> <i class="fa fa-circle"></i> Online</option>
                    <option> <i class="fa fa-circle"></i> Offline</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-5 justify-content-center mb-3">
                <div class="col-md-12 mb-1">
                  <label for="exampleFormControlTextarea1">Away Messege:</label>
                </div>
                <div class="col-md-12">
                  <textarea class="form-control text-left exampleFormControlTextarea2" id="exampleFormControlTextarea" placeholder="" rows="3">I am busy! You can reach me from 5:00pm to 9:00pm EST.If it's something urgent,leave me messege.</textarea>
                </div>
              </div>
            </div>
          </form>
           <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-6" class="btn btn-primary default-btn">Next</button>
          </div> 
        </div>
        <!--======================== 
                             client-modal-7
                     =========================-->
        <div id="clients-modal7" class="modal-blue-bg" style="display: none;">
          <div class="row mb-3">
            <div class="col-12 client1">
              <h5>joeMartyjoe,Keep this app running !</h5>
              <p class="mt-2">keep this application running or minimized eith online status to get request from users who need you users who need your help to fix their problems</p>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-3">
                <div class="col-12">
                  <p class="mb-1">Choose your status below:</p>
                </div>
                <div class="col-5 label-problem-div">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect1">
                    <option> <i class="fa fa-circle"></i> Offline</option>
                    <option> <i class="fa fa-circle"></i> Away</option>
                    <option> <i class="fa fa-circle"></i> Online</option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
              </div>
              <div class="row mb-5 justify-content-center mb-3">
                <div class="col-md-12 mb-1">
                  <label for="exampleFormControlTextarea1">Offline Messege:</label>
                </div>
                <div class="col-md-12">
                  <textarea class="form-control text-left exampleFormControlTextarea2" id="exampleFormControlTextarea" placeholder="" rows="3">My regular timings are from 3:00pm to 6:00pm Weekdays.Leave me a messege</textarea>
                </div>
              </div>
            </div>
          </form>
           <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-7" class="btn btn-primary default-btn">Next</button>
          </div> 
        </div>
        <!--======================== 
                             client-modal-8
                     =========================-->
        <div id="clients-modal8" class="modal-blue-bg" style="display: none;">
          <div class="row mb-4">
            <div class="col-12 client1">
              <h5>MarkShelby25 sent you a request for help!</h5>
              <p class="mt-3">He wants to hire you as for the following problems:</p>
              <p class="mt-3"><b>'How to install animated wallpaper im windows 10?'</b></p>
              <p class="mt-1 green_user-1"><b><i class="fa fa-check"></i>You fixed this issue in the past for another User</b></p>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col-12">
              <p class="mb-1">Markselby25 needs help using the following method:</p>
              <a href="#">Remote Access Asistance</a> </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-5 pb-">
                <div class="col-5 my-auto pr-0">
                  <p><b>Please choose your price</b></p>
                  <p>to work this problem</p>
                </div>
                <div class="col-3 pl-0 label-problem-div">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect1">
                    <option></option>
                    <option></option>
                    <option></option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
                <div class="col-1 my-auto px-0 text-center">
                  <p>US<br>
                    Dollars</p>
                </div>
              </div>
              <div class="row mb-4 justify-content-center mb-3">
                <div class="col-12">
                  <p><b>Markshelby25</b> is using <b>Windows 10, version 10.0940</b></p>
                </div>
              </div>
              <div class="row mb-5 clent-btn-grp-1 pb-3 justify-content-center">
                <div class="col-4  px-2">
                  <button type="button" id="modal2-btn-10" class="btn block-btn text-center w-100">Block User</button>
                </div>
                <div class="col-4 px-1">
                  <button type="button" id="modal2-btn-9" class="btn decline-btn text-center disabled w-100">Deny Asistance</button>
                </div>
                <div class="col-4 px-2">
                  <button type="button" id="modal2-btn-12" class="btn start-s-btn text-center disabled w-100">Send Offer</button>
                </div>
              </div>
            </div>
          </form>
           <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-8" class="btn btn-primary default-btn">Next</button>
          </div> 
        </div>
        <!--======================== 
                             client-modal-9
                     =========================-->
         <div id="clients-modal9" class="modal-blue-bg" style="display: none;">
          <div class="row mb-4">
            <div class="col-12 client1">
              <h5>MarkShelby25 has declined your offer</h5>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col-12">
              <p class="mb-2"><b>Decline Reason:</b></p>
              <p>That ridicoulesly high rate.i wont pay $35 to just get an nimated wallpaper set on my desktop. Bye!</p>
            </div>
          </div>
          <div class="row mb-3">
            <div class="col-12">
              <p class="mb-2"><b>Want to send a conter offer:</b></p>
              <p>Your last offer was $35, we suggest you to try again by lowering this price.</p>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-5 pb-5">
                <div class="col-5 my-auto pr-0">
                  <p><b>Please choose your price</b></p>
                  <p>to work this problem</p>
                </div>
                <div class="col-3 pl-0 label-problem-div">
                  <select class="form-control form-control-modal w-100 position-relative" id="exampleFormControlSelect1">
                    <option></option>
                    <option></option>
                    <option></option>
                  </select>
                  <div class="select-drop-icon"> </div>
                </div>
                <div class="col-1 my-auto px-0 text-center">
                  <p>US<br>
                    Dollars</p>
                </div>
              </div>
              <div class="row mb-3 clent-btn-grp-1 justify-content-center">
                <div class="col-5 px-2">
                  <button type="button" class="btn start-s-btn text-center w-100">Send Counter Offer</button>
                </div>
              </div>
            </div>
          </form>
          <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-9" class="btn btn-primary default-btn">Next</button>
          </div>
        </div> 
        <!--======================== 
                             client-modal-10
                     =========================-->
        <div id="clients-modal10" class="modal-blue-bg" style="display: none;">
          <div class="row mb-4">
            <div class="col-12 client1">
              <h5>Are you sure you want to deny assistance to Markshelby25?</h5>
              <p class="mt-3">Describe breifly why you are denying assistance to this user this will be visible to the user who's requesting assistance.</p>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-5 justify-content-center">
                <div class="col-md-12 mb-1">
                  <label for="exampleFormControlTextarea1"><b>Reason For Denial</b></label>
                </div>
                <div class="col-md-12">
                  <textarea class="form-control text-left exampleFormControlTextarea2" id="exampleFormControlTextarea" placeholder="" rows="3">I am not expert on this.i have no experience with animated wallpapers in windows 10.you can look for another user.Thank you for contacting me.</textarea>
                </div>
              </div>
              <div class="row mb-3 clent-btn-grp-1">
                <div class="col-4 px-2">
                  <button type="button" class="btn float-left start-s-btn text-center">Cancel</button>
                </div>
                <div class="col-4"></div>
                <div class="col-4 text-right px-2">
                  <button type="button" class="btn float-right block-btn text-center">Deny</button>
                </div>
              </div>
            </div>
          </form>
           <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-10" class="btn btn-primary default-btn">Next</button>
          </div> 
        </div>
        <!--======================== 
                             client-modal-11
                     =========================-->
        <div id="clients-modal11" class="modal-blue-bg" style="display: none;">
          <div class="row mb-3">
            <div class="col-12 client1">
              <h5>Are you sure you want to block this user Markshelby25?</h5>
              <p class="mt-3">Describe breifly why you are blocking this user.This will be visible to the user who's requesting assistance.</p>
            </div>
          </div>
          <form class="checkbox_listing">
            <div class="form-group">
              <div class="row mb-5 justify-content-center mb-3">
                <div class="col-md-12 mb-1">
                  <label for="exampleFormControlTextarea1"><b>Reason For Denial:</b></label>
                </div>
                <div class="col-md-12">
                  <textarea class="form-control text-left exampleFormControlTextarea2" id="exampleFormControlTextarea" placeholder="" rows="3">I have already told you multiple times that i am not an expert on this issue and you are contiously sending me request to handle this issue.please do not ping me again.</textarea>
                </div>
              </div>
              <div class="row mb-5">
                <div class="col-12">
                  <p><b>NOTE:</b> you can Unblock any blocked user later by going to our website <i class="fa fa-chevron-right"></i>My acoount <i class="fa fa-chevron-right"></i>Security settings</p>
                </div>
              </div>
              <div class="row mb-3 clent-btn-grp-1">
                <div class="col-4 px-2">
                  <button type="button" class="btn float-left start-s-btn text-center">Cancel</button>
                </div>
                <div class="col-4"></div>
                <div class="col-4 text-right px-2">
                  <button type="button" class="btn float-right block-btn text-center">Block</button>
                </div>
              </div>
            </div>
          </form>
           <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-11" class="btn btn-primary default-btn">Next</button>
          </div> 
        </div>
        <!--======================== 
                             client-modal-12
                     =========================-->
         <div id="clients-modal12" class="modal-blue-bg" style="display: none;">
          <div class="row mb-5 pb-5">
            <div class="col-12 client1">
              <h5>Waiting for Markshelby25 to accept your offer</h5>
              <p class="mt-3">Make sure your microphones & Speakers are turned on.</p>
            </div>
          </div>
          <div class="row justify-content-center">
            <div class="col-4">
              <button type="button" class="btn float-right block-btn text-center">Block</button>
            </div>
          </div>
          <div class="text-center mt-4 blue-bg-under">
            <button type="button" id="modal2-btn-12" class="btn btn-primary default-btn">Next</button>
          </div>
        </div> 
        <!--======================== 
                             client-modal-13
                     =========================-->
        <div id="clients-modal13" class="modal-blue-bg" style="display: none;">
          <div class="row mb-4 ">
            <div class="col-12 client1">
              <h5>Markshelby25 has been alerted to pay continue!</h5>
              <p class="mt-2">After 5 minutes of free session.We Require users to make a payment to continue recieving help form you.</p>
              <p class="mt-3"> While Markshelby25 is deciding whether to pay you for work ,you access to his computer is paused. </p>
              <p class="mt-3"> Once the transaction are successful,you will recieve payment you've set for this user.if you deny assistanceafter payment,we'll be alerted & may be stop your payment& blacklist you. </p>
            </div>
          </div>
          <div class="row mb-3 justify-content-end">
            <div class="col-5">
              <p class="mb-1">Total Payment: <b>35 USD</b></p>
              <p class="mb-1">Our Commision: <b>20%</b></p>
              <p class="mb-1">Your Proceeds: <b>28 USD</b></p>
            </div>
          </div>
          <div class="row mb-5">
            <div class="col-12">
              <p>If you think you won't be able to fix this problem or aren't satisfied with this user For any reason,end this session now by clicking the button below.<span class="red_user-1">Note: you won"t be able to end session after payment,</span>only <b>Markshelby25</b>can</p>
            </div>
          </div>
          <div class="row mb-3 justify-content-center">
            <div class="col-5">
              <button type="button" class="btn float-right block-btn text-center">End Session</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
$(document).ready(function(){
  $("#login_btn").click(function(){
          var user_name = $("#user_name").val();
          var password = $("#password").val();
           
          if(password=='' || user_name=='')
          {
             swal("Sorry!! Insert Your Login Data");
          }
          else
          {
            $.ajax({
            url:'<?php echo base_url();?>home/login',
            type:'post',
            data:{user_name:user_name,password:password},
            success:function(data)
            {

              if(data=='success')
              {
               $('#next_hide').hide();
               $('#next_show').show();
              }
              else
              {
               $('#next_hide').show();
               $('#next_show').hide();
              }
              
            }
          });
          }
   
        });
		
		$("#modal2-btn-download").click(function(){
		   $("#note").hide();
		   $("#modal2-btn-download").hide();
		   $("#cha").show();
		   $("#tt").show();
		   $("#modal2-btn-3").show();
		});
		
     });
</script>