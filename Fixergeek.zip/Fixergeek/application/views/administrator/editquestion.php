<!-- Mobiscroll JS and CSS Includes -->
<link href="<?php echo base_url();?>files/assets/css/mobiscroll.jquery.min.css" rel="stylesheet">
<!-- <script src="<?php echo base_url();?>files/assets/js/mobiscroll.jquery.min.js"></script> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>Edit Question</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="#"> <i class="feather icon-home"></i> </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Edit Question</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<!-- Page-body start -->
<div class="page-body">
<div class="row">
<div class="col-sm-12">
<!-- Basic Form Inputs card start -->
<div class="card">
    <div class="card-block">
        <h4 class="sub-title">Basic Inputs</h4>
        <?php foreach($questions as $row){
        $topic=explode(",", $row->topics);
        ?>
        <form id="main" action="<?php echo base_url();?>admin/questions/updatequestion" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?=$row->id?>">
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Question</label>
                <div class="col-sm-10">
                    <input type="text" name="question" value="<?=$row->question?>" id="question" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Category</label>
                <div class="col-sm-10">
                     
                     <select mbsc-dropdown id="cat_name" name="cat_name" class="form-control">
                            <option value="">Select</option>
                            <?php
                               $query = $this->db->get('category_master');  
                                foreach($query->result() as $res)
                                {
                            ?>
                                <option value="<?=$res->id?>"<?php if($row->category_name==$res->id){echo"selected";}?>>
                                    <?=$res->category_name?> 
                                </option>
                            <?php
                                }
                            ?>
                     </select>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Sub Category</label>
                <div class="col-sm-10">
                 <!--<select name="subcat_name" class="form-control" id="scat">
                 </select>-->
                 <select  name="subcat_name" mbsc-dropdown id="subcat_name" class="form-control">
                    <?php 
                    $query = $this->db->get_where('sub_category_master',array('cat_id'=>$row->category_name));
                    foreach($query->result() as $res)
                    {
                    ?>
                    <option value="<?=$res->id?>"<?php if($row->sub_cat_id==$res->id){echo"selected";}?>><?=$res->sub_category_name?></option>
                    <?php
                    }
                    ?>
                 </select>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Sub Sub Category</label>
                <div class="col-sm-10">
                 <!--<select name="category_name" class="form-control" id="sucat">
                 </select>-->
                 <select name="sub_sub_catname" mbsc-dropdown id="sub_sub_catname" class="form-control">
                    <?php 
                    $query = $this->db->query("select * from `sub_sub_category_master` where sub_cat_id ='".$row->sub_cat_id."'");  
                    foreach($query->result() as $res)
                    {
                    ?>
                    <option value="<?=$res->id?>"<?php if($row->sub_sub_cat_id==$res->id){echo"selected";}?>><?=$res->sub_sub_category_name?></option>
                    <?php
                    }
                    ?>
                 </select>
                </div>
            </div>

             <!--<div class="form-group row">
                <label class="col-sm-2 col-form-label">Topics</label>
                <div class="col-sm-10">
                 <select name="topics[]" class="js-example-responsive col-sm-12" multiple="multiple">
                        <?php
                            $query = $this->db->get('topics_master');  
                            foreach($query->result() as $res)
                            {
                        ?>
                            <option value="<?=$res->topic?>"<?php foreach($topic as $val){if($val==$res->topic){echo"selected";}} ?>>
                                <?=$res->topic?> 
                            </option>
                        <?php
                            }
                        ?>
                 </select>
                </div>
            </div>


           <div class="form-group row">
                <label class="col-sm-2 col-form-label">Description</label>
                <div class="col-sm-10">

                 <textarea name="content" id="editor"><?=$row->content?></textarea>
                <script>
                CKEDITOR.replace('content');
                </script>
                </div>
            </div>

             <div class="form-group row">
                <label class="col-sm-2 col-form-label">Upload</label>
                <div class="col-sm-10">
                <input type="file" name="uploaded_files" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-12 text-right">
               <img src="<?php echo base_url();?>uploads/<?=$row->uploaded_files?>" class="img-div">
                </div>
            </div>-->
            
            <div class="form-group row">
                <label class="col-sm-2"></label>
                <div class="col-sm-10 text-right">
                    <button type="submit" class="btn btn-primary m-b-0">Update</button>&nbsp;
                    <button type="button" class="btn btn-primary m-b-0" onclick="javascript: history.go(-1);">Cancel</button>
                </div>
            </div>
        </form>
        <?php } ?>
      </div>
     </div>
        <!-- Basic Form Inputs card end -->
     </div>
   </div>
  </div>
      <!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>

<!-- <script>
    mobiscroll.settings = {
        lang: 'en',                           // Specify language like: lang: 'pl' or omit setting to use default
        theme: 'ios',                         // Specify theme like: theme: 'ios' or omit setting to use default
            themeVariant: 'light'             // More info about themeVariant: https://docs.mobiscroll.com/4-10-3/select#opt-themeVariant
    };
    
    $(function () {
        var reg,
            div,
            sub,
            remoteReg,
            remoteDiv,
            remoteSub,
            emptyValue = { value: '', text: '', disabled: true },
            regions = [

                <?php
                    $query = $this->db->get('category_master');

                    $arr = array();
                    foreach($query->result() as $res)
                    {
                        $arr[] = $res->id;
                ?>

                { value: <?=$res->id?>, text: '<?=$res->category_name?>' }<?php if($res->id != 8) { ?>,<?php } ?>

                <?php
                    }
                ?>
            ],
            divisions = {

                <?php 
                  foreach($arr as $val) 
                  { 

                     $subcat = $this->db->query("select * from `sub_category_master` where cat_id = '".$val."'");
                ?>

                <?=$val?>: [

                    <?php
                        foreach($subcat->result() as $row) 
                        { 
                    ?>
                    { value: <?=$row->id?>, text: '<?=$row->sub_category_name?>' },
                    <?php } ?>
                ],

               <?php  } ?>
            },
            subdivisions = {
                <?php 

                  $subSql = $this->db->query("select * from `sub_category_master`");

                  foreach($subSql->result() as $rex) 
                  { 

                     $mcat = $this->db->query("select * from `sub_sub_category_master` where sub_cat_id = '".$rex->id."'");
                ?>

                <?=$rex->id?>: [

                    <?php  foreach($mcat->result() as $rec) { ?> 
                    { value: <?=$rec->id?>, text: '<?=$rec->sub_sub_category_name?>' },
                    <?php } ?>
                ],

                <?php } ?>
            };
    
        function getData(region, division) {
            var arr;
    
            if (division) {
                arr = subdivisions[division];
            } else if (region) {
                arr = divisions[region];
            } else {
                arr = regions;
            }
    
            return arr;
        }
    
        reg = $('#demo-data-reg').mobiscroll().select({
            touchUi: false,                   // More info about touchUi: https://docs.mobiscroll.com/4-10-3/select#opt-touchUi
            placeholder: 'Please select...',  // More info about placeholder: https://docs.mobiscroll.com/4-10-3/select#opt-placeholder
            data: getData(),                  // More info about data: https://docs.mobiscroll.com/4-10-3/select#opt-data
            onSet: function (ev, inst) {      // More info about onSet: https://docs.mobiscroll.com/4-10-3/select#event-onSet
                div.settings.invalid.length = 0
                div.setVal('', true);
                div.refresh(getData(inst.getVal()));
                div.enable();
    
                sub.settings.invalid.length = 0;
                sub.setVal('', true);
                sub.refresh([emptyValue]);
                sub.disable();
            }
        }).mobiscroll('getInst');
    
        div = $('#demo-data-div').mobiscroll().select({
            touchUi: false,                   // More info about touchUi: https://docs.mobiscroll.com/4-10-3/select#opt-touchUi
            disabled: true,                   // More info about disabled: https://docs.mobiscroll.com/4-10-3/select#opt-disabled
            placeholder: 'Please select...',  // More info about placeholder: https://docs.mobiscroll.com/4-10-3/select#opt-placeholder
            data: [emptyValue],               // More info about data: https://docs.mobiscroll.com/4-10-3/select#opt-data
            onSet: function (ev, inst) {      // More info about onSet: https://docs.mobiscroll.com/4-10-3/select#event-onSet
                sub.settings.invalid.length = 0;
                sub.setVal('', true);
                sub.refresh(getData(null, inst.getVal()));
                sub.enable();
            }
        }).mobiscroll('getInst');
    
        sub = $('#demo-data-sub').mobiscroll().select({
            touchUi: false,                   // More info about touchUi: https://docs.mobiscroll.com/4-10-3/select#opt-touchUi
            disabled: true,                   // More info about disabled: https://docs.mobiscroll.com/4-10-3/select#opt-disabled
            placeholder: 'Please select...',  // More info about placeholder: https://docs.mobiscroll.com/4-10-3/select#opt-placeholder
            data: [emptyValue]                // More info about data: https://docs.mobiscroll.com/4-10-3/select#opt-data
        }).mobiscroll('getInst');
    
    });
</script> -->
<script>
     $(document).ready(function(){

        $("#cat_name").on('change', function(){

            var sub = $("#cat_name").val();

            var xurl = "<?php echo base_url();?>admin/questions/showsubcat/"+sub;
            // alert(xurl);
            $.ajax({url: xurl, success: function(result){

                $("#subcat_name").html(result);

            }});

        });
         $("#subcat_name").on('change', function(){

            var sub = $("#subcat_name").val();

            var xurl = "<?php echo base_url();?>admin/questions/showsubsubcat/"+sub;
            // alert(xurl);
            $.ajax({url: xurl, success: function(result){

                $("#sub_sub_catname").html(result);

            }});

        });
    });
</script>
<style type="text/css">
    .img-div
    {
    width: 83%;
    height: 70%;
    }
</style>