<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>View Comments</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="#"> <i class="feather icon-home"></i> </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">View Comments</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<!-- Page-body start -->
<div class="page-body">
<div class="row">
<div class="col-sm-12">
<!-- Basic Form Inputs card start -->
<div class="card">
    <div class="card-block">
        <h4 class="sub-title">Basic Inputs</h4>
        <?php 
        foreach($comments as $row)
        {
        $query = $this->db->query("select * from `questions_master` where id = '".$row->question_id."'");
        $result = $query->row();
        $user=$this->db->get_where('user_master',array('id'=>$row->user_id))->row();
        ?>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">User:-</label>
                <div class="col-sm-10">
                    <?=$user->name?>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Question:-</label>
                <div class="col-sm-10">
                    <?=$result->question?>
                </div>
            </div>


           <div class="form-group row">
                <label class="col-sm-2 col-form-label">Comments:-</label>
                <div class="col-sm-10">

                <?=$row->comments?>

                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2"></label>
                <div class="col-sm-10 text-right">
                    <button type="button" class="btn btn-primary m-b-0" onClick="history.go(-1);">Back</button>
                </div>
            </div>

       <?php } ?> 
      </div>
     </div>
		<!-- Basic Form Inputs card end -->
 	 </div>
   </div>
  </div>
  	  <!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>
<style type="text/css">
    .img-div
    {
    width: 83%;
    height: 70%;
    }
</style>