<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>Add User</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="#"> <i class="feather icon-home"></i> </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Add User</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<!-- Page-body start -->
<div class="page-body">
<div class="row">
<div class="col-sm-12">
<!-- Basic Form Inputs card start -->
<div class="card">
    <div class="card-block">
        <h4 class="sub-title">Basic Inputs</h4>
        <form id="main" action="<?php echo base_url();?>admin/users/insertuser" method="post" enctype="multipart/form-data">
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Geek Name</label>
                <div class="col-sm-10">
                    <input type="text" name="geek_name" id="geekname" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Full Name</label>
                <div class="col-sm-10">
                    <input type="text" name="name" id="name" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="text" name="email" id="email" class="form-control" required>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" name="password" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Date of Birth</label>
                <div class="col-sm-10">
                    <input type="date" name="date_of_birth" class="form-control">
                </div>
            </div>
            
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Gender</label>
                <div class="col-sm-10">
                    <select name="gender" class="form-control">
                        <option value="">Select</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
            </div>
            
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Country</label>
                <div class="col-sm-10">
                	<select name="country" class="form-control">
                    <option value="">Select</option>
	                	<?php
	                	    $query = $this->db->get('country_master');  
							foreach($query->result() as $res)
							{
	                	?>
	                    	<option value="<?=$res->iso?>">
	                    		<?=$res->nicename?> 
	                    	</option>
	                    <?php
							}
	                    ?>
	                </select>
                </div>
            </div>
            
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Phone</label>
                <div class="col-sm-10">
                    <input type="text" name="phone" class="form-control" maxlength="12">
                </div>
            </div>
            
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Qualification</label>
                <div class="col-sm-10">
                    <select name="qualification" class="form-control sl-new" required>
                          <option value="">Select</option>
                          <option value="School">School</option>
                          <option value="High School">High School</option>
                          <option value="Diploma">Diploma</option>
                          <option value="Bachelors">Bachelors</option>
                          <option value="Postgraduate Diploma">Postgraduate Diploma</option>
                          <option value="Masters">Masters</option>
                      </select>
                </div>
            </div>
            
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Profile Picture</label>
                <div class="col-sm-10">
                    <div class="pic-sec-delect">
                           <div class="comon-sec-picker">
                              <input type="radio" name="profile_picture" id="av1" class="input-hidden" value="avatar1.png" />
                              <label for="av1">
                                <img src="<?php echo base_url();?>/uploads/avatar1.png"  alt="I'm sad" />
                              </label>
                           </div>
                           <div class="comon-sec-picker">
                              <input type="radio" name="profile_picture" id="av2" class="input-hidden" value="avatar2.png" />
                              <label for="av2">
                                <img src="<?php echo base_url();?>/uploads/avatar2.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av3" class="input-hidden" value="avatar3.png" />
                              <label for="av3">
                                <img src="<?php echo base_url();?>/uploads/avatar3.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av4" class="input-hidden" value="avatar4.png" />
                              <label for="av4">
                                <img src="<?php echo base_url();?>/uploads/avatar4.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av5" class="input-hidden" value="avatar5.png" />
                              <label for="av5">
                                <img src="<?php echo base_url();?>/uploads/avatar5.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av6" class="input-hidden" value="avatar6.png" />
                              <label for="av6">
                                <img src="<?php echo base_url();?>/uploads/avatar6.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av7" class="input-hidden" value="avatar7.png" />
                              <label for="av7">
                                <img src="<?php echo base_url();?>/uploads/avatar7.png" alt="I'm happy" />
                              </label>

                              
                           </div>
                           
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av8" class="input-hidden" value="avatar8.png" />
                              <label for="av8">
                                <img src="<?php echo base_url();?>/uploads/avatar8.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av9" class="input-hidden" value="avatar9.png" />
                              <label for="av9">
                                <img src="<?php echo base_url();?>/uploads/avatar9.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           
                            <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av10" class="input-hidden" value="avatar10.png" />
                              <label for="av10">
                                <img src="<?php echo base_url();?>/uploads/avatar10.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av11" class="input-hidden" value="avatar11.png" />
                              <label for="av11">
                                <img src="<?php echo base_url();?>/uploads/avatar11.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av12" class="input-hidden" value="avatar12.png" />
                              <label for="av12">
                                <img src="<?php echo base_url();?>/uploads/avatar12.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av13" class="input-hidden" value="avatar13.png" />
                              <label for="av13">
                                <img src="<?php echo base_url();?>/uploads/avatar13.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av14" class="input-hidden" value="avatar14.png" />
                              <label for="av14">
                                <img src="<?php echo base_url();?>/uploads/avatar14.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                           <div class="comon-sec-picker">
                                <input type="radio" name="profile_picture" id="av15" class="input-hidden" value="avatar15.png" />
                              <label for="av15">
                                <img src="<?php echo base_url();?>/uploads/avatar15.png" alt="I'm happy" />
                              </label>
                              
                           </div>
                            
                              
                             
                         </div>
                </div>
            </div>
                        
            <div class="form-group row">
                <label class="col-sm-2"></label>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary m-b-0">Submit</button>
                </div>
            </div>
        </form>
        
  	  </div>
  	 </div>
		<!-- Basic Form Inputs card end -->
 	 </div>
   </div>
  </div>
  	  <!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>