<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>View Answer</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="#"> <i class="feather icon-home"></i> </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">View Answer</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<!-- Page-body start -->
<div class="page-body">
<div class="row">
<div class="col-sm-12">
<!-- Basic Form Inputs card start -->
<div class="card">
    <div class="card-block">
        <h4 class="sub-title">Basic Inputs</h4>
         <?php
          foreach ($answers as $row)
          {
        ?>
        <form id="main" action="<?php echo base_url();?>admin/answers/updateanswer" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?=$this->uri->segment(5)?>">
        <input type="hidden" name="qid" value="<?=$this->uri->segment(4)?>">
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Geek Name</label>
                <div class="col-sm-10">

                <?php 
				 if($row->user_id=='Admin'){echo "Admin";}
				 else {
                 $user=$this->db->get_where('user_master',array('id'=>$row->user_id))->row();
				 echo $user->geek_name;
				 }
				 ?>

                </div>
            </div>
            

            <div class="form-group row">
            	<label class="col-sm-2 col-form-label">Level</label>
                <div class="col-sm-10"><?=$row->level?></div>
            </div>
            
            <div class="form-group row">
            	<label class="col-sm-2 col-form-label">Answer</label>
                <div class="col-sm-10">  <?=stripslashes($row->answer);?>
                   
                 <!--<textarea name="answer" id="editor"><?=$row->answer?></textarea>
                 <script>
                    CKEDITOR.replace('answer');
                </script>-->
                </div>
            </div>

            <div class="form-group row">
            	<label class="col-sm-2 col-form-label">&nbsp;</label>
                <div class="col-sm-10">
				  <button type="button" name="back" class="btn btn-primary m-b-0" onclick="javascript:history.go(-1)">Back</button>
                </div>
            </div>
        </form>
         <?php 
     		}
    	 ?>
  	  </div>
  	 </div>
		<!-- Basic Form Inputs card end -->
 	 </div>
   </div>
  </div>
  	  <!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>

<script>
    mobiscroll.settings = {
        lang: 'en',                           // Specify language like: lang: 'pl' or omit setting to use default
        theme: 'ios',                         // Specify theme like: theme: 'ios' or omit setting to use default
            themeVariant: 'light'             // More info about themeVariant: https://docs.mobiscroll.com/4-10-3/select#opt-themeVariant
    };
    
    $(function () {
        var reg,
            div,
            sub,
            remoteReg,
            remoteDiv,
            remoteSub,
            emptyValue = { value: '', text: '', disabled: true },
            regions = [

	            <?php
	                $query = $this->db->get('category_master');

	                $arr = array();
	                foreach($query->result() as $res)
	                {
	                	$arr[] = $res->id;
	            ?>

                { value: <?=$res->id?>, text: '<?=$res->category_name?>' }<?php if($res->id != 8) { ?>,<?php } ?>

                <?php
                    }
                ?>
            ],
            divisions = {

            	<?php 
            	  foreach($arr as $val) 
            	  { 

            	  	 $subcat = $this->db->query("select * from `sub_category_master` where cat_id = '".$val."'");
            	?>

                <?=$val?>: [

                    <?php
	                    foreach($subcat->result() as $row) 
	                    { 
                    ?>
                    { value: <?=$row->id?>, text: '<?=$row->sub_category_name?>' },
               		<?php } ?>
                ],

               <?php  } ?>
            },
            subdivisions = {
            	<?php 

            	  $subSql = $this->db->query("select * from `sub_category_master`");

            	  foreach($subSql->result() as $rex) 
            	  { 

            	  	 $mcat = $this->db->query("select * from `sub_sub_category_master` where sub_cat_id = '".$rex->id."'");
            	?>

                <?=$rex->id?>: [

                    <?php  foreach($mcat->result() as $rec) { ?> 
                    { value: <?=$rec->id?>, text: '<?=$rec->sub_sub_category_name?>' },
                    <?php } ?>
                ],

                <?php } ?>
            };
    
        function getData(region, division) {
            var arr;
    
            if (division) {
                arr = subdivisions[division];
            } else if (region) {
                arr = divisions[region];
            } else {
                arr = regions;
            }
    
            return arr;
        }
    
        reg = $('#demo-data-reg').mobiscroll().select({
            touchUi: false,                   // More info about touchUi: https://docs.mobiscroll.com/4-10-3/select#opt-touchUi
            placeholder: 'Please select...',  // More info about placeholder: https://docs.mobiscroll.com/4-10-3/select#opt-placeholder
            data: getData(),                  // More info about data: https://docs.mobiscroll.com/4-10-3/select#opt-data
            onSet: function (ev, inst) {      // More info about onSet: https://docs.mobiscroll.com/4-10-3/select#event-onSet
                div.settings.invalid.length = 0
                div.setVal('', true);
                div.refresh(getData(inst.getVal()));
                div.enable();
    
                sub.settings.invalid.length = 0;
                sub.setVal('', true);
                sub.refresh([emptyValue]);
                sub.disable();
            }
        }).mobiscroll('getInst');
    
        div = $('#demo-data-div').mobiscroll().select({
            touchUi: false,                   // More info about touchUi: https://docs.mobiscroll.com/4-10-3/select#opt-touchUi
            disabled: true,                   // More info about disabled: https://docs.mobiscroll.com/4-10-3/select#opt-disabled
            placeholder: 'Please select...',  // More info about placeholder: https://docs.mobiscroll.com/4-10-3/select#opt-placeholder
            data: [emptyValue],               // More info about data: https://docs.mobiscroll.com/4-10-3/select#opt-data
            onSet: function (ev, inst) {      // More info about onSet: https://docs.mobiscroll.com/4-10-3/select#event-onSet
                sub.settings.invalid.length = 0;
                sub.setVal('', true);
                sub.refresh(getData(null, inst.getVal()));
                sub.enable();
            }
        }).mobiscroll('getInst');
    
        sub = $('#demo-data-sub').mobiscroll().select({
            touchUi: false,                   // More info about touchUi: https://docs.mobiscroll.com/4-10-3/select#opt-touchUi
            disabled: true,                   // More info about disabled: https://docs.mobiscroll.com/4-10-3/select#opt-disabled
            placeholder: 'Please select...',  // More info about placeholder: https://docs.mobiscroll.com/4-10-3/select#opt-placeholder
            data: [emptyValue]                // More info about data: https://docs.mobiscroll.com/4-10-3/select#opt-data
        }).mobiscroll('getInst');
    
    });
</script>