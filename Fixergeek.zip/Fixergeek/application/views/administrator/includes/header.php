<?php
  $user_id = $this->session->userdata('id');
  if($user_id == "")
  {
    redirect('admin/login', 'refresh');
  }
?>
<nav class="navbar header-navbar pcoded-header">
<div class="navbar-wrapper">

<div class="navbar-logo">
    <a class="mobile-menu" id="mobile-collapse" href="#!">
        <i class="feather icon-menu"></i>
    </a>
    <a href="#" align="center">
       FIXER GEEK
    </a>
    <a class="mobile-options">
        <i class="feather icon-more-horizontal"></i>
    </a>
</div>

<div class="navbar-container container-fluid">
<ul class="nav-left">
    <li class="header-search">
        <div class="main-search morphsearch-search">
            <div class="input-group">
                <span class="input-group-addon search-close"><i class="feather icon-x"></i></span>
                <input type="text" class="form-control">
                <span class="input-group-addon search-btn"><i class="feather icon-search"></i></span>
            </div>
        </div>
    </li>
    <li>
        <a href="#!" onClick="javascript:toggleFullScreen()">
            <i class="feather icon-maximize full-screen"></i>
        </a>
    </li>
</ul>

<ul class="nav-right">
    
    
    <li class="user-profile header-notification">
        <div class="dropdown-primary dropdown">
            <div class="dropdown-toggle" data-toggle="dropdown">
                <img src="<?php echo base_url();?>uploads/avatar6.png" class="img-radius" alt="User-Profile-Image">
                <span>Administrator</span>
                <i class="feather icon-chevron-down"></i>
            </div>
            <ul class="show-notification profile-notification dropdown-menu" data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                <li>
                    <a href="<?php echo base_url();?>admin/dashboard">
                        <i class="feather icon-settings"></i> Dashboard
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>admin/login/user_logout">
                        <i class="feather icon-log-out"></i> Logout
                    </a>
                </li>
            </ul>

        </div>
    </li>
</ul>
</div>
</div>
</nav>
