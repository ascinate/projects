       </div>
    </div>
  </div>
</div>



<!-- Warning Section Ends -->
<!-- Required Jquery -->
<script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>files/bower_components/jquery-ui/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>files/bower_components/popper.js/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>files/bower_components/bootstrap/js/bootstrap.min.js"></script>
<!-- jquery slimscroll js -->
<script src="<?php echo base_url();?>files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js" type="text/javascript"></script>
<!-- modernizr js -->
<script src="<?php echo base_url();?>files/bower_components/modernizr/js/modernizr.js" type="text/javascript"></script>
<!-- Chart js -->
<script src="<?php echo base_url();?>files/bower_components/chart.js/js/Chart.js" type="text/javascript"></script>
<!-- amchart js -->
<script src="<?php echo base_url();?>files/assets/pages/widget/amchart/amcharts.js"></script>
<script src="<?php echo base_url();?>files/assets/pages/widget/amchart/serial.js"></script>
<script src="<?php echo base_url();?>files/assets/pages/widget/amchart/light.js"></script>
<script src="<?php echo base_url();?>files/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo base_url();?>files/assets/js/SmoothScroll.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>files/assets/js/pcoded.min.js"></script>


<!-- custom js -->
<script src="<?php echo base_url();?>files/assets/js/vartical-layout.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>files/assets/pages/dashboard/custom-dashboard.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>files/assets/js/script.min.js"></script>

<!-- Select 2 js -->
<script type="text/javascript" src="<?php echo base_url();?>files/bower_components/select2/js/select2.full.min.js"></script>
<!-- Multiselect js -->
<script type="text/javascript" src="<?php echo base_url();?>files/bower_components/bootstrap-multiselect/js/bootstrap-multiselect.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>files/bower_components/multiselect/js/jquery.multi-select.js"></script>


<!-- data-table js -->
<script src="<?php echo base_url();?>files/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>files/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>files/assets/pages/data-table/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>files/assets/pages/data-table/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>files/assets/pages/data-table/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>files/bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url();?>files/bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>files/bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url();?>files/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url();?>files/bower_components/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

<!-- Validation js -->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script type="text/javascript" src="<?php //echo base_url();?>files/assets/pages/form-validation/validate.js"></script>-->
    
<!-- i18next.min.js -->
<script type="text/javascript" src="<?php echo base_url();?>files/bower_components/i18next/js/i18next.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>files/bower_components/i18next-xhr-backend/js/i18nextXHRBackend.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>files/bower_components/i18next-browser-languagedetector/js/i18nextBrowserLanguageDetector.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>files/bower_components/jquery-i18next/js/jquery-i18next.min.js"></script>
<!-- Custom js -->
<script src="<?php echo base_url();?>files/assets/pages/data-table/js/data-table-custom.js"></script>
<script src="<?php echo base_url();?>files/assets/js/pcoded.min.js"></script>
<script src="<?php echo base_url();?>files/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo base_url();?>files/assets/js/script.js" type="text/javascript"></script>

<script type="text/javascript" src="<?php echo base_url();?>files/assets/pages/form-validation/form-validation.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#cat_name").change(function(){
		    var catid = $("#cat_name").val();
		    $.ajax({url: "<?php echo base_url();?>admin/dashboard/showsubcat/"+catid, success: function(result){
		    $("#scat").html(result);
		  }});
		});
	});
</script>

<script type="text/javascript">
    $( ".row_position" ).sortable({
        delay: 150,
        stop: function() {
            var selectedData = new Array();
            $('.row_position>tr').each(function() {
                selectedData.push($(this).attr("id"));
            });
            updateOrder(selectedData);
        }
    });


    function updateOrder(data) {
        $.ajax({
            url:"<?php echo base_url();?>admin/dashboard/updatecatorder/",
            type:'post',
            data:{position:data},
            success:function(){
               // alert('Your change successfully saved');
                location.reload(true);
            }
        })
    }
</script>
</body>
</html>
