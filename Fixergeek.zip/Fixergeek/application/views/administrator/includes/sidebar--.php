<?php
  $cName = $this->router->fetch_class();
  $mName = $this->router->fetch_method();
?>
<style>
	#styleSelector
	{
	  display:none;
	}
</style>	
<div class="pcoded-main-container">
<div class="pcoded-wrapper">
<nav class="pcoded-navbar">
<div class="pcoded-inner-navbar main-menu">
<div class="pcoded-navigatio-lavel">Navigation</div>
     <ul class="pcoded-item pcoded-left-item">
        <li class="<? if($cName=='dashboard'){?>active<? }?>">
            <a href="<?php echo base_url();?>admin/dashboard">
                <span class="pcoded-micon"><i class="feather icon-home"></i></span>
                <span class="pcoded-mtext">Dashboard</span>
            </a>
        </li>

        <li class="pcoded-hasmenu">
            <a href="javascript:void(0)">
                <span class="pcoded-micon"><i class="feather icon-sidebar"></i></span>
                <span class="pcoded-mtext">CMS Pages</span>
                <span class="pcoded-badge label label-warning">NEW</span>
            </a>
            <ul class="pcoded-submenu">
                <li class="">
                    <a href="javascript:void(0)">
                        <span class="pcoded-mtext">How it works</span>
                    </a>
                </li>
                
                <li class="">
                    <a href="#">
                        <span class="pcoded-mtext">Terms & Use</span>
                    </a>
                </li>
                <li class=" ">
                    <a href="#">
                        <span class="pcoded-mtext">Privacy Policy</span>
                    </a>
                </li>
                <li class=" ">
                    <a href="#">
                        <span class="pcoded-mtext">About Us</span>
                    </a>
                </li>
            </ul>
        </li>
    </ul>

    <ul class="pcoded-item pcoded-left-item">
        <li class="pcoded-hasmenu  pcoded-trigger">
            <a href="javascript:void(0)">
                <span class="pcoded-micon"><i class="feather icon-menu"></i></span>
                <span class="pcoded-mtext">Fixes Categories</span>
            </a>
            <ul class="pcoded-submenu">
                <li class=" pcoded-hasmenu">
                    <a href="#">
                        <span class="pcoded-mtext">Category</span>
                    </a>

                    <ul class="pcoded-submenu">
                        <li class=" ">
                            <a href="<?php echo base_url();?>admin/dashboard/addcategory">
                                <span class="pcoded-mtext">Add Category</span>
                            </a>
                        </li>

                        <li class=" ">
                            <a href="<?php echo base_url();?>admin/dashboard/category">
                                <span class="pcoded-mtext">Category List</span>
                            </a>
                        </li>

                    </ul>
                 </li>

                 <li class=" pcoded-hasmenu">
                    <a href="#">
                        <span class="pcoded-mtext">Sub Category</span>
                    </a>

                    <ul class="pcoded-submenu">
                        <li class=" ">
                            <a href="<?php echo base_url();?>admin/dashboard/addsubcategory">
                                <span class="pcoded-mtext">Add Sub Category</span>
                            </a>
                        </li>

                        <li class=" ">
                            <a href="<?php echo base_url();?>admin/dashboard/subcategory">
                                <span class="pcoded-mtext">Sub Category List</span>
                            </a>
                        </li>

                    </ul>
                 </li>

                 <li class=" pcoded-hasmenu">
                    <a href="#">
                        <span class="pcoded-mtext">Sub Sub Items</span>
                    </a>

                    <ul class="pcoded-submenu">
                        <li class=" ">
                            <a href="<?php echo base_url();?>admin/dashboard/addsubsubcategory">
                                <span class="pcoded-mtext">Add Sub Sub Item</span>
                            </a>
                        </li>

                        <li class=" ">
                            <a href="<?php echo base_url();?>admin/dashboard/subsubcategory">
                                <span class="pcoded-mtext">Sub Sub Items List</span>
                            </a>
                        </li>

                    </ul>
                 </li>
            </ul>
        </li>
    </ul>

    <ul class="pcoded-item pcoded-left-item">
        <li class="pcoded-hasmenu <? if($cName=='users'){?>active<? }?>">
            <a href="javascript:void(0)">
                <span class="pcoded-micon"><i class="feather icon-users"></i></span>
                <span class="pcoded-mtext">Manage Geeks</span>
            </a>
            <ul class="pcoded-submenu">
                <li>
                    <a href="<?php echo base_url();?>admin/users/add">
                        <span class="pcoded-mtext">Add Geek</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>admin/users">
                        <span class="pcoded-mtext">Geeks List</span>
                    </a>
                </li>
                
            </ul>
        </li>
    </ul>

  <!--   <ul class="pcoded-item pcoded-left-item">
        <li class="pcoded-hasmenu">
            <a href="javascript:void(0)">
                <span class="pcoded-micon"><i class="feather icon-layers"></i></span>
                <span class="pcoded-mtext">Manage Topics</span>
            </a>
            <ul class="pcoded-submenu">
                <li>
                    <a href="<?php echo base_url();?>admin/topics/addtopic">
                        <span class="pcoded-mtext">Add Topic</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url();?>admin/topics">
                        <span class="pcoded-mtext">Topic List</span>
                    </a>
                </li>
                
            </ul>
        </li>
      </ul>
 -->
    <ul class="pcoded-item pcoded-left-item">
        <li class="pcoded-hasmenu <? if($cName=='questions'){?>active<? }?>">
            <a href="javascript:void(0)">
                <span class="pcoded-micon"><i class="feather icon-check-circle"></i></span>
                <span class="pcoded-mtext">Manage Q&A</span>
            </a>
            <ul class="pcoded-submenu">

            	<li>
                    <a href="<?php echo base_url();?>admin/questions/add">
                        <span class="pcoded-mtext">Add Question</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>admin/questions">
                        <span class="pcoded-mtext">Questions List</span>
                    </a>
                </li>
                
            </ul>
        </li>

      </ul>
      <!-- <ul class="pcoded-item pcoded-left-item">
        <li class="pcoded-hasmenu">
            <a href="javascript:void(0)">
                <span class="pcoded-micon"><i class="feather icon-check-circle"></i></span>
                <span class="pcoded-mtext">Comments Master</span>
            </a>
            <ul class="pcoded-submenu">

                <li>
                    <a href="<?php echo base_url();?>admin/comments/add">
                        <span class="pcoded-mtext">Add Comments</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>admin/comments">
                        <span class="pcoded-mtext">Comments List</span>
                    </a>
                </li>
                
            </ul>
        </li>

      </ul>
       <ul class="pcoded-item pcoded-left-item">
        <li class="pcoded-hasmenu">
            <a href="javascript:void(0)">
                <span class="pcoded-micon"><i class="feather icon-check-circle"></i></span>
                <span class="pcoded-mtext">Reply Master</span>
            </a>
            <ul class="pcoded-submenu">

                <li>
                    <a href="<?php echo base_url();?>admin/reply/add">
                        <span class="pcoded-mtext">Add Reply</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url();?>admin/reply">
                        <span class="pcoded-mtext">Reply List</span>
                    </a>
                </li>
                
            </ul>
        </li>

      </ul> -->

</div>
</nav>
