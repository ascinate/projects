
<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>Category List</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="#"> <i class="feather icon-home"></i> </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Category</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<div align="right"><a href="<?php echo base_url();?>admin/dashboard/addcategory" class="btn btn-primary m-b-0">Add Category</a></div>
<div>&nbsp;</div>

<!-- Page-body start -->
<div class="page-body">
    <!-- DOM/Jquery table start -->
    <div class="card">
        <div class="card-block">
            <div class="dt-responsive table-responsive">
                <table id="dom-jqry" class="table table-striped table-bordered nowrap">
                    <thead>
                        <tr>
                            <th>Serial No.</th>
                            <th>Category Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody class="row_position">
                    	<?php
                    		$i = 1;
 							foreach($category as $row)
 							{
                    	?>
                        <tr id="<?=$row->id?>" style="cursor: move;">
                            <td><?=$i?></td>
                            <td><?=$row->category_name;?></td>
                            <td align="center">
                            	<a href="<?php echo base_url();?>admin/dashboard/editcategory/<?=$row->id;?>"><i class="fa fa-pencil" aria-hidden="true"></i></a> &nbsp;
                           		<a href="<?php echo base_url();?>admin/dashboard/deletecat/<?=$row->id;?>"><i class="fa fa-trash" aria-hidden="true"></i></a>  
                           	</td>
                        </tr>
                       <?php
                             $i++;
                         	}
                        ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
    <!-- DOM/Jquery table end -->
    <!-- Column Rendering table start -->
</div>
    <!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>

