<?php
   $id = $this->uri->segment(4);
   $result = $this->db->get_where('user_master', array('id'=>$id))->row();

   $query = $this->db->query("select * from `fixergeek_master` where `user_id` = '".$id."'");
   $rec = $query->row();
   
   $start = $rec->start_time;
   $end = $rec->end_time;
   $available = $rec->available_days;
   $timezone = $rec->timezone;
   
    $review=$this->db->get_where('review_master',array('fixer_id'=>$id));
	$stat=$this->db->get_where('review_master',array('fixer_id'=>$fixer->user_id , 'status'=>'Fixed'));
	$stat2=$this->db->get_where('review_master',array('fixer_id'=>$fixer->user_id , 'status'=>'Not Fixed'));
	
	$score = $review->row();
	$tot = ($score->conduct+$score->timing+$score->literacy+$score->knowledge+$score->pchandle+$score->type_speed)/6;
	$fixes = $stat->num_rows();
	$nonfixes = $stat2->num_rows();
				
   $stat=$this->db->get_where('review_master',array('fixer_id'=>$id , 'status'=>'Fixed'));
   $fixes = $stat->num_rows();
							 
   $numrow = $query->num_rows();
   
    if($numrow!=0)
	{
	   $this->session->set_userdata('user_type', 'fixer');
	}
	else
	{
	   $this->session->set_userdata('user_type', 'asker');
	}
?>
<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>Edit User</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="#"> <i class="feather icon-home"></i> </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Edit User</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<!-- Page-body start -->
<div class="page-body">
<div class="row">
<div class="col-sm-12">

<!-- Basic Form Inputs card start -->
<div class="card">
    <div class="card-block">
        <h4 class="sub-title">Admin Inputs</h4>
       <?php
          foreach ($users as $row)
          {
        ?>
        <form id="main" action="<?php echo base_url();?>admin/users/updateuser" method="post" enctype="multipart/form-data">
        	<input type="hidden" name="id" value="<?=$row->id?>" />

        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Geek Type</label>
            <div class="col-sm-10"> <?php echo ucwords($this->session->userdata('user_type'));?> </div>		
        </div>
        
        <div class="form-group row">
        <label class="col-sm-2 col-form-label">Geek Active</label>
        <div class="col-sm-10"> 
          <select name="is_active" class="form-control">
            <option value="">Select</option>
            <option value="Y"<? if($row->is_active=='Y'){ echo 'selected';}?>>Yes</option>
            <option value="N"<? if($row->is_active=='N'){ echo 'selected';}?>>No</option>
          </select>
        </div>		
        </div>
        <?php if($this->session->userdata('user_type')=='fixer') {?>
         <div class="form-group row">
            <label class="col-sm-2 col-form-label">Categories</label>
            <div class="col-sm-10"> 
              <?php
                 $items = explode(",",$rec->sub_sub_cat_id);
				 
				 $i=1;
				 foreach($items as $val)
				 {
				    $rs = $this->db->get_where('sub_sub_category_master', array('id'=>$val))->row();
					$comma_string[] = $rs->sub_sub_category_name;
				 } 
				 
			     echo implode(", ", $comma_string);
			  ?>
            </div>		
        </div>
        
         <div class="form-group row">
            <label class="col-sm-2 col-form-label">Days</label>
            <div class="col-sm-10"><?php echo str_replace(",",", ",$available);?></div>		
        </div>
        
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Availability</label>
            <div class="col-sm-10"><?php echo $start;?> to <?php echo $end;?></div>		
        </div>
        
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">Timezone</label>
            <div class="col-sm-10"><?php echo $timezone;?></div>		
         </div>
         
         <div class="form-group row">
            <label class="col-sm-2 col-form-label">Total Payment</label>
            <div class="col-sm-10"></div>		
         </div>
         
         <div class="form-group row">
            <label class="col-sm-2 col-form-label">Total Score</label>
            <div class="col-sm-10"><?php if($tot!=0){ echo number_format($tot,2); } else { echo 'Not Available.'; }?></div>		
         </div>
         
         <div class="form-group row">
            <label class="col-sm-2 col-form-label">Problem Fixed</label>
            <div class="col-sm-10"> <?=$fixes?></div>		
         </div>
         
         <div class="form-group row">
            <label class="col-sm-2 col-form-label">Problem Not Fixed</label>
            <div class="col-sm-10"><?=$nonfixes?></div>		
         </div>
         <?php }?>
        <hr />
        <h4 class="sub-title">User Inputs</h4>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Geek Name</label>
                <div class="col-sm-10">
                    <input type="text" name="geek_name"  value="<?=$row->geek_name?>" id="geekname" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Full Name</label>
                <div class="col-sm-10">
                    <input type="text" name="name"  value="<?=$row->name?>" id="name" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="text" name="email" value="<?=$row->email?>"  id="email" class="form-control" required>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" name="password" value="<?=$row->password?>" class="form-control">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Date of Birth</label>
                <div class="col-sm-10">
                    <input type="date" name="date_of_birth" value="<?=$row->date_of_birth?>" class="form-control">
                </div>
            </div>
            
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Gender</label>
                <div class="col-sm-10">
                    <select name="gender" class="form-control">
                        <option value="">Select</option>
                        <option value="Male"<?php if($row->gender=='Male'){ echo 'selected'; }?>>Male</option>
                        <option value="Female"<?php if($row->gender=='Female'){ echo 'selected'; }?>>Female</option>
                    </select>
                </div>
            </div>
            
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Country</label>
                <div class="col-sm-10">
                    <select name="country" class="form-control">
                    	<option value="">Select</option>
                    	<?php
  							$query = $this->db->get('country_master');
  							foreach($query->result() as $res)
  							{
                    	?>
                        	<option value="<?=$res->iso?>"<?php if($row->country==$res->iso){ echo 'selected'; }?>>
                        		<?=$res->nicename;?> 
                        	</option>
                        <?php
   							}
                        ?>
                    </select>
                </div>
            </div>
            
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Phone</label>
                <div class="col-sm-10">
                    <input type="text" name="phone" value="<?=$row->phone?>" class="form-control" maxlength="12">
                </div>
            </div>
            
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Qualification</label>
                <div class="col-sm-10">
                    
                     <select name="qualification" class="form-control sl-new" required>
                          <option value="">Select</option>
                          <option value="School"<?php if($row->qualification=='School'){ echo 'selected'; }?>>School</option>
                          <option value="High School"<?php if($row->qualification=='High School'){ echo 'selected'; }?>>High School</option>
                          <option value="Diploma"<?php if($row->qualification=='Diploma'){ echo 'selected'; }?>>Diploma</option>
                          <option value="Bachelors"<?php if($row->qualification=='Bachelors'){ echo 'selected'; }?>>Bachelors</option>
                          <option value="Postgraduate Diploma"<?php if($row->qualification=='Postgraduate Diploma'){ echo 'selected'; }?>>Postgraduate Diploma</option>
                          <option value="Masters"<?php if($row->qualification=='Masters'){ echo 'selected'; }?>>Masters</option>
                      </select>
                </div>
            </div>
            
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Profile Picture</label>
                <div class="col-sm-10">
                    <div class="pic-sec-delect">
                           <?php for($x=1;$x<=15;$x++) {?>
                               <div class="comon-sec-picker">
                                  <input type="radio" name="profile_picture" id="av<?=$x?>" class="input-hidden" value="avatar<?=$x?>.png"
                                    <?php if($row->profile_picture=='avatar'.$x.'.png') { echo 'checked';}?>  />
                                  <label for="av<?=$x?>">
                                    <img src="<?php echo base_url();?>/uploads/avatar<?=$x?>.png"  alt="avatar<?=$x?>" />
                                  </label>
                               </div>
                           <?php }?>
                    </div>
                </div>
            </div>
                        
            <div class="form-group row">
                <label class="col-sm-2"></label>
                <div class="col-sm-10">
                    <button type="submit" name="update" class="btn btn-primary m-b-0">Update</button>&nbsp;
                    <button type="button" name="cancel" class="btn btn-primary m-b-0" onclick="javascript:history.go(-1);">Cancel</button>
                </div>
            </div>
        </form>
        <?php
          }
         ?>
        
  	  </div>
  	 </div>
		<!-- Basic Form Inputs card end -->
 	 </div>
   </div>
  </div>
  	  <!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>