<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>Edit Answer</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="#"> <i class="feather icon-home"></i> </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Edit Answer</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<!-- Page-body start -->
<div class="page-body">
<div class="row">
<div class="col-sm-12">
<!-- Basic Form Inputs card start -->
<div class="card">
    <div class="card-block">
        <h4 class="sub-title">Basic Inputs</h4>
         <?php
          foreach ($answers as $row)
          {
        ?>
        <form id="main" action="<?php echo base_url();?>admin/answers/update" method="post" enctype="multipart/form-data">
        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
        <input type="hidden" name="id" value="<?=$this->uri->segment(5)?>">
        <input type="hidden" name="qid" value="<?=$this->uri->segment(4)?>">
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Geek Name</label>
                <div class="col-sm-10">
                <select name="user_id" class="form-control" required>
                <option value="Admin"<?php if($row->user_id=='Admin'){echo"selected";}?>>Admin</option>
                <?php 
                $user=$this->db->get_where('user_master')->result();
                foreach($user as $val)
                {?>
                <option value="<?=$val->id?>"<?php if($row->user_id==$val->id){echo"selected";}?>><?=$val->geek_name?></option>
                <?php }?>
                </select>

                </div>
            </div>
            <div class="form-group row">
            	<label class="col-sm-2 col-form-label">Answer</label>
                <div class="col-sm-10">

                 <textarea name="answer" id="editor"><?=$row->answer?></textarea>
                <script>
					tinymce.init({
					  selector: '#editor',
					  plugins: 'a11ychecker advcode casechange formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
					  toolbar: 'a11ycheck addcomment showcomments casechange checklist code formatpainter pageembed permanentpen table',
					  toolbar_mode: 'floating',
					  tinycomments_mode: 'embedded',
					  tinycomments_author: 'Author name',
					});
				  </script>
                </div>
            </div>
             <!-- <div class="form-group row">
                <label class="col-sm-2 col-form-label">Image</label>
                <div class="col-sm-10">
                <input type="file" name="image" class="form-control">
                </div>
            </div> -->
            <div class="form-group row">
            	<label class="col-sm-2 col-form-label">Level</label>
                <div class="col-sm-10">

                <select name="level" class="form-control">
                 <option value="Open"<?php if('Open'==$row->level) { echo 'selected'; }?>>Open</option>
                 <option value="Locked"<?php if('Locked'==$row->level) { echo 'selected'; }?>>Locked</option>
                 <option value="Approved"<?php if('Approved'==$row->level) { echo 'selected'; }?>>Approved</option>
                </select>

                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2"></label>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary m-b-0">Update</button>&nbsp;
                    <button type="button" onclick="javascript:history.go(-1)" class="btn btn-primary m-b-0">Cancel</button>
                </div>
            </div>
        </form>
         <?php 
     		}
    	 ?>
  	  </div>
  	 </div>
		<!-- Basic Form Inputs card end -->
 	 </div>
   </div>
  </div>
  	  <!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>

<script>
    mobiscroll.settings = {
        lang: 'en',                           // Specify language like: lang: 'pl' or omit setting to use default
        theme: 'ios',                         // Specify theme like: theme: 'ios' or omit setting to use default
            themeVariant: 'light'             // More info about themeVariant: https://docs.mobiscroll.com/4-10-3/select#opt-themeVariant
    };
    
    $(function () {
        var reg,
            div,
            sub,
            remoteReg,
            remoteDiv,
            remoteSub,
            emptyValue = { value: '', text: '', disabled: true },
            regions = [

	            <?php
	                $query = $this->db->get('category_master');

	                $arr = array();
	                foreach($query->result() as $res)
	                {
	                	$arr[] = $res->id;
	            ?>

                { value: <?=$res->id?>, text: '<?=$res->category_name?>' }<?php if($res->id != 8) { ?>,<?php } ?>

                <?php
                    }
                ?>
            ],
            divisions = {

            	<?php 
            	  foreach($arr as $val) 
            	  { 

            	  	 $subcat = $this->db->query("select * from `sub_category_master` where cat_id = '".$val."'");
            	?>

                <?=$val?>: [

                    <?php
	                    foreach($subcat->result() as $row) 
	                    { 
                    ?>
                    { value: <?=$row->id?>, text: '<?=$row->sub_category_name?>' },
               		<?php } ?>
                ],

               <?php  } ?>
            },
            subdivisions = {
            	<?php 

            	  $subSql = $this->db->query("select * from `sub_category_master`");

            	  foreach($subSql->result() as $rex) 
            	  { 

            	  	 $mcat = $this->db->query("select * from `sub_sub_category_master` where sub_cat_id = '".$rex->id."'");
            	?>

                <?=$rex->id?>: [

                    <?php  foreach($mcat->result() as $rec) { ?> 
                    { value: <?=$rec->id?>, text: '<?=$rec->sub_sub_category_name?>' },
                    <?php } ?>
                ],

                <?php } ?>
            };
    
        function getData(region, division) {
            var arr;
    
            if (division) {
                arr = subdivisions[division];
            } else if (region) {
                arr = divisions[region];
            } else {
                arr = regions;
            }
    
            return arr;
        }
    
        reg = $('#demo-data-reg').mobiscroll().select({
            touchUi: false,                   // More info about touchUi: https://docs.mobiscroll.com/4-10-3/select#opt-touchUi
            placeholder: 'Please select...',  // More info about placeholder: https://docs.mobiscroll.com/4-10-3/select#opt-placeholder
            data: getData(),                  // More info about data: https://docs.mobiscroll.com/4-10-3/select#opt-data
            onSet: function (ev, inst) {      // More info about onSet: https://docs.mobiscroll.com/4-10-3/select#event-onSet
                div.settings.invalid.length = 0
                div.setVal('', true);
                div.refresh(getData(inst.getVal()));
                div.enable();
    
                sub.settings.invalid.length = 0;
                sub.setVal('', true);
                sub.refresh([emptyValue]);
                sub.disable();
            }
        }).mobiscroll('getInst');
    
        div = $('#demo-data-div').mobiscroll().select({
            touchUi: false,                   // More info about touchUi: https://docs.mobiscroll.com/4-10-3/select#opt-touchUi
            disabled: true,                   // More info about disabled: https://docs.mobiscroll.com/4-10-3/select#opt-disabled
            placeholder: 'Please select...',  // More info about placeholder: https://docs.mobiscroll.com/4-10-3/select#opt-placeholder
            data: [emptyValue],               // More info about data: https://docs.mobiscroll.com/4-10-3/select#opt-data
            onSet: function (ev, inst) {      // More info about onSet: https://docs.mobiscroll.com/4-10-3/select#event-onSet
                sub.settings.invalid.length = 0;
                sub.setVal('', true);
                sub.refresh(getData(null, inst.getVal()));
                sub.enable();
            }
        }).mobiscroll('getInst');
    
        sub = $('#demo-data-sub').mobiscroll().select({
            touchUi: false,                   // More info about touchUi: https://docs.mobiscroll.com/4-10-3/select#opt-touchUi
            disabled: true,                   // More info about disabled: https://docs.mobiscroll.com/4-10-3/select#opt-disabled
            placeholder: 'Please select...',  // More info about placeholder: https://docs.mobiscroll.com/4-10-3/select#opt-placeholder
            data: [emptyValue]                // More info about data: https://docs.mobiscroll.com/4-10-3/select#opt-data
        }).mobiscroll('getInst');
    
    });
</script>