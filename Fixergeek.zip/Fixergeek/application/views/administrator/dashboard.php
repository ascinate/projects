<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
 <div class="page-wrapper">

        <div class="page-body">
            <div class="row">
                <!-- task, page, download counter  start -->
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-c-yellow update-card">
                        <div class="card-block">
                            <div class="row align-items-end">
                                <div class="col-8">
                                    <?php 
                                    $no=$this->db->get('fixergeek_master')->num_rows();
                                    ?>
                                    <h4 class="text-white"><?=$no;?></h4>
                                    <h6 class="text-white m-b-0">No of Fixer Geeks</h6>
                                </div>
                                <div class="col-4 text-right">
                                    <canvas id="update-chart-1" height="50"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <p class="text-white m-b-0"><i class="feather icon-clock text-white f-14 m-r-10"></i>update : <?=date('H:i a')?></p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-c-green update-card">
                        <div class="card-block">
                            <div class="row align-items-end">
                                <div class="col-8">
                                    <?php 
                                     $geek=$this->db->get('user_master')->num_rows();
                                    ?>
                                    <h4 class="text-white"><?php echo ($geek - $no);?></h4>
                                    <h6 class="text-white m-b-0">No of Asker Geeks</h6>
                                </div>
                                <div class="col-4 text-right">
                                    <canvas id="update-chart-2" height="50"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <p class="text-white m-b-0"><i class="feather icon-clock text-white f-14 m-r-10"></i>update : <?=date('H:i a')?></p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-c-pink update-card">
                        <div class="card-block">
                            <div class="row align-items-end">
                                <div class="col-8">
                                    <h4 class="text-white">0$</h4>
                                    <h6 class="text-white m-b-0">Total Earning</h6>
                                </div>
                                <div class="col-4 text-right">
                                    <canvas id="update-chart-3" height="50"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <p class="text-white m-b-0"><i class="feather icon-clock text-white f-14 m-r-10"></i>update : <?=date('H:i a')?></p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-c-lite-green update-card">
                        <div class="card-block">
                            <div class="row align-items-end">
                                <div class="col-12">
                                    <?php
                                    $ans=$this->db->get('answers_master')->num_rows(); 
                                    $qus=$this->db->get('questions_master')->num_rows();
                                    ?>
                                    <h4 class="text-white"><?=$ans;?>/<?=$qus;?></h4>
                                    <h6 class="text-white m-b-0">Total Answers/Questions</h6>
                                </div>
                                <!--<div class="col-3 text-right">
                                    <canvas id="update-chart-4" height="50"></canvas>
                                </div>-->
                            </div>
                        </div>
                        <div class="card-footer">
                            <p class="text-white m-b-0"><i class="feather icon-clock text-white f-14 m-r-10"></i>update : <?=date('H:i a')?></p>
                        </div>
                    </div>
                </div>
                <!-- task, page, download counter  end -->

               <div class="col-xl-6 col-md-12">
                    <div class="card table-card">
                        <div class="card-header">
                            <h5>Fixer Geeks Online</h5>
                            <!-- <div class="card-header-right">
                                <ul class="list-unstyled card-option">
                                    <li><i class="feather icon-maximize full-card"></i></li>
                                    <li><i class="feather icon-minus minimize-card"></i></li>
                                    <li><i class="feather icon-trash-2 close-card"></i></li>
                                </ul>
                            </div> -->
                        </div>
                        <div class="card-block">
                            <div class="table-responsive">
                                <table class="table table-hover  table-borderless">
                                    <thead>
                                        <tr>
                                            <th>Geek Name</th>
                                            <th>Fixes</th>
                                            <th>Availability</th>
                                            <th>Timezone</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
									  $fixer_qry=$this->db->query("select * from `fixergeek_master`");
									  foreach($fixer_qry->result() as $fixer)
									  {
									    $sqluser=$this->db->get_where('user_master',array('id' => $fixer->user_id,'status' => 'online'));
										$numrows = $sqluser->num_rows();
										$user = $sqluser->row();
										
										$stat=$this->db->get_where('review_master',array('fixer_id'=>$fixer->user_id , 'status'=>'Fixed'));
										$fixes = $stat->num_rows();
										
										if($numrows!=0)
										{
									?>
                                        <tr>
                                            <td><?=$user->name?></td>
                                            <td><?=$fixes?></td>
                                            <td<?=$fixer->start_time;?> to <?=$fixer->end_time;?></td>
                                            <td><?=$fixer->timezone?></td>
                                        </tr>
                                    <?php
									    }
										/*else
										{
									?>
                                       <tr><td colspan="4" align="center">No Records Found.</td></tr>
                                    <?php
									    }	*/
									  }
									 ?>    
                                    </tbody>
                                </table>
                                <!--<div class="text-center">
                                    <a href="#!" class=" b-b-primary text-primary">View all</a>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-md-12">
                    <div class="card table-card">
                        <div class="card-header">
                            <h5>Asker Geeks Online</h5>
                            <!-- <div class="card-header-right">
                                <ul class="list-unstyled card-option">
                                    <li><i class="feather icon-maximize full-card"></i></li>
                                    <li><i class="feather icon-minus minimize-card"></i></li>
                                    <li><i class="feather icon-trash-2 close-card"></i></li>
                                </ul>
                            </div> -->
                        </div>
                        <div class="card-block">
                            <div class="table-responsive">
                                <table class="table table-hover  table-borderless">
                                    <thead>
                                        <tr>
                                            <th>Geek Name</th>
                                            <th>Level Required</th>
                                            <th>Problems Fixed</th>
                                            <th>Not Fixed</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
									    $sqluser=$this->db->get_where('user_master',array('status' => 'online'));
										$numrows = $sqluser->num_rows();
										
										foreach($sqluser->result() as $asker)
									    {
											$question=$this->db->get_where('questions_master',array('user_id'=>$asker->id))->row();
				
											if($question->level==3) { $level = 'Fixer (Level 3)'; }
											if($question->level==2) { $level = 'Helper (Level 2)'; }
											if($question->level==1) { $level = 'Chatter (Level 1)'; }
											
											$assign = $this->db->get_where('questions_assign_master',array('assigned_by'=>$asker->id, 'status'=>'Fixed'));
											$assign2 = $this->db->get_where('questions_assign_master',array('assigned_by'=>$asker->id, 'status'=>'Not Fixed'));
											
											$fix = $assign->num_rows();
											$notfix = $assign2->num_rows();
										
										if($numrows!=0)
										{
									?>
                                        <tr>
                                          <td><?=$asker->name?></td>
                                          <td align="center"><?php if($question->level!=NULL){ echo $level; } else { echo '<i class="fa fa-times" aria-hidden="true"></i>'; }?></td>
                                          <td align="center"><?=$fix?></td>
                                          <td align="center"><?=$notfix?></td>
                                        </tr>
                                    <?php
									    }
										else
										{
									?>
                                       <tr><td colspan="4" align="center">No Records Found.</td></tr>
                                    <?php
									    }	
									   }
									 ?>    
                                    </tbody>
                                </table>
                                <!--<div class="text-center">
                                    <a href="#!" class=" b-b-primary text-primary">View all</a>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div id="styleSelector"></div>
</div>
</div>
</div>