<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>Answer List</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li>
                      <a href="<?php echo base_url();?>admin/answers/add/<?=$this->uri->segment(4);?>">
                        <button type="button" class="btn btn-success">Add Answer</button> 
                      </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<div class="page-body">
<div class="card">
        <div class="card-block">
 <?php
    $sql = $this->db->get_where('questions_master', array('id' => $this->uri->segment(4)));
	$res = $sql->row();
	
	echo "<strong>Question: </strong>".  stripslashes($res->question); 
 ?>
 </div>
 </div>
</div>
    <!-- Page-body start -->
<div class="page-body">
    <!-- DOM/Jquery table start -->
    <div class="card">
        <div class="card-block">
            <div class="dt-responsive table-responsive">
                <table width="100%" id="dom-jqry" class="table table-striped table-bordered nowrap">
                    <thead>
                        <tr>
                            <th width="19%">Geek Name</th>
                          <th width="25%">Answers</th>
                          <th width="35%">Comments & Replies</th>
                          <th width="21%">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    	<?php
                    		$qid = $this->uri->segment(4);
                            $i=1;
 							foreach($answers as $row)
 							{

                    	    ?>
                        <tr>
                            <td><?php 
                            if($row->user_id=="Admin")
                            {
                             echo"Admin";
                            }else{
                            $user=$this->db->get_where('user_master',array('id'=>$row->user_id))->row();
                            echo $user->geek_name;
                            }
                            ?></td>
                            <td><?=substr($row->answer,0,100);?></td>
                            <!--<td><?=$row->level;?></td>-->
                            <td align="center">
                               <a href="<?php echo base_url();?>admin/comments/show/<?=$qid?>/<?=$row->id;?>" title="view answers">
                                <i class="fa fa-eye" aria-hidden="true"></i></a>
                            </td>
                            <td align="center">
                                <a href="<?php echo base_url();?>admin/answers/viewanswer/<?=$qid?>/<?=$row->id;?>" title="view answers">
                                <i class="fa fa-eye" aria-hidden="true"></i></a> &nbsp;
                                <a href="<?php echo base_url();?>admin/answers/editanswer/<?=$qid?>/<?=$row->id;?>" title="view answers">
                                <i class="fa fa-pencil" aria-hidden="true"></i></a> &nbsp;
                           		<a href="<?php echo base_url();?>admin/answers/deleteanswer/<?=$qid?>/<?=$row->id;?>" title="delete question">
                                <i class="fa fa-trash" aria-hidden="true"></i></a>  
                           	</td>
                        </tr>
                       <?php
                             $i++;
                         	}
                        ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
    <!-- DOM/Jquery table end -->
    <!-- Column Rendering table start -->
</div>
    <!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>