<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>Comments List</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li>
                      <a href="<?php echo base_url();?>admin/comments/add/<?=$this->uri->segment(4);?>/<?=$this->uri->segment(5);?>">
                        <button type="button" class="btn btn-success">Add Comment</button> 
                      </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<!-- Page-body start -->
<div class="page-body">
    <!-- DOM/Jquery table start -->
    <div class="card">
        <div class="card-block">
            <div class="dt-responsive table-responsive">
                <table id="dom-jqry" class="table table-striped table-bordered nowrap">
                    <thead>
                        <tr><th>User</th>
                            <th>Answer</th>
                            <th>Comments</th>
                            <!--<th>Reply</th>-->
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    	<?php
                    		$i = 1;
 							foreach($comments as $row)
 							{
                               $query = $this->db->query("select * from `answers_master` where id = '".$this->uri->segment(5)."'");
                               $result = $query->row();
                               $user=$this->db->get_where('user_master',array('id'=>$row->user_id))->row();
                    	?>
                        <tr>
                            <td><?=$user->name;?></td>
                            <td><?=substr($result->answer,0,75);?>..</td>
                            <td><?=$row->comment;?></td>
                            <!--<td>
                            <a href="<?php echo base_url();?>admin/reply/show/<?=$row->id;?>" title="view answers">
                            <i class="fa fa-eye" aria-hidden="true"></i></a> </td>-->
                            <td align="center">
                            	<!-- <a href="<?php echo base_url();?>admin/comments/list/<?=$row->id;?>" title="view answers">
                                <i class="fa fa-eye" aria-hidden="true"></i></a> &nbsp;
                                <a href="<?php //echo base_url();?>admin/questions/editquestion/<?=$row->id;?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>&nbsp; -->
                           		<a href="<?php echo base_url();?>admin/comments/deletecomments/<?=$row->id;?>/<?=$row->question_id?>" title="delete question">
                                <i class="fa fa-trash" aria-hidden="true"></i></a>  
                           	</td>
                              <div class="total-review-sec">
                              <tbody>
                                <?php
                                   $reply = $this->db->get_where('reply_master', array('comment_id' => $row->id));
								   foreach($reply->result() as $rval)
								   {
								      $ruser=$this->db->get_where('user_master',array('id'=>$rval->user_id))->row();
								?>
                                <div class="one-d1">
                                    <tr style="background:#fff;">
                                      <td style="background:#fff;  border-top:none;"> 
                                         <div class="one-row"> <strong>Reply</strong> User: <?=$ruser->name;?>  </div>
                                      </td>
                                      <td style="background:#fff;  border-top:none;"> 
                                         <div class="one-row"> <?=substr($result->answer,0,40);?>...  </div>
                                      </td>
                                      <td style="background:#fff;  border-top:none;">
                                        <div class="one-row ">  <strong>Re:</strong> <?=$rval->reply;?>  </div> 
                                      </td>
                                      <td style="text-align:center; border-top:none;">
                                         <a href="#"> <i class="fa fa-trash" aria-hidden="true"></i> </a>
                                      </td>
                                    </tr>
                                  </div>
                                   <?php
									   $rreply = $this->db->get_where('reply_reply_master', array('reply_id' => $rval->id));
									   foreach($rreply->result() as $rrval)
									   {
										  $rruser=$this->db->get_where('user_master',array('id'=>$rrval->user_id))->row();
								  ?>
                                  <div class="one-d1">
                                    <tr style="background:#fff;  border-bottom:none;">
                                      <td style="background:#fff;   border-top:none;"> 
                                         <div class="one-row">  <strong>Re:Re:</strong> User: <?=$rruser->name;?>  </div>
                                      </td>
                                      <td style="background:#fff;  border-top:none;"> 
                                         <div class="one-row"> <?=substr($result->answer,0,40);?>...  </div>
                                      </td>
                                      <td style="background:#fff;  border-top:none;">
                                        <div class="one-row ">  <strong>Re:Re:</strong> <?=$rrval->subreply;?>  </div> 
                                      </td>
                                      <td style="text-align:center; border-top:none;">
                                         <a href="#"> <i class="fa fa-trash" aria-hidden="true"></i> </a>
                                      </td>
                                    </tr>
                                  </div>
                                  
                                  <?php 
								      } 
								    }
								  ?>
                                  
                               </div>
                             </tbody>
                        </tr>
                       <?php
                             $i++;
                         	}
                        ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
    <!-- DOM/Jquery table end -->
    <!-- Column Rendering table start -->
</div>
<!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>