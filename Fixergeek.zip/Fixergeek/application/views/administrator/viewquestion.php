<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>View Question</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="#"> <i class="feather icon-home"></i> </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">View Question</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<!-- Page-body start -->
<div class="page-body">
<div class="row">
<div class="col-sm-12">
<!-- Basic Form Inputs card start -->
<div class="card">
    <div class="card-block">
        <h4 class="sub-title">Basic Inputs</h4>
        <?php 
        foreach($questions as $row)
        {
        $cat= $this->db->get_where('category_master',array('id'=>$row->category_name))->row(); 
        $sub= $this->db->get_where('sub_category_master',array('id'=>$row->sub_cat_id))->row(); 
        $sub_sub=$this->db->get_where('sub_sub_category_master',array('id'=>$row->sub_sub_cat_id))->row(); 
        ?>
      
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Question:-</label>
                <div class="col-sm-10">
                    <?=$row->question?>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Category:-</label>
                <div class="col-sm-10">
                     <?=$cat->category_name;?>                   
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Sub Category:-</label>
                <div class="col-sm-10">
                  <?=$sub->sub_category_name?>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Sub Sub Category:-</label>
                <div class="col-sm-10">
                 <?=$sub_sub->sub_sub_category_name;?>
                </div>
            </div>

             <div class="form-group row">
                <label class="col-sm-2 col-form-label">Topics:-</label>
                <div class="col-sm-10">
                <?=$row->topics;?>
                </div>
            </div>


           <div class="form-group row">
                <label class="col-sm-2 col-form-label">Description:-</label>
                <div class="col-sm-10">

                <?=$row->content?>

                </div>
            </div>

             <div class="form-group row">
                <div class="col-md-12 text-right">
               <img src="<?php echo base_url();?>uploads/<?=$row->uploaded_files?>" class="img-div">
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2"></label>
                <div class="col-sm-10 text-right">
                    <button type="button" class="btn btn-primary m-b-0" onClick="history.go(-1);">Back</button>
                </div>
            </div>

       <?php } ?> 
      </div>
     </div>
		<!-- Basic Form Inputs card end -->
 	 </div>
   </div>
  </div>
  	  <!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>
<style type="text/css">
    .img-div
    {
    width: 83%;
    height: 70%;
    }
</style>