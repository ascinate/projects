<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>Reply List</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
         <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li>
                      <a href="<?php echo base_url();?>admin/reply/add/<?=$this->uri->segment(4);?>">
                        <button type="button" class="btn btn-success">Add Reply</button> 
                      </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<!-- Page-body start -->
<div class="page-body">
    <!-- DOM/Jquery table start -->
    <div class="card">
        <div class="card-block">
            <div class="dt-responsive table-responsive">
                <table id="dom-jqry" class="table table-striped table-bordered nowrap">
                    <thead>
                        <tr><th>User</th>
                            <th>Question</th>
                            <th>Comments</th>
                            <th>Reply</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    	<?php
                    		$i = 1;
 							foreach($reply as $row)
 							{
                               $query = $this->db->query("select * from `questions_master` where id = '".$row->question_id."'");
                               $result = $query->row();
                               $user=$this->db->get_where('user_master',array('id'=>$row->user_id))->row();
                               $comm=$this->db->get_where('comment_master',array('id'=>$row->comment_id))->row();
                    	?>
                        <tr>
                            <td><?=$user->name;?></td>
                            <td><?=substr($result->question,0,30);?>..</td>
                            <td><?=substr($comm->comments,0,30);?>..</td>
                            <td><?=substr($row->reply,0,30);?>..</td>
                            <td align="center">
                            	<a href="<?php echo base_url();?>admin/reply/list/<?=$row->id;?>" title="view answers">
                                <i class="fa fa-eye" aria-hidden="true"></i></a> &nbsp;
                                <!-- <a href="<?php //echo base_url();?>admin/questions/editquestion/<?=$row->id;?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>&nbsp; -->
                           		<a href="<?php echo base_url();?>admin/reply/deletereply/<?=$row->id;?>/<?=$comm->id?>" title="delete question">
                                <i class="fa fa-trash" aria-hidden="true"></i></a>  
                           	</td>
                        </tr>
                       <?php
                             $i++;
                         	}
                        ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
    <!-- DOM/Jquery table end -->
    <!-- Column Rendering table start -->
</div>
<!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>