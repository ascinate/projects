<!-- Mobiscroll JS and CSS Includes -->
<link href="<?php echo base_url();?>files/assets/css/mobiscroll.jquery.min.css" rel="stylesheet">
<script src="<?php echo base_url();?>files/assets/js/mobiscroll.jquery.min.js"></script>

<div class="pcoded-content">
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<!-- Page-header start -->
<div class="page-header">
    <div class="row align-items-end">
        <div class="col-lg-8">
            <div class="page-header-title">
                <div class="d-inline">
                    <h4>Add Comments</h4>
                    <span>Basic informations</span>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="page-header-breadcrumb">
                <ul class="breadcrumb-title">
                    <li class="breadcrumb-item">
                        <a href="#"> <i class="feather icon-home"></i> </a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#!">Add Comments</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page-header end -->

<!-- Page-body start -->
<div class="page-body">
<div class="row">
<div class="col-sm-12">
<!-- Basic Form Inputs card start -->
<div class="card">
    <div class="card-block">
        <h4 class="sub-title">Basic Inputs</h4>
        <form id="main" action="<?php echo base_url();?>admin/comments/insertcomments" method="post" enctype="multipart/form-data">
          <input type="hidden" name="question_id" value="<?=$this->uri->segment(4);?>">
          <input type="hidden" name="answer_id" value="<?=$this->uri->segment(5);?>">
              <!--<div class="form-group row">
                <label class="col-sm-2 col-form-label">Answer</label>
                <div class="col-sm-10">
                  <?php 
                   // $ans=$this->db->get_where('answers_master',array('id'=>$this->uri->segment(4)))->row();
                  ?>
                   <input type="text" name="" value="<?=$ans->answer?>" class="form-control" disabled>
                </div>
            </div>-->
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">User</label>
                <div class="col-sm-10">
                   <select name="user_id" class="form-control">
                       <?php 
                        $user=$this->db->get_where('user_master')->result();
                        foreach($user as $val)
                        {
                        ?>
                        <option value="<?=$val->id?>"><?=$val->name?></option>
                    <?php } ?>
                   </select>
                </div>
            </div>
          
    
           <div class="form-group row">
            	<label class="col-sm-2 col-form-label">Comment</label>
                <div class="col-sm-10">
                 <textarea name="comments" id="editor"></textarea>
                 <script>
                 CKEDITOR.replace('comments');
                </script>

                </div>
            </div>


            <div class="form-group row">
                <label class="col-sm-2"></label>
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary m-b-0">Submit</button>
                </div>
            </div>
        </form>
        
  	  </div>
  	 </div>
		<!-- Basic Form Inputs card end -->
 	 </div>
   </div>
  </div>
  	  <!-- Page-body start -->
</div>
</div>
</div>
</div>
</div>
</div>

