    <!--    host-account-section-start-->
    <section class="body-background py-5">
        <div class="host-section-wrap">
            <div class="container big-container">
                <div class="row justify-content-center">
                    <div class="col-xl-9  pr-xl-0 pr-3">
                        <div class="host-section-left-box">
                            <div class="row justify-content-center ml-lg-0 ml-3">
                                <div class="host-section-border col-lg-3 col-md-6 col-sm-10 col-11 pl-lg-0 pl-3 pr-lg-0 pr-3 mb-lg-0 mb-3">
                                    <div class="host-section-left-list">
                                        <?php $this->load->view('includes/left-navigation-supporters');?>
                                    </div>
                                </div>
                                <div class="col-lg-9 mt-lg-0 mt-3 pr-xl-0 pr-3">
                                    <div class="security-settings-wrap">
                                        <h6 class="mt-3 mb-3 security-settings-page-heading">
                                            Change Password
                                        </h6>
                                        <div class="security-password-div">
                                            <form>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-md-8">
                                                            <div class="row mb-3">
                                                                <div class="col-md-4 my-auto">
                                                                    <label for="exampleInputPassword1">Current Password</label>
                                                                </div>
                                                                <div class="col-md-8">
                                                                    <input type="password" class="form-control" id="exampleInputPassword1">
                                                                </div>
                                                            </div>

                                                            <div class="row mb-3">
                                                                <div class="col-md-4 my-auto">
                                                                    <label for="exampleInputPassword1">New Password</label>
                                                                </div>
                                                                <div class="col-md-8">
                                                                    <input type="password" class="form-control" id="exampleInputPassword1">
                                                                </div>
                                                            </div>

                                                            <div class="row mb-3">
                                                                <div class="col-md-4 my-auto">
                                                                    <label for="exampleInputPassword1">Confirm New Password</label>
                                                                </div>
                                                                <div class="col-md-8">
                                                                    <input type="password" class="form-control" id="exampleInputPassword1">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <h6 class="mt-2 mb-3 security-settings-page-heading">
                                            Block/Unblock User
                                        </h6>
                                        <div class="block-user-form-part mb-4">
                                            <form>
                                                <div class="form-group">
                                                    <div class="row justify-content-center mb-3">
                                                        <div class="col-md-3 my-auto">
                                                            <label for="exampleInputEmail1">Block User</label>
                                                        </div>
                                                        <div class="col-md-7">
                                                            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter User Name">
                                                        </div>
                                                        <div class="col-md-2 pl-0">
                                                            <button type="submit" class="btn btn-primary default-btn">Block</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            <div class="row justify-content-end mb-5">
                                                <div class="col-md-9">
                                                    <ul class="blocked-list">
                                                        <li>Maxbrayne (<a href="#">Unblock</a>)</li>
                                                        <li>MarkSelby25 (<a href="#">Unblock</a>)</li>
                                                        <li>Shawn667 (<a href="#">Unblock</a>)</li>
                                                        <li>Shariq_2027 (<a href="#">Unblock</a>)</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="account-deactivation pt-3">
                                            <a class="mb-3" href="#">Deactivate Account</a>
                                            <a class="mb-3" href="#">Delete Account</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
                        <div class="host-section-right-box">
                            <a href="#">Advertisement</a>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <!--    host-account-section-end-->
