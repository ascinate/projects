    <section class="body-background py-5">
        <div class="host-section-wrap position-relative">
            <div class="container big-container">
                <div class="row justify-content-center">
                    <div class="col-xl-9  pr-xl-0 pr-3">
                        <div class="host-section-left-box">
                            <div class="row justify-content-center ml-lg-0 ml-3">
                                <div class="host-section-border col-lg-3 col-md-6 col-sm-10 col-11 pl-lg-0 pl-3 pr-lg-0 pr-3 mb-lg-0 mb-3">
                                    <div class="host-section-left-list">
                                        <?php $this->load->view('includes/left-navigation-supporters');?>
                                    </div>
                                </div>
                                <div class="col-lg-9 mt-lg-0 mt-3 pr-xl-0 pr-3">
                                    <div class="acoount_coment_wrap-1">
                                        <div class="row mx-0">
                                            <div class="col-lg-4">
                                                <div class="acoount_coment_score text-center">
                                                    <h4 class="mb-2">Your Score</h4>
                                                    <h1 class="mb-3">3.8</h1>
                                                    <div class="fixed_not_fixed text-center">
                                                        <p class="green_user-1"><i class="fa fa-check"></i>35 problems fixed</p>
                                                        <p class="red_user-1"><i class="fa fa-times"></i>15 problems not fixed</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--  -->
                                            <div class="offset-lg-3 col-lg-5">
                                                <div class="scoreboard">
                                                    <p class="mb-2"><b>Maxbrayne's Score:</b></p>
                                                    <table class="table table12">
                                                        <tbody>
                                                            <tr>
                                                                <td>Conduct</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Timing/Speed</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>English Literacy</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Technical Knowledge</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Pc Handeling</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Typing Speed</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr class="total">
                                                                <td>Total</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </div>
                                            </div>
                                        </div>
                                        <hr class="my-3">
                                        <div class="row mx-0 mt-4">
                                            <div class="col-md-7">
                                                <div class="Problem-details">
                                                    <ul>
                                                        <li><b>Problem:</b> <span>'How do i speed up my PC to play games'</span></li>
                                                        <li><b>Price:</b> <span>$35</span></li>
                                                        <li><b>Outcome:</b> <span class="green_user-1"><i class="fa fa-check"></i>Fixed</span></li>
                                                        <li><b>Level: 3</b> <span>(Fixer)</span></li>
                                                        <li><b>Comment:</b> <span class="problems_details_para">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                                                consequat. </span></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="scoreboard">
                                                    <p class="mb-2"><b>Maxbrayne's Score:</b></p>
                                                    <table class="table table12">
                                                        <tbody>
                                                            <tr>
                                                                <td>Conduct</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Timing/Speed</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>English Literacy</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Technical Knowledge</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Pc Handeling</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Typing Speed</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr class="total">
                                                                <td>Total</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </div>
                                            </div>
                                        </div>
                                        <!--  -->
                                        <hr class="my-0">
                                        <!-- row-finish -->
                                        <div class="row mx-0 mt-4">
                                            <div class="col-md-7">
                                                <div class="Problem-details">
                                                    <ul>
                                                        <li><b>Problem:</b> <span>'How to install animated walpaper in windows 10'</span></li>
                                                        <li><b>Price:</b> <span>$30</span></li>
                                                        <li class="user_podium_score_fixed red_user-"><b>Outcome:</b> <span class="red_user-1"><i class="fa fa-check "></i>Didn't Fix</span></li>
                                                        <li><b>Level: 2</b> <span>(Helper)</span></li>
                                                        <li><b>Comment:</b> <span class="problems_details_para">joeMartyjoe wasn't able to solve my issue,i wanted to get installed an animated wallpaper and he just wasn't able to do it.However, he tried his best.I figured out how to do it myself after ideas from him.</span></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="scoreboard">
                                                    <p class="mb-2"><b>Markshelby25's Score:</b></p>
                                                    <table class="table table12">
                                                        <tbody>
                                                            <tr>
                                                                <td>Conduct</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Timing/Speed</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>English Literacy</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Technical Knowledge</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Pc Handeling</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Typing Speed</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr class="total">
                                                                <td>Total</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </div>
                                            </div>
                                        </div>
                                        <!--  -->
                                        <hr class="my-0">
                                        <!-- row-finish -->
                                        <div class="row mx-0 mt-4">
                                            <div class="col-md-7">
                                                <div class="Problem-details">
                                                    <ul>
                                                        <li><b>Problem:</b> <span>'How to install animated walpaper in windows 10'</span></li>
                                                        <li><b>Price:</b> <span>$30</span></li>
                                                        <li class="user_podium_score_fixed red_user-"><b>Outcome:</b> <span class="red_user-1"><i class="fa fa-check "></i>Didn't Fix</span></li>
                                                        <li><b>Level: 2</b> <span>(Helper)</span></li>
                                                        <li><b>Comment:</b> <span class="problems_details_para">joeMartyjoe wasn't able to solve my issue,i wanted to get installed an animated wallpaper and he just wasn't able to do it.However, he tried his best.I figured out how to do it myself after ideas from him.</span></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="scoreboard">
                                                    <p class="mb-2"><b>Markshelby25's Score:</b></p>
                                                    <table class="table table12">
                                                        <tbody>
                                                            <tr>
                                                                <td>Conduct</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Timing/Speed</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>English Literacy</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Technical Knowledge</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Pc Handeling</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr>
                                                                <td>Typing Speed</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                            <tr class="total">
                                                                <td>Total</td>
                                                                <td class="end">4.0</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </div>
                                            </div>
                                        </div>
                                        <!--  -->
                                        <hr class="my-0">
                                        <!-- pegination -->
                                        <div class="row justify-content-end mx-0 mt-4">
                                            <div class="col-md-12">
                                                <div class="user_po_pegination">
                                                    <nav aria-label="Page navigation example">
                                                        <ul class="pagination">
                                                            <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">Previous</a></li>
                                                            <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">1</a></li>
                                                            <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">2</a></li>
                                                            <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">3</a></li>
                                                            <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">Next</a></li>
                                                        </ul>
                                                    </nav>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--  -->
                    <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
                        <div class="host-section-right-box">
                            <a href="#">Advertisement</a>
                        </div>
                    </div>
                    <!--
                <div class="col-xl-2 pl-xl-0 pl-3 mt-xl-0 mt-4">
                    <div class="host-section-right-box right-box-special" style="background-image: url(images/ad.png)">
                        <a href="#">Advertisement</a>
                    </div>
                </div>
-->
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <!-- account-settings-part -->
