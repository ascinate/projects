    <!--    host-account-section-start-->
    <section class="body-background py-5">
        <div class="host-section-wrap">
            <div class="container big-container">
                <div class="row justify-content-center">
                    <div class="col-xl-9  pr-xl-0 pr-3">
                        <div class="host-section-left-box">
                            <div class="row justify-content-center ml-lg-0 ml-3">
                                <div class="host-section-border col-lg-3 col-md-6 col-sm-10 col-11 pl-lg-0 pl-3 pr-lg-0 pr-3 mb-lg-0 mb-3">
                                    <div class="host-section-left-list">
                                         <?php $this->load->view('includes/left-navigation-supporters');?>
                                    </div>
                                </div>
                                <div class="col-lg-9 mt-lg-0 mt-3 pr-xl-0 pr-3">
                                    <div class="fixes-and-problems-wrap">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="problems-wrap mb-3">
                                                    <h6 class="mb-3"><b>Your Problems:</b></h6>
                                                    <a href="#" class="mb-1">How can I start virtualization through BIOS Configuration? (5 fixes)</a>
                                                    <a href="#" class="mb-1">How do I install retroArch on my PC? (2 fixes)</a>
                                                </div>
                                                <div class="fixes-wrap mb-3">
                                                    <h6 class="mb-3"><b>Your Fixes:</b></h6>
                                                    <a href="#" class="mb-1">How do I install animated Wallpaper on my PC?</a>
                                                    <a href="#" class="mb-1">How do I overclock my processor in Windows 10?</a>
                                                    <a href="#" class="mb-1">How can I rename multiple files faster?</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
                        <div class="host-section-right-box">
                            <a href="#">Advertisement</a>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <!--    host-account-section-end-->
