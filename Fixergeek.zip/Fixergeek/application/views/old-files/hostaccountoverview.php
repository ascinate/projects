<!--    host-account-section-start-->
<section class="body-background py-5">
  <div class="host-section-wrap">
    <div class="container big-container">
      <div class="row justify-content-center">
        <div class="col-xl-9  pr-xl-0 pr-3">
          <div class="host-section-left-box">
            <div class="row justify-content-center ml-lg-0 ml-3">
              <div class="host-section-border col-lg-3 col-md-6 col-sm-10 col-11 pl-lg-0 pl-3 pr-lg-0 pr-3 mb-lg-0 mb-3">
                <div class="host-section-left-list">
                   <?php $this->load->view('includes/left-navigation-supporters');?>
                </div>
              </div>
              <div class="col-lg-9 mt-lg-0 mt-3 pr-xl-0 pr-3">
                <div class="host-section-mid-profile-box">
                  <div class="row justify-content-lg-start justify-content-center mr-lg-0 mx-0">
                    <div class="col-lg-4 col-md-5 col-sm-6 col-10 px-xl-2 px-3">
                      <div class="host-section-box-grid grid-1 my-3">
                        <h6 class="text-center mb-3">Profile</h6>
                        <p class="mb-1"><b>Geek Name:</b> maxbrayne</p>
                        <p class="mb-1"><b>Email:</b> maxbrayne@gmail.com</p>
                        <p><b>Country:</b> Canada</p>
                        <div class="host-section-grid-img text-center my-3"> <i class="fa fa-user" aria-hidden="true"></i> </div>
                        <div class="host-section-box-bottom text-center"> <a href="#">Change Info</a> </div>
                      </div>
                    </div>
                    <div class="col-lg-4 col-md-5 col-sm-6 col-10 px-xl-2 px-3">
                      <div class="host-section-box-grid grid-2 my-3">
                        <h6 class="text-center mb-3">Become a Fixer Geek</h6>
                        <h6 class="mb-1">Make Money Online.</h6>
                        <p class="mb-3">Follow our guidelines when answering/fixing problems of users to become a Fixer Geek</p>
                        <h6 class="mb-1">How to become a Fixer Geek?</h6>
                        <ul class="host-section-box-dropdown">
                          <li>1. Fix 3 Problems per Category</li>
                          <li>2. Be Technically Accurate</li>
                          <li>3. Show Good Use of Language</li>
                          <li>4. Write at least 250-500 Words</li>
                        </ul>
                        <div class="host-section-box-bottom text-center"> <a href="#">Our Guidelines</a> </div>
                      </div>
                    </div>
                    <div class="col-lg-4 col-md-5 col-sm-6 col-10 px-xl-2 px-3">
                      <div class="host-section-box-grid grid-3 my-3">
                        <h6 class="text-center mb-3">Fixes & Problems</h6>
                        <h6 class="mb-1">Problems</h6>
                        <a class="mb-1" href="#">How can I start virtualization through BIOS Configuration?</a> <a class="mb-3" href="#">How do I install retroArch on my PC ?</a>
                        <h6 class="mb-1">Fixes</h6>
                        <a class="mb-1" href="#">How do I install animated Wallpaper on my PC ?</a> <a class="mb-0" href="#">How do I overclock my processor in Windows 10? </a>
                        <div class="host-section-box-bottom text-center"> <a href="#">See More</a> </div>
                      </div>
                    </div>
                    <div class="col-lg-4 col-md-5 col-sm-6 col-10 px-xl-2 px-3">
                      <div class="host-section-box-grid grid-4 my-3">
                        <h6 class="text-center mb-3">Messeges</h6>
                        <h6 class="mt-4 mb-1">Admin Messages</h6>
                        <a class="mb-3" href="#">Unread (2)</a>
                        <h6 class="mt-3 mb-1">Geek Messages</h6>
                        <a class="mb-0" href="#">Unread (15)</a>
                        <div class="host-section-box-bottom text-center"> <a href="#">Read all Messages</a> </div>
                      </div>
                    </div>
                    <div class="col-lg-4 col-md-5 col-sm-6 col-10 px-xl-2 px-3">
                      <div class="host-section-box-grid grid-5 my-3">
                        <h6 class="text-center mb-3">Notifications</h6>
                        <p class="mt-3 mb-4">You’re in control of what emails you receive from FixerGeek.com</p>
                        <a class="mb-1" href="#">Admin Notifications</a> <a href="#">Geek Notifications</a>
                        <div class="host-section-box-bottom text-center"> <a href="#">Change Notifications</a> </div>
                      </div>
                    </div>
                    <div class="col-lg-4 col-md-5 col-sm-6 col-10 px-xl-2 px-3">
                      <div class="host-section-box-grid grid-6 my-3">
                        <h6 class="text-center mb-3">Account Settings</h6>
                        <p class="spl-p mb-0"><b>Your Default Credit/Debit Card:</b></p>
                        <p class="mb-3">VISA Ending 2308, exp 07/23</p>
                        <a href="#">View Payment & Billing Info</a>
                        <h6 class="mt-3 mb-1">Security Settings</h6>
                        <ul class="host-section-box-dropdown-2">
                          <li><a href="#">Change Password</a></li>
                          <li><a href="#">Deactiviate Account</a></li>
                          <li><a href="#">Delete Account</a></li>
                        </ul>
                        <div class="host-section-box-bottom text-center"> <a href="#">Change Security Options</a> </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
          <div class="host-section-right-box"> <a href="#">Advertisement</a> </div>
        </div>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
</section>
<!--    host-account-section-end-->