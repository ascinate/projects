    <!--    host-account-section-start-->

    <section class="host-section-wrap my-5">
        <div class="container big-container">
            <div class="row justify-content-center">
                <div class="col-xl-9  pr-xl-0 pr-3">
                    <div class="host-section-left-box">
                        <div class="row justify-content-center ml-lg-0 ml-3">
                            <div class="host-section-border col-lg-3 col-md-6 col-sm-10 col-11 pl-lg-0 pl-3 pr-lg-0 pr-3 mb-lg-0 mb-3">
                                <div class="host-section-left-list">
                                    <?php $this->load->view('includes/left-navigation-supporters-2');?>
                                </div>
                            </div>
                            <div class="col-lg-9 mt-lg-0 mt-3 pr-xl-0 pr-3">
                                <div class="become-a-supporter-box">
                                    <h6 class="mt-3 mb-3 become-a-supporter-heading">
                                        Make Money Online!
                                    </h6>
                                    <p class="my-3">Following are our guidelines to become a Fixer Geek for Free!</p>

                                    <h6 class="mt-3 mb-3 become-a-supporter-heading">
                                        How to become a Fixer Geek?
                                    </h6>

                                    <ul class="become-a-supporter-list-1 mb-3">
                                        <li>1. You MUST Answer/Fix at least <span>3 Problems</span> in the category you want to become a Fixer Geek.</li>
                                        <li>2. You MUST be <span>Technically Accurate</span> providing complete solution to the problem.</li>
                                        <li>3. You MUST show <span>good use of Language</span>.</li>
                                        <li>4. You MUST write <span>at least 250-500 words</span> in your reply to the problem.</li>
                                        <li>5. You MUST write <span>a unique reply, plagarism will disqualify you</span>.</li>
                                        <li>6. You MAY <span>use images and videos</span> to support your answer/fix.</li>
                                        <li>7. You MAY <span>use headings and steps</span> in your write up.</li>
                                    </ul>

                                    <p class="mb-4">We review all answers/fixes to determine whether we qualify them or not on the points above.</p>

                                    <p class="mb-4">Here are a few good examples of qualified fixes given by some of our Fixer Geeks.</p>

                                    <ul class="become-a-supporter-list-2 mb-3">
                                        <li><a href="#">How do I install animated Wallpaper in Windows?</a></li>
                                        <li><a href="#">How do I play Neo Geo on RetroArch Emulator for Windows?</a></li>
                                        <li><a href="#">How do I Speed up my PC to play graphic intensive games?</a></li>
                                    </ul>

                                    <p class="mb-3">Once you qualify, you’ll start earning money helping people using JUST your computer. Join thousands who are already making a fortune doing their favorite job!</p>

                                    <p class="mb-3">Happy Supporting!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
                    <div class="host-section-right-box">
                        <a href="#">Advertisement</a>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </section>

    <!--    host-account-section-end-->
