
    <!--    host-account-section-start-->
    <section class="body-background py-5">
        <div class="host-section-wrap">
            <div class="container big-container">
                <div class="row justify-content-center">
                    <div class="col-xl-9  pr-xl-0 pr-3">
                        <div class="host-section-left-box">
                            <div class="row justify-content-center ml-lg-0 ml-3">
                                <div class="host-section-border col-lg-3 col-md-6 col-sm-10 col-11 pl-lg-0 pl-3 pr-lg-0 pr-3 mb-lg-0 mb-3">
                                    <div class="host-section-left-list">
                                         <?php $this->load->view('includes/left-navigation-supporters');?>
                                    </div>
                                </div>
                                <div class="col-lg-9 mt-lg-0 mt-3 pr-xl-0 pr-3">
                                    <div class="host-section-mid-profile-box notifica-set-wrap">
                                        <div class="notifica-set-wrap-head">
                                            <p>You will be informed via email for activity in your account on the following criteria.</p>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="admin_notification mt-4 text-left">
                                                    <p class="mb-3"><b>Admin Notifications:</b></p>
                                                    <form class="checkbox_listing checkbox_listing-1">
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html1" checked>
                                                            <label for="html1">Welcome Notification on Successful Signup (Notify me for successfully signup at FixerGeek.com)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html2" checked>
                                                            <label for="html2">Forgot Password or User Name Notification (Notify me for email address verification etc.)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html3" checked>
                                                            <label for="html3">Payment Notification (Notify me each month with amount earned for services)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html4" checked>
                                                            <label for="html4">Billing Notification (Notify if my Credit/Debit Card expires, floors etc.)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html5" checked>
                                                            <label for="html5">Deactivate Account Notification (Notify me if my account gets deactivated)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html6" checked>
                                                            <label for="html6">Delete Account Notification (Notify if your account gets deleted)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html7" checked>
                                                            <label for="html7"> Let Admin Contact me Notification (Notify me if FixerGeek.com want to contact me)</label>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!--  -->
                                        <hr class="my-0">
                                        <div class="row mt-3">
                                            <div class="col-12">
                                                <div class="User_notification mt-4 text-left">
                                                    <p class="mb-3"><b>User Notifications:</b></p>
                                                    <form class="checkbox_listing checkbox_listing-1">
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html91" checked>
                                                            <label for="html91">Fix Notification (Notify me if a Fix of my problem has been given)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html101" checked>
                                                            <label for="html101">Problem Notification (Notify me requests of geeks to fix their problems)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html111" checked>
                                                            <label for="html111">User Message Notification (Noify me if a User messages me)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html121" checked>
                                                            <label for="html121">Score & Comment Notification (Notify me if a User leaves a Score & Comment for me)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html131" checked>
                                                            <label for="html131">Hire Notification (Notify me if a user hires me through app)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html141" checked>
                                                            <label for="html141">Decline Notification (Notify me if a user declines a request for support)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html151" checked>
                                                            <label for="html151">Deny Notification (Notify me if a user denies an offer for support)</label>
                                                        </div>
                                                        <div class="form-group form-group-1 mb-1">
                                                            <input type="checkbox" id="html161" checked>
                                                            <label for="html161">Block Notification (Notify me if a user blocks me)</label>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
                        <div class="host-section-right-box">
                            <a href="#">Advertisement</a>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <!--    host-account-section-end-->

