    <!--    host-account-section-start-->
    <section class="body-background py-5">
        <div class="host-section-wrap">
            <div class="container big-container">
                <div class="row justify-content-center">
                    <div class="col-xl-9  pr-xl-0 pr-3">
                        <div class="sign-up-email-wrap">
                            <h6 class="mt-3 mb-3 sign-up-email-heading">
                                Sign up using your Email.
                            </h6>
                            <span class="mb-4">Create your account using</span>
                            <h6 class="mt-4 mb-3 sign-up-email-heading">
                                Sign Up!
                            </h6>
                            <div style="text-align: center; color: #08951B; padding-bottom: 10px;">
                                <?=$this->session->flashdata('err');?>
                            </div>
                            <div class="sign-up-email-form">
                               <form id="main" action="<?php echo base_url();?>signup/insertuser" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-lg-7">
                                                <div class="row mb-3">
                                                    <div class="col-md-4 my-auto pb-md-0 pb-2">
                                                        <label for="exampleFormControlFile1">Picture</label>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <input type="file" class="form-control-file" name="profile_picture" required>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-4 my-auto pb-md-0 pb-2">
                                                        <label for="exampleInputEmail1">Geek Name</label>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <input type="text" class="form-control" aria-describedby="emailHelp" name="geek_name" required>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-4 my-auto pb-md-0 pb-2">
                                                        <label for="exampleInputEmail1">Email Address</label>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <input type="email" class="form-control" aria-describedby="emailHelp" name="email" required>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-4 my-auto pb-md-0 pb-2">
                                                        <label for="exampleInputEmail1">Password</label>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <input type="password" class="form-control" aria-describedby="emailHelp" name="password" required>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-4 my-auto pb-md-0 pb-2">
                                                        <label for="exampleInputEmail1">Full Name</label>
                                                    </div>
                                                    <div class="col-md-8">
                                                    <input type="text" class="form-control" aria-describedby="emailHelp" name="name" required>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-4 my-auto pb-md-0 pb-2">
                                                        <label for="exampleFormControlSelect1">Date of Birth</label>
                                                    </div>
                                                    <div class="col-md-3 col-sm-4">
                                                      <select name="month" class="form-control sl-new" required>
                                                            <option value="01">January</option>
                                                            <option value="02">February</option>
                                                            <option value="03">March</option>
                                                            <option value="04">April</option>
                                                            <option value="05">May</option>
                                                            <option value="06">June</option>
                                                            <option value="07">July</option>
                                                            <option value="08">August</option>
                                                            <option value="09">September</option>
                                                            <option value="10">October</option>
                                                            <option value="11">November</option>
                                                            <option value="12">December</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-2 col-sm-4 px-sm-0 px-3 py-sm-0 py-3">
                                                     <select name="days" class="form-control" id="exampleFormControlSelect1" required>
                                                            <?php for($x=1; $x<=31; $x++) {?>
                                                            <option value="<?=$x?>"><?=$x?></option>
                                                            <?php }?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3 col-sm-4">
                                                       <select name="year" class="form-control" id="exampleFormControlSelect1" required>
                                                            <?php for($x=1980; $x<=1992; $x++) {?>
                                                            <option value="<?=$x?>"><?=$x?></option>
                                                            <?php }?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-4 my-auto pb-md-0 pb-2">
                                                        <label for="exampleFormControlSelect1">Gender</label>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <select name="gender" class="form-control" required>
                                                            <option value="">Select</option>
                                                            <option value="Male">Male</option>
                                                            <option value="Female">Female</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-4 my-auto pb-md-0 pb-2">
                                                        <label for="exampleFormControlSelect1">Country</label>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <select name="country" class="form-control sl-new" required>
                                                            <?php
                                                                $query = $this->db->get('country_master');  
                                                                foreach($query->result() as $res)
                                                                {
                                                            ?>
                                                                <option value="<?=$res->iso?>">
                                                                    <?=$res->nicename?> 
                                                                </option>
                                                            <?php
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-4 my-auto pb-md-0 pb-2">
                                                        <label for="exampleFormControlSelect1">Phone</label>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <input id="phone" type="text" name="phone" required>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-4 my-auto pb-md-0 pb-2">
                                                        <label for="exampleFormControlSelect1">Qualification</label>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <select name="qualification" class="form-control" required>
                                                            <option value="">Select</option>
                                                            <option value="bca">BCA</option>
                                                            <option value="mca">MCA</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row justify-content-lg-end justify-content-center">
                                                    <div class="col-md-8 col-sm-4 col-6 mt-3">
                                                        <button type="submit" class="btn btn-primary default-btn">Sign Up</button>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>


                    <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
                        <div class="host-section-right-box">
                            <a href="#">Advertisement</a>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <!--    host-account-section-end-->