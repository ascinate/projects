 <!-- account-settings-part -->
    <section class="body-background py-5">
        <div class="host-section-wrap position-relative">
            <div class="container big-container">
                <div class="row justify-content-center">
                    <div class="col-xl-9  pr-xl-0 pr-3">
                        <div class="host-section-left-box">
                            <div class="row justify-content-center ml-lg-0 ml-3">
                                <div class="host-section-border col-lg-3 col-md-6 col-sm-10 col-11 pl-lg-0 pl-3 pr-lg-0 pr-3 mb-lg-0 mb-3">
                                    <div class="host-section-left-list">
                                        <?php $this->load->view('includes/left-navigation-supporters');?>
                                    </div>
                                </div>
                                <div class="col-lg-9 mt-lg-0 mt-3 pr-xl-0 pr-3">
                                    <div class="ac_set_wrap">
                                        <div class="ac_set_wrap_head">
                                            <h6><b>Payment</b></h6>
                                            <h6 class="mt-3"><b>Report & Finance</b></h6>
                                        </div>
                                        <div class="ac-set-boxes mt-2">
                                            <div class="row">
                                                <div class="col-sm-3 mt-3">
                                                    <div class="weekly">
                                                        <div class="form-group  mb-0">
                                                            <select class="form-control act-set-from-control" id="exampleFormControlSelect1">
                                                                <option>Weekly</option>
                                                                <option>Monthly</option>
                                                                <option>Yearly</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3 mt-3">
                                                    <div class="calender-2">

                                                        <input placeholder="From" type="text" name="checkIn" id="datepicker" value="" class="calendar w-100"><i class="fa fa-calendar icon"></i>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3 mt-3">
                                                    <div class="calender-2">

                                                        <input placeholder="To" type="text" name="checkIn" id="datepicker1" value="" class="calendar w-100"><i class="fa fa-calendar icon"></i>
                                                    </div>
                                                </div>
                                                <div class="col-sm-3 mt-3">
                                                    <button class="default-btn">Run Report<br></button>
                                                </div>
                                            </div>
                                        </div>
                                        <!--  -->
                                        <div class="ac-set-table mt-4">
                                            <table class="table table-account">
                                                <thead class="thead-dark">
                                                    <tr>
                                                        <th scope="col">Date & Time</th>
                                                        <th scope="col">User Name</th>
                                                        <th scope="col">Price</th>
                                                        <th scope="col">Commission</th>
                                                        <th scope="col">Revenue</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <th scope="row">23/2-2020- 2:45 p.m</th>
                                                        <td>Mark</td>
                                                        <td>Otto</td>
                                                        <td>@mdo</td>
                                                        <td>@mdo</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">23/2-2020- 2:45 p.m</th>
                                                        <td>Jacob</td>
                                                        <td>Thornton</td>
                                                        <td>@fat</td>
                                                        <td>@mdo</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">23/2-2020- 2:45 p.m</th>
                                                        <td>Larry</td>
                                                        <td>the Bird</td>
                                                        <td>@twitter</td>
                                                        <td>@mdo</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">23/2-2020- 2:45 p.m</th>
                                                        <td>Larry</td>
                                                        <td>the Bird</td>
                                                        <td>@twitter</td>
                                                        <td>@mdo</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">23/2-2020- 2:45 p.m</th>
                                                        <td>Larry</td>
                                                        <td>the Bird</td>
                                                        <td>@twitter</td>
                                                        <td>@mdo</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">23/2-2020- 2:45 p.m</th>
                                                        <td>Larry</td>
                                                        <td>the Bird</td>
                                                        <td>@twitter</td>
                                                        <td>@mdo</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">23/2-2020- 2:45 p.m</th>
                                                        <td>Larry</td>
                                                        <td>the Bird</td>
                                                        <td>@twitter</td>
                                                        <td>@mdo</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">23/2-2020- 2:45 p.m </th>
                                                        <td>Larry</td>
                                                        <td>the Bird</td>
                                                        <td>@twitter</td>
                                                        <td>@mdo</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">23/2-2020- 2:45 p.m</th>
                                                        <td>Larry</td>
                                                        <td>the Bird</td>
                                                        <td>@twitter</td>
                                                        <td>@mdo</td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">23/2-2020- 2:45 p.m</th>
                                                        <td>Larry</td>
                                                        <td>the Bird</td>
                                                        <td>@twitter</td>
                                                        <td>@mdo</td>
                                                    </tr>
                                                </tbody>
                                            </table>

                                        </div>
                                        <!--  -->
                                        <div class="account-settings-payment mt-4">
                                            <h6><b>Choose Method of Payment</b></h6>
                                            <p class="mt-2">Choose how would you like to get paid each month for your services at FixerGeek.com</p>
                                            <hr class="my-2">
                                            <!-- check-box-start -->
                                            <div class="form-check my-1 form-check-inline">
                                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option2">
                                                <label class="form-check-label form-check-label-1" for="inlineRadio1">Check</label>
                                            </div>
                                            <div class="form-check my-4 form-check-inline">
                                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
                                                <label class="form-check-label form-check-label-1" for="inlineRadio2">Telegraphic Transfer</label>
                                            </div>
                                            <div id="check-form" class="row mt-4">
                                                <div class="col-sm-9 col-12">
                                                    <div class="row mx-0">
                                                        <div class="col-4 form-payment px-0">
                                                            <p class="pt-2">Full Name</p>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--  -->
                                                    <div class="row mx-0">
                                                        <div class="col-4  form-payment px-0">
                                                            <p class="pt-2">Address</p>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--  -->
                                                    <div class="row mx-0">
                                                        <div class="col-4  form-payment px-0">
                                                            <p class="pt-2">City</p>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--  -->
                                                    <div class="row mx-0">
                                                        <div class="col-4  form-payment px-0">
                                                            <p class="pt-2">Zip Code</p>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--  -->
                                                    <div class="row mx-0">
                                                        <div class="col-4  form-payment px-0">
                                                            <p class="pt-2">State</p>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row mx-0">
                                                        <div class="col-4 form-payment px-0">
                                                            <p class="pt-2">Country</p>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- 1-radio-option -->
                                            <!--                                        <hr>-->

                                            <!-- radio-start -->
                                            <!--
                                        <div class="form-check my-4 form-check-inline">
                                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
                                            <label class="form-check-label form-check-label-1" for="inlineRadio2">Telegraphic Transfer</label>
                                        </div>
-->
                                            <div id="telegraphic-form" class="row mt-4">
                                                <div class="col-sm-9 col-12">
                                                    <div class="row mx-0">
                                                        <div class="col-4  form-payment px-0">
                                                            <p class="pt-2">Full Name</p>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--  -->
                                                    <div class="row mx-0">
                                                        <div class="col-4  form-payment px-0">
                                                            <p class="pt-2">Bank Account No.</p>
                                                        </div>
                                                        <div class="col-8">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--  -->
                                                    <div class="row mx-0">
                                                        <div class="col-sm-4 col-4  form-payment px-0">
                                                            <p class="pt-2">Swift Code</p>
                                                        </div>
                                                        <div class="col-sm-8 col-8">
                                                            <div class="form-group">
                                                                <input type="text" class="form-control form-2" id="exampleInputPassword1" placeholder="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--  -->

                                                    <!--  -->
                                                </div>
                                            </div>
                                            <!-- 1-radio-option -->

                                        </div>
                                        <hr>
                                        <div class="account-set-billing mt-3">
                                            <div class="row">
                                                <div class="col-6">
                                                    <h6><b>Billing</b></h6>
                                                    <p class="mt-2">Save Credit / Debit Cards</p>
                                                </div>
                                                <div class="col-6 text-right">
                                                    <button class="default-btn">Add Card<br></button>
                                                </div>
                                            </div>
                                            <hr class="my-2">

                                            <div class="row justify-content-center mx-0 mt-3">
                                                <div class="col-md-12">
                                                    <div class="row">
                                                    <div class=" mb-3 col-xl-12 mx-0">
                                                        <div class="row">
                                                            <div class="col-4 px-0">
                                                                <div class="row mx-0">
                                                                    <div class="col-5 d-sm-block d-none billing-img">
                                                                        <img src="<?php echo base_url();?>assets/images/visa_PNG38.png.jpg" alt="">
                                                                    </div>
                                                                    <div class="col-7 my-auto visa px-2">
                                                                        <p>Visa (Default)</p>
                                                                        <p>**** **** **** 2308</p>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="col-4 my-auto px-0 text-center expires">
                                                                <p>Expires</p>
                                                                <p>07/12/2028</p>
                                                            </div>

                                                            <div class="col-4 px-0 my-auto text-center expires">
                                                                <a href="#">Delete</a>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div class=" mb-3 col-xl-12 mx-0">
                                                        <div class="row">
                                                            <div class="col-4 px-0">
                                                                <div class="row mx-0">
                                                                    <div class="col-5 d-sm-block d-none billing-img">
                                                                        <img src="<?php echo base_url();?>assets/images/mastercard_PNG13.png" alt="">
                                                                    </div>
                                                                    <div class="col-7 my-auto visa px-2">
                                                                        <p>Visa (Default)</p>
                                                                        <p>**** **** **** 2308</p>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="col-4 my-auto px-0 text-center expires">
                                                                <p>Expires</p>
                                                                <p>07/12/2028</p>
                                                            </div>

                                                            <div class="col-4 px-0 my-auto text-center expires">
                                                                <a href="#">Set Default</a><br>
                                                                <a href="#">Delete</a>
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <div class=" mb-3 col-xl-12 mx-0">
                                                        <div class="row">
                                                            <div class="col-4 px-0">
                                                                <div class="row mx-0">
                                                                    <div class="col-5 d-sm-block d-none billing-img">
                                                                        <img src="<?php echo base_url();?>assets/images/mastercard_PNG13.png" alt="">
                                                                    </div>
                                                                    <div class="col-7 my-auto visa px-2">
                                                                        <p>Visa (Default)</p>
                                                                        <p>**** **** **** 2308</p>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="col-4 my-auto px-0 text-center expires">
                                                                <p>Expires</p>
                                                                <p>07/12/2028</p>
                                                            </div>

                                                            <div class="col-4 px-0 my-auto text-center expires">
                                                                <a href="#">Set Default</a><br>
                                                                <a href="#">Delete</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--  -->
                    <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
                        <div class="host-section-right-box">
                            <a href="#">Advertisement</a>
                        </div>
                    </div>
                    <!--
                <div class="col-xl-2 pl-xl-0 pl-3 mt-xl-0 mt-4">
                    <div class="host-section-right-box right-box-special" style="background-image: url(images/ad.png)">
                        <a href="#">Advertisement</a>
                    </div>
                </div>
-->
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <!-- account-settings-part -->