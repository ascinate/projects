    <!--    host-account-section-start-->
    <section class="body-background py-5">
        <div class="host-section-wrap">
            <div class="container big-container">
                <div class="row justify-content-center">
                    <div class="col-xl-9  pr-xl-0 pr-3">
                        <div class="host-section-left-box">
                            <div class="row justify-content-center ml-lg-0 ml-3">
                                <div class="host-section-border col-lg-3 col-md-6 col-sm-10 col-11 pl-lg-0 pl-3 pr-lg-0 pr-3 mb-lg-0 mb-3">
                                    <div class="host-section-left-list">
                                        <?php $this->load->view('includes/left-navigation-supporters');?>
                                    </div>
                                </div>
                                <div class="col-lg-9 mt-lg-0 mt-3 pr-xl-0 pr-3">
                                    <div class="supporter-settings-wrap">
                                        <div class="row mb-3">
                                            <div class="col-md-12">
                                                <div class="supporter-box-1">
                                                    <p class="mb-3">You are currently a Fixer Geek. You can earn money by helping other geeks on Fixer Geek.com. Being a Fixer Geek you can provide services as a:</p>
                                                    <div class="supporter-page-list-1">
                                                        <ul>
                                                            <li class="pb-1"><i class="fa fa-check" aria-hidden="true"></i> <b>Fixer (Level 3) </b> - Remote Access Assistance</li>
                                                         <li class="pb-1"><i class="fa fa-check" aria-hidden="true"></i> <b>Helper (Level 2) </b> - Screen Sharing & Voice Chat</li>
                                                            <li class="pb-1"><i class="fa fa-check" aria-hidden="true"></i> <b>Chatter (Level 1) </b> - Text Chat Support</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="supporter-settings-form-box">
                                                    <h6 class="mb-1"><b>Your Availability:</b></h6>
                                                    <p>Being a Fixer Geek, you MUST choose your availability time so that other geeks can find out when you get Online to give your services. This time will be displayed on Fixer Geek.com</p>
                                                    <form>
                                                        <div class="row form-group mt-3 mb-3">
                                                            <div class="col-md-2 my-auto pr-0">
                                                                <label>Choose Time</label>
                                                            </div>
                                                            <div class="col-md-3 pl-0">
                                                                <select class="form-control spl-drop-time" id="exampleFormControlSelect1">
                                                                    <option>10.00 AM</option>
                                                                    <option>10.30 AM</option>
                                                                    <option>11.00 AM</option>
                                                                    <option>11.30 AM</option>
                                                                    <option>12.00 PM</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-2 px-0">
                                                                <select class="form-control spl-drop-time" id="exampleFormControlSelect1">
                                                                    <option>10.00 AM</option>
                                                                    <option>10.30 AM</option>
                                                                    <option>11.00 AM</option>
                                                                    <option>11.30 AM</option>
                                                                    <option>12.00 PM</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-5 supporter-spl-dropdown">
                                                                <div class="dropdown-spl">
                                                                    <div class="select">
                                                                        <span>Choose Days</span>
                                                                    </div>
                                                                    <input type="hidden">
                                                                    <ul class="dropdown-menu-spl">
                                                                        <li id="alldays">
                                                                            <div class="form-check">
                                                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                                                <label class="form-check-label" for="exampleCheck1">All Days</label>
                                                                            </div>
                                                                        </li>
                                                                        <hr>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                                                <label class="form-check-label" for="exampleCheck1">Weekdays</label>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                                                <label class="form-check-label" for="exampleCheck1">Weekends</label>
                                                                            </div>
                                                                        </li>
                                                                        <hr>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                                                <label class="form-check-label" for="exampleCheck1">Mondays</label>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                                                <label class="form-check-label" for="exampleCheck1">Tuesdays</label>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                                                <label class="form-check-label" for="exampleCheck1">Wednesdays</label>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                                                <label class="form-check-label" for="exampleCheck1">Thursdays</label>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                                                <label class="form-check-label" for="exampleCheck1">Fridays</label>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                                                <label class="form-check-label" for="exampleCheck1">Saturdays</label>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="form-check">
                                                                                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                                                                <label class="form-check-label" for="exampleCheck1">Sundays</label>
                                                                            </div>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row form-group mb-3">
                                                            <div class="col-md-2 my-auto pr-0">
                                                                <label for="exampleFormControlSelect100">Your Timezone</label>
                                                            </div>
                                                            <div class="col-md-6 pl-0">
                                                                <select class="form-control" id="exampleFormControlSelect100">
                                                                    <option>Choose your Timezone</option>
                                                                    <option>GMT+00:00</option>
                                                                    <option>GMT+01:00</option>
                                                                    <option>GMT+02:00</option>
                                                                    <option>GMT+03:00</option>
                                                                    <option>GMT+04:00</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-3 mb-4">
                                            <div class="col-md-12">
                                                <div class="supporter-box-2">
                                                    <h6 class="mb-1"><b>Your Fixer Geeks Categories:</b></h6>
                                                    <p class="mb-2">You are qualified as a Fixer Geeks in the categories below.</p>
                                                    <div class="supporter-page-list-2">
                                                        <ul>
                                                            <li class="pb-1"><i class="fa fa-check" aria-hidden="true"></i> <b>Viruses & Malware </b> (Viruses, Spyware, Ransomeware, Rootkit, Phishing, Spam, Key Logging, Firewall)</li>
                                                            <li class="pb-1"><i class="fa fa-check" aria-hidden="true"></i> <b>Tweaking </b> (Hidden Features, Hidden Settings, Customization, Configuration, Disk Compression)</li>
                                                            <li class="pb-1"><i class="fa fa-check" aria-hidden="true"></i> <b>Speed Up </b> (Boot Speed Up, Startup Issues, Process & Service Issues, User Issues, Restore Point Issues)</li>
                                                            <li class="pb-1"><i class="fa fa-check" aria-hidden="true"></i> <b>Disk Space Cleanup </b> (Temp Files & History, Empty Folders, Duplicate Files, Broken Shortcuts)</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mb-4">
                                            <div class="col-md-12">
                                                <div class="supporter-box-3">
                                                    <h6 class="mb-1"><b>Categories that you can qualify:</b></h6>
                                                    <p class="mb-2">In the following categories, you can qualify to become a Fixer Geek as soon as you give 3 answers/fixes for each based on our guidelines.</p>
                                                    <div class="supporter-page-list-3">
                                                        <ul>
                                                            <li class="pb-1"><b>Memory (RAM) Issues </b> (2 qualified answers/fixes so far!)</li>
                                                            <li class="pb-1"><b>Gaming </b> (1 qualified answer/fix so far!)</li>
                                                        </ul>
                                                        <p class="mt-2 mb-2">If you want to add more categories in your profile as a Fixer Geek, reply as many problems as you can in desired category. Following are our guidelines:</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="supporter-box-4">
                                                    <h6 class="mb-3"><b>How to become a Fixer Geek?</b></h6>
                                                    <div class="supporter-page-list-4 pt-1">
                                                        <ul>
                                                            <li class="pb-1">1. You MUST Answer/Fix at least <span>3 Problems</span> in the category you want to become a Fixer Geek.</li>
                                                            <li class="pb-1">2. You MUST be <span>Technically Accurate</span> providing complete solution to the problem.</li>
                                                            <li class="pb-1">3. You MUST show <span>good use of Language</span>.</li>
                                                            <li class="pb-1">4. You MUST write <span>at least 250-500 words</span> in your reply to the problem.</li>
                                                            <li class="pb-1">5. You MUST write <span>a unique reply, plagarism will disqualify you</span>.</li>
                                                            <li class="pb-1">6. You MAY <span>use images and videos</span> to support your answer/fix.</li>
                                                            <li class="pb-1">7. You MAY <span>use headings and steps</span> in your write up.</li>
                                                        </ul>
                                                    </div>
                                                    <p class="pt-3">We review all answers/fixes to determine whether we qualify them or not on the points above.</p>
                                                    <p class="pt-2">Here are a few good examples of qualified fixes given by some of our Fixer Geeks.</p>

                                                    <div class="supporter-page-list-5 pt-3">
                                                        <ul>
                                                            <li class="pb-1"><a href="#">How do I install animated Wallpaper in Windows?</a></li>
                                                            <li class="pb-1"><a href="#">How do I play Neo Geo on RetroArch Emulator for Windows?</a></li>
                                                            <li class="pb-1"><a href="#">How do I Speed up my PC to play graphic intensive games?</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
                        <div class="host-section-right-box">
                            <a href="#">Advertisement</a>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <!--    host-account-section-end-->