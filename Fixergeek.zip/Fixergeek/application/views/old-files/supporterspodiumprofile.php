    <!--    host-account-section-start-->
    <section class="body-background py-5">
        <div class="host-section-wrap supporter_podium_Profile supporter_podium_Profile_1 mx-4">
            <div class="container-fluid">
                <div class="row mx-0 ">
                    <div class="col-lg-9 col-12">
                        <div class="row mx-0">
                            <div class="col-12">
                                <div class="supporter_podium_Profile_pic d-flex">
                                    <i class="fa fa-user-circle-o" aria-hidden="true"></i>
                                    <div class="user_name pl-2 pt-2">
                                        <h4>JoeMartyJoe</h4>
                                        <p><i class="fa fa-circle green_user"></i> Online</p>
                                    </div>
                                </div>
                            </div>
                            <!--  -->
                            <div class="col-md-9">
                                <div class="grey_PODIUM_bg grey_PODIUM_bg-1 mt-3">
                                    <h6><b>Availability:</b> 3:00pm to 8:00pm</h6>
                                    <p class="mt-3"><b>Timezone:</b> Eastern Standard Time (GMT -5)</p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="user_podium_btn mt-3">
                                    <button class="btn btn-primary w-100 default-btn">Hire This Fixer</button>
                                    <button class="btn btn-primary mt-2 w-100 default-btn">Go Back</button>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="categories-1 mt-3">
                                    <ul>
                                        <li><b>Categories(Expert in):</b></li>
                                        <li><a href="#">PC Speed Up</a></li>
                                        <li><a href="#">Internet Speed Up</a></li>
                                        <li><a href="#">Memory (RAM) Issues</a></li>
                                        <li><a href="#">Personalization</a></li>
                                        <li><a href="#">Gaming</a></li>
                                        <li><a href="#">Apple Products</a></li>
                                        <li><a href="#">Microsoft Products</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="user_podium_info mt-4">
                                    <h6><b>JoeMartyJoe’s Profile:</b></h6>
                                    <p class="pt-2"><b>Gender: </b> Male</p>
                                    <p class="pt-1"><b>Country: </b>Canada</p>
                                    <p class="pt-1"><b>Educational Level: </b>Postgraduate Diploma</p>
                                    <p class="pt-1"><b>About JoeMartyJoe: </b> have worked on Windows since version 3.1. I have extensive knowledge in how to set it up correctly and even know all the hidden jewels
                                        in this operating system. My interests are in finding Windows security updates, security issues, speed up internet, fix IP and DNS related issues, overhaul Windows
                                        and fix errors etc.</p>
                                </div>
                            </div>
                            <hr class="mt-3 w-100">
                            <!--  -->
                            <div class="col-md-7 mt-2">
                                <div class="user_podium_info_2 mt-4">
                                    <h6><b>JoeMartyJoe’s Score:</b></h6>
                                    <div class="row">
                                        <div class="offset-lg-1 col-sm-4">
                                            <div class="user_podium_score py-4 text-center">
                                                <h5>3.8</h5>
                                                <div class="user_podium_score_fixed pt-4">
                                                    <p class="green_user-1"><i class="fa fa-check"></i>35 Problems Fixed</p>
                                                    <p class="red_user-1"><i class="fa fa-times"></i>32 Problem Not Fixed</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- table -->
                            <div class="col-md-5 mt-4">
                                <div class="scoreboard">
                                    <table class="table table12">
                                        <tbody>
                                            <tr>
                                                <td>Conduct</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Timing/Speed</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>English Literacy</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Technical Knowledge</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Pc Handeling</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Typing Speed</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr class="total">
                                                <td>Total</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>


                            <hr class="mb-3 w-100">
                            <!-- col-12-fnish -->

                            <!-- new-col-start -->
                            <div class="col-md-7 mt-2">
                                <div class="Problem-details">
                                    <ul>
                                        <li><b>Problem:</b> <span>'How do i speed up my PC to play games'</span></li>
                                        <li><b>Price:</b> <span>$35</span></li>
                                        <li class="user_podium_score_fixed"><b>Outcome:</b> <span class="green_user-1"><i class="fa fa-check "></i>Fixed</span></li>
                                        <li><b>Level: 3</b> <span>(Fixer)</span></li>
                                        <li><b>Comment:</b> <span class="problems_details_para">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                                consequat. </span></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-5 mt-3">
                                <div class="scoreboard">
                                    <p class="mb-2"><b>Maxbrayne's Score & Comments:</b></p>
                                    <table class="table table12">
                                        <tbody>
                                            <tr>
                                                <td>Conduct</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Timing/Speed</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>English Literacy</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Technical Knowledge</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Pc Handeling</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Typing Speed</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr class="total">
                                                <td>Total</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                            <!-- 1st-part-table -->
                            <hr class="mb-3 w-100">
                            <div class="col-md-7 mt-2">
                                <div class="Problem-details">
                                    <ul>
                                        <li><b>Problem:</b> <span>'How to install animated walpaper in windows 10'</span></li>
                                        <li><b>Price:</b> <span>$30</span></li>
                                        <li class="user_podium_score_fixed red_user-"><b>Outcome:</b> <span class="red_user-1"><i class="fa fa-check "></i>Didn't Fix</span></li>
                                        <li><b>Level: 2</b> <span>(Helper)</span></li>
                                        <li><b>Comment:</b> <span class="problems_details_para">joeMartyjoe wasn't able to solve my issue,i wanted to get installed an animated wallpaper and he just wasn't able to do it.However, he tried his best.I figured out how to do it myself after ideas from him.</span></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-5 mt-3">
                                <div class="scoreboard">
                                    <p class="mb-2"><b>Maxbrayne's Score & Comments:</b></p>
                                    <table class="table table12">
                                        <tbody>
                                            <tr>
                                                <td>Conduct</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Timing/Speed</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>English Literacy</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Technical Knowledge</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Pc Handeling</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr>
                                                <td>Typing Speed</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                            <tr class="total">
                                                <td>Total</td>
                                                <td class="end">4.0</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                            <!--  -->
                            <hr class="mb-3 w-100">
                        </div>
                    </div>
                </div>
                <!-- row-finish -->
                <div class="row justify-content-end mt-4">
                    <div class="col-12 text-right">
                        <div class="user_po_pegination">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                    <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">Previous</a></li>
                                    <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link page-link-1 default-btn" href="#">Next</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--    host-account-section-end-->