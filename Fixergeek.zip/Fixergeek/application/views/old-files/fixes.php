<!--    fixes-main-page-start-->
    <section class="body-background py-5">
        <div class="host-section-wrap fixes-main-page-wrap">
            <div class="container big-container">
                <div class="fixes-main-page-box">
                    <div class="row">
                        <div class="col-md-12">
                            <h6 class="fixes-main-page-heading mb-3">
                                Repairs & Security
                            </h6>
                        </div>
                        <div class="col-md-4">
                            <div class="fixes-main-page-small-box security-1 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Viruses & Malware
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Viruses</a></li>
                                    <li><a href="#">Spyware</a></li>
                                    <li><a href="#">Ransomeware</a></li>
                                    <li><a href="#">Phishing</a></li>
                                    <li><a href="#">Spam</a></li>
                                    <li><a href="#">Key Logging</a></li>
                                    <li><a href="#">Firewal</a></li>
                                    <li><a href="#">Identity Theft</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-2 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Disk Management
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Drive Partitioning</a></li>
                                    <li><a href="#">Disk Formatting</a></li>
                                    <li><a href="#">Check Disk</a></li>
                                    <li><a href="#">Scan Disk</a></li>
                                    <li><a href="#">Disk Compression</a></li>
                                    <li><a href="#">Defragmentation</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-3 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    User Control & Rights
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Access Control</a></li>
                                    <li><a href="#">Software Restriction</a></li>
                                    <li><a href="#">UAC</a></li>
                                    <li><a href="#">User</a></li>
                                    <li><a href="#">Rights Management</a></li>
                                    <li><a href="#">Parental Control</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-4 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    File Explorer
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Search</a></li>
                                    <li><a href="#">File & Search Option</a></li>
                                    <li><a href="#">Folder Options</a></li>
                                    <li><a href="#">Thumbnails</a></li>
                                    <li><a href="#">Sort & View</a></li>
                                    <li><a href="#">Context Menu</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-5 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Printing
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Printing Issues</a></li>
                                    <li><a href="#">Print to PDF</a></li>
                                    <li><a href="#">3D Printing</a></li>
                                    <li><a href="#">Settings</a></li>
                                    <li><a href="#">Page Layout</a></li>
                                    <li><a href="#">Color & Brightness</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="fixes-main-page-small-box security-6 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Operating System Issues
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">OS Install</a></li>
                                    <li><a href="#">OS Update/Upgrade</a></li>
                                    <li><a href="#">Patches</a></li>
                                    <li><a href="#">Smart Screen</a></li>
                                    <li><a href="#">Security Issues</a></li>
                                    <li><a href="#">Bugs</a></li>
                                    <li><a href="#">BSOD</a></li>
                                    <li><a href="#">BIOS</a></li>
                                    <li><a href="#">System & Kernel</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-7 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Computer Management
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">System Tools</a></li>
                                    <li><a href="#">Shared Folders</a></li>
                                    <li><a href="#">Local Users & Groups</a></li>
                                    <li><a href="#">Performance</a></li>
                                    <li><a href="#">Event Viewer</a></li>
                                    <li><a href="#">Task Scheduler</a></li>
                                    <li><a href="#">Storage</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-8 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Network Issues
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Internet</a></li>
                                    <li><a href="#">LAN</a></li>
                                    <li><a href="#">WiFi</a></li>
                                    <li><a href="#">Router</a></li>
                                    <li><a href="#">ISP</a></li>
                                    <li><a href="#">IP</a></li>
                                    <li><a href="#">DNS</a></li>
                                    <li><a href="#">Proxy</a></li>
                                    <li><a href="#">Map Network Drive</a></li>
                                    <li><a href="#">FTP</a></li>
                                    <li><a href="#">SSH</a></li>
                                    <li><a href="#">WebDev</a></li>
                                    <li><a href="#">Network</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-9 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Start Menu, Desktop & Taskbar
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Start Menu</a></li>
                                    <li><a href="#">Taskbar Settings</a></li>
                                    <li><a href="#">Desktop</a></li>
                                    <li><a href="#">Quick Launch</a></li>
                                    <li><a href="#">Task Manager</a></li>
                                    <li><a href="#">Task View</a></li>
                                    <li><a href="#">Process/Service Manager</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-10 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Output
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Display & Monitor</a></li>
                                    <li><a href="#">Projector</a></li>
                                    <li><a href="#">Project Screen</a></li>
                                    <li><a href="#">Cast Screen</a></li>
                                    <li><a href="#">Extended Display </a></li>
                                    <li><a href="#">Sound System</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="fixes-main-page-small-box security-11 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Device Management & Drivers
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Device Management</a></li>
                                    <li><a href="#">Find Drivers</a></li>
                                    <li><a href="#">Install Drivers</a></li>
                                    <li><a href="#">Fix Drivers</a></li>
                                    <li><a href="#">Device Manager</a></li>
                                    <li><a href="#">Download Drivers</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-12 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Command Line & Keyboard Shortcuts
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Command Prompt</a></li>
                                    <li><a href="#">Power Shell</a></li>
                                    <li><a href="#">Subsystem Linux</a></li>
                                    <li><a href="#">Keyboard Shortcuts</a></li>
                                    <li><a href="#">App Shortcuts</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-13 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Connection Issues
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Bluetooth</a></li>
                                    <li><a href="#">Hotspot</a></li>
                                    <li><a href="#">Mobile Hotspot</a></li>
                                    <li><a href="#">Connect Issues</a></li>
                                    <li><a href="#">Sharing</a></li>
                                    <li><a href="#">Nearby Sharing </a></li>
                                    <li><a href="#">Project</a></li>
                                    <li><a href="#">Cast</a></li>
                                    <li><a href="#">VPN</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-14 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Users & Accounts
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Users</a></li>
                                    <li><a href="#">Email & Accounts</a></li>
                                    <li><a href="#">Sign-in Options</a></li>
                                    <li><a href="#">Family Users</a></li>
                                    <li><a href="#">Sync your Settings</a></li>
                                    <li><a href="#">Work & School Users</a></li>
                                    <li><a href="#">Your Info</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box security-15 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Input
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Keyboard</a></li>
                                    <li><a href="#">Mouse & Other Pointing Devices</a></li>
                                    <li><a href="#">Pen & Touch</a></li>
                                    <li><a href="#">Scanner</a></li>
                                    <li><a href="#">Digitizer</a></li>
                                    <li><a href="#">Finger Print Device</a></li>
                                    <li><a href="#">Camera</a></li>
                                </ul>
                            </div>
                        </div>


                        <!--                    Optimization & Customization-->

                        <div class="col-md-12">
                            <h6 class="fixes-main-page-heading mt-3 mb-3">
                                Optimization & Customization
                            </h6>
                        </div>

                        <div class="col-md-4">
                            <div class="fixes-main-page-small-box optimization-1 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Tweaking
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Hidden Features</a></li>
                                    <li><a href="#">Hidden Settings</a></li>
                                    <li><a href="#">Customization</a></li>
                                    <li><a href="#">Configuration</a></li>
                                    <li><a href="#">Tips & Tricks</a></li>
                                    <li><a href="#">Hidden Tweaks</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box optimization-2 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Internet Speed Up
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Internet Speed Up</a></li>
                                    <li><a href="#">Internet Speed Test </a></li>
                                    <li><a href="#">Cache Issues</a></li>
                                    <li><a href="#">Ad Blocking</a></li>
                                    <li><a href="#">VPN Issues</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box optimization-3 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Personalization
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Desktop Wallpaper</a></li>
                                    <li><a href="#">Animated Wallpaper</a></li>
                                    <li><a href="#">Screensavers</a></li>
                                    <li><a href="#">Themes</a></li>
                                    <li><a href="#">Colors</a></li>
                                    <li><a href="#">Enhancements</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box optimization-4 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Overclocking
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Processor Overclocking</a></li>
                                    <li><a href="#">RAM Overclocking</a></li>
                                    <li><a href="#">Hard Drive Overclocking</a></li>
                                    <li><a href="#">Device Cooling</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="fixes-main-page-small-box optimization-5 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    PC Speed Up
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Boot Speed Up</a></li>
                                    <li><a href="#">Startup Issues</a></li>
                                    <li><a href="#">Process Issues</a></li>
                                    <li><a href="#">Service Issues</a></li>
                                    <li><a href="#">Shutdown Issues</a></li>
                                    <li><a href="#">Uninstall Apps</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box optimization-6 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Memory (RAM) Issues
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Drive Partitioning </a></li>
                                    <li><a href="#">Disk Formatting</a></li>
                                    <li><a href="#">Check Disk</a></li>
                                    <li><a href="#">Scan Disk</a></li>
                                    <li><a href="#">Disk Compression</a></li>
                                    <li><a href="#">Defragmentation</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box optimization-7 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Display Settings
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Screen Resolution</a></li>
                                    <li><a href="#">Scale & Layout</a></li>
                                    <li><a href="#">Font & Text Size</a></li>
                                    <li><a href="#">Night Light</a></li>
                                    <li><a href="#">Multiple Display</a></li>
                                    <li><a href="#">Context Menu</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box optimization-8 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Indexing & Search
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Indexing</a></li>
                                    <li><a href="#">Searching</a></li>
                                    <li><a href="#">Batch Processing</a></li>
                                    <li><a href="#">Advanced Searching</a></li>
                                    <li><a href="#">Performance Troubleshooting</a></li>

                                </ul>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="fixes-main-page-small-box optimization-9 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Disk Space Cleanup
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Temp Files & History</a></li>
                                    <li><a href="#">Empty Folders</a></li>
                                    <li><a href="#">Duplicate Files</a></li>
                                    <li><a href="#">Broken Shortcuts</a></li>
                                    <li><a href="#">Shred</a></li>
                                    <li><a href="#">Zero-byte Files</a></li>
                                    <li><a href="#">Clean Cache</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box optimization-10 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Registry
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Registry Cleanup</a></li>
                                    <li><a href="#">Registry Defragmentation</a></li>
                                    <li><a href="#">Registry Manipulationk</a></li>
                                    <li><a href="#">Registry Editor</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box optimization-11 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Ease of Access
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Accessibility</a></li>
                                    <li><a href="#">Speech Recognition</a></li>
                                    <li><a href="#">Magnification & Zoom</a></li>
                                    <li><a href="#">Brightness & Contrast</a></li>
                                    <li><a href="#">Narrator</a></li>
                                    <li><a href="#">Additional Hardware</a></li>
                                </ul>
                            </div>

                            <div class="fixes-main-page-small-box optimization-12 mb-4">
                                <h6 class="fixes-main-page-sub-heading mb-1">
                                    Optimization for Gaming
                                </h6>
                                <ul class="fixes-main-page-list">
                                    <li><a href="#">Graphics Driver</a></li>
                                    <li><a href="#">GPU overclocking</a></li>
                                    <li><a href="#">Superfetch/Prefetch</a></li>
                                    <li><a href="#">Hard Drive Trimming & Defrag</a></li>
                                    <li><a href="#">NVDIA/GForce Tweaking</a></li>
                                    <li><a href="#">Context Menu</a></li>
                                </ul>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--    fixes-main-page-end-->