    <!-- Offline_Website_Ask-->
    <section class="body-background pb-5">
        <div class="offline_website_ask position-relative host-section-wrap pt-2 mb-5 pb-5">
            <div class="container big-container">
                <div class="offline_website_ask_head breadcrumb-1">
                    <a class="breadcrumb1-anchor nt-spl-anchor anchor-brc-1" href="#">Categories</a>
                    <!--                <i class="fa fa-angle-right px-2" aria-hidden="true"></i>-->
                    <a class="breadcrumb1-anchor nt-spl-anchor" href="#">Special Apps</a>
                    <!--                <i class="fa fa-angle-right px-2" aria-hidden="true"></i>-->
                    <li class="nav-item dropdown dropdown1">
                        <a class="breadcrumb1-anchor nav-link Profile-pad active dropdown-toggle button" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span>Gaming</span>
                        </a>
                        <div class="dropdown-menu drop-menu-new dropdown-menu1" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#">GAMESTORES</a>
                            <a class="dropdown-item" href="#">XBOX</a>
                            <a class="dropdown-item" href="#">STEAM</a>
                            <a class="dropdown-item" href="#">EMULATORS</a>
                            <a class="dropdown-item" href="#">RETROARCH</a>
                            <a class="dropdown-item" href="#">LAUNCHBOX</a>
                            <a class="dropdown-item" href="#">DOLPHIN</a>
                        </div>
                    </li>
                </div>
                <hr class="my-2">
                <div class="row">
                    <div class="col-xl-9 pr-xl-0 pr-3">
                        <div class="row">
                            <div class="col-12 pr-xl-0 pr-3">
                                <div class="accordian-part mt-3">
                                    <div class="main">
                                        <div class="accordion">
                                            <div class="expansion-panel">
                                                <button class="expansion-panel-header">
                                                    <div class="expansion-panel-header-content">
                                                        <span class="title">How do I play Metal Slug on RetroArch?</span>
                                                        <div class="expansion-indicator"></div>
                                                    </div>
                                                </button>
                                                <div class="expansion-panel-body">
                                                    <div class="expansion-panel-body-content">
                                                        <p>I recommend you the following:</p>

                                                        <p class="mt-3">Go to http://www.retroarch.com and download the latest version of Retroacrch and follow these steps</p>

                                                        <p class="mt-3 steps"><b>Step 1:</b></p>
                                                        <span class="steps-span">Run RetroArch and click Settings</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 2:</b></p>
                                                        <span class="steps-span">Click the Bios button</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 3:</b></p>
                                                        <span class="steps-span">Choose the bios file windl.bios from the list in the Bios menu.</span>
                                                        <div>
                                                            <br>
                                                            <div id="text">
                                                                <p class="mt-3 steps"><b>Step 4:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 5:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 6:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <br>
                                                                <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                                                                <hr>
                                                                <form class="my-4">
                                                                    <div class="form-group">
                                                                        <div class="row justify-content-center accordion-comment-section">
                                                                            <div class="col-md-1 text-right">
                                                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                                            </div>
                                                                            <div class="col-md-9 px-0">
                                                                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" placeholder="Add a comment..."></textarea>
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button class="default-btn">Add Comment<br></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                        <div class="btn-container text-center">
                                                            <button id="toggle" class="default-btn">Read More<br></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="expansion-panel">
                                                <button class="expansion-panel-header">
                                                    <div class="expansion-panel-header-content">
                                                        <span class="title">How can I play any ROM?</span>
                                                        <div class="expansion-indicator"></div>
                                                    </div>
                                                </button>
                                                <div class="expansion-panel-body">
                                                    <div class="expansion-panel-body-content">
                                                        <p>I recommend you the following:</p>

                                                        <p class="mt-3">Go to http://www.retroarch.com and download the latest version of Retroacrch and follow these steps</p>

                                                        <p class="mt-3 steps"><b>Step 1:</b></p>
                                                        <span class="steps-span">Run RetroArch and click Settings</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 2:</b></p>
                                                        <span class="steps-span">Click the Bios button</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 3:</b></p>
                                                        <span class="steps-span">Choose the bios file windl.bios from the list in the Bios menu.</span>
                                                        <div>
                                                            <br>
                                                            <div id="text2">
                                                                <p class="mt-3 steps"><b>Step 4:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 5:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 6:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <br>
                                                                <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                                                                <hr>
                                                                <form class="my-4">
                                                                    <div class="form-group">
                                                                        <div class="row justify-content-center accordion-comment-section">
                                                                            <div class="col-md-1 text-right">
                                                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                                            </div>
                                                                            <div class="col-md-9 px-0">
                                                                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" placeholder="Add a comment..."></textarea>
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button class="default-btn">Add Comment<br></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                        <div class="btn-container text-center">
                                                            <button id="toggle2" class="default-btn">Read More<br></button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="expansion-panel">
                                                <button class="expansion-panel-header">
                                                    <div class="expansion-panel-header-content">
                                                        <span class="title">Where can I find RetroArch?</span>
                                                        <div class="expansion-indicator"></div>

                                                    </div>
                                                </button>
                                                <div class="expansion-panel-body">
                                                    <div class="expansion-panel-body-content">
                                                        <p>I recommend you the following:</p>

                                                        <p class="mt-3">Go to http://www.retroarch.com and download the latest version of Retroacrch and follow these steps</p>

                                                        <p class="mt-3 steps"><b>Step 1:</b></p>
                                                        <span class="steps-span">Run RetroArch and click Settings</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 2:</b></p>
                                                        <span class="steps-span">Click the Bios button</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 3:</b></p>
                                                        <span class="steps-span">Choose the bios file windl.bios from the list in the Bios menu.</span>
                                                        <div>
                                                            <br>
                                                            <div id="text3">
                                                                <p class="mt-3 steps"><b>Step 4:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 5:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 6:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <br>
                                                                <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                                                                <hr>
                                                                <form class="my-4">
                                                                    <div class="form-group">
                                                                        <div class="row justify-content-center accordion-comment-section">
                                                                            <div class="col-md-1 text-right">
                                                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                                            </div>
                                                                            <div class="col-md-9 px-0">
                                                                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" placeholder="Add a comment..."></textarea>
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button class="default-btn">Add Comment<br></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                        <div class="btn-container text-center">
                                                            <button id="toggle3" class="default-btn">Read More<br></button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="expansion-panel">
                                                <button class="expansion-panel-header">
                                                    <div class="expansion-panel-header-content">
                                                        <span class="title">I want to play metal slug arcade game</span>
                                                        <div class="expansion-indicator"></div>
                                                    </div>
                                                </button>
                                                <div class="expansion-panel-body">
                                                    <div class="expansion-panel-body-content">
                                                        <p>I recommend you the following:</p>

                                                        <p class="mt-3">Go to http://www.retroarch.com and download the latest version of Retroacrch and follow these steps</p>

                                                        <p class="mt-3 steps"><b>Step 1:</b></p>
                                                        <span class="steps-span">Run RetroArch and click Settings</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 2:</b></p>
                                                        <span class="steps-span">Click the Bios button</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 3:</b></p>
                                                        <span class="steps-span">Choose the bios file windl.bios from the list in the Bios menu.</span>
                                                        <div>
                                                            <br>
                                                            <div id="text4">
                                                                <p class="mt-3 steps"><b>Step 4:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 5:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 6:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <br>
                                                                <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                                                                <hr>
                                                                <form class="my-4">
                                                                    <div class="form-group">
                                                                        <div class="row justify-content-center accordion-comment-section">
                                                                            <div class="col-md-1 text-right">
                                                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                                            </div>
                                                                            <div class="col-md-9 px-0">
                                                                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" placeholder="Add a comment..."></textarea>
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button class="default-btn">Add Comment<br></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                        <div class="btn-container text-center">
                                                            <button id="toggle4" class="default-btn">Read More<br></button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>


                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- col-9 -->
                    <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
                        <div class="right-fixed-box mt-3">
                            <div class="host-section-right-offline-box host-section-right-box">
                                <div class="host-offline-heading-box mb-2">
                                    <span class="text-center inactive-span"><i class="fa fa-circle" aria-hidden="true"></i> <b>No Fixers available</b></span>
                                </div>
                                <div class="host-middle-box">
                                    <div class="row mb-2">
                                        <div class="col-md-9 my-auto">
                                            <p>Currently there are no Fixer Geeks who can fix this problem for you by remotely connecting to your PC.</p>
                                        </div>
                                        <div class="col-md-3 pl-xl-1">
                                            <img src="<?php echo base_url();?>assets/images/no-fixer.png" alt="">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-7">
                                            <a href="#">Become a Fixer Geek</a>
                                        </div>
                                        <div class="col-sm-5 pl-0 text-right">
                                            <a href="#">Find Availability</a>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="host-bottom-box">
                                    <div class="row">
                                        <div class="col-md-12 text-center mb-2">
                                            <h6><b>Ask a Troubleshooting Question</b></h6>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="col-md-9 my-auto">
                                                    <p>We will find someone who can reply, if we can’t, we’ll try to find a Fixer who can fix this problem for you now.</p>
                                                </div>
                                                <div class="col-md-3 pl-xl-1 my-auto">
                                                    <img src="<?php echo base_url();?>assets/images/troubleshoot.png" alt="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12 mt-3">
                                            <form>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-md-12 my-auto">
                                                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="6" placeholder="Type here..."></textarea>
                                                        </div>
                                                        <div class="col-md-12 text-right mt-3">
                                                            <button type="button" class="btn btn-primary default-btn">Ask</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="host-section-right-box spl-right-box mt-3">
                                <a href="#">Advertisement</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <!-- Offline_Website_Ask -->
