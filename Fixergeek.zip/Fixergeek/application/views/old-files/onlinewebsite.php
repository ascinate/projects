   <!-- Offline_Website_Ask-->
    <section class="body-background pb-5">
        <div class="offline_website_ask position-relative host-section-wrap pt-2 mb-5 pb-5">
            <div class="container big-container">
                <div class="offline_website_ask_head breadcrumb-1">
                    <a class="breadcrumb1-anchor nt-spl-anchor anchor-brc-1" href="#">Categories</a>
                    <!--                <i class="fa fa-angle-right px-2" aria-hidden="true"></i>-->
                    <a class="breadcrumb1-anchor nt-spl-anchor" href="#">Special Apps</a>
                    <!--                <i class="fa fa-angle-right px-2" aria-hidden="true"></i>-->
                    <li class="nav-item dropdown dropdown1">
                        <a class="breadcrumb1-anchor nav-link Profile-pad active dropdown-toggle button" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span>Gaming</span>
                        </a>
                        <div class="dropdown-menu drop-menu-new dropdown-menu1" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#">GAMESTORES</a>
                            <a class="dropdown-item" href="#">XBOX</a>
                            <a class="dropdown-item" href="#">STEAM</a>
                            <a class="dropdown-item" href="#">EMULATORS</a>
                            <a class="dropdown-item" href="#">RETROARCH</a>
                            <a class="dropdown-item" href="#">LAUNCHBOX</a>
                            <a class="dropdown-item" href="#">DOLPHIN</a>
                        </div>
                    </li>
                </div>
                <hr class="my-2">
                <div class="row">
                    <div class="col-xl-9  pr-xl-0 pr-3">
                        <div class="row">
                            <div class="col-12 pr-xl-0 pr-3">
                                <div class="accordian-part mt-3">
                                    <div class="main">
                                        <div class="accordion">
                                            <div class="expansion-panel">
                                                <button class="expansion-panel-header">
                                                    <div class="expansion-panel-header-content">
                                                        <span class="title">How do I play Metal Slug on RetroArch?</span>
                                                        <div class="expansion-indicator"></div>
                                                    </div>
                                                </button>
                                                <div class="expansion-panel-body">
                                                    <div class="expansion-panel-body-content">
                                                        <p>I recommend you the following:</p>

                                                        <p class="mt-3">Go to http://www.retroarch.com and download the latest version of Retroacrch and follow these steps</p>

                                                        <p class="mt-3 steps"><b>Step 1:</b></p>
                                                        <span class="steps-span">Run RetroArch and click Settings</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 2:</b></p>
                                                        <span class="steps-span">Click the Bios button</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 3:</b></p>
                                                        <span class="steps-span">Choose the bios file windl.bios from the list in the Bios menu.</span>
                                                        <div>
                                                            <br>
                                                            <div id="text">
                                                                <p class="mt-3 steps"><b>Step 4:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 5:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 6:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <br>
                                                                <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                                                                <hr>
                                                                <form class="my-4">
                                                                    <div class="form-group">
                                                                        <div class="row justify-content-center accordion-comment-section">
                                                                            <div class="col-md-1 text-right">
                                                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                                            </div>
                                                                            <div class="col-md-9 px-0">
                                                                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" placeholder="Add a comment..."></textarea>
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button class="default-btn">Add Comment<br></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                        <div class="btn-container text-center">
                                                            <button id="toggle" class="default-btn">Read More<br></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="expansion-panel">
                                                <button class="expansion-panel-header">
                                                    <div class="expansion-panel-header-content">
                                                        <span class="title">How can I play any ROM?</span>
                                                        <div class="expansion-indicator"></div>
                                                    </div>
                                                </button>
                                                <div class="expansion-panel-body">
                                                    <div class="expansion-panel-body-content">
                                                        <p>I recommend you the following:</p>

                                                        <p class="mt-3">Go to http://www.retroarch.com and download the latest version of Retroacrch and follow these steps</p>

                                                        <p class="mt-3 steps"><b>Step 1:</b></p>
                                                        <span class="steps-span">Run RetroArch and click Settings</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 2:</b></p>
                                                        <span class="steps-span">Click the Bios button</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 3:</b></p>
                                                        <span class="steps-span">Choose the bios file windl.bios from the list in the Bios menu.</span>
                                                        <div>
                                                            <br>
                                                            <div id="text2">
                                                                <p class="mt-3 steps"><b>Step 4:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 5:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 6:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <br>
                                                                <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                                                                <hr>
                                                                <form class="my-4">
                                                                    <div class="form-group">
                                                                        <div class="row justify-content-center accordion-comment-section">
                                                                            <div class="col-md-1 text-right">
                                                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                                            </div>
                                                                            <div class="col-md-9 px-0">
                                                                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" placeholder="Add a comment..."></textarea>
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button class="default-btn">Add Comment<br></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                        <div class="btn-container text-center">
                                                            <button id="toggle2" class="default-btn">Read More<br></button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="expansion-panel">
                                                <button class="expansion-panel-header">
                                                    <div class="expansion-panel-header-content">
                                                        <span class="title">Where can I find RetroArch?</span>
                                                        <div class="expansion-indicator"></div>

                                                    </div>
                                                </button>
                                                <div class="expansion-panel-body">
                                                    <div class="expansion-panel-body-content">
                                                        <p>I recommend you the following:</p>

                                                        <p class="mt-3">Go to http://www.retroarch.com and download the latest version of Retroacrch and follow these steps</p>

                                                        <p class="mt-3 steps"><b>Step 1:</b></p>
                                                        <span class="steps-span">Run RetroArch and click Settings</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 2:</b></p>
                                                        <span class="steps-span">Click the Bios button</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 3:</b></p>
                                                        <span class="steps-span">Choose the bios file windl.bios from the list in the Bios menu.</span>
                                                        <div>
                                                            <br>
                                                            <div id="text3">
                                                                <p class="mt-3 steps"><b>Step 4:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 5:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 6:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <br>
                                                                <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                                                                <hr>
                                                                <form class="my-4">
                                                                    <div class="form-group">
                                                                        <div class="row justify-content-center accordion-comment-section">
                                                                            <div class="col-md-1 text-right">
                                                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                                            </div>
                                                                            <div class="col-md-9 px-0">
                                                                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" placeholder="Add a comment..."></textarea>
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button class="default-btn">Add Comment<br></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                        <div class="btn-container text-center">
                                                            <button id="toggle3" class="default-btn">Read More<br></button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="expansion-panel">
                                                <button class="expansion-panel-header">
                                                    <div class="expansion-panel-header-content">
                                                        <span class="title">I want to play metal slug arcade game</span>
                                                        <div class="expansion-indicator"></div>
                                                    </div>
                                                </button>
                                                <div class="expansion-panel-body">
                                                    <div class="expansion-panel-body-content">
                                                        <p>I recommend you the following:</p>

                                                        <p class="mt-3">Go to http://www.retroarch.com and download the latest version of Retroacrch and follow these steps</p>

                                                        <p class="mt-3 steps"><b>Step 1:</b></p>
                                                        <span class="steps-span">Run RetroArch and click Settings</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 2:</b></p>
                                                        <span class="steps-span">Click the Bios button</span>
                                                        <!--  -->
                                                        <p class="mt-3 steps"><b>Step 3:</b></p>
                                                        <span class="steps-span">Choose the bios file windl.bios from the list in the Bios menu.</span>
                                                        <div>
                                                            <br>
                                                            <div id="text4">
                                                                <p class="mt-3 steps"><b>Step 4:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 5:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <p class="mt-3 steps"><b>Step 6:</b></p>
                                                                <span class="steps-span">Click the Bios button</span>
                                                                <!--  -->
                                                                <br>
                                                                <span class="source">Source:</span><a href="https://en.wikipedia.org/wiki/Cascading_Style_Sheets">Wikipedia</a>
                                                                <hr>
                                                                <form class="my-4">
                                                                    <div class="form-group">
                                                                        <div class="row justify-content-center accordion-comment-section">
                                                                            <div class="col-md-1 text-right">
                                                                                <i class="fa fa-user" aria-hidden="true"></i>
                                                                            </div>
                                                                            <div class="col-md-9 px-0">
                                                                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="1" placeholder="Add a comment..."></textarea>
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button class="default-btn">Add Comment<br></button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                        <div class="btn-container text-center">
                                                            <button id="toggle4" class="default-btn">Read More<br></button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>


                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- col-9 -->
                    <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
                        <div class="right-fixed-box fixed-carousel-spl-box mt-3">
                            <div class="host-section-right-carousel-box host-section-right-box">
                                <div class="host-right-heading-box">
                                    <span class="text-center active-span"><i class="fa fa-circle" aria-hidden="true"></i> <b>5 Fixer Geeks (online)</b></span>
                                </div>

                                <div class="host-right-owl-box mb-3">
                                    <div class="owl-carousel owl-theme">
                                        <div class="item">
                                            <div class="row">
                                                <div class="col-12 py-3 hide-details">
                                                    <h6 class="mb-2 text-center"><a class="show-details1" href="#">JoeMartyJoe</a> <b>- 3.9 score</b></h6>
                                                    <span class="spl-span-owl text-center"><i class="fa fa-check" aria-hidden="true"></i> Fixed this Problem</span>

                                                    <div class="profile-hover-details profile-hover-carousel1">
                                                        <div class="row">
                                                            <div class="col-md-12 mb-1">
                                                                <h6><i class="fa fa-user-circle-o" aria-hidden="true"></i> JoeMartyJoe</h6>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <span>Score: 4.8 <a href="#">Read Comments</a></span>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <p>Availability: 3:00pm to 8:00pm</p>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <p>Timezone: Eastern Standard Time (GMT -5)</p>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <ul class="profile-hover-list">
                                                                    <li class="spl-li">Categories (Expet in):</li>
                                                                    <li><a href="#">PC Speed Up</a></li>
                                                                    <li><a href="#">Internet Speed Up</a></li>
                                                                    <li><a href="#">Memory (RAM) Issues</a></li>
                                                                    <li><a href="#">Personalization</a></li>
                                                                    <li><a href="#">Gaming</a></li>
                                                                    <li><a href="#">Apple Products</a></li>
                                                                    <li><a href="#">Microsoft Products</a></li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="row">
                                                                    <div class="col-md-6 text-left">
                                                                        <a href="#">Read Full Profile</a>
                                                                    </div>
                                                                    <div class="col-md-6 text-right">
                                                                        <a href="#">Hire User</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                </div>
                                                <div class="col-12 owl-right-grid pb-3">
                                                    <a href="#">
                                                        <div class="row">
                                                            <div class="col-md-9 my-auto">
                                                                <h6><span>Get Remote Assistance</span><br> on this problem from <span>JoeMartyJoe</span></h6>
                                                            </div>
                                                            <div class="col-md-3 pl-0 my-auto">
                                                                <img src="<?php echo base_url();?>assets/images/level3.png" alt="">
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>

                                                <div class="col-12 owl-right-grid pb-3">
                                                    <a href="#">
                                                        <div class="row">
                                                            <div class="col-md-9 my-auto">
                                                                <h6><span>Get Screen Sharing & Voice Chat Support</span> on this problem from <span>JoeMartyJoe</span></h6>
                                                            </div>
                                                            <div class="col-md-3 pl-0 my-auto">
                                                                <img src="<?php echo base_url();?>assets/images/level2.png" alt="">
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>

                                                <div class="col-12 owl-right-grid pb-3">
                                                    <a href="#">
                                                        <div class="row">
                                                            <div class="col-md-9 my-auto">
                                                                <h6><span>Get Text Chat Support</span><br> on this problem from <span>JoeMartyJoe</span></h6>
                                                            </div>
                                                            <div class="col-md-3 pl-0 my-auto">
                                                                <img src="<?php echo base_url();?>assets/images/level1.png" alt="">
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="item">
                                            <div class="row">
                                                <div class="col-12 py-3 hide-details">
                                                    <h6 class="mb-2 text-center"><a class="show-details2" href="#">AdamJosh</a> <b>- 3.9 score</b></h6>
                                                    <span class="spl-span-owl text-center">Expert in this Category</span>

                                                    <div class="profile-hover-details profile-hover-carousel2">
                                                        <div class="row">
                                                            <div class="col-md-12 mb-1">
                                                                <h6><i class="fa fa-user-circle-o" aria-hidden="true"></i> AdamJosh</h6>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <span>Score: 4.8 <a href="#">Read Comments</a></span>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <p>Availability: 3:00pm to 8:00pm</p>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <p>Timezone: Eastern Standard Time (GMT -5)</p>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <ul class="profile-hover-list">
                                                                    <li class="spl-li">Categories (Expet in):</li>
                                                                    <li><a href="#">PC Speed Up</a></li>
                                                                    <li><a href="#">Internet Speed Up</a></li>
                                                                    <li><a href="#">Memory (RAM) Issues</a></li>
                                                                    <li><a href="#">Personalization</a></li>
                                                                    <li><a href="#">Gaming</a></li>
                                                                    <li><a href="#">Apple Products</a></li>
                                                                    <li><a href="#">Microsoft Products</a></li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="row">
                                                                    <div class="col-md-6 text-left">
                                                                        <a href="#">Read Full Profile</a>
                                                                    </div>
                                                                    <div class="col-md-6 text-right">
                                                                        <a href="#">Hire User</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                </div>
                                                <div class="col-12 owl-right-grid pb-3">
                                                    <a href="#">
                                                        <div class="row">
                                                            <div class="col-md-9 my-auto">
                                                                <h6><span>Get Remote Assistance</span><br> on this problem from <span>AdamJosh</span></h6>
                                                            </div>
                                                            <div class="col-md-3 pl-0 my-auto">
                                                                <img src="<?php echo base_url();?>assets/images/level3.png" alt="">
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>

                                                <div class="col-12 owl-right-grid pb-3">
                                                    <a href="#">
                                                        <div class="row">
                                                            <div class="col-md-9 my-auto">
                                                                <h6><span>Get Screen Sharing & Voice Chat Support</span> on this problem from <span>AdamJosh</span></h6>
                                                            </div>
                                                            <div class="col-md-3 pl-0 my-auto">
                                                                <img src="<?php echo base_url();?>assets/images/level2.png" alt="">
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>

                                                <div class="col-12 owl-right-grid pb-3">
                                                    <a href="#">
                                                        <div class="row">
                                                            <div class="col-md-9 my-auto">
                                                                <h6><span>Get Text Chat Support</span><br> on this problem from <span>AdamJosh</span></h6>
                                                            </div>
                                                            <div class="col-md-3 pl-0 my-auto">
                                                                <img src="<?php echo base_url();?>assets/images/level1.png" alt="">
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="item">
                                            <div class="row">
                                                <div class="col-12 py-3 hide-details">
                                                    <h6 class="mb-2 text-center"><a class="show-details3" href="#">SimonPhilip</a> <b>- 3.9 score</b></h6>
                                                    <span class="spl-span-owl text-center"><i class="fa fa-check" aria-hidden="true"></i> Fixed this Problem</span>

                                                    <div class="profile-hover-details profile-hover-carousel3">
                                                        <div class="row">
                                                            <div class="col-md-12 mb-1">
                                                                <h6><i class="fa fa-user-circle-o" aria-hidden="true"></i> SimonPhilip</h6>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <span>Score: 4.8 <a href="#">Read Comments</a></span>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <p>Availability: 3:00pm to 8:00pm</p>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <p>Timezone: Eastern Standard Time (GMT -5)</p>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <p class="fix-p"><i class="fa fa-check" aria-hidden="true"></i> 35 Problems Fixed</p>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <p class="unfix-p"><i class="fa fa-times" aria-hidden="true"></i> 2 Problems Not Fixed</p>
                                                            </div>
                                                            <div class="col-md-12 mb-1">
                                                                <ul class="profile-hover-list">
                                                                    <li class="spl-li">Categories (Expet in):</li>
                                                                    <li><a href="#">PC Speed Up</a></li>
                                                                    <li><a href="#">Internet Speed Up</a></li>
                                                                    <li><a href="#">Memory (RAM) Issues</a></li>
                                                                    <li><a href="#">Personalization</a></li>
                                                                    <li><a href="#">Gaming</a></li>
                                                                    <li><a href="#">Apple Products</a></li>
                                                                    <li><a href="#">Microsoft Products</a></li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <div class="row">
                                                                    <div class="col-md-6 text-left">
                                                                        <a href="#">Read Full Profile</a>
                                                                    </div>
                                                                    <div class="col-md-6 text-right">
                                                                        <a href="#">Hire User</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                </div>
                                                <div class="col-12 owl-right-grid pb-3">
                                                    <a href="#">
                                                        <div class="row">
                                                            <div class="col-md-9 my-auto">
                                                                <h6><span>Get Remote Assistance</span><br> on this problem from <span>SimonPhilip</span></h6>
                                                            </div>
                                                            <div class="col-md-3 pl-0 my-auto">
                                                                <img src="images/level3.png" alt="">
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>

                                                <div class="col-12 owl-right-grid pb-3">
                                                    <a href="#">
                                                        <div class="row">
                                                            <div class="col-md-9 my-auto">
                                                                <h6><span>Get Screen Sharing & Voice Chat Support</span> on this problem from <span>SimonPhilip</span></h6>
                                                            </div>
                                                            <div class="col-md-3 pl-0 my-auto">
                                                                <img src="images/level2.png" alt="">
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>

                                                <div class="col-12 owl-right-grid pb-3">
                                                    <a href="#">
                                                        <div class="row">
                                                            <div class="col-md-9 my-auto">
                                                                <h6><span>Get Text Chat Support</span><br> on this problem from <span>SimonPhilip</span></h6>
                                                            </div>
                                                            <div class="col-md-3 pl-0 my-auto">
                                                                <img src="images/level1.png" alt="">
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="host-section-right-bottom">
                                    <a href="#">See All Fixer Geeks...</a>
                                </div>

                            </div>
                            <div class="host-section-right-box spl-right-box mt-3">
                                <a href="#">Advertisement</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <!-- Offline_Website_Ask -->
