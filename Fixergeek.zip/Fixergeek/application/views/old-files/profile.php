   <!--    host-account-section-start-->
    <section class="body-background py-5">
        <div class="host-section-wrap">
            <div class="container big-container">
                <div class="row justify-content-center">
                    <div class="col-xl-9  pr-xl-0 pr-3">
                        <div class="host-section-left-box">
                            <div class="row justify-content-center ml-lg-0 ml-3">
                                <div class="host-section-border col-lg-3 col-md-6 col-sm-10 col-11 pl-lg-0 pl-3 pr-lg-0 pr-3 mb-lg-0 mb-3">
                                    <div class="host-section-left-list">
                                         <?php $this->load->view('includes/left-navigation-supporters');?>
                                    </div>
                                </div>
                                <div class="col-lg-9 mt-lg-0 mt-3 pr-xl-0 pr-3">
                                    <div class="account-profile-form">
                                        <form>
                                            <div class="form-group">
                                                <div class="row mb-3">
                                                    <div class="col-md-3 my-auto">
                                                        <label for="exampleFormControlFile1">Picture</label>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <input type="file" class="form-control-file" id="exampleFormControlFile1">
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-3 my-auto">
                                                        <label for="exampleInputEmail1">Geek Name</label>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Maxbrayne">
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-3 my-auto">
                                                        <label for="exampleInputEmail1">Email Address</label>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="maxbrayne@gmail.com">
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-3 my-auto">
                                                        <label for="exampleInputEmail1">Full Name</label>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Salmon Assarraff">
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-3 my-auto">
                                                        <label for="exampleFormControlSelect1">Date of Birth</label>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                            <option>August</option>
                                                            <option>September</option>
                                                            <option>October</option>
                                                            <option>November</option>
                                                            <option>December</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3 px-0">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                            <option>26</option>
                                                            <option>27</option>
                                                            <option>28</option>
                                                            <option>29</option>
                                                            <option>30</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                            <option>1980</option>
                                                            <option>1981</option>
                                                            <option>1982</option>
                                                            <option>1983</option>
                                                            <option>1984</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-3 my-auto">
                                                        <label for="exampleFormControlSelect1">Gender</label>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                            <option>Male</option>
                                                            <option>Female</option>
                                                            <option>Other</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-3 my-auto">
                                                        <label for="exampleFormControlSelect1">Country</label>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                            <option>India</option>
                                                            <option>Canada</option>
                                                            <option>Japan</option>
                                                            <option>Australia</option>
                                                            <option>Korea</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-3 my-auto">
                                                        <label for="exampleFormControlSelect1">Phone</label>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <input id="phone" type="tel">
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-3 my-auto">
                                                        <label for="exampleFormControlSelect1">Educational Level</label>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                            <option>Postgraduate Diploma</option>
                                                            <option>Postgraduate Diploma</option>
                                                            <option>Postgraduate Diploma</option>
                                                            <option>Postgraduate Diploma</option>
                                                            <option>Postgraduate Diploma</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-12 mb-3">
                                                        <label for="exampleFormControlTextarea1">About You</label>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>
                                                    </div>
                                                </div>

                                                <div class="row mb-3">
                                                    <div class="col-md-12 mb-3">
                                                        <label>Connect With:</label>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <ul class="account-profile-form-list">
                                                            <li class="spl-linkedin"><i class="fa fa-linkedin-square" aria-hidden="true"></i><br><a href="#">LinkedIn</a></li>
                                                            <li class="spl-google"><i class="fa fa-google" aria-hidden="true"></i><br><a href="#">Google</a></li>
                                                            <li class="spl-facebook"><i class="fa fa-facebook-official"></i><br><a href="#">Facebook</a></li>
                                                            <li class="spl-microsoft"><i class="fa fa-windows" aria-hidden="true"></i><br><a href="#">Microsoft</a></li>
                                                        </ul>
                                                    </div>
                                                </div>


                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 mt-xl-0 mt-4 pl-xl-3">
                        <div class="host-section-right-box">
                            <a href="#">Advertisement</a>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <!--    host-account-section-end-->