<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Vote extends CI_Controller
     {
        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->helper('url');
        }
		
		public function qupvote()
		{
		   $qid = $this->uri->segment(3);
		   $uid = $this->uri->segment(4);
		   //$rec = $this->db->get_where("question_up_down",array('question_id'=>$qid))->row();

		   $result = $this->db->insert("question_up_down", array('user_id'=>$uid, 'question_id'=>$qid, 'up_vote'=> 1));
		   
		   if($result) {
		     $vt = $this->db->query("select sum(up_vote) as upvot from `question_up_down` where `question_id` = '".$qid."'")->row();
			 
			 if($vt->upvot==0)
			 {
				echo ''; 
			 }
			 else
			 {
			   echo $vt->upvot;
			 }
		   }
		}
		
		public function downvote()
		{
		   $qid = $this->uri->segment(3);
		   $uid = $this->uri->segment(4);
		   //$rec = $this->db->get_where("question_up_down",array('question_id'=>$qid))->row();

		   $result2 = $this->db->insert("question_up_down", array('user_id'=>$uid, 'question_id'=>$qid, 'down_vote'=> 1));
		   
		   if($result2) {
		     $vt2 = $this->db->query("select sum(down_vote) as downvot from `question_up_down` where `question_id` = '".$qid."'")->row();
			 
			 if($vt2->downvot==0)
			 {
				echo ''; 
			 }
			 else
			 {
			   echo $vt2->downvot;
			 }
		   }
		}
		
		public function ansupvote()
		{
		   $aid = $this->uri->segment(3);
		   $uid = $this->uri->segment(4);
		   //$rec = $this->db->get_where("question_up_down",array('question_id'=>$qid))->row();
		   
		   $query = $this->db->query("select * from `answer_up_down` where `answer_id` = '".$aid."' and 
		   							 `user_id` = '".$uid."' and (`upvote` = 1 || `downvote` = 1)");
		   $count = $query->num_rows();				
		   
		   if($count==0)
		   {
			   $result = $this->db->insert("answer_up_down", array('user_id'=>$uid, 'answer_id'=>$aid, 'upvote'=> 1));
			   
			   if($result) 
			   {
				 $vt = $this->db->query("select sum(upvote) as upvot from `answer_up_down` where `answer_id` = '".$aid."'")->row();
				
				 $this->db->where('id',$aid);
				 $this->db->update('answers_master', array('upvote'=>$vt->upvot));
				 
				 if($vt->upvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt->upvot;
				 }
				 
			   }
		   }
		   
		   else
		   {
		    	 $vt = $this->db->query("select sum(upvote) as upvot from `answer_up_down` where `answer_id` = '".$aid."'")->row();
				
				 if($vt->upvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt->upvot;
				 }
		   }
		}
		
		public function ansdownvote()
		{
		   $a_id = $this->uri->segment(3);
		   $u_id = $this->uri->segment(4);
		   //$rec = $this->db->get_where("question_up_down",array('question_id'=>$qid))->row();
		   
		   $sql = $this->db->query("select * from `answer_up_down` where `answer_id` = '".$a_id."' and 
		   							 `user_id` = '".$u_id."' and (`upvote` = 1 || `downvote` = 1)");
		   $numrow = $sql->num_rows();				
		   
		   if($numrow==0)
		   {
			   $result2 = $this->db->insert("answer_up_down", array('user_id'=>$u_id, 'answer_id'=>$a_id, 'downvote'=> 1));
			   
			   if($result2) 
			   {
				 $vt2 = $this->db->query("select sum(downvote) as downvot from `answer_up_down` where `answer_id` = '".$a_id."'")->row();
				 
				 $this->db->where('id',$a_id);
				 $this->db->update('answers_master', array('downvote'=>$vt2->downvot));
				 
				 if($vt2->downvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt2->downvot;
				 }
			   }
		   }
		   
		   else
		   {
				 $vt2 = $this->db->query("select sum(downvote) as downvot from `answer_up_down` where `answer_id` = '".$a_id."'")->row();
				 
				 if($vt2->downvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt2->downvot;
				 }
		   }
		}
		
		public function comupvote()
		{
		   $cid = $this->uri->segment(3);
		   $uid = $this->uri->segment(4);
		   //$rec = $this->db->get_where("question_up_down",array('question_id'=>$qid))->row();
		   
		   $sql = $this->db->query("select * from `comment_up_down` where `comment_id` = '".$cid."' and 
		   							 `user_id` = '".$uid."' and (`upvote` = 1 || `downvote` = 1)");
		   $numrow = $sql->num_rows();	
			
		   if($numrow==0)
		   {
			   $result = $this->db->insert("comment_up_down", array('user_id'=>$uid, 'comment_id'=>$cid, 'upvote'=> 1));
			   
			   if($result) {
				 $vt = $this->db->query("select sum(upvote) as upvot from `comment_up_down` where `comment_id` = '".$cid."'")->row();
				
				 if($vt->upvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt->upvot;
				 }
			   }
		   }
		   
		   else
		   {
				 $vt = $this->db->query("select sum(upvote) as upvot from `comment_up_down` where `comment_id` = '".$cid."'")->row();
				
				 if($vt->upvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt->upvot;
				 }
		   }
		}
		
		public function comdownvote()
		{
		   $cid = $this->uri->segment(3);
		   $uid = $this->uri->segment(4);
		   //$rec = $this->db->get_where("question_up_down",array('question_id'=>$qid))->row();
		   
		   $sql = $this->db->query("select * from `comment_up_down` where `comment_id` = '".$cid."' and 
		   							 `user_id` = '".$uid."' and (`upvote` = 1 || `downvote` = 1)");
		   $numrow = $sql->num_rows();

		   if($numrow==0)
		   {
			   $result2 = $this->db->insert("comment_up_down", array('user_id'=>$uid, 'comment_id'=>$cid, 'downvote'=> 1));
			   
			   if($result2) 
			   {
				 $vt2 = $this->db->query("select sum(downvote) as downvot from `comment_up_down` where `comment_id` = '".$cid."'")->row();
				 
				 if($vt2->downvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt2->downvot;
				 }
			   }
		    }
		   
		   else
		   {
				 $vt2 = $this->db->query("select sum(downvote) as downvot from `comment_up_down` where `comment_id` = '".$cid."'")->row();
				
				 if($vt2->downvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt2->downvot;
				 }
		   }
		}
		
		
		public function replyupvote()
		{
		   $cid = $this->uri->segment(3);
		   $uid = $this->uri->segment(4);
		   //$rec = $this->db->get_where("question_up_down",array('question_id'=>$qid))->row();
		   
		   $sql = $this->db->query("select * from `reply_up_down` where `reply_id` = '".$cid."' and 
		   							 `user_id` = '".$uid."' and (`upvote` = 1 || `downvote` = 1)");
		   $numrow = $sql->num_rows();
		   
		   if($numrow==0)
		   {
		    $result = $this->db->insert("reply_up_down", array('user_id'=>$uid, 'reply_id'=>$cid, 'upvote'=> 1));
		   
			   if($result) 
			   {
				 $vt = $this->db->query("select sum(upvote) as upvot from `reply_up_down` where `reply_id` = '".$cid."'")->row();
				 
				 if($vt->upvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt->upvot;
				 }
			   }
		   }
		   
		   else
		   {
				 $vt = $this->db->query("select sum(upvote) as upvot from `reply_up_down` where `reply_id` = '".$cid."'")->row();
				 
				 if($vt->upvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt->upvot;
				 }
		   }
		}
		
		public function replydownvote()
		{
		   $cid = $this->uri->segment(3);
		   $uid = $this->uri->segment(4);
		   //$rec = $this->db->get_where("question_up_down",array('question_id'=>$qid))->row();
		   
		   $sql = $this->db->query("select * from `reply_up_down` where `reply_id` = '".$cid."' and 
		   							 `user_id` = '".$uid."' and (`upvote` = 1 || `downvote` = 1)");
		   $numrow = $sql->num_rows();
		   
		   if($numrow==0)
		   {
		    $result2 = $this->db->insert("reply_up_down", array('user_id'=>$uid, 'reply_id'=>$cid, 'downvote'=> 1));
		   
			   if($result2)
			   {
				 $vt2 = $this->db->query("select sum(downvote) as downvot from `reply_up_down` where `reply_id` = '".$cid."'")->row();
				 
				 if($vt2->downvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt2->downvot;
				 }
			   }
		   }
		   
		   else
		   {
				 $vt2 = $this->db->query("select sum(downvote) as downvot from `reply_up_down` where `reply_id` = '".$cid."'")->row();
				 
				 if($vt2->downvot==0)
				 {
					echo ''; 
				 }
				 else
				 {
				   echo $vt2->downvot;
				 }
		   }
		   
		}
     }
?>