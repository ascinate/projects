<?php
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Problems extends CI_Controller
     {
        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->helper('url');
        }

        public function index()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/problems');
          $this->load->view('inc/modal2');
          $this->load->view('inc/footer');
        }
		
        public function submitanswer()
        {
          $id=$this->uri->segment(3);
          $u_id=$this->uri->segment(4);
		  $ans_id = $this->input->post('ans_id');
          $question=$this->db->get_where('questions_master',array('id'=>$id))->row();
		  $time =  date('H:i:s');
		  
          $data=array('user_id'=>$u_id,
					  'question_id'=>$id,
					  'sub_sub_cat_id'=>$question->sub_sub_cat_id,
					  'answer'=> addslashes($this->input->post('answer'.$ans_id)),
					  'post_date'=>date('Y-m-d'),
					  'post_time'=>$time );
			  
          $status=$this->db->insert('answers_master',$data);
          //redirect('problems/answer/'.$id);
		  
		    $title = str_replace(" ","-",trim($question->question));
			$title_1 = str_replace("?-","",$title);
			$title_1 = str_replace("-?","",$title);
			$title_1 = str_replace("-?-","",$title);
			$title_2 = str_replace("?","",$title_1);
		  
			redirect('details/show/'.$title_2);
        }
		
		public function editanswer()
		{
		  $id=$this->uri->segment(3);
          $u_id=$this->uri->segment(4);
		  $ans_id = $this->input->post('upans_id');
          $question=$this->db->get_where('questions_master',array('id'=>$id))->row();
		  $time =  date('H:i:s');
		  
		  $data = array('user_id'=>$u_id,'answer'=>addslashes($this->input->post('updateanswer'.$ans_id)));
		 
		  $this->db->where('id',$ans_id);
		  $query = $this->db->update('answers_master',$data);
		  
		  //echo $this->db->last_query();
		  
		    $title = str_replace(" ","-",trim($question->question));
			$title_1 = str_replace("?-","",$title);
			$title_1 = str_replace("-?","",$title);
			$title_1 = str_replace("-?-","",$title);
			$title_2 = str_replace("?","",$title_1);
		  
		    redirect('details/show/'.$title_2);
		}
		
		public function deleteanswer()
		{
		    //$id=$this->uri->segment(3);
			$ansid=$this->uri->segment(3);
			
		    $this->db->where('id', $ansid);
			$this->db->delete('answers_master');
			
			//redirect('details/show/'.$id);
		}
		
		////////////////// Related answer's edit/delete ///////////
		
		
		public function releditanswer()
		{
		  $id=$this->uri->segment(3);
          $u_id=$this->uri->segment(4);
		  $ans_id = $this->input->post('upans_id2');
          $question=$this->db->get_where('questions_master',array('id'=>$id))->row();
		  $time =  date('H:i:s');
		  
		  $data = array('user_id'=>$u_id,'answer'=>addslashes($this->input->post('updateanswer2'.$ans_id)));
		 
		  $this->db->where('id',$ans_id);
		  $query = $this->db->update('answers_master',$data);
		  
		 //echo $this->db->last_query();
		  
		  redirect('details/show/'.$id);
		}
		
		public function reldeleteanswer()
		{
		    //$id=$this->uri->segment(3);
			$ansid=$this->uri->segment(3);
			
		    $this->db->where('id', $ansid);
			$this->db->delete('answers_master');
			
			//redirect('details/show/'.$id);
		}
		
		/////////////////// end //////////////
		
		public function submitproblemanswer()
        {
          $id=$this->uri->segment(3);
          $u_id=$this->uri->segment(4);
		  //$ans_id = $this->input->post('ans_id');
          $question=$this->db->get_where('questions_master',array('id'=>$id))->row();
		  $time =  date('H:i:s');
		  
          $data=array(
			  'user_id'=>$u_id,
			  'question_id'=>$id,
			  'sub_sub_cat_id'=>$question->sub_sub_cat_id,
			  'answer'=> addslashes($this->input->post('answer'.$id)),
			  'post_date'=>date('Y-m-d'),
			  'post_time'=>$time);
			  
          $status=$this->db->insert('answers_master',$data);
          //redirect('problems/answer/'.$id);
		  
			$title = str_replace(" ","-",trim($question->question));
			$title_1 = str_replace("?-","",$title);
			$title_1 = str_replace("-?","",$title);
			$title_1 = str_replace("-?-","",$title);
			$title_2 = str_replace("?","",$title_1);
			
		  redirect('details/show/'.$title_2);
        }
        ///////////////////////////
        public function answer()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/problems_answer');
          $this->load->view('inc/modal2');
          $this->load->view('inc/footer');
        }
        ///////////////////////////
        public function submitcomment()
        {
          $id=$this->uri->segment(3);
          $u_id=$this->uri->segment(4);
		  $ans_id = $this->input->post('ans_id');
          $data=array(
		  'answer_id'=>$ans_id,
          'question_id'=>$id,
		  'user_id'=>$u_id,
          'comment'=>addslashes($this->input->post('comment'.$ans_id)),
          'post_date'=>date('Y-m-d'),
          );
          $status=$this->db->insert('answer_comment',$data);
         //redirect('problems/answer/'.$q_id);
		 
		 redirect('details/show/'.$id);
        }
		
		public function addcomment()
		{
		  /*$ans_id = $this->uri->segment(3);
   	      $id = $this->uri->segment(4);
          $u_id = $this->uri->segment(5);
		  $comment = $this->uri->segment(6);*/
		  
		  $ans_id = $this->input->post('ans_id');
   	      $id = $this->input->post('ques_id');
          $u_id = $this->input->post('user_id');
		  $comment = $this->input->post('content');
		 
          $data=array(
		  'answer_id'=>$ans_id,
          'question_id'=>$id,
		  'user_id'=>$u_id,
          'comment'=> str_replace("%20"," ",addslashes($comment)),
          'post_date'=>date('Y-m-d')
          );
		  
          $status = $this->db->insert('answer_comment',$data);
		  
		  if($status==true)
		  {
		    ///////////////////////////////////////////////////////////////////
		?>  
        <div>
		<?php
          $this->db->order_by('id', 'DESC');
          $comment =$this->db->get_where('answer_comment',array('answer_id'=>$ans_id));
          $comnum = $comment->num_rows();
          $x = 0;
          
          if($comnum!=0) {
          foreach($comment->result() as $rec)
          {
            $comId = $rec->id;
            $comauthor = $rec->user_id;
            
            $username = $this->db->get_where('user_master',array('id'=>$rec->user_id))->row();
            $exdate = explode('-', $rec->post_date);
            $postdate = mktime(12,0,0, $exdate[1],$exdate[2],$exdate[0]);
            $date = date("F j, Y", $postdate);
            
              $cvt = $this->db->query("select sum(upvote) as upvot from `comment_up_down` where 
                                      `comment_id` = '".$rec->id."'")->row();
              $cupv = $cvt->upvot;  
            
              $cvt2 = $this->db->query("select sum(downvote) as downvot from `comment_up_down` where 
                                    `comment_id` = '".$rec->id."'")->row();
              $cdwv = $cvt2->downvot;
           ?>
             <div class="detial-new-comon <? if($x!=0){?>reply-div<?=$x?><? }?>">
        
                 <div id="cmt">
                     <div class="comment-show-top-new">
                       <figure>
                        <?php 
                          if($username->id=="Admin")
                          {
                        ?>
                           <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" width="30" height="30">
                        <?php
                          }
                          else
                          {
                           if($username->profile_picture!="")
                           {
                         ?>
                           <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                           style="border-radius:50%; width:30px; height:30px;">
                        <?php 
                           } 
                          else
                           {
                        ?>
                           <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                        <?php 
                           }
                          }
                        ?>
                        </figure>
                       <figcaption><?=$username->geek_name?> Commented on <?=$date?></figcaption>
                     </div>
                     
                    <div id="com1<?=$rec->id?>"> <?=stripslashes(str_replace("%20"," ",$rec->comment));?> </div>
                  </div> 
                  
                  <div id="ademo"></div>
                  
                    <div class="comment-sec-d1" id="comedit<?=$rec->id?>" style="display:none;">
                    <div class="detail-comment-sec2 new-dt-sec">
                       
                        <div class="form-group">
                          <div class="coment-area-dv">
                            <div class="col-md-1 text-right">
                               <?php if($username->profile_picture!=""){ ?>
                               <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                               style="border-radius:50%; width:20px; height:20px;">
                               <?php } else {?>
                               <i class="fa fa-user" aria-hidden="true"></i>
                               <?php }?>
                            </div>
                            <div class="col-md-9 px-0">
                              <input type="text" name="commentedit<?=$rec->id?>" id="cedit<?=$rec->id?>" class="form-control" 
                              value="<?=stripslashes(str_replace("%20"," ",$rec->comment));?>" style="font-size:13px;">
                            </div>
                            <div class="col-md-3">
                              <button type="button" id="add_com<?=$rec->id?>" class="comon-dv-bn" 
                              onclick="javascript:updatecomment(<?=$rec->id?>);">Update</button>
                              
                              <button type="button" id="cancel_com<?=$rec->id?>" class="comon-dv-bn" 
                              onclick="javascript:comcancel(<?=$rec->id?>);">Cancel</button>
                            </div>
                          </div>
                        </div>

                    </div>
                  </div>
                   
                  <?php //////////////////////// End Comments //////////////////// ?> 
                  
                  <?php ///////////////// Reply over comments /////////////////?>
                  <div class="comment-sec-bottom1">
                   <ul>
                      <li class="d-flex">
                      <a class="reply-box" id="show-d<?=$rec->id?>" onclick="javascript:replyshow(<?=$rec->id?>);">
                         <i class="fa fa-reply"></i> Reply
                      </a>
                      <a class="reply-box" id="hide-d<?=$rec->id?>" onclick="javascript:replyhide(<?=$rec->id?>);" style="display:none;">
                         <i class="fa fa-reply"></i> Reply
                      </a>
                      
                      <?php if($this->session->userdata('id')!='') { ?>
                      <a href="javascript: comupvote(<?=$rec->id?>,<?=$userId?>)" class="up">
                      <i class="far fa-thumbs-up"></i> <span id="demoo<?=$rec->id?>"> <?=$cupv?> </span>
                      </a>
                      <a href="javascript: comdownvote(<?=$rec->id?>,<?=$userId?>)" class="up">
                      <i class="far fa-thumbs-down"></i><span id="demoo2<?=$rec->id?>"> <?=$cdwv?> </span>
                      </a>
                      <?php } else { ?>
                      <a href="javascript: void(0);" class="up"> 
                         <i class="far fa-thumbs-up"></i>  <span> <?=$cupv?> </span> 
                      </a>
                      <a href="javascript: void(0);" class="up"> 
                         <i class="far fa-thumbs-down"></i>  <span> <?=$cdwv?> </span> 
                      </a>
                      <?php }?>
                      
                      <?php if($this->session->userdata('id')== $comauthor) {?>
                        <div class="dropdown detail-dp1">
                           <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                           <i class="fas fa-ellipsis-h"></i> 
                           </a>
                           <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                              <a class="dropdown-item" href="javascript:editcomment(<?=$rec->id?>);"> Edit </a>
                              <a class="dropdown-item" href="javascript:removecomment(<?=$rec->id?>);"> Delete </a>
                              <? //} else { ?>
                            </div>
                        </div>
                        <?php }?>
                        
                      </li>
                    </ul>
                 </div>
                 
                  <form name="frmreply<?=$rec->id?>" action="" method="post">
                 <input type="hidden" name="comment_id" value="<?=$rec->id?>" />
                 <div class="chat-sec-1" id="chat-d<?=$rec->id?>" style="display:none;">
                     <div class="comment-area2">
                           <div class="form-group">
                               <textarea name="reply<?=$rec->id?>" class="form-control" style="font-size:13px;" required></textarea>
                           </div>
                           <?php if($this->session->userdata('id')!='') { ?>
                           <button type="button" class="rely-dv-bn" id="hide-d<?=$rec->id?>" 
                           onclick="javascript:insertreply(<?=$id?>,<?=$user_id?>,<?=$rec->id?>,<?=$ans_id?>)">
                            Reply
                           </button>
                           <?php } else { ?>
                           <button type="button" class="rely-dv-bn" id="hide-d<?=$rec->id?>" data-toggle="modal" 
                           data-target="#cusModal">Reply</button>
                         <?php }?>
                     </div>
                     <hr>
                </div>
                </form>
                
                  <?php ///////////////// End Reply over comments /////////////////?>
                   
                  <?php
				      $this->db->order_by('id', 'DESC');
                      $reply =$this->db->get_where('reply_master',array('comment_id'=>$rec->id));
                      $x = 0;
                      
                      foreach($reply->result() as $rex)
                      {
                        $relauthor = $rex->user_id;
                        
                        $uname = $this->db->get_where('user_master',array('id'=>$rex->user_id))->row();
                        $exdt = explode('-', $rex->post_date);
                        $postdt = mktime(12,0,0, $exdt[1],$exdt[2],$exdt[0]);
                        $dt = date("F j, Y", $postdt);
                        
                          $cvt3 = $this->db->query("select sum(upvote) as upvot from `reply_up_down` where 
                                                  `reply_id` = '".$rex->id."'")->row();
                          $cupv3 = $cvt3->upvot;  
                        
                          $cvt3 = $this->db->query("select sum(downvote) as downvot from `reply_up_down` where 
                                                   `reply_id` = '".$rex->id."'")->row();
                          $cdwv3 = $cvt3->downvot;
                   ?>
                   <div class="comment-show-top-new">
                   <figure>
                    <?php 
                      if($uname->id=="Admin")
                      {
                    ?>
                       <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" width="25" height="25">
                    <?php
                     }
                     else
                     {
                       if($uname->profile_picture!="")
                       {
                     ?>
                       <img src="<?php echo base_url();?>uploads/<?=$uname->profile_picture?>" alt="user" 
                       style="border-radius:50%; width:30px; height:30px;">
                    <?php 
                       } 
                      else
                       {
                    ?>
                       <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                    <?php 
                       }
                     }
                    ?>
                    </figure>
                   <figcaption>
                    <?=$uname->name?> Replied on <?=$dt?>
                   </figcaption>
                 </div>
                 
                 <div style="padding-left:10px; line-height:20px;" id="rep<?=$rex->id?>"><?=stripslashes($rex->reply)?></div>
                 
                 <div class="chat-sec-1" id="rep-d<?=$rex->id?>" style="display:none;">
                 
                 <form name="frmedit" action="<?php echo base_url();?>problems/editreply/<?=$rex->id?>" method="post">
                 <input type="hidden" name="ques_id" value="<?=$qus_id?>" />
                 <div class="comment-area2">
                   <div class="form-group">
                       <input type="text" name="redit<?=$rex->id?>" class="form-control" style="font-size:13px;" 
                       value="<?=stripslashes($rex->reply)?>" required>
                   </div>
                    <button type="submit" class="rely-dv-bn" id="hide-d<?=$rex->id?>">Update</button>
                    <button type="button" class="rely-dv-bn" onclick="javascript:reveditreply(<?=$rex->id?>);">Cancel</button>
                  </div>
                  </form>
                  
                 <hr>
                </div>
                 
                 
                  <?php ///////////////// Reply over reply /////////////////?>
                  <div class="comment-sec-bottom1">
                   <ul>
                      <li class="d-flex">
                      <a class="reply-box" id="show-d_1<?=$rex->id?>" onclick="javascript:replyshow_1(<?=$rex->id?>);">
                         <i class="fa fa-reply"></i> Reply
                      </a>
                      <a class="reply-box" id="hide-d_1<?=$rex->id?>" onclick="javascript:replyhide_1(<?=$rex->id?>);" style="display:none;">
                         <i class="fa fa-reply"></i> Reply
                      </a>
                      
                      <?php if($this->session->userdata('id')!="") {?>
                      <a href="javascript: comupvote_1(<?=$rex->id?>,<?=$userId?>)" class="up">
                      <i class="far fa-thumbs-up"></i> <span id="demoo_1<?=$rex->id?>"> <?=$cupv3?> </span>
                      </a>
                      <a href="javascript: comdownvote_1(<?=$rex->id?>,<?=$userId?>)" class="up">
                      <i class="far fa-thumbs-down"></i> <span id="demoo2_1<?=$rex->id?>"> <?=$cdwv3?> </span>
                      </a>
                       <?php } else { ?>
                          <a href="javascript: void(0)" class="up">
                            <i class="far fa-thumbs-up"></i> <span> <?=$cupv3?> </span>
                          </a>
                          <a href="javascript: void(0)" class="up">
                            <i class="far fa-thumbs-down"></i> <span> <?=$cdwv3?> </span>
                          </a> 
                       <?php }?>
                       
                       <?php if($this->session->userdata('id')== $relauthor) {?>
                        <div class="dropdown detail-dp1">
                           <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                           <i class="fas fa-ellipsis-h"></i> 
                           </a>
                           <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                              
                              <a class="dropdown-item" href="javascript:editreply(<?=$rex->id?>);"> Edit </a>
                              <a class="dropdown-item" href="javascript:removereply(<?=$rex->id?>);"> Delete </a>
                              <?php //} else { ?>
                            </div>
                        </div>
                        <?php }?>
                        
                      </li>
                 </ul>
           </div>
                 
                 <form name="subreply<?=$rex->id?>" action="<?php echo base_url();?>problems/submitreply/<?=$qus_id?>/<?=$userId?>" method="post">
                 <input type="hidden" name="comment_id" value="<?=$comId?>" />
                 <div class="chat-sec-1" id="chat-d_1<?=$rex->id?>" style="display:none;">
                     <div class="comment-area2">
                           <div class="form-group">
                               <textarea name="reply<?=$comId?>" class="form-control" style="font-size:13px;" required></textarea>
                           </div>
                           <?php if($this->session->userdata('id')!='') { ?>
                           <button type="button" class="rely-dv-bn" id="hide-d_1<?=$rex->id?>" 
                           onclick="javascript:insertreply(<?=$id?>,<?=$user_id?>,<?=$rex->id?>,<?=$ans_id?>)">Reply</button>
                           <?php } else { ?>
                           <button type="button" class="rely-dv-bn" id="hide-d_1<?=$rex->id?>" data-toggle="modal" 
                           data-target="#cusModal">Reply</button>
                         <?php }?>
                     </div>
                     <hr>
                </div>
                </form>
                  <?php ///////////////// End Reply over reply /////////////////?>
                     
                   <?php
                      }
                   ?>
                <hr />
              </div>
              
           <?php
              $x++;
             } /// End Comments
           }
          ?>
        </div>
		      
		<?php    
			/////////////////////////// Action Section ////////////////////////
		  }
		?>
		  <script language="javascript">
		    function insertreply(qid,uid,cid,ansid)
			{
			  var xhttp = new XMLHttpRequest();
			  var content = document.getElementById('rep'+cid).value;
			  if(content!="")
			  {
				 xhttp.open("GET", "<?php echo base_url();?>problems/addreply/"+qid+"/"+uid+"/"+cid+"/"+ansid+"/"+content, false);
				 xhttp.send();
				  
				 document.getElementById("comments_x").style.display = 'none';
				 document.getElementById("comrep1").innerHTML = xhttp.responseText;
				 document.getElementById('rep'+cid).value = '';
			  }
			}
		  </script>
		<?php  
		}  // end function
		
		public function addcomment2()
		{
		  $ans_id = $this->uri->segment(3);
   	      $id = $this->uri->segment(4);
          $u_id = $this->uri->segment(5);
		  $comment = $this->uri->segment(6);
		 
          $data=array(
					  'answer_id'=>$ans_id,
					  'question_id'=>$id,
					  'user_id'=>$u_id,
					  'comment'=>str_replace("%20"," ",addslashes($comment)),
					  'post_date'=>date('Y-m-d')
					  );
		  
          $status = $this->db->insert('answer_comment',$data);
		  
		  if($status==true)
		  {
		    ///////////////////////////////////////////////////////////////////
		?>  

	   <?php
	      $this->db->order_by('id', 'DESC');
          $comment2 =$this->db->get_where('answer_comment',array('answer_id'=>$ans_id));
          $cntnum = $comment2->num_rows();
          $k = 0;
          
          if($cntnum!=0) {
          foreach($comment2->result() as $rec)
          {
            $comId = $rec->id;
            $authorcom = $rec->user_id;
            
            $username = $this->db->get_where('user_master',array('id'=>$rec->user_id))->row();
            $exdate = explode('-', $rec->post_date);
            $postdate = mktime(12,0,0, $exdate[1],$exdate[2],$exdate[0]);
            $date = date("F j, Y", $postdate);
            
            $cvt = $this->db->query("select sum(upvote) as upvot from `comment_up_down` where `comment_id` = '".$rec->id."'")->row();
            $cupv = $cvt->upvot;  
        
            $cvt2 = $this->db->query("select sum(downvote) as downvot from `comment_up_down` where `comment_id` = '".$rec->id."'")->row();
            $cdwv = $cvt2->downvot;
        ?>
        
      <div class="detial-new-comon reply-div">
             <div class="comment-show-top-new">
               <figure>
                 
                <?php 
                  if($username->id=="Admin")
                  {
                ?>
                   <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" 
                   style="border-radius:50%; width:30px; height:30px;">
                <?php
                 }
                 else
                 {
                   if($username->profile_picture!="")
                   {
                 ?>
                   <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                   style="border-radius:50%; width:30px; height:30px;">
                <?php 
                   } 
                  else
                   {
                ?>
                  <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                <?php 
                   }
                 }
                ?>
                </figure>
               <figcaption>
                <?=$username->name?> Commented on <?=$date?>
               </figcaption>
              </div>
              
              <p id="com_1<?=$comId?>"><?=stripslashes(str_replace("%20"," ",$rec->comment))?></p>
              
            <div id="com_edit<?=$comId?>" class="comment-sec-d1">
            <div class="detail-comment-sec2 new-dt-sec">
              <form name="frm<?=$comId?>" action="<?php echo base_url();?>problems/editcomment2/<?=$comId?>" method="post">
              <input type="hidden" name="ques_id" value="<?=$qId?>" /> 
                <div class="form-group">
                  <div class="coment-area-dv">
                    <div class="col-md-1 text-right">
                    <?php
                     if($username->profile_picture!="")
                     {  
                    ?>
                    <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" 
                      style="border-radius:50%; width:20px; height:20px;">
                    <?php } else {?>
                      <i class="fa fa-user" aria-hidden="true"></i>
                     <?php }?>
                    </div>
                    <div class="col-md-9 px-0">
                     <input type="text" name="cedit2<?=$comId?>" class="form-control" style="font-size:13px;" 
                     value="<?=stripslashes(str_replace("%20"," ",$rec->comment))?>">
                    </div>
                <div class="col-md-3">
                
                 <button type="submit" id="e_comment2<?=$comId?>" class="comon-dv-bn" onclick="javascript:updatecomment2(<?=$comId?>);">
                   Update
                 </button>
                 <button type="button" id="d_comment2<?=$comId?>" class="comon-dv-bn" onclick="javascript:comcancel2(<?=$comId?>);">
                   Cancel
                 </button>
                 
                </div>
              </div>
            </div>
           </form> 
        </div>
      </div>
              
              <? /////////////////////////  Reply for comments /////////////////////////////// ?>
              
            <div class="comment-sec-bottom1">
               <ul>
                  <li class="d-flex">
                     <a class="reply-box" id="show-d2<?=$rec->id?>" onclick="javascript:replyshow2(<?=$rec->id?>);">
                         <i class="fa fa-reply"></i> Reply
                      </a>
                      <a class="reply-box" id="hide-d2<?=$rec->id?>" onclick="javascript:replyhide2(<?=$rec->id?>);" 
                      style="display:none;"><i class="fa fa-reply"></i> Reply
                      </a>
                   
                    <?php if($this->session->userdata('id')!="") {?>   
                     <a href="javascript:comupvote2(<?=$rec->id?>,<?=$userId?>)" class="up">
                      <i class="far fa-thumbs-up"></i><span id="demoox<?=$rec->id?>"> <?=$cupv?> </span>  
                     </a>
                     <a href="javascript:comdownvote2(<?=$rec->id?>,<?=$userId?>)" class="up"> 
                       <i class="far fa-thumbs-down"></i><span id="demoox2<?=$rec->id?>"> <?=$cdwv?> </span> 
                     </a>
                     <?php } else { ?>
                     <a href="javascript:void(0);" class="up">
                      <i class="far fa-thumbs-up"></i><span> <?=$cupv?> </span>  
                     </a>
                     <a href="javascript:void(0)" class="up"> 
                       <i class="far fa-thumbs-down"></i><span> <?=$cdwv?> </span> 
                     </a>
                     <?php }?>
                     
                     <?php if($this->session->userdata('id')== $authorcom) {?>
                    <div class="dropdown detail-dp1">
                       <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                         <i class="fas fa-ellipsis-h"></i> 
                        </a>
                       <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                          <a class="dropdown-item" href="javascript:editcomment2(<?=$rec->id?>);"> Edit </a>
                          <a class="dropdown-item" href="javascript:removecomment2(<?=$rec->id?>);"> Delete </a>
                          <?php //} else { ?>
                        </div>
                    </div>
                    <?php }?>
                  </li>
                </ul>
               </div>
               
                 <form name="frmreply<?=$rec->id?>" action="" method="post">
                 <input type="hidden" name="comment_id" value="<?=$comId?>" />
                 <div class="chat-sec-1" id="chat-d2<?=$rec->id?>" style="display:none;">
                     <div class="comment-area2">
                       <div class="form-group">
                           <textarea name="reply<?=$rec->id?>" class="form-control" style="font-size:13px;" required></textarea>
                       </div>
                       <?php if($this->session->userdata('id')!='') { ?>
                       <button type="button" class="rely-dv-bn" id="hide-d2<?=$rec->id?>"
                        onclick="javascript:insertcomment2(<?=$rec->id?>,<?=$qId?>,<?=$userId?>)">Reply</button>
                       <?php } else { ?>
                       <button type="button" class="rely-dv-bn" id="hide-d2<?=$rec->id?>" data-toggle="modal" data-target="#cusModal">Reply</button>
                     <?php }?>
                 </div>
                 <hr>
                </div>
                </form>
              
              <? /////////////////////////// End Reply //////////////////////////////////////// ?>
             
              <?php
			      $this->db->order_by('id', 'DESC');
                  $reply =$this->db->get_where('reply_master',array('comment_id'=>$rec->id));
                  $x = 0;
                  foreach($reply->result() as $rex)
                  {
                    $authorrep = $rex->user_id;
                    $uname = $this->db->get_where('user_master',array('id'=>$rex->user_id))->row();
                    $exdt = explode('-', $rex->post_date);
                    $postdt = mktime(12,0,0, $exdt[1],$exdt[2],$exdt[0]);
                    $dt = date("F j, Y", $postdt);
                    
                    $rcvt = $this->db->query("select sum(upvote) as upvot from `reply_up_down` where 
                                            `reply_id` = '".$rex->id."'")->row();
                    $rcupv = $rcvt->upvot;  
                
                    $rcvt2 = $this->db->query("select sum(downvote) as downvot from `reply_up_down` where 
                                             `reply_id` = '".$rex->id."'")->row();
                    $rcdwv = $rcvt2->downvot;
               ?>
               <div class="comment-show-top-new">
               <figure>
                <?php 
                  if($uname->id=="Admin")
                  {
                ?>
                   <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" width="30" height="30">
                <?php
                 }
                 else
                 {
                   if($uname->profile_picture!="")
                   {
                 ?>
                   <img src="<?php echo base_url();?>uploads/<?=$uname->profile_picture?>" alt="user" 
                   style="border-radius:50%; width:30px; height:30px;">
                <?php 
                   } 
                  else
                   {
                ?>
                   <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                <?php 
                   }
                 }
                ?>
                </figure>
               <figcaption>
                <?=$uname->name?> Replied on <?=$dt?>
               </figcaption>
             </div>
                 <p style="padding-left:10px; line-height:20px;" id="rep2<?=$rex->id?>"><?=stripslashes($rex->reply)?></p>
                 
                 <div class="chat-sec-1" id="rep-d2<?=$rex->id?>" style="display:none;">
                 
                 <form name="frmedit" action="<?php echo base_url();?>problems/editreply/<?=$rex->id?>" method="post">
                 <input type="hidden" name="ques_id" value="<?=$qId?>" />
                 <div class="comment-area2">
                   <div class="form-group">
                       <input type="text" name="redit<?=$rex->id?>" class="form-control" style="font-size:13px;" 
                       value="<?=stripslashes($rex->reply)?>" required>
                   </div>
                    <button type="submit" class="rely-dv-bn" id="hide-d<?=$rex->id?>">Update</button>
                    <button type="button" class="rely-dv-bn" onclick="javascript:reveditreply2(<?=$rex->id?>);">Cancel</button>
                  </div>
                  </form>
                  
                 <hr>
                </div>
              
               <?php  ///////////////////////////// Reply over reply /////////////////////////////// ?>
                
              <div class="comment-sec-bottom1">
               <ul>
                  <li class="d-flex">
                     <a class="reply-box" id="show-d2_1<?=$rex->id?>" onclick="javascript:replyshow2_1(<?=$rex->id?>);">
                         <i class="fa fa-reply"></i> Reply
                      </a>
                      <a class="reply-box" id="hide-d2_1<?=$rex->id?>" onclick="javascript:replyhide2_1(<?=$rex->id?>);" 
                      style="display:none;"><i class="fa fa-reply"></i> Reply
                      </a>
                      
                    <a href="javascript:replyupvote2_1(<?=$rex->id?>)" class="up">
                      <i class="far fa-thumbs-up"></i><span id="demooxr<?=$rex->id?>"> <?=$rcupv?> </span>  
                    </a>
                    <a href="javascript:replydownvote2_1(<?=$rex->id?>)" class="up"> 
                       <i class="far fa-thumbs-down"></i><span id="demoox2r<?=$rex->id?>"> <?=$rcdwv?> </span> 
                    </a>
                    
                    <?php if($this->session->userdata('id')== $authorrep) {?>
                    <div class="dropdown detail-dp1">
                       <a href="#" id="dropdownMenuButton" data-toggle="dropdown" 
                       aria-haspopup="true" aria-expanded="false"> <i class="fas fa-ellipsis-h"></i> 
                        </a>
                       <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                          
                          <a class="dropdown-item" href="javascript:editreply2(<?=$rex->id?>)"> Edit </a>
                          <a class="dropdown-item" href="javascript:removereply2(<?=$rex->id?>)"> Delete </a>
                          <?php //} else { ?>
                        </div>
                    </div>
                     <?php }?>
                    
                  </li>
                </ul>
               </div>
               
                 <form name="frmreply<?=$rex->id?>" action="" method="post">
                 <input type="hidden" name="comment_id" value="<?=$comId?>" />
                 <div class="chat-sec-1" id="chat-d2_1<?=$rex->id?>" style="display:none;">
                     <div class="comment-area2">
                           <div class="form-group">
                               <textarea name="reply<?=$comId?>" class="form-control" style="font-size:13px;" required></textarea>
                           </div>
                           <?php if($this->session->userdata('id')!='') { ?>
                           <button type="button" class="rely-dv-bn" id="hide-d2<?=$rex->id?>" onclick="javascript:insertcomment2(<?=$rex->id?>,<?=$qId?>,<?=$userId?>)">Reply</button>
                           <?php } else { ?>
                           <button type="button" class="rely-dv-bn" id="hide-d2<?=$rex->id?>" data-toggle="modal" 
                           data-target="#cusModal">Reply</button>
                         <?php }?>
                     </div>
                     <hr>
                </div>
                </form>
                
               <? /////////////////////////////// End Reply over reply ////////////////////////// ?>
                <?php
                  }
               ?>
               <hr />
            </div>
                
                <?php
                    } // End comment loop for related
                 }
                
                 ?>
                                                     
		      
		<?php    
			/////////////////////////// Action Section ////////////////////////
		  }
		  
		}  // end function
		
		public function editcomment()
        {
          $id=$this->uri->segment(3);
          $content=$this->uri->segment(4);
		  
          $data=array('comment'=>$content);
		  
		  $this->db->where('id',$id);
          $status=$this->db->update('answer_comment',$data);
         //redirect('problems/answer/'.$q_id);
		 
		// redirect('details/show/'.$id);
        }
		
		public function editcomment2()
        {
          $id=$this->uri->segment(3);
		  $qid = $this->input->post('ques_id');
          $content=$this->input->post('cedit2'.$id);
		  
          $data=array('comment'=>$content);
		  
		  $this->db->where('id',$id);
          $status=$this->db->update('answer_comment',$data);
         //redirect('problems/answer/'.$q_id);
		 
		  redirect('details/show/'.$qid);
        }
		
		public function deletecomment()
		{
		   $id=$this->uri->segment(3);
		   $ans_id=$this->uri->segment(4);
		   
		   $this->db->where('id', $id);
		   $result = $this->db->delete('answer_comment');
		   
		   if($result==true)
		   {
	 	?>
            <div>
                <?php
                  $this->db->order_by('id', 'DESC');
                  $comment =$this->db->get_where('answer_comment',array('id'=>$ans_id));
                  $comnum = $comment->num_rows();
                  $x = 0;
                  
                  if($comnum!=0) {
                  foreach($comment->result() as $rec)
                  {
                    $comId = $rec->id;
                    $comauthor = $rec->user_id;
                    
                    $username = $this->db->get_where('user_master',array('id'=>$rec->user_id))->row();
                    $exdate = explode('-', $rec->post_date);
                    $postdate = mktime(12,0,0, $exdate[1],$exdate[2],$exdate[0]);
                    $date = date("F j, Y", $postdate);
                    
                      $cvt = $this->db->query("select sum(upvote) as upvot from `comment_up_down` where 
                                              `comment_id` = '".$rec->id."'")->row();
                      $cupv = $cvt->upvot;  
                    
                      $cvt2 = $this->db->query("select sum(downvote) as downvot from `comment_up_down` where 
                                            `comment_id` = '".$rec->id."'")->row();
                      $cdwv = $cvt2->downvot;
                   ?>
                     <div class="detial-new-comon <? if($x!=0){?>reply-div<?=$x?><? }?>">
                
                         <div id="cmt">
                             <div class="comment-show-top-new">
                               <figure>
                                <?php 
                                  if($username->id=="Admin")
                                  {
                                ?>
                                   <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" width="30" height="30">
                                <?php
                                  }
                                  else
                                  {
                                   if($username->profile_picture!="")
                                   {
                                 ?>
                                   <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                                   style="border-radius:50%; width:30px; height:30px;">
                                <?php 
                                   } 
                                  else
                                   {
                                ?>
                                   <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                                <?php 
                                   }
                                  }
                                ?>
                                </figure>
                               <figcaption><?=$username->geek_name?> Commented on <?=$date?></figcaption>
                             </div>
                             
                               <div id="com1<?=$rec->id?>"> <?=stripslashes(str_replace("%20"," ",$rec->comment));?> </div>
                          </div> 
                          
                          <!--<div id="ademo"></div>-->
                          
                            <div class="comment-sec-d1" id="comedit<?=$rec->id?>" style="display:none;">
                            <div class="detail-comment-sec2 new-dt-sec">
                               
                                <div class="form-group">
                                  <div class="coment-area-dv">
                                    <div class="col-md-1 text-right">
                                       <?php if($username->profile_picture!=""){ ?>
                                       <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                                       style="border-radius:50%; width:20px; height:20px;">
                                       <?php } else {?>
                                       <i class="fa fa-user" aria-hidden="true"></i>
                                       <?php }?>
                                    </div>
                                    <div class="col-md-9 px-0">
                                      <input type="text" name="commentedit<?=$rec->id?>" id="cedit<?=$rec->id?>" class="form-control" 
                                      value="<?=stripslashes(str_replace("%20"," ",$rec->comment));?>" style="font-size:13px;">
                                    </div>
                                    <div class="col-md-3">
                                      <button type="button" id="add_com<?=$rec->id?>" class="comon-dv-bn" 
                                      onclick="javascript:updatecomment(<?=$rec->id?>);">Update</button>
                                      
                                      <button type="button" id="cancel_com<?=$rec->id?>" class="comon-dv-bn" 
                                      onclick="javascript:comcancel(<?=$rec->id?>);">Cancel</button>
                                    </div>
                                  </div>
                                </div>
            
                            </div>
                          </div>
                           
                          <?php //////////////////////// End Comments //////////////////// ?> 
                          
                          <?php ///////////////// Reply over comments /////////////////?>
                          <div class="comment-sec-bottom1">
                           <ul>
                              <li class="d-flex">
                              <a class="reply-box" id="show-d<?=$rec->id?>" onclick="javascript:replyshow(<?=$rec->id?>);">
                                 <i class="fa fa-reply"></i> Reply
                              </a>
                              <a class="reply-box" id="hide-d<?=$rec->id?>" onclick="javascript:replyhide(<?=$rec->id?>);" style="display:none;">
                                 <i class="fa fa-reply"></i> Reply
                              </a>
                              
                              <?php if($this->session->userdata('id')!='') { ?>
                              <a href="javascript: comupvote(<?=$rec->id?>,<?=$userId?>)" class="up">
                              <i class="far fa-thumbs-up"></i> <span id="demoo<?=$rec->id?>"> <?=$cupv?> </span>
                              </a>
                              <a href="javascript: comdownvote(<?=$rec->id?>,<?=$userId?>)" class="up">
                              <i class="far fa-thumbs-down"></i><span id="demoo2<?=$rec->id?>"> <?=$cdwv?> </span>
                              </a>
                              <?php } else { ?>
                              <a href="javascript: void(0);" class="up"> 
                                 <i class="far fa-thumbs-up"></i>  <span> <?=$cupv?> </span> 
                              </a>
                              <a href="javascript: void(0);" class="up"> 
                                 <i class="far fa-thumbs-down"></i>  <span> <?=$cdwv?> </span> 
                              </a>
                              <?php }?>
                              
                              <?php if($this->session->userdata('id')== $comauthor) {?>
                                <div class="dropdown detail-dp1">
                                   <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                   <i class="fas fa-ellipsis-h"></i> 
                                   </a>
                                   <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                                      <a class="dropdown-item" href="javascript:editcomment(<?=$rec->id?>);"> Edit </a>
                                      <a class="dropdown-item" href="javascript:removecomment(<?=$rec->id?>);"> Delete </a>
                                      <? //} else { ?>
                                    </div>
                                </div>
                                <?php }?>
                                
                              </li>
                            </ul>
                         </div>
                         
                         <form name="frmreply<?=$rec->id?>" action="" method="post">
                         <input type="hidden" name="comment_id" value="<?=$rec->id?>" />
                         <div class="chat-sec-1" id="chat-d<?=$rec->id?>" style="display:none;">
                             <div class="comment-area2">
                                   <div class="form-group">
                                     <textarea name="reply<?=$rec->id?>" id="rep<?=$rec->id?>" class="form-control" 
                                     style="font-size:13px;" required></textarea>
                                   </div>
                                   <?php if($this->session->userdata('id')!='') { ?>
                                   <button type="button" class="rely-dv-bn" id="hide-d<?=$rec->id?>" 
                                   onclick="javascript:insertreply(<?=$qus_id?>,<?=$userId?>,<?=$rec->id?>,<?=$record->id?>)">
                                   Reply</button>
                                   <?php } else { ?>
                                   <button type="button" class="rely-dv-bn" id="hide-d<?=$rec->id?>" data-toggle="modal" 
                                   data-target="#cusModal">Reply</button>
                                 <?php }?>
                             </div>
                             <hr>
                        </div>
                        </form>
                        
                          <?php ///////////////// End Reply over comments /////////////////?>
                           
                          <?php
                              $reply =$this->db->get_where('reply_master',array('comment_id'=>$rec->id));
                              $x = 0;
                              
                              foreach($reply->result() as $rex)
                              {
                                $relauthor = $rex->user_id;
                                
                                $uname = $this->db->get_where('user_master',array('id'=>$rex->user_id))->row();
                                $exdt = explode('-', $rex->post_date);
                                $postdt = mktime(12,0,0, $exdt[1],$exdt[2],$exdt[0]);
                                $dt = date("F j, Y", $postdt);
                                
                                  $cvt3 = $this->db->query("select sum(upvote) as upvot from `reply_up_down` where 
                                                          `reply_id` = '".$rex->id."'")->row();
                                  $cupv3 = $cvt3->upvot;  
                                
                                  $cvt3 = $this->db->query("select sum(downvote) as downvot from `reply_up_down` where 
                                                           `reply_id` = '".$rex->id."'")->row();
                                  $cdwv3 = $cvt3->downvot;
                           ?>
                           <div id="comrep">
                           <div class="comment-show-top-new">
                           <figure>
                            <?php 
                              if($uname->id=="Admin")
                              {
                            ?>
                               <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" width="25" height="25">
                            <?php
                             }
                             else
                             {
                               if($uname->profile_picture!="")
                               {
                             ?>
                               <img src="<?php echo base_url();?>uploads/<?=$uname->profile_picture?>" alt="user" 
                               style="border-radius:50%; width:30px; height:30px;">
                            <?php 
                               } 
                              else
                               {
                            ?>
                               <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                            <?php 
                               }
                             }
                            ?>
                            </figure>
                           <figcaption>
                            <?=$uname->geek_name?> Replied on <?=$dt?>
                           </figcaption>
                         </div>
                         
                         <div style="padding-left:10px; line-height:20px;" id="rep<?=$rex->id?>">
                            <?=stripslashes($rex->reply)?>
                         </div>
                         </div>
                         
                         <!--<div id="comrep1"></div>-->
                         
                         <div class="chat-sec-1" id="rep-d<?=$rex->id?>" style="display:none;">
                         
                         <form name="frmedit" action="<?php echo base_url();?>problems/editreply/<?=$rex->id?>" method="post">
                         <input type="hidden" name="ques_id" value="<?=$qus_id?>" />
                         <div class="comment-area2">
                           <div class="form-group">
                               <input type="text" name="redit<?=$rex->id?>" class="form-control" style="font-size:13px;" 
                               value="<?=stripslashes($rex->reply)?>" required>
                           </div>
                            <button type="submit" class="rely-dv-bn" id="hide-d<?=$rex->id?>">Update</button>
                            <button type="button" class="rely-dv-bn" onclick="javascript:reveditreply(<?=$rex->id?>);">Cancel</button>
                          </div>
                          </form>
                          
                         <hr>
                        </div>
                         
                         
                          <?php ///////////////// Reply over reply /////////////////?>
                          <div class="comment-sec-bottom1">
                           <ul>
                              <li class="d-flex">
                              <a class="reply-box" id="show-d_1<?=$rex->id?>" onclick="javascript:replyshow_1(<?=$rex->id?>);">
                                 <i class="fa fa-reply"></i> Reply
                              </a>
                              <a class="reply-box" id="hide-d_1<?=$rex->id?>" onclick="javascript:replyhide_1(<?=$rex->id?>);" style="display:none;">
                                 <i class="fa fa-reply"></i> Reply
                              </a>
                              
                              <?php if($this->session->userdata('id')!="") {?>
                              <a href="javascript: comupvote_1(<?=$rex->id?>,<?=$userId?>)" class="up">
                              <i class="far fa-thumbs-up"></i> <span id="demoo_1<?=$rex->id?>"> <?=$cupv3?> </span>
                              </a>
                              <a href="javascript: comdownvote_1(<?=$rex->id?>,<?=$userId?>)" class="up">
                              <i class="far fa-thumbs-down"></i> <span id="demoo2_1<?=$rex->id?>"> <?=$cdwv3?> </span>
                              </a>
                               <?php } else { ?>
                                  <a href="javascript: void(0)" class="up">
                                    <i class="far fa-thumbs-up"></i> <span> <?=$cupv3?> </span>
                                  </a>
                                  <a href="javascript: void(0)" class="up">
                                    <i class="far fa-thumbs-down"></i> <span> <?=$cdwv3?> </span>
                                  </a> 
                               <?php }?>
                               
                               <?php if($this->session->userdata('id')== $relauthor) {?>
                                <div class="dropdown detail-dp1">
                                   <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                                   <i class="fas fa-ellipsis-h"></i> 
                                   </a>
                                   <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                                      
                                      <a class="dropdown-item" href="javascript:editreply(<?=$rex->id?>);"> Edit </a>
                                      <a class="dropdown-item" href="javascript:removereply(<?=$rex->id?>);"> Delete </a>
                                      <?php //} else { ?>
                                    </div>
                                </div>
                                <?php }?>
                                
                              </li>
                         </ul>
                   </div>
                         
                         <form name="subreply<?=$rex->id?>" action="" method="post">
                         <input type="hidden" name="comment_id" value="<?=$comId?>" />
                         <div class="chat-sec-1" id="chat-d_1<?=$rex->id?>" style="display:none;">
                             <div class="comment-area2">
                                   <div class="form-group">
                                       <textarea name="reply<?=$comId?>" class="form-control" style="font-size:13px;" required></textarea>
                                   </div>
                                   <?php if($this->session->userdata('id')!='') { ?>
                                   <button type="button" class="rely-dv-bn" id="hide-d_1<?=$rex->id?>"
                                    onclick="javascript:insertreply(<?=$qus_id?>,<?=$userId?>,<?=$rex->id?>,<?=$record->id?>)">Reply</button>
                                   <?php } else { ?>
                                   <button type="button" class="rely-dv-bn" id="hide-d_1<?=$rex->id?>" data-toggle="modal" 
                                   data-target="#cusModal">Reply</button>
                                 <?php }?>
                             </div>
                             <hr>
                        </div>
                        </form>
                          <?php ///////////////// End Reply over reply /////////////////?>
                             
                           <?php
                              }
                           ?>
                        <hr />
                      </div>
                   <?php
                      $x++;
                     } /// End Comments
                   
                   }
                  else
                  { 
                  ?>
                    <p align="center">No comments found.</p>
                  <?php
                  }
                  ?>
                </div>
            <script>
			function removecomment(id) 
			{
			  var xhttp = new XMLHttpRequest();
			  xhttp.open("GET", "<?php echo base_url();?>problems/deletecomment/"+id, false);
			  xhttp.send();
			  
			  document.getElementById("comments_x").style.display = 'none';
			  document.getElementById("ademo").style.display = 'none';
			  document.getElementById("comrep1").style.display = 'none';
			  
			  document.getElementById("ddemo").innerHTML = xhttp.responseText;
			  
			  /*xhttp.responseText;
			  location.reload(true);*/
			}
			</script>    
        <?php	   
		   }
		   
		}
		////////////////////////////////////
		
		public function submitreply()
        {
          $id=$this->uri->segment(3);
          $u_id=$this->uri->segment(4);
		  $com_id = $this->input->post('comment_id');
          
		  $data=array(
          'comment_id'=>$com_id,
		  'question_id'=>$id,
		  'user_id'=>$u_id,
          'reply'=>$this->input->post('reply'.$com_id),
          'post_date'=>date('Y-m-d'),
          );
		  
          $status=$this->db->insert('reply_master',$data);
		  
		  redirect('details/show/'.$id);
        }
		
		public function addreply()
		{
		 /*$id = $this->uri->segment(3);
          $u_id=$this->uri->segment(4);
		  $com_id = $this->uri->segment(5);
		  $ans_id = $this->uri->segment(6);
		  $reply = $this->uri->segment(7);*/
		  
		  $id = $this->input->post('ques_id');
          $u_id=$this->input->post('user_id');
		  $com_id = $this->input->post('comment_id');
		  $ans_id = $this->input->post('ans_id');
		  $reply = $this->input->post('content');
          
		  $data = array('comment_id'=>$com_id,
						  'question_id'=>$id,
						  'user_id'=>$u_id,
						  'reply'=>str_replace("%20"," ",addslashes($reply)),
						  'post_date'=>date('Y-m-d'));
		  
          $status = $this->db->insert('reply_master',$data);
		  
		  if($status==true)
		   {
		    ///////////////////////////////////////////////////////////////////
		?>  
        <div>
		<?php
          $this->db->order_by('id', 'DESC');
          $comment =$this->db->get_where('answer_comment',array('answer_id'=>$ans_id));
          $comnum = $comment->num_rows();
          $x = 0;
          
          if($comnum!=0) {
          foreach($comment->result() as $rec)
          {
            $comId = $rec->id;
            $comauthor = $rec->user_id;
            
            $username = $this->db->get_where('user_master',array('id'=>$rec->user_id))->row();
            $exdate = explode('-', $rec->post_date);
            $postdate = mktime(12,0,0, $exdate[1],$exdate[2],$exdate[0]);
            $date = date("F j, Y", $postdate);
            
              $cvt = $this->db->query("select sum(upvote) as upvot from `comment_up_down` where 
                                      `comment_id` = '".$rec->id."'")->row();
              $cupv = $cvt->upvot;  
            
              $cvt2 = $this->db->query("select sum(downvote) as downvot from `comment_up_down` where 
                                    `comment_id` = '".$rec->id."'")->row();
              $cdwv = $cvt2->downvot;
           ?>
             <div class="detial-new-comon <? if($x!=0){?>reply-div<?=$x?><? }?>">
        
                 <div id="cmt">
                     <div class="comment-show-top-new">
                       <figure>
                        <?php 
                          if($username->id=="Admin")
                          {
                        ?>
                           <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" width="30" height="30">
                        <?php
                          }
                          else
                          {
                           if($username->profile_picture!="")
                           {
                         ?>
                           <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                           style="border-radius:50%; width:30px; height:30px;">
                        <?php 
                           } 
                          else
                           {
                        ?>
                           <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                        <?php 
                           }
                          }
                        ?>
                        </figure>
                       <figcaption><?=$username->geek_name?> Commented on <?=$date?></figcaption>
                     </div>
                     
                       <div id="com1<?=$rec->id?>"> <?=stripslashes(str_replace("%20"," ",$rec->comment));?> </div>
                  </div> 
                  
                  <div id="ademo"></div>
                  
                    <div class="comment-sec-d1" id="comedit<?=$rec->id?>" style="display:none;">
                    <div class="detail-comment-sec2 new-dt-sec">
                       
                        <div class="form-group">
                          <div class="coment-area-dv">
                            <div class="col-md-1 text-right">
                               <?php if($username->profile_picture!=""){ ?>
                               <img src="<?php echo base_url();?>uploads/<?=$username->profile_picture?>" alt="user" 
                               style="border-radius:50%; width:20px; height:20px;">
                               <?php } else {?>
                               <i class="fa fa-user" aria-hidden="true"></i>
                               <?php }?>
                            </div>
                            <div class="col-md-9 px-0">
                              <input type="text" name="commentedit<?=$rec->id?>" id="cedit<?=$rec->id?>" class="form-control" 
                              value="<?=stripslashes(str_replace("%20"," ",$rec->comment));?>" style="font-size:13px;">
                            </div>
                            <div class="col-md-3">
                              <button type="button" id="add_com<?=$rec->id?>" class="comon-dv-bn" 
                              onclick="javascript:updatecomment(<?=$rec->id?>);">Update</button>
                              
                              <button type="button" id="cancel_com<?=$rec->id?>" class="comon-dv-bn" 
                              onclick="javascript:comcancel(<?=$rec->id?>);">Cancel</button>
                            </div>
                          </div>
                        </div>

                    </div>
                  </div>
                   
                  <?php //////////////////////// End Comments //////////////////// ?> 
                  
                  <?php ///////////////// Reply over comments /////////////////?>
                  <div class="comment-sec-bottom1">
                   <ul>
                      <li class="d-flex">
                      <a class="reply-box" id="show-d<?=$rec->id?>" onclick="javascript:replyshow(<?=$rec->id?>);">
                         <i class="fa fa-reply"></i> Reply
                      </a>
                      <a class="reply-box" id="hide-d<?=$rec->id?>" onclick="javascript:replyhide(<?=$rec->id?>);" style="display:none;">
                         <i class="fa fa-reply"></i> Reply
                      </a>
                      
                      <?php if($this->session->userdata('id')!='') { ?>
                      <a href="javascript: comupvote(<?=$rec->id?>,<?=$userId?>)" class="up">
                      <i class="far fa-thumbs-up"></i> <span id="demoo<?=$rec->id?>"> <?=$cupv?> </span>
                      </a>
                      <a href="javascript: comdownvote(<?=$rec->id?>,<?=$userId?>)" class="up">
                      <i class="far fa-thumbs-down"></i><span id="demoo2<?=$rec->id?>"> <?=$cdwv?> </span>
                      </a>
                      <?php } else { ?>
                      <a href="javascript: void(0);" class="up"> 
                         <i class="far fa-thumbs-up"></i>  <span> <?=$cupv?> </span> 
                      </a>
                      <a href="javascript: void(0);" class="up"> 
                         <i class="far fa-thumbs-down"></i>  <span> <?=$cdwv?> </span> 
                      </a>
                      <?php }?>
                      
                      <?php if($this->session->userdata('id')== $comauthor) {?>
                        <div class="dropdown detail-dp1">
                           <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                           <i class="fas fa-ellipsis-h"></i> 
                           </a>
                           <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                              <a class="dropdown-item" href="javascript:editcomment(<?=$rec->id?>);"> Edit </a>
                              <a class="dropdown-item" href="javascript:removecomment(<?=$rec->id?>);"> Delete </a>
                              <? //} else { ?>
                            </div>
                        </div>
                        <?php }?>
                        
                      </li>
                    </ul>
                 </div>
                 
                 <form name="frmreply<?=$rec->id?>" action="" method="post">
                 <input type="hidden" name="comment_id" value="<?=$rec->id?>" />
                 <div class="chat-sec-1" id="chat-d<?=$rec->id?>" style="display:none;">
                     <div class="comment-area2">
                           <div class="form-group">
                               <textarea name="reply<?=$rec->id?>" class="form-control" style="font-size:13px;" required></textarea>
                           </div>
                           <?php if($this->session->userdata('id')!='') { ?>
                           <button type="button" class="rely-dv-bn" id="hide-d<?=$rec->id?>" 
                           onclick="javascript:insertreply(<?=$qus_id?>,<?=$userId?>,<?=$rec->id?>,<?=$record->id?>)">Reply</button>
                           <?php } else { ?>
                           <button type="button" class="rely-dv-bn" id="hide-d<?=$rec->id?>" data-toggle="modal" 
                           data-target="#cusModal">Reply</button>
                         <?php }?>
                     </div>
                     <hr>
                </div>
                </form>
                
                  <?php ///////////////// End Reply over comments /////////////////?>
                   
                  <?php
				      $this->db->order_by('id', 'DESC');
                      $reply =$this->db->get_where('reply_master',array('comment_id'=>$rec->id));
                      $x = 0;
                      
                      foreach($reply->result() as $rex)
                      {
                        $relauthor = $rex->user_id;
                        
                        $uname = $this->db->get_where('user_master',array('id'=>$rex->user_id))->row();
                        $exdt = explode('-', $rex->post_date);
                        $postdt = mktime(12,0,0, $exdt[1],$exdt[2],$exdt[0]);
                        $dt = date("F j, Y", $postdt);
                        
                          $cvt3 = $this->db->query("select sum(upvote) as upvot from `reply_up_down` where 
                                                  `reply_id` = '".$rex->id."'")->row();
                          $cupv3 = $cvt3->upvot;  
                        
                          $cvt3 = $this->db->query("select sum(downvote) as downvot from `reply_up_down` where 
                                                   `reply_id` = '".$rex->id."'")->row();
                          $cdwv3 = $cvt3->downvot;
                   ?>
                   <div class="comment-show-top-new">
                   <figure>
                    <?php 
                      if($uname->id=="Admin")
                      {
                    ?>
                       <img src="<?php echo base_url();?>assets2/images/avataaars-2.png" alt="user" width="25" height="25">
                    <?php
                     }
                     else
                     {
                       if($uname->profile_picture!="")
                       {
                     ?>
                       <img src="<?php echo base_url();?>uploads/<?=$uname->profile_picture?>" alt="user" 
                       style="border-radius:50%; width:30px; height:30px;">
                    <?php 
                       } 
                      else
                       {
                    ?>
                       <img src="<?php echo base_url();?>assets2/images/avatar.png" alt="user" width="30" height="30">
                    <?php 
                       }
                     }
                    ?>
                    </figure>
                   <figcaption>
                    <?=$uname->name?> Replied on <?=$dt?>
                   </figcaption>
                 </div>
                 
                 <div style="padding-left:10px; line-height:20px;" id="rep<?=$rex->id?>"><?=stripslashes($rex->reply)?></div>
                 
                 <div class="chat-sec-1" id="rep-d<?=$rex->id?>" style="display:none;">
                 
                 <form name="frmedit" action="<?php echo base_url();?>problems/editreply/<?=$rex->id?>" method="post">
                 <input type="hidden" name="ques_id" value="<?=$qus_id?>" />
                 <div class="comment-area2">
                   <div class="form-group">
                       <input type="text" name="redit<?=$rex->id?>" class="form-control" style="font-size:13px;" 
                       value="<?=stripslashes($rex->reply)?>" required>
                   </div>
                    <button type="submit" class="rely-dv-bn" id="hide-d<?=$rex->id?>">Update</button>
                    <button type="button" class="rely-dv-bn" onclick="javascript:reveditreply(<?=$rex->id?>);">Cancel</button>
                  </div>
                  </form>
                  
                 <hr>
                </div>
                 
                 
                  <?php ///////////////// Reply over reply /////////////////?>
                  <div class="comment-sec-bottom1">
                   <ul>
                      <li class="d-flex">
                      <a class="reply-box" id="show-d_1<?=$rex->id?>" onclick="javascript:replyshow_1(<?=$rex->id?>);">
                         <i class="fa fa-reply"></i> Reply
                      </a>
                      <a class="reply-box" id="hide-d_1<?=$rex->id?>" onclick="javascript:replyhide_1(<?=$rex->id?>);" style="display:none;">
                         <i class="fa fa-reply"></i> Reply
                      </a>
                      
                      <?php if($this->session->userdata('id')!="") {?>
                      <a href="javascript: comupvote_1(<?=$rex->id?>,<?=$userId?>)" class="up">
                      <i class="far fa-thumbs-up"></i> <span id="demoo_1<?=$rex->id?>"> <?=$cupv3?> </span>
                      </a>
                      <a href="javascript: comdownvote_1(<?=$rex->id?>,<?=$userId?>)" class="up">
                      <i class="far fa-thumbs-down"></i> <span id="demoo2_1<?=$rex->id?>"> <?=$cdwv3?> </span>
                      </a>
                       <?php } else { ?>
                          <a href="javascript: void(0)" class="up">
                            <i class="far fa-thumbs-up"></i> <span> <?=$cupv3?> </span>
                          </a>
                          <a href="javascript: void(0)" class="up">
                            <i class="far fa-thumbs-down"></i> <span> <?=$cdwv3?> </span>
                          </a> 
                       <?php }?>
                       
                       <?php if($this->session->userdata('id')== $relauthor) {?>
                        <div class="dropdown detail-dp1">
                           <a href="#" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
                           <i class="fas fa-ellipsis-h"></i> 
                           </a>
                           <div class="dropdown-menu sub-dp1" aria-labelledby="dropdownMenuButton">
                              
                              <a class="dropdown-item" href="javascript:editreply(<?=$rex->id?>);"> Edit </a>
                              <a class="dropdown-item" href="javascript:removereply(<?=$rex->id?>);"> Delete </a>
                              <?php //} else { ?>
                            </div>
                        </div>
                        <?php }?>
                        
                      </li>
                 </ul>
           </div>
                 
                 <form name="subreply<?=$rex->id?>" action="" method="post">
                 <input type="hidden" name="comment_id" value="<?=$comId?>" />
                 <div class="chat-sec-1" id="chat-d_1<?=$rex->id?>" style="display:none;">
                     <div class="comment-area2">
                           <div class="form-group">
                               <textarea name="reply<?=$comId?>" class="form-control" style="font-size:13px;" required></textarea>
                           </div>
                           <?php if($this->session->userdata('id')!='') { ?>
                           <button type="button" class="rely-dv-bn" id="hide-d_1<?=$rex->id?>" 
                           onclick="javascript:insertreply(<?=$qus_id?>,<?=$userId?>,<?=$rex->id?>,<?=$record->id?>)">Reply</button>
                           <?php } else { ?>
                           <button type="button" class="rely-dv-bn" id="hide-d_1<?=$rex->id?>" data-toggle="modal" 
                           data-target="#cusModal">Reply</button>
                         <?php }?>
                     </div>
                     <hr>
                </div>
                </form>
                  <?php ///////////////// End Reply over reply /////////////////?>
                     
                   <?php
                      }
                   ?>
                <hr />
              </div>
              
           <?php
              $x++;
             } /// End Comments
           }
          ?>
        </div>
		      
		<?php    
			/////////////////////////// Action Section ////////////////////////
		  
			   
		   }
		}  // End function
		
		public function editreply()
		{
          $id=$this->uri->segment(3);
		  $qid = $this->input->post('ques_id');
          $content=$this->input->post('redit'.$id);
		  
          $data=array('reply'=>$content);
		  
		  $this->db->where('id',$id);
          $status=$this->db->update('reply_master',$data);
		  
		  redirect('details/show/'.$qid);
        }
		
		public function deletereply()
		{
		   $id=$this->uri->segment(3);
		   
		   $this->db->where('id', $id);
		   $this->db->delete('reply_master');
		}
		
		///////////////////////////////////////////
		
		public function submitsubreply()
        {
          $replyid=$this->uri->segment(3);
          $u_id=$this->uri->segment(4);
		  $quesid = $this->input->post('ques_id');
		  
          $data=array(
          'reply_id'=>$replyid,
		  'user_id'=>$u_id,
          'subreply'=>$this->input->post('subreply'.$replyid),
          'post_date'=>date('Y-m-d'),
          );
		  
          $status=$this->db->insert('reply_reply_master',$data);
		  
         //redirect('problems/answer/'.$q_id);
		 
		 redirect('details/show/'.$quesid);
        }
	 }
?>