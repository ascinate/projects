<?php
     //error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Fixes extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->helper('url');
        }

        public function index()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/fixes');
          $this->load->view('inc/modal2');
          $this->load->view('inc/footer');
        }
	 }
?>