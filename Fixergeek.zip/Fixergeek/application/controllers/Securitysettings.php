<?php
     //error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Securitysettings extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->helper('url');
		  $this->load->library('session');
        }

        public function index()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/securitysettings');
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
		
		public function block()
        {
		  $userid = $this->session->userdata('id');
		  $blockid = $this->uri->segment(3);
		  $this->db->insert("user_block_master", array('user_id'=>$userid, 'block_ids'=>$blockid));
		}
		
		public function unblock()
        {
		  $userid = $this->session->userdata('id');
		  $id = $this->uri->segment(3);
		  $this->db->where('id', $id);
		  $this->db->delete('user_block_master');
		}
		
	 }
?>