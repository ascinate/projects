<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Details extends CI_Controller
     {
        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->helper('url');
		  $this->load->helper('security');
          $this->load->model('admin_model');
		  $this->load->model('category_model');
        }

        public function show()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/details1');
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
		
		public function view()
		{
		  $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/ans_details');
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
		}
		
		public function testview()
		{
		  $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/details1-cut-sec');
		  $this->load->view('inc/modal');
          $this->load->view('inc/footer');
		}
		
        public function submitcomment()
        {
          $user_id = $this->input->post('user_id');
          $qus_id = $this->input->post('ques_id');
          $comment = $this->input->post('comment');
          $question = $this->db->get_where('questions_master',array('id'=>$qus_id))->row();
		  
          $data = array(
					  'user_id'=>$user_id,
					  'question_id'=>$qus_id,
					  'comments'=>$comment,
					  'post_date'=>date('Y-m-d'));
         
		  $status=$this->db->insert('comment_master',$data);
          
		  if($status)
          {
            echo "success";
          }
          else
		  {
            echo "Wrong";
          }
          // redirect('details/show/'.$qus_id);
        }
        ////////////////////////////////////
        public function submitreply()
        {
          $user_id=$this->input->post('user_id');
          $qus_id=$this->input->post('ques_id');
          $val= $this->input->post('comm_id');
          $reply=$this->input->post('reply');
         
          $question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
          $data=array(
          'user_id'=>$user_id,
          'question_id'=>$qus_id,
          'comment_id'=>$val,
          'reply'=>$reply,
          'post_date'=>date('Y-m-d'),
          );
          $status=$this->db->insert('reply_master',$data);
          // redirect('details/show/'.$qus_id);
          if($status)
          {
            echo"success";
          }
          else
		  {
            echo"Wrong";
          }
        }
        ///////////////////////////////
        public function submitcommentfromhome()
        {
          $user_id=$this->uri->segment(3);
          $qus_id=$this->uri->segment(4);
          $question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
          $data=array(
          'user_id'=>$user_id,
          'question_id'=>$qus_id,
          'comments'=>$this->input->post('comment'.$qus_id),
          'post_date'=>date('Y-m-d'),
          );
          $status=$this->db->insert('comment_master',$data);
          redirect('');
        }
        //////////////////////////////
        public function submitreplyfromhome()
        {
          $user_id=$this->uri->segment(3);
          $qus_id=$this->uri->segment(4);
          $val= $this->uri->segment(5);
          $question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
          $data=array(
          'user_id'=>$user_id,
          'question_id'=>$qus_id,
          'comment_id'=>$val,
          'reply'=>$this->input->post('reply'.$val),
          'post_date'=>date('Y-m-d'),
          );
          $status=$this->db->insert('reply_master',$data);
          redirect('/');
        }
        ///////////////////////////////////////
         public function submitcommentfromsearch()
        {
          $user_id=$this->uri->segment(3);
          $qus_id=$this->uri->segment(4);
          $url=$this->uri->segment(5);
          $question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
          $data=array(
          'user_id'=>$user_id,
          'question_id'=>$qus_id,
          'comments'=>$this->input->post('comment'.$qus_id),
          'post_date'=>date('Y-m-d'),
          );
          $status=$this->db->insert('comment_master',$data);
          redirect('category/show/'.$url);
        }
        //////////////////////////////
        public function submitcommentfromtopic()
        {
          $user_id=$this->uri->segment(3);
          $qus_id=$this->uri->segment(4);
          $url=$this->uri->segment(5);
          $question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
          $data=array(
          'user_id'=>$user_id,
          'question_id'=>$qus_id,
          'comments'=>$this->input->post('comment'.$qus_id),
          'post_date'=>date('Y-m-d'),
          );
          $status=$this->db->insert('comment_master',$data);
          redirect('details/topic/'.$url);
        }
        /////////////////////////////
        public function submitreplyfromsearch()
        {
          $user_id=$this->uri->segment(3);
          $qus_id=$this->uri->segment(4);
          $val= $this->uri->segment(5);
          $url= $this->uri->segment(6);
          $question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
          $data=array(
          'user_id'=>$user_id,
          'question_id'=>$qus_id,
          'comment_id'=>$val,
          'reply'=>$this->input->post('reply'.$val),
          'post_date'=>date('Y-m-d'),
          );
          $status=$this->db->insert('reply_master',$data);
           redirect('category/show/'.$url);
        }
        //////////////////////////////////////////
        public function submitreplyfromtopic()
        {
          $user_id=$this->uri->segment(3);
          $qus_id=$this->uri->segment(4);
          $val= $this->uri->segment(5);
          $url= $this->uri->segment(6);
          $question=$this->db->get_where('questions_master',array('id'=>$qus_id))->row();
          $data=array(
          'user_id'=>$user_id,
          'question_id'=>$qus_id,
          'comment_id'=>$val,
          'reply'=>$this->input->post('reply'.$val),
          'post_date'=>date('Y-m-d'),
          );
          $status=$this->db->insert('reply_master',$data);
          redirect('details/topic/'.$url);
        }
        ///////////////////////////////////////
        public function topic()
        {
          $topic = str_replace("_", " ", $this->uri->segment(3));
          $result['search'] = $this->admin_model->get_list($topic);
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/searchtopic',$result);
          $this->load->view('inc/modal2');
          $this->load->view('inc/footer');
        }
        //////////////////////////////////////////
        public function search()
        {
          $topic=$this->input->post('category');
         // $result['search'] = $this->admin_model->get_search_list($topic);
		 
		  $result['search'] = $this->category_model->get_list($topic);
		  
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          //$this->load->view('front/searchdetails',$result);
		  
		  $this->load->view('front/simple_html_dom');
          $this->load->view('front/searchfixes',$result);
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
        //////////////////////////////////////
      }
  ?>