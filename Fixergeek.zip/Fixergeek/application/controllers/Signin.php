<?php
     error_reporting(0);
     ob_start();
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Signin extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->model('user_model');
          $this->load->database();
          $this->load->library('session');
          $this->load->helper('url');
        }

        public function login_user()
        { 
          $geek = $this->input->post('geek_name');
          $pass = md5($this->input->post('password'));
		  
		  /*$geek = $this->uri->segment(3);
          $pass = md5($this->uri->segment(4));*/

          $query = $this->db->query("select * from `user_master`
                                     where geek_name = '".$geek."' OR `email`='".$geek."' 
                                     and password = '".$pass."'");

          //echo $this->db->last_query();

          if($query->num_rows() != 0)
           {
              $record = $query->row();

              $this->session->set_userdata('id', $record->id);
              $this->session->set_userdata('email', $record->email);
              $this->session->set_userdata('geek', $record->geek_name);
              $time=date("H:i:s");
              $this->db->set('login_time',$time);
              $this->db->set('logout_time',"");
              $this->db->set('status',"online");
              $this->db->where('id',$this->session->userdata('id'));
              $this->db->update('user_master');
               if($this->session->userdata('id')!="")
                {

                    $query = $this->db->query("select * from `fixergeek_master` where `user_id` = '".$this->session->userdata('id')."'");
                    $numrow = $query->num_rows();

                    if($numrow!=0)
                    {
                      redirect('fixeroverview');
                    }
                    else
                    {
                      redirect('askeroverview');
                    }

                   // redirect('hostaccountoverview');
                }
           } 
          
          else
          {
            redirect('/', 'refresh');
          }

        }

        public function user_logout()
        {
          $time=date("H:i:s");
          $this->db->set('logout_time',$time);
          $this->db->set('status',"offline");
          $this->db->where('id',$this->session->userdata('id'));
          $this->db->update('user_master');
          $this->session->sess_destroy();
          redirect('/', 'refresh');
        }
        ///////////////////////////
        public function oauth2callback(){
        $email=$this->input->post('email');
        $name=$this->input->post('f_name');
        $geek_name=$this->input->post('g_name');
               
        // echo $email;
        // exit();
        $this->db->like('email',$email);
        $check=$this->db->get_where('user_master');
        $che=$check->row();
        if($check->num_rows()!=0)
        {
              $this->session->set_userdata('id', $che->id);
              $this->session->set_userdata('email', $che->email);
              $this->session->set_userdata('geek', $che->geek_name);
              $time=date("H:i:s");
              $this->db->set('google_connect',"Yes");
              $this->db->set('login_time',$time);
              $this->db->set('logout_time',"");
              $this->db->set('status',"online");
              $this->db->where('id',$this->session->userdata('id'));
              $this->db->update('user_master');
               if($this->session->userdata('id')!="")
                {

                    $query = $this->db->query("select * from `fixergeek_master` where `user_id` = '".$this->session->userdata('id')."'");
                    $numrow = $query->num_rows();

                    if($numrow!=0)
                    {
                      // redirect('fixeroverview');
                      echo"fixeroverview";
                    }
                    else
                    {
                      // redirect('askeroverview');
                      echo"askeroverview";
                    }

                   // redirect('hostaccountoverview');
                }
           }
        else
        {   
        $otp=$this->generate_otp();
        $data=array(
        'profile_picture'=>'pngtree-user-avatar-boy-image_1482937.jpg',
        'geek_name'=>$geek_name,
        'name'=>$name,
        'email'=>$email,
        'password'=>md5($otp),
        'pass'=>$otp,
        'google_connect'=>'Yes',
        );
        $status=$this->db->insert('user_master',$data);
        $id=$this->db->insert_id();
        ///////////////////////////////
        $to = $this->input->post('email');
        $subject = "Fixer Geek - Registration Confirmation";

        $message = "
        <html>
        <body>
          <table>
            <tr>
              <td colspan='2'>
                <h3>Congratualation! You have successfully registered with FixerGeek.</h3> 
                <p>
                Name:".$name."<br>
                Geek Name:".$geek_name."<br>
                Email:".$email."<br>
                Password:".$otp."<br>
                </p> 
              </td>
            </tr>
          </table>
        </body>
        </html>
        ";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: <support@rbajsol.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
        /////////////////////////////

              $this->session->set_userdata('id', $id);
              $this->session->set_userdata('email', $email);
              $this->session->set_userdata('geek', $geek_name);
              $time=date("H:i:s");
              $this->db->set('login_time',$time);
              $this->db->set('logout_time',"");
              $this->db->set('status',"online");
              $this->db->where('id',$id);
              $this->db->update('user_master');
               if($this->session->userdata('id')!="")
                {

                    $query = $this->db->query("select * from `fixergeek_master` where `user_id` = '".$this->session->userdata('id')."'");
                    $numrow = $query->num_rows();

                    if($numrow!=0)
                    {
                      // redirect('fixeroverview');
                      echo"fixeroverview";
                    }
                    else
                    {
                      // redirect('askeroverview');
                      echo"askeroverview";
                    }

                   // redirect('hostaccountoverview');
                }
        /////////////////////////////         
        }
        }
        public function addmail()
        {
          $id=$this->input->post('id');
          $email=$this->input->post('email');
          $user=$this->db->get_where('user_master',array('id'=>$id))->row();
          if($user->email=='')
          {
            $mail=$email;
          }
          if($user->email!='')
          {
          $mail=$user->email.",".$email;
          }
          $m=explode(",", $user->email);
          // foreach ($m as $val) {
          //   if($val==$email)
          //   {
          //     echo"profile";
          //   }
          //    if($val!=$email)
          //   {
          //     echo"profile";
          //   }
          // }

          $this->db->set('email',$mail);
          $this->db->set('google_connect','Yes');
          $this->db->where('id',$id);
          $status=$this->db->update('user_master');
          echo"profile";
        }
        ////////////////////////////////
        private function generate_otp(int $length=6)
        {
        $otp="";
        $numbers="0s1a2n3j4a5y6r7o8y9";
        for($i=0;$i<$length;$i++)
        {
        $otp.=$numbers[rand(0,strlen($numbers)-1)];
        }
        return $otp;
        }
        //////////////////////////////////
        public function oauthfacebook()
        {
        $name=$this->input->post('f_name');
        $geek_name=$this->input->post('f_name').'_fixergeek';             
                
        $check=$this->db->get_where('user_master',array('geek_name'=>$geek_name));
        $che=$check->row();
        if($check->num_rows()!=0)
        {
              $this->session->set_userdata('id', $che->id);
              $this->session->set_userdata('email', $che->email);
              $this->session->set_userdata('geek', $che->geek_name);
              $time=date("H:i:s");
              $this->db->set('facebook_connect',"Yes");
              $this->db->set('login_time',$time);
              $this->db->set('logout_time',"");
              $this->db->set('status',"online");
              $this->db->where('id',$this->session->userdata('id'));
              $this->db->update('user_master');
               if($this->session->userdata('id')!="")
                {

                    $query = $this->db->query("select * from `fixergeek_master` where `user_id` = '".$this->session->userdata('id')."'");
                    $numrow = $query->num_rows();

                    if($numrow!=0)
                    {
                      // redirect('fixeroverview');
                      echo"fixeroverview";
                    }
                    else
                    {
                      // redirect('askeroverview');
                      echo"askeroverview";
                    }

                   // redirect('hostaccountoverview');
                }
           }
        else
        {   
        $otp=$this->generate_otp();
        $data=array(
        'profile_picture'=>'pngtree-user-avatar-boy-image_1482937.jpg',
        'geek_name'=>$geek_name,
        'name'=>$name,
        'email'=>"",
        'password'=>md5($otp),
        'pass'=>$otp,
        'facebook_connect'=>'Yes',
        );
        $status=$this->db->insert('user_master',$data);
        $id=$this->db->insert_id();
        ///////////////////////////////
        $to = $this->input->post('email');
        $subject = "Fixer Geek - Registration Confirmation";

        $message = "
        <html>
        <body>
          <table>
            <tr>
              <td colspan='2'>
                <h3>Congratualation! You have successfully registered with FixerGeek.</h3>
                <p>
                Name:".$name."<br>
                Geek Name:".$geek_name."<br>
                Password:".$otp."<br>
                </p> 
              </td>
            </tr>
          </table>
        </body>
        </html>
        ";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: <support@rbajsol.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
        /////////////////////////////

              $this->session->set_userdata('id', $id);
              $this->session->set_userdata('email', "");
              $this->session->set_userdata('geek', $geek_name);
              $time=date("H:i:s");
              $this->db->set('login_time',$time);
              $this->db->set('logout_time',"");
              $this->db->set('status',"online");
              $this->db->where('id',$id);
              $this->db->update('user_master');
               if($this->session->userdata('id')!="")
                {

                    $query = $this->db->query("select * from `fixergeek_master` where `user_id` = '".$this->session->userdata('id')."'");
                    $numrow = $query->num_rows();

                    if($numrow!=0)
                    {
                      // redirect('fixeroverview');
                      echo"fixeroverview";
                    }
                    else
                    {
                      // redirect('askeroverview');
                      echo"askeroverview";
                    }

                   // redirect('hostaccountoverview');
                }
        /////////////////////////////         
        }
        }
        //////////////////////////////////
     }
  ?>