<?php
     //error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Supporterspodium extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->helper('url');
        }

        public function index()
        {
          $this->load->view('includes/top-header-3');
          $this->load->view('includes/header');
          $this->load->view('front/supporterspodium');
          $this->load->view('includes/modal');
          $this->load->view('includes/footer-6');
        }
	 }
?>