<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Comments extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->model('comments_model');
          $this->load->database();
          $this->load->helper('url');
        }

        public function show($id)
        {
		  $id = $this->uri->segment(5);
          $result['comments'] = $this->comments_model->get_comments_list($id);

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/comments',$result);
          $this->load->view('administrator/includes/footer');
        }

        public function add()
        {
          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/addcomments');
          $this->load->view('administrator/includes/footer');
        }

        public function insertcomments()
        {
		  $qid = $this->input->post('question_id');
		  $aid = $this->input->post('answer_id');
		  
          $data = array('user_id'=>$this->input->post('user_id'),
		  				'answer_id'=> $this->input->post('answer_id'),
                        'question_id'=> $this->input->post('question_id'),
                        'comment'=> $this->input->post('comments'),
						'post_date'=> date('Y-m-d')
                      );
                      
          
          $query = $this->comments_model->comments_insert($data);
          redirect('admin/comments/show/'.$qid.'/'.$aid, 'refresh');
        }

        public function editquestion()
        {
          $id = $this->uri->segment(4);
          $result = $this->question_model->get_question_data($id);

          if($result)
          {
            $data['questions'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/editquestion',$data);
          $this->load->view('administrator/includes/footer');
        }
		
        public function list()
        {
         $id = $this->uri->segment(4);
          $result = $this->comments_model->get_comments_data($id);

          if($result)
          {
            $data['comments'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/viewcomments',$data);
          $this->load->view('administrator/includes/footer');
        }
		
        public function updatequestion()
        {
          $id = $this->input->post('id');
          $data = $data = array('user_id'=> $this->input->post('user_id'),
								'category_name'=> $this->input->post('category_name'),
								'topics'=> $this->input->post('topics'),
								'question'=> $this->input->post('question'),
								'content'=> $this->input->post('content'),
								'uploaded_files'=> $this->input->post('uploaded_files'),
								'post_date'=> date('Y-m-d'));
          
          $query = $this->question_model->update_question($id, $data);
          redirect('admin/questions', 'refresh');
        }

        public function deletecomments()
        {
          $id = $this->uri->segment(4);
          $query = $this->comments_model->deletecomments($id);
          redirect('admin/comments/show/'.$this->uri->segment(5), 'refresh');
        }

         /////////////// Ajax Call sub category ///////////////


     }
  ?>