<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Topics extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->model('admin_model');
          $this->load->database();
          $this->load->helper('url');
        }

        public function index()
        {
          $result['topics'] = $this->admin_model->get_topic_list();

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/topics',$result);
          $this->load->view('administrator/includes/footer');
        }

        public function addtopic()
        {
          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/addtopic');
          $this->load->view('administrator/includes/footer');
        }

        public function inserttopic()
        {
          $data = array('topic'=> $this->input->post('topic'));
          
          $query = $this->admin_model->topic_insert($data);
          redirect('admin/topics', 'refresh');
        }

        public function edittopic()
        {
          $id = $this->uri->segment(4);
          $result = $this->admin_model->get_topic_data($id);

          if($result)
          {
            $data['topics'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/edittopic',$data);
          $this->load->view('administrator/includes/footer');
        }

        public function updatetopic()
        {
          $id = $this->input->post('id');
          $data = array('topic'=> $this->input->post('topic'));
          
          $query = $this->admin_model->update_topic($id, $data);
          redirect('admin/topics', 'refresh');
        }

        public function deletetopic()
        {
          $id = $this->uri->segment(4);
          
          $query = $this->admin_model->delete_topic($id);
          redirect('admin/topics', 'refresh');
        }


     }
  ?>