<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Dashboard extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->model('admin_model');
          $this->load->database();
          $this->load->helper('url');
        }

        public function index()
        {
          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/dashboard');
          $this->load->view('administrator/includes/footer');
        }

        ///////////////////////// Category ////////////////////////

        public function category()
        {
          $result['category'] = $this->admin_model->get_cat_list();

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/category',$result);
          $this->load->view('administrator/includes/footer');
        }

        public function addcategory()
        {
          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/addcategory');
          $this->load->view('administrator/includes/footer');
        }

        public function updatecatorder()
        {
            $position = $this->input->post('position');

            $i=1;
            foreach($position as $k=>$v){

              $sql = $this->db->query("Update `category_master` SET ordering = ".$i." WHERE id=".$v);

              $i++;
          }
        }

        public function insertcat()
        {
          $data = array('category_name'=> $this->input->post('cat_name'));
          
          $query = $this->admin_model->cat_insert($data);
          redirect('admin/dashboard/category', 'refresh');
        }

        public function editcategory()
        {
          $id = $this->uri->segment(4);
          $result = $this->admin_model->get_cat_data($id);

          if($result)
          {
            $data['category'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/editcategory',$data);
          $this->load->view('administrator/includes/footer');
        }

        public function updatecat()
        {
          $id = $this->input->post('id');
          $data = array('category_name'=> $this->input->post('cat_name'));
          
          $query = $this->admin_model->update_cat($id, $data);
          redirect('admin/dashboard/category', 'refresh');
        }

        public function deletecat()
        {
          $id = $this->uri->segment(4);
          
          $query = $this->admin_model->delete_cat($id);
          redirect('admin/dashboard/category', 'refresh');
        }

        //////////////////////// Sub Category //////////////////////

        public function subcategory()
        {
          $result['subcategory'] = $this->admin_model->get_subcat_list();

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/subcategory',$result);
          $this->load->view('administrator/includes/footer');
        }

        public function addsubcategory()
        {
          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/addsubcategory');
          $this->load->view('administrator/includes/footer');
        }

        public function insertsubcat()
        {
          $data = array('cat_id'=> $this->input->post('cat_name'),
                        'sub_category_name'=> $this->input->post('subcat_name'));
          
          $query = $this->admin_model->subcat_insert($data);
          redirect('admin/dashboard/subcategory', 'refresh');
        }

        public function editsubcategory()
        {
          $id = $this->uri->segment(4);
          $result = $this->admin_model->get_subcat_data($id);

          if($result)
          {
            $data['subcategory'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/editsubcategory',$data);
          $this->load->view('administrator/includes/footer');
        }

        public function updatesubcat()
        {
          $id = $this->input->post('id');
          $data = array('cat_id'=> $this->input->post('cat_name'),
                        'sub_category_name'=> $this->input->post('subcat_name'));
          
          $query = $this->admin_model->update_subcat($id, $data);
          redirect('admin/dashboard/subcategory', 'refresh');
        }

        public function deletesubcat()
        {
          $id = $this->uri->segment(4);
          
          $query = $this->admin_model->delete_subcat($id);
          redirect('admin/dashboard/subcategory', 'refresh');
        }

        //////////////////////// Sub Sub Category //////////////////////

        public function subsubcategory()
        {
          $result['subsubcategory'] = $this->admin_model->get_subsubcat_list();

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/subsubcategory',$result);
          $this->load->view('administrator/includes/footer');
        }

        public function addsubsubcategory()
        {
          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/addsubsubcategory');
          $this->load->view('administrator/includes/footer');
        }

        public function insertsubsubcat()
        {
          $data = array('cat_id'=> $this->input->post('cat_name'),
                        'sub_cat_id'=> $this->input->post('subcat_name'),
                        'sub_sub_category_name'=> $this->input->post('subsubcat_name'));
          
          $query = $this->admin_model->subsubcat_insert($data);
          redirect('admin/dashboard/subsubcategory', 'refresh');
        }

        public function editsubsubcategory()
        {
          $id = $this->uri->segment(4);
          $result = $this->admin_model->get_subsubcat_data($id);

          if($result)
          {
            $data['subsubcategory'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/editsubsubcategory',$data);
          $this->load->view('administrator/includes/footer');
        }

        public function updatesubsubcat()
        {
          $id = $this->input->post('id');
          $data = array('cat_id'=> $this->input->post('cat_name'),
                        'sub_cat_id'=> $this->input->post('subcat_name'),
                        'sub_sub_category_name'=> $this->input->post('subsubcat_name'));
          
          $query = $this->admin_model->update_subsubcat($id, $data);
          redirect('admin/dashboard/subsubcategory', 'refresh');
        }

        public function deletesubsubcat()
        {
          $id = $this->uri->segment(4);
          
          $query = $this->admin_model->delete_subsubcat($id);
          redirect('admin/dashboard/subsubcategory', 'refresh');
        }

        /////////////// Ajax Call sub category ///////////////

        public function showsubcat()
        {
            $id = $this->uri->segment(4);

            $query = $this->db->query("select * from `sub_category_master` where cat_id ='".$id."'");  
            foreach($query->result() as $res)
            {
        ?>
            <option value="<?=$res->id?>"><?=$res->sub_category_name?></option>
        <?php
            }
        }
     }
  ?>