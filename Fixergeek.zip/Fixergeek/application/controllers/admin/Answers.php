<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Answers extends CI_Controller
     {
        public function __construct()
        {
          parent::__construct();
          $this->load->model('answer_model');
          $this->load->database();
          $this->load->helper('url');
        }

        public function lists()
        {
          $qid = $this->uri->segment(4);
          $result['answers'] = $this->answer_model->get_answer_list($qid);

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/answers',$result);
          $this->load->view('administrator/includes/footer');
        }

        public function add()
        {
          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/addanswer');
          $this->load->view('administrator/includes/footer');
        }

        public function insertanswer()
        {
          $qid = $this->input->post('q_id');
          $question=$this->db->get_where('questions_master',array('id'=>$qid))->row();
          if($_FILES['image']['name']!='')
          {
          $upload_dir= 'uploads/';
          $temp_error = $_FILES['image']['error'];

          $file_name  = time().'_'.$_FILES['image']['name']; 
          $tmp_name   = $_FILES['image']['tmp_name'];
          $file_size  = $_FILES['image']['size'];

          move_uploaded_file($tmp_name,$upload_dir.$file_name);
          }else
          {
            $file_name="";
          }
         

          $data = array('user_id'=> $this->input->post('user_id'),
          'question_id'=> $qid,
          'sub_sub_cat_id'=>$question->sub_sub_cat_id,
          'answer'=> $this->input->post('answer'),
          'image'=>$file_name,
          'level'=> $this->input->post('level'),
          'post_date'=> date('Y-m-d'));
          
          $query = $this->answer_model->answer_insert($data);
          $check=$this->db->get_where('answers_master',array('sub_sub_cat_id'=>$question->sub_sub_cat_id,'level'=>'Approved','user_id'=>$this->input->post('user_id')));
          if($check->num_rows()>=3)
          {
            $check2=$this->db->get_where('fixergeek_master',array('user_id'=>$this->input->post('user_id'),'sub_sub_cat_id'=>$question->sub_sub_cat_id));
            $ch=$check2->row();
            if($check2->num_rows()==0)
            {
              $data2=array(
              'sub_sub_cat_id'=>$question->sub_sub_cat_id,
              'user_id'=>$this->input->post('user_id'),
              'level'=>1,
              );
              $status=$this->db->insert('fixergeek_master',$data2);
            }
            if($check2!=0)
            {
              $data2=array(
              'sub_sub_cat_id'=>$question->sub_sub_cat_id,
              'user_id'=>$this->input->post('user_id'),
              'level'=>1,
              );
            
              $this->db->where('id',$ch->id);
              $status=$this->db->update('fixergeek_master',$data2);
            }
          }
          

          redirect('admin/answers/lists/'.$qid, 'refresh');
        }

        public function editanswer()
        {
          $id = $this->uri->segment(5);
          $result = $this->answer_model->get_answer_data($id);

          if($result)
          {
            $data['answers'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/editanswer',$data);
          $this->load->view('administrator/includes/footer');
        }
		
		public function viewanswer()
        {
          $id = $this->uri->segment(5);
          $result = $this->answer_model->get_answer_data($id);

          if($result)
          {
            $data['answers'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/viewanswer',$data);
          $this->load->view('administrator/includes/footer');
        }

        public function update()
        {
          $id = $this->input->post('id');
          $qid = $this->input->post('qid');
          $question=$this->db->get_where('questions_master',array('id'=>$qid))->row();
          $ans=$this->db->get_where('answers_master',array('id'=>$id))->row();
		  
          /*if($_FILES['image']['name']!='')
          {
          $upload_dir= 'uploads/';
          $temp_error = $_FILES['image']['error'];

          $file_name  = time().'_'.$_FILES['image']['name']; 
          $tmp_name   = $_FILES['image']['tmp_name'];
          $file_size  = $_FILES['image']['size'];

          move_uploaded_file($tmp_name,$upload_dir.$file_name);
          } 
          else
          {
            $file_name=$ans->image;
          }*/
          

           $data = array(
            'user_id'=> $this->input->post('user_id'),
            'answer'=> addslashes($this->input->post('answer')),
            'level'=>  $this->input->post('level'));
          
          $query = $this->answer_model->update_answer($id, $data);
		  
          $check = $this->db->get_where('answers_master',
		  								array('sub_sub_cat_id'=>$question->sub_sub_cat_id,
		  									  'level'=>'Approved',
											  'user_id'=>$this->input->post('user_id')));
         
		  if($check->num_rows()!=0)
          {
           // $check2=$this->db->get_where('fixergeek_master',array('user_id'=>$this->input->post('user_id'),'sub_sub_cat_id'=>$question->sub_sub_cat_id));
			
			$check2 = $this->db->get_where('fixergeek_master', array('user_id' => $this->input->post('user_id')));
            $ch=$check2->row();
			
            if($check2->num_rows()==0)
            {
              $data2=array(
              'sub_sub_cat_id'=>$question->sub_sub_cat_id,
              'user_id'=>$this->input->post('user_id'),
              'level'=>1,
              );
			  
              $status=$this->db->insert('fixergeek_master',$data2);
            }
			
            if($check2->num_rows()!=0)
            {
			  $ex_cat = $ch->sub_sub_cat_id;
			  
			  $arr = explode(",",$ex_cat);
			  
			  if(in_array($question->sub_sub_cat_id , $arr))
			  {
			     $cat_ids = $ex_cat;
			  }
			  
			  else
			  {
			    $cat_ids = $ex_cat.",".$question->sub_sub_cat_id;
			  }
			  
              $data2=array(
              'sub_sub_cat_id'=> $cat_ids,
              'user_id'=>$this->input->post('user_id'),
              'level'=>1,
              );
            
              $this->db->where('id',$ch->id);
              $status=$this->db->update('fixergeek_master',$data2);
			  
			  //echo $this->db->last_query();  exit();
            }
			
          }
         
          redirect('admin/answers/lists/'.$qid, 'refresh');
        }

        public function deleteanswer()
        {
          $qid = $this->uri->segment(4);
          $id = $this->uri->segment(5);
          $query = $this->answer_model->delete_answer($id);
          redirect('admin/answers/lists/'.$qid, 'refresh');
        }

         /////////////// Ajax Call sub category ///////////////

        public function showsubcat()
        {
            $id = $this->uri->segment(4);

            $query = $this->db->query("select * from `sub_category_master` where cat_id ='".$id."'");  
            foreach($query->result() as $res)
            {
        ?>
            <option value="<?=$res->id?>"><?=$res->sub_category_name?></option>
        <?php
            }
        }

     }
  ?>