<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Questions extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->model('question_model');
          $this->load->database();
          $this->load->helper('url');
        }

        public function index()
        {
          $result['questions'] = $this->question_model->get_question_list();

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/questions',$result);
          $this->load->view('administrator/includes/footer');
        }

        public function add()
        {
          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/addquestion');
          $this->load->view('administrator/includes/footer');
        }

        public function insertquestion()
        {
            if($_FILES['uploaded_files']['name']) 
            {
             $filename = time()."_".$_FILES['uploaded_files']['name'];
            }
            else
            { 
              $filename = ""; 
            }

            $data = array('user_id'=> 'Admin',
                        'category_name'=> $this->input->post('cat_name'),
						'sub_cat_id'=> $this->input->post('subcat_name'),
						'sub_sub_cat_id'=> $this->input->post('sub_sub_catname'),
                        'question'=> $this->input->post('question'),
                        'post_date'=> date('Y-m-d'));

       /*  $target_path = "uploads/";  
         $target_path = $target_path.basename($filename); 
    
        move_uploaded_file($_FILES['uploaded_files']['tmp_name'], $target_path);*/
          
          $query = $this->question_model->question_insert($data);
		 // echo $this->db->last_query();
          redirect('admin/questions', 'refresh');
        }

        public function editquestion()
        {
          $id = $this->uri->segment(4);
          $result = $this->question_model->get_question_data($id);

          if($result)
          {
            $data['questions'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/editquestion',$data);
          $this->load->view('administrator/includes/footer');
        }
		
        public function list()
        {
         $id = $this->uri->segment(4);
          $result = $this->question_model->get_question_data($id);

          if($result)
          {
            $data['questions'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/viewquestion',$data);
          $this->load->view('administrator/includes/footer');
        }
        public function updatequestion()
        {
          $id = $this->input->post('id');
          $qus=$this->db->get_where('questions_master',array('id'=>$id))->row();
          /*if($_FILES['uploaded_files']['name']) 
            {
             $filename = time()."_".$_FILES['uploaded_files']['name'];
            }
            else
            { 
              $filename = $qus->uploaded_files; 
            }*/

          $data = array('user_id'=> 'Admin',
                        'category_name'=> $this->input->post('cat_name'),
                        'sub_cat_id'=> $this->input->post('subcat_name'),
                        'sub_sub_cat_id'=> $this->input->post('sub_sub_catname'),
                        'question'=> $this->input->post('question'),
                        'post_date'=> date('Y-m-d'));

         
          $this->db->where('id',$id);
          $query = $this->db->update('questions_master',$data);
          redirect('admin/questions', 'refresh');
        }

        public function deletequestion()
        {
          $id = $this->uri->segment(4);
          
          $query = $this->question_model->delete_question($id);
          redirect('admin/questions', 'refresh');
        }

         /////////////// Ajax Call sub category ///////////////

        public function showsubcat()
        {
            $id = $this->uri->segment(4);

            $query = $this->db->query("select * from `sub_category_master` where cat_id ='".$id."'");  
            foreach($query->result() as $res)
            {
        ?>
            <option value="<?=$res->id?>"><?=$res->sub_category_name?></option>
        <?php
            }
        }
         public function showsubsubcat()
        {
            $id = $this->uri->segment(4);

            $query = $this->db->query("select * from `sub_sub_category_master` where sub_cat_id ='".$id."'");  
            foreach($query->result() as $res)
            {
        ?>
            <option value="<?=$res->id?>"><?=$res->sub_sub_category_name?></option>
        <?php
            }
        }

     }
  ?>