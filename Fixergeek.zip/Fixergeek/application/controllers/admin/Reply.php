<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Reply extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->model('reply_model');
          $this->load->database();
          $this->load->helper('url');
        }

        public function show($id)
        {
          $result['reply'] = $this->reply_model->get_reply_list($id);

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/reply',$result);
          $this->load->view('administrator/includes/footer');
        }

        public function add()
        {
          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/addreply');
          $this->load->view('administrator/includes/footer');
        }

        public function insertreply()
        {
          $com=$this->db->get_where('comment_master',array('id'=>$this->input->post('comment_id')))->row();
          $data = array(
          'comment_id'=>$this->input->post('comment_id'),
          'user_id'=>$com->user_id,
          'question_id'=> $com->question_id,
          'reply'=> $this->input->post('reply'),
          );
                      
          
          $query = $this->reply_model->reply_insert($data);
          redirect('admin/reply/show/'.$this->input->post('comment_id'), 'refresh');
        }

        public function list()
        {
         $id = $this->uri->segment(4);
          $result = $this->reply_model->get_reply_data($id);

          if($result)
          {
            $data['reply'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/viewreply',$data);
          $this->load->view('administrator/includes/footer');
        }
     

        public function deletereply()
        {
          $id = $this->uri->segment(4);
          
          $query = $this->reply_model->deletereply($id);
          redirect('admin/reply/show/'.$this->uri->segment(5), 'refresh');
        }

         /////////////// Ajax Call sub category ///////////////


     }
  ?>