<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Cms extends CI_Controller
     {
        public function __construct()
        {
          parent::__construct();
          $this->load->database();
		  $this->load->helper('security');
		  $this->load->model('cms_model');
          $this->load->helper('url');
        }
		
        public function show()
        {
          $id = $this->uri->segment(4);
          $result = $this->cms_model->get_cms_data($id);

          if($result)
          {
            $data['cms'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/cms',$data);
          $this->load->view('administrator/includes/footer');
        }
		
		public function updatecms()
        {
          $id = $this->uri->segment(4);
          $data = array('content'=> addslashes($this->input->post('content')));
          
          $query = $this->cms_model->update_cms($id, $data);
          redirect('admin/cms/show/'.$id, 'refresh');
        }

         /////////////// Ajax Call sub category ///////////////


     }
  ?>