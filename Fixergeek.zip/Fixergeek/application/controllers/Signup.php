<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Signup extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->helper('url');
          $this->load->model('admin_model');
        }

        public function index()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/signup');
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
        
        public function insertuser()
        {
          $geek = $this->input->post('geek_name');
          $email = $this->input->post('email');

          $query = $this->db->query("select * from `user_master`
                                     where `geek_name` = '".$geek."' OR `email` = '".$email."'");

          if($query->num_rows() == 0)
          {
	         /* if($_FILES['profile_picture']['name']) 
			  {
			   $filename = time()."_".$_FILES['profile_picture']['name'];
			  }
			  else
			  { 
			  	$filename = ""; 
			  } */

			  $dob = $this->input->post('year').'-'.$this->input->post('month').'-'.$this->input->post('days');

			  $data = array(
			  'geek_name'=>$this->input->post('geek_name'),
			  'email'=>$this->input->post('email'),
			  'name'=>$this->input->post('name'),
			  'password'=>md5($this->input->post('password')),
			  'date_of_birth'=>$dob,
			  'gender'=> $this->input->post('gender'),
			  'profile_picture'=>$this->input->post('profile_picture'),
			  'phone'=>$this->input->post('phone'),
			  'country'=>$this->input->post('country'),
			  'qualification'=>$this->input->post('qualification'));

			  /*$target_path = "uploads/";  
			  $target_path = $target_path.basename($filename); 
			
			  move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_path);*/
			
			 ///////////////////// Model Call /////////////////
			  $insert = $this->admin_model->user_insert($data);
			  $lastid = $this->db->insert_id();

			  if($lastid!="")
			  {
			      $signin = $this->db->query("select * from `user_master`
										   where geek_name = '".$this->input->post('geek_name')."' 
										   and password = '".md5($this->input->post('password'))."'");
				
				  $record = $signin->row();
				  //echo $this->db->last_query();  exit;
				  
				  $this->session->set_userdata('id', $record->id);
				  $this->session->set_userdata('email', $record->email);
				  $this->session->set_userdata('geek', $record->geek_name);
				  $time=date("H:i:s");
				  $this->db->set('login_time',$time);
				  $this->db->set('logout_time',"");
				  $this->db->set('status',"online");
				  $this->db->where('id',$this->session->userdata('id'));
				  $this->db->update('user_master');
				  
				  redirect('askeroverview', 'refresh');
				  
				   /*if($this->session->userdata('id')!="")
					{
						/*$to = $this->input->post('email');
						$subject = "Fixer Geek - Registration Confirmation";
		
						$message = "
						<html>
						<body>
							<table>
								<tr>
									<td colspan='2'>
									  <h3>Congratualation! You have successfully registered with FixerGeek.</h3> Click here to login.
									</td>
								</tr>
							</table>
						</body>
						</html>
						";
						// Always set content-type when sending HTML email
						$headers = "MIME-Version: 1.0" . "\r\n";
						$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		
						// More headers
						$headers .= 'From: <support@rbajsol.com>' . "\r\n";
		
						mail($to,$subject,$message,$headers);
				   }*/
			  }

		  }

		  else
		  {
		  	$this->session->set_flashdata('err','Geek name or Email already exist!');
		  	redirect('signup', 'refresh');
		  }
        }
		
	  public function validate()
	  {
	      $geek = $this->uri->segment(3);
         //$email = $this->input->post('email');

          $query = $this->db->query("select * from `user_master`
                                     where `geek_name` = '".$geek."'");
									 
		  if($query->num_rows()!= 0)
          {
		    echo 'Geek name already exist!';
		  }
		  
	  }
	  
	  public function validateemail()
	  {
	      $email = $this->input->get('mail');
         //$email = $this->input->post('email');

          $query = $this->db->query("select * from `user_master` where `email` = '".$email."'");
		  //echo $this->db->last_query();	
		  					 
		  if($query->num_rows()!= 0)
          {
		    echo 'Email address already exist!';
		  }
		  
	  }

    }
  ?>