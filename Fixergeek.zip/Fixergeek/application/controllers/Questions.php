<?php
     //error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Questions extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->model('admin_model');
          $this->load->database();
          $this->load->helper('url');
        }

        public function index()
        {
          $result['questions'] = $this->admin_model->get_questions_list();

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/questions',$result);
          $this->load->view('administrator/includes/footer');
        }

        public function addquestion()
        {
          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/addquestion');
          $this->load->view('administrator/includes/footer');
        }

        public function insertquestion()
        {
          $data = array('user_id'=> $this->input->post('user_id'),
                        'category_name'=> $this->input->post('category_name'),
                        'topics'=> $this->input->post('topics'),
                        'question'=> $this->input->post('question'),
                        'content'=> $this->input->post('content'),
                        'uploaded_files'=> $this->input->post('uploaded_files'),
                        'post_date'=> date('Y-m-d'));
          
          $query = $this->admin_model->question_insert($data);
          redirect('admin/questions', 'refresh');
        }

        public function editquestion()
        {
          $id = $this->uri->segment(4);
          $result = $this->admin_model->get_question_data($id);

          if($result)
          {
            $data['questions'] =  $result;
          }

          $this->load->view('administrator/includes/top-header');
          $this->load->view('administrator/includes/header');
          $this->load->view('administrator/includes/sidebar');
          $this->load->view('administrator/viewquestion',$data);
          $this->load->view('administrator/includes/footer');
        }

        public function updatequestion()
        {
          $id = $this->input->post('id');
          $data = $data = array('user_id'=> $this->input->post('user_id'),
                        'category_name'=> $this->input->post('category_name'),
                        'topics'=> $this->input->post('topics'),
                        'question'=> $this->input->post('question'),
                        'content'=> $this->input->post('content'),
                        'uploaded_files'=> $this->input->post('uploaded_files'),
                        'post_date'=> date('Y-m-d'));
          
          $query = $this->admin_model->update_question($id, $data);
          redirect('admin/questions', 'refresh');
        }

        public function deletequestion()
        {
          $id = $this->uri->segment(4);
          
          $query = $this->admin_model->delete_question($id);
          redirect('admin/questions', 'refresh');
        }


     }
  ?>