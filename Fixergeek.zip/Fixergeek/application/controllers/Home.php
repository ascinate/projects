<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Home extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->helper('url');
          $this->load->library('session');
		  $this->load->helper('security');
        }

        public function index()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/simple_html_dom');
          $this->load->view('front/home');
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
		
		public function test()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
		  $this->load->view('front/simple_html_dom');
          $this->load->view('front/home_1');
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
		
		public function getcontent()
        {
          $this->load->view('front/viewcontent');
        }
		
        public function login()
        { 
          /*$geek = $this->input->post('user_name');
          $pass = md5($this->input->post('password'));*/
		  
		  $geek = $this->uri->segment(3);
          $pass = md5($this->uri->segment(4));

          $query = $this->db->query("select * from `user_master`
                                     where geek_name = '".$geek."' OR `email`='".$geek."' 
                                     and password = '".$pass."'");

          //echo $this->db->last_query();

          if($query->num_rows() != 0)
           {
              $record = $query->row();

              $this->session->set_userdata('id', $record->id);
              $this->session->set_userdata('email', $record->email);
              $this->session->set_userdata('geek', $record->geek_name);
			  
			  $time=date("H:i:s");
              $this->db->set('login_time',$time);
              $this->db->set('logout_time',"");
              $this->db->set('status',"online");
              $this->db->where('id',$this->session->userdata('id'));
              $this->db->update('user_master');

               if($this->session->userdata('id')!="")
                {
				  echo $this->session->userdata('id');
                  //echo "success"; exit();
                }
           } 
          
          else
          {
           echo "Wrong";
          }

        }
	 }
?>