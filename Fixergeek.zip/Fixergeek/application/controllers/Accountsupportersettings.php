<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Accountsupportersettings extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->helper('url');
        }

        public function index()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/accountsupportersettings');
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
        ////////////////////////////////////
        public function updatestart_time()
        {
          $id=$this->input->post('id');
          $start_time=$this->input->post('start_time');
          // $end_time= $this->input->post('end_time');
          // $days=implode(",",$this->input->post('days'));
          // $timezone=$this->input->post('timezone');
         
          $data=array(
          'start_time'=>$start_time,
          );
          $this->db->where('id',$id);
          $status=$this->db->update('user_master',$data);
          // redirect('details/show/'.$qus_id);
          if($status)
          {
            $this->db->where('user_id',$id);
            $status=$this->db->update('fixergeek_master',$data);
            echo"success";
          }
          else{
            echo"Wrong";
          }
        }
         ////////////////////////////////////
        public function updateend_time()
        {
          $id=$this->input->post('id');
          $end_time= $this->input->post('end_time');
         
          $data=array(
          'end_time'=>$end_time,
          );
          $this->db->where('id',$id);
          $status=$this->db->update('user_master',$data);
          // redirect('details/show/'.$qus_id);
          if($status)
          {
            $this->db->where('user_id',$id);
            $status=$this->db->update('fixergeek_master',$data);
            echo"success";
          }
          else{
            echo"Wrong";
          }
        }
          ////////////////////////////////////
        public function updatetimezone()
        {
          $id=$this->input->post('id');
          $timezone= $this->input->post('timezone');
         
          $data=array(
          'timezone'=>$timezone,
          );
          $this->db->where('id',$id);
          $status=$this->db->update('user_master',$data);
          // redirect('details/show/'.$qus_id);
          if($status)
          {
            $this->db->where('user_id',$id);
            $status=$this->db->update('fixergeek_master',$data);
            echo"success";
          }
          else{
            echo"Wrong";
          }
        }
             ////////////////////////////////////
        public function updatedays()
        {
          $id=$this->input->post('id');
          $days=$this->input->post('days');
         
          $data=array(
          'available_days'=>$days,
          );
          $this->db->where('id',$id);
          $status=$this->db->update('user_master',$data);
          // redirect('details/show/'.$qus_id);
          if($status)
          {
            $this->db->where('user_id',$id);
            $status=$this->db->update('fixergeek_master',$data);
            echo"success";
          }
          else{
            echo"Wrong";
          }
        }
	 }
?>