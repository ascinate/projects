<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Category extends CI_Controller
     {
        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->model('category_model');
          $this->load->helper('url');
          $this->load->library('session');
        }
        public function index()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/fixes');
          $this->load->view('inc/modal2');
          $this->load->view('inc/footer');
        }
        public function show()
        {
          $cat = $this->uri->segment(3);
          $result['search'] = $this->category_model->get_list($cat);
		  
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
		  $this->load->view('front/simple_html_dom');
          $this->load->view('front/searchfixes',$result);
          $this->load->view('inc/modal2');
          $this->load->view('inc/footer');
        }
	 }
?>