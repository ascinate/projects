<?php
     //error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Privacy extends CI_Controller
     {
        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->helper('url');
        }

        public function index()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/privacy');
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
	 }
?>