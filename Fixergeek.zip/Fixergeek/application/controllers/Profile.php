<?php
     error_reporting(0);
     if(!defined('BASEPATH')) exit('No direct script access allowed');
   
     class Profile extends CI_Controller
     {

        public function __construct()
        {
          parent::__construct();
          $this->load->database();
          $this->load->model('user_model');
          $this->load->helper('url');
          $this->load->library('session');
        }

        public function index()
        {
          $id = $this->session->userdata('id');
          $result = $this->user_model->get_user_data($id);

          if($result)
          {
            $data['profile'] =  $result;
          }

          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/profile',$data);
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
        ////////////////////////////////////////////

        public function editownprofile()
        {
          $id = $this->session->userdata('id');
          $user=$this->db->get_where('user_master',array('id'=>$id))->row();

          $geek = $this->input->post('geek_name');
          $email = $this->input->post('email');

          $query = $this->db->query("select * from `user_master`
          where `geek_name` = '".$geek."' AND `id` = '".$id."'");
          $qry = $this->db->query("select * from `user_master`
          where `email` like '".$email."' AND `id` = '".$id."'");

          if($query->num_rows() != 0 && $qry->num_rows() !=0)
          {
          
          /*if($_FILES['profile_picture']['name']!='') 
          {
            $upload_dir= 'uploads/';
            $temp_error = $_FILES['profile_picture']['error'];

            $file_name  = time().'_'.$_FILES['profile_picture']['name']; 
            $tmp_name   = $_FILES['profile_picture']['tmp_name'];
            $file_size  = $_FILES['profile_picture']['size'];

            move_uploaded_file($tmp_name,$upload_dir.$file_name);
          }
          else
          { 
          $file_name = $user->profile_picture; 
          }*/

          $dob = $this->input->post('year').'-'.$this->input->post('month').'-'.$this->input->post('day');

          $data = array(
          'geek_name'=>$this->input->post('geek_name'),
          'email'=>$this->input->post('email'),
          'name'=>$this->input->post('name'),
          'date_of_birth'=>$dob,
          'gender'=> $this->input->post('gender'),
          'profile_picture'=> $this->input->post('profile_picture'),
          'phone'=>$this->input->post('phone'),
          'country'=>$this->input->post('country'),
          'qualification'=>$this->input->post('qualification'),
          'about_me'=>$this->input->post('about_me'),
           );
          

          ///////////////////// Model Call /////////////////
          $query = $this->user_model->user_update($id,$data);
          $this->session->set_flashdata('msg','Profile Updated Successfully');
          redirect('profile', 'refresh');
          }
          
          /////Check Greek Name//////////////////
          if($query->num_rows() != 0 && $qry->num_rows() ==0)
          {
          $query2 = $this->db->query("select * from `user_master`
          where `geek_name` = '".$geek."' OR `email` like '".$email."'");
          if($query2->num_rows() == 0)
          {
            if($_FILES['profile_picture']['name']!='') 
          {
            $upload_dir= 'uploads/';
            $temp_error = $_FILES['profile_picture']['error'];

            $file_name  = time().'_'.$_FILES['profile_picture']['name']; 
            $tmp_name   = $_FILES['profile_picture']['tmp_name'];
            $file_size  = $_FILES['profile_picture']['size'];

            move_uploaded_file($tmp_name,$upload_dir.$file_name);
          }
          else
          { 
          $file_name = $user->profile_picture; 
          }

          $dob = $this->input->post('year').'-'.$this->input->post('month').'-'.$this->input->post('day');

          $data = array(
          'geek_name'=>$this->input->post('geek_name'),
          'email'=>$this->input->post('email'),
          'name'=>$this->input->post('name'),
          'date_of_birth'=>$dob,
          'gender'=> $this->input->post('gender'),
          'profile_picture'=>$file_name,
          'phone'=>$this->input->post('phone'),
          'country'=>$this->input->post('country'),
          'qualification'=>$this->input->post('qualification'),
          'about_me'=>$this->input->post('about_me'),
           );


          ///////////////////// Model Call /////////////////
          $query = $this->user_model->user_update($id,$data);
          $this->session->set_flashdata('msg','Profile Updated Successfully');
          redirect('profile', 'refresh');
          }
          else
          {
          $this->session->set_flashdata('msg','Email already exist!');
          redirect('profile', 'refresh');
          }
          
          }
          ////////////////Check Email///////////////
          if($query->num_rows() == 0 && $qry->num_rows() !=0)
          {
          $query2 = $this->db->query("select * from `user_master`
          where `geek_name` = '".$geek."' OR `email` like '".$email."'");
          if($query2->num_rows() == 0)
          {
            if($_FILES['profile_picture']['name']!='') 
          {
            $upload_dir= 'uploads/';
            $temp_error = $_FILES['profile_picture']['error'];

            $file_name  = time().'_'.$_FILES['profile_picture']['name']; 
            $tmp_name   = $_FILES['profile_picture']['tmp_name'];
            $file_size  = $_FILES['profile_picture']['size'];

            move_uploaded_file($tmp_name,$upload_dir.$file_name);
          }
          else
          { 
          $file_name = $user->profile_picture; 
          }

          $dob = $this->input->post('year').'-'.$this->input->post('month').'-'.$this->input->post('day');

          $data = array(
          'geek_name'=>$this->input->post('geek_name'),
          'email'=>$this->input->post('email'),
          'name'=>$this->input->post('name'),
          'date_of_birth'=>$dob,
          'gender'=> $this->input->post('gender'),
          'profile_picture'=>$file_name,
          'phone'=>$this->input->post('phone'),
          'country'=>$this->input->post('country'),
          'qualification'=>$this->input->post('qualification'),
          'about_me'=>$this->input->post('about_me'),
           );


          ///////////////////// Model Call /////////////////
          $query = $this->user_model->user_update($id,$data);
          $this->session->set_flashdata('msg','Profile Updated Successfully');
          redirect('profile', 'refresh');
          }
          else
          {
          $this->session->set_flashdata('msg','Greek name already exist!');
          redirect('profile', 'refresh');
          }
          
          }
          /////////////////////////////////////////
          if($query->num_rows() == 0 && $qry->num_rows() ==0)
          {
          $query2 = $this->db->query("select * from `user_master`
          where `geek_name` = '".$geek."' OR `email` like '".$email."'");
          if($query2->num_rows() == 0)
          {
            if($_FILES['profile_picture']['name']!='') 
          {
            $upload_dir= 'uploads/';
            $temp_error = $_FILES['profile_picture']['error'];

            $file_name  = time().'_'.$_FILES['profile_picture']['name']; 
            $tmp_name   = $_FILES['profile_picture']['tmp_name'];
            $file_size  = $_FILES['profile_picture']['size'];

            move_uploaded_file($tmp_name,$upload_dir.$file_name);
          }
          else
          { 
          $file_name = $user->profile_picture; 
          }

          $dob = $this->input->post('year').'-'.$this->input->post('month').'-'.$this->input->post('day');

          $data = array(
          'geek_name'=>$this->input->post('geek_name'),
          'email'=>$this->input->post('email'),
          'name'=>$this->input->post('name'),
          'date_of_birth'=>$dob,
          'gender'=> $this->input->post('gender'),
          'profile_picture'=>$file_name,
          'phone'=>$this->input->post('phone'),
          'country'=>$this->input->post('country'),
          'qualification'=>$this->input->post('qualification'),
          'about_me'=>$this->input->post('about_me'),
           );


          ///////////////////// Model Call /////////////////
          $query = $this->user_model->user_update($id,$data);
          $this->session->set_flashdata('msg','Profile Updated Successfully');
          redirect('profile', 'refresh');
          }
          else
          {
          $this->session->set_flashdata('msg','Greek name or Email already exist!');
          redirect('profile', 'refresh');
          }
          
          }
          /////////////////////////////////////////
        }
        ////////////////////////////////////////////
        public function changepassword()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/changepassword');
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
        /////////////////////////////////////////////
        public function editpassword()
        {
          $id=$this->uri->segment(3);
          $user=$this->db->get_where('user_master',array('id'=>$id))->row();
          $pass=$this->input->post('new_password');
          $this->db->set('password',md5($pass));
          $this->db->set('pass',$pass);
          $this->db->where('id',$id);
          $status=$this->db->update('user_master');
          if($status)
          {
            $to = $user->email;
            $subject = "Notification of Change Password";
            $message = "
            <html>
            <head>
            <title>HTML email</title>
            </head>
            <body>
            <h1></h1>
            <hr>
            <p>
            <span >Dear, ".$user->name."</span>
            <br><br>
            <p>
            Your Old Password Was:".$this->input->post('password').";<br>
            Your New Password is : ".$pass."
            </p>
            </p>

            </body>
            </html>
            ";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

            // More headers
            $headers .= 'From: <fixergeek.in>' . "\r\n";
            // $headers .= 'Cc: '.$email_qry->reg_email. "\r\n";

            mail($to,$subject,$message,$headers);
            $this->session->set_flashdata('msg',"Password Changed Susseccfully");
            redirect('profile/changepassword');
          }
        }
        ////////////////////////////////////////////
        public function account()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/changeaccount');
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
        ////////////////////////////////////////////
        public function accountdelete()
        {
          $this->load->view('inc/top-header');
          $this->load->view('inc/header');
          $this->load->view('front/deleteaccount');
          $this->load->view('inc/modal');
          $this->load->view('inc/footer');
        }
        ////////////////////////////////////////////
         public function editaccount()
        {
          $id=$this->uri->segment(3);
          $user=$this->db->get_where('user_master',array('id'=>$id))->row();
          if($user->account=="Activate")
          {
           $acc="Deactivate";
          }
          if($user->account=="Deactivate")
          {
            $acc="Activate";
          }
          $this->db->set('account',$acc);
          $this->db->where('id',$id);
          $status=$this->db->update('user_master');
          if($status)
          {
           
            $this->session->set_flashdata('msg',"Your Account ".$acc." Susseccfully");
            redirect('profile/account');
          }
        }
        ///////////////////////////////////////////
        public function confirmdelete()
        {
          $id=$this->uri->segment(3);
          $this->db->delete('answers_master',array('user_id'=>$id));
          $this->db->delete('comment_master',array('user_id'=>$id));
          $this->db->delete('fixergeek_master',array('user_id'=>$id));
          $this->db->delete('questions_master',array('user_id'=>$id));
          $this->db->delete('reply_master',array('user_id'=>$id));
          $status=$this->db->delete('user_master',array('id'=>$id));

          if($status)
          {
           $this->session->sess_destroy();
           redirect('/', 'refresh');
          }
        
        }
        //////////////////////////////////////////
	   }
?>