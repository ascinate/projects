<?php
 //error_reporting(0);
 if(!defined('BASEPATH')) exit('No direct script access allowed');

 class Messages extends CI_Controller
 {
	public function __construct()
	{
	  parent::__construct();
	  $this->load->database();
	  $this->load->helper('url');
	  $this->load->library('session');
	}

	public function index()
	{
	  $this->load->view('inc/top-header');
	  $this->load->view('inc/header');
	  $this->load->view('front/messages');
	  $this->load->view('inc/modal');
	  $this->load->view('inc/footer');
	}
	
	public function insert()
	{
	  $receiver = $this->input->post('receiver_id');
	  $sender = $this->input->post('sender_id');
	  $message = $this->input->post('message');
	  $session = session_id();
	  
	  $verify = $this->db->get_where('message_master', array('sender_id'=>$sender, 'receiver_id'=>$receiver));
	  $count = $verify->num_rows();
	  $rec = $verify->row();
	  
	  if($count==0)
	  {
		  $data = array('session_id' => $session, 
						'sender_id' => $sender, 
						'receiver_id' => $receiver,
						'message' => $message, 
						'author' => $this->session->userdata('id'),
						'date_time' => date('Y-m-d H:i:s'));
		  
		  $query = $this->db->insert('message_master', $data);
		  $lastid = $this->db->insert_id();
		  
		  if($query)
		  {
			$arr = array('reply' => $message,
						 'user_id_fk' => $sender,
						 'message_id_fk' => $lastid,
						 'date_time' => date('Y-m-d H:i:s'));
						 
			$this->db->insert('chat_conversation_master', $arr);
		  }
	  }
	  
	  else
	  {
	        $arr = array('reply' => $message,
						 'user_id_fk' => $sender,
						 'message_id_fk' => $rec->id,
						 'date_time' => date('Y-m-d H:i:s'));
						 
			$this->db->insert('chat_conversation_master', $arr);
	  }
	  
	  redirect('messages');
	}
	
	public function ajaxinsert()
	{
	  $sender = $this->input->get('s');
	  $receiver = $this->input->get('r');
	  $message = $this->input->get('m');
	  $record_id = $this->input->get('id');
	  $session = session_id();
	  
	  $verify = $this->db->get_where('message_master', array('sender_id'=>$sender, 'receiver_id'=>$receiver));
	  $count = $verify->num_rows();
	  $rec = $verify->row();
	  
	  $data = array('reply' => $message, 
					'user_id_fk' => $sender,
					'message_id_fk' => $record_id, 
					'date_time' => date('Y-m-d H:i:s'));
	  
	  $query = $this->db->insert('chat_conversation_master', $data);
	  
	  if($query) 
	  {
		 //$sub = $this->db->get_where('message_master', array('receiver_id'=>$receiver));
		 $sub = $this->db->get_where('chat_conversation_master', array('message_id_fk'=>$record_id));
		 
		 foreach($sub->result() as $rex)
		 {
		   $author = $this->db->get_where('user_master',array('id'=>$rex->user_id_fk))->row();
	   ?> 

	  <div class="row mt-4 mx-0 chating text-left">
		<div class="col-1 px-2">
		  <div class="chat_pic float-left"> 
			<?php
			 if($author->profile_picture!="")
			 {
		  ?>
		   <img src="<?php echo base_url();?>uploads/<?=$author->profile_picture?>" alt="user" 
		   style="border-radius:50%;" class="w-100">
		   <?php
			 }
			 else
			 {
			?>
			   <i class="far fa-user-circle"></i>
			<?php
			  }
			?>
		  </div>
		  <div class="online-2"></div>
		</div>
		<div class="col-10 chatting_messege px-4 pt-1">
		  <h6 class="mb-2"><b><?=$author->geek_name?></b></h6>
		  <p><?=$rex->reply?> </p>
		</div>
		<div class="col-1 pt-1 px-0">
		  <div class="chat-time">
			<p><?php $ddt = explode(" ",$rex->date_time); echo $ddt[1];?></p>
		  </div>
		</div>
	  </div>
	  <?php
		}
	  ?>


<?php
	  }
	}
 }
?>