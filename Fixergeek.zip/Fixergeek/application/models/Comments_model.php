<?php
	class Comments_model extends CI_model
	{

		public function comments_insert($data)
		{
			$query = $this->db->insert('answer_comment',$data);
		}

		public function get_comments_list($id)
		{
			$query=$this->db->get_where('answer_comment',array('answer_id'=>$id));
			return $query->result();
		}

		public function get_comments_data($id)
		{
			$this->db->select('*');
			$this->db->from('answer_comment');
			$this->db->where('id', $id);
			$query = $this->db->get();
			return $query->result();
		}

		public function update_question($id, $data)
		{
			$this->db->where('id', $id);
			$query = $this->db->update('questions_master', $data); 
		}

		public function deletecomments($id)
		{
			$this->db->where('id', $id);
			$query = $this->db->delete('answer_comment'); 
			
			if($query)
			{
			   $this->db->where('comment_id', $id);
			   $this->db->delete('reply_master'); 
			}
		}
	 
	}
?>