<?php
	class Answer_model extends CI_model
	{

		public function answer_insert($data)
		{
			$query = $this->db->insert('answers_master',$data);
		}

		public function get_answer_list($id)
		{
			$query=$this->db->query("select * from `answers_master` where question_id = '".$id."'");
			return $query->result();
		}

		public function get_answer_data($id)
		{
			$this->db->select('*');
			$this->db->from('answers_master');
			$this->db->where('id', $id);
			$query = $this->db->get();
			return $query->result();
		}

		public function update_answer($id, $data)
		{
			$this->db->where('id', $id);
			$query = $this->db->update('answers_master', $data); 
		}

		public function delete_answer($id)
		{
			$this->db->where('id', $id);
			$query = $this->db->delete('answers_master'); 
		}
	 
	}
?>