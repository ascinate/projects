<?php
	class Category_model extends CI_model
	{

		

		public function get_list($cat)
		{
			$category=str_replace("_"," ",str_replace("-","&",$cat));
			$sub_id=$this->db->get_where('sub_sub_category_master',array('sub_sub_category_name'=>$category))->row();
			$this->db->order_by('id','desc');
			$query=$this->db->get_where('questions_master',array('sub_sub_cat_id'=>$sub_id->id));
			return $query->result();
		}		
	 
	}
?>