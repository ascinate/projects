<?php
	class Question_model extends CI_model
	{

		public function question_insert($data)
		{
			$query = $this->db->insert('questions_master',$data);
		}

		public function get_question_list()
		{
			$query=$this->db->query("select * from `questions_master`");
			return $query->result();
		}

		public function get_question_data($id)
		{
			$this->db->select('*');
			$this->db->from('questions_master');
			$this->db->where('id', $id);
			$query = $this->db->get();
			return $query->result();
		}

		public function update_question($id, $data)
		{
			$this->db->where('id', $id);
			$query = $this->db->update('questions_master', $data); 
		}

		public function delete_question($id)
		{
			$this->db->where('id', $id);
			$query = $this->db->delete('questions_master'); 
		}
	 
	}
?>