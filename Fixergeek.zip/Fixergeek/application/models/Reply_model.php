<?php
	class Reply_model extends CI_model
	{

		public function reply_insert($data)
		{
			$query = $this->db->insert('reply_master',$data);
		}

		public function get_reply_list($id)
		{
			$query=$this->db->get_where("reply_master",array('comment_id'=>$id));
			return $query->result();
		}

		public function get_reply_data($id)
		{
			$this->db->select('*');
			$this->db->from('reply_master');
			$this->db->where('id', $id);
			$query = $this->db->get();
			return $query->result();
		}


		public function deletereply($id)
		{
			$this->db->where('id', $id);
			$query = $this->db->delete('reply_master'); 
		}
	 
	}
?>