<?php
	class Cms_model extends CI_model
	{
	
	   public function get_cms_data($id)
		{
			$this->db->select('*');
			$this->db->from('cms_master');
			$this->db->where('id', $id);
			$query = $this->db->get();
			return $query->result();
		}
		
		public function update_cms($id, $data)
		{
			$this->db->where('id', $id);
			$query = $this->db->update('cms_master', $data); 
		}
	  
	
	}
	
?>