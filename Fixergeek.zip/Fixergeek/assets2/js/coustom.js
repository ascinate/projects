// JavaScript Document
$(document).ready(function() {
	$("#modal-btn-1").click(function() {
		$("#modal-no-1").hide();
		$("#modal-no-2").show();
	});
	
	$("#modal-btn-2").click(function() {
		$("#modal-no-2").hide();
		$("#modal-no-3").show();
	});
	$("#modal-btn-3").click(function() {
		$("#modal-no-3").hide();
		$("#modal-no-4").show();
	});
	$("#modal-btn-4").click(function() {
		$("#modal-no-4").hide();
		$("#modal-no-5").show();
	});
	$("#modal-btn-5").click(function() {
		$("#modal-no-5").hide();
		$("#modal-no-6").show();
	});
	$("#modal-btn-6").click(function() {
		$("#modal-no-6").hide();
		$("#modal-no-7").show();
	});
	$("#modal-btn-7").click(function() {
		$("#modal-no-7").hide();
		$("#modal-no-8").show();
	});
	$("#modal-btn-8").click(function() {
		$("#modal-no-8").hide();
		$("#modal-no-10").show();
	});
	$("#modal-btn-10").click(function() {
		$("#modal-no-10").hide();
		$("#modal-no-11").show();
	});
	$("#modal-btn-11").click(function() {
		$("#modal-no-11").hide();
		$("#modal-no-12").show();
	});
	$("#modal-btn-12").click(function() {
        $("#modal-no-7").hide();
		$("#modal-no-8").hide();
        $("#modal-no-10").hide();
        $("#modal-no-11").hide();
        $("#modal-no-12").hide();
		$("#modal-no-13").show();
	});
	$("#modal-btn-13").click(function() {
		$("#modal-no-13").hide();
		$("#modal-no-14").show();
	});
	$("#modal-btn-14").click(function() {
		$("#modal-no-14").hide();
		$("#modal-no-15").show();
	});
	$("#modal-btn-15").click(function() {
		$("#modal-no-15").hide();
		$("#modal-no-16").show();
	});
	$("#modal-btn-16").click(function() {
		$("#modal-no-16").hide();
		$("#modal-no-17").show();
	});
	$("#modal-btn-17").click(function() {
        $("#modal-no-15").hide();
        $("#modal-no-16").hide();
		$("#modal-no-17").hide();
		$("#modal-no-18").show();
	});
	$("#modal-btn-18").click(function() {
		$("#modal-no-18").hide();
		$("#modal-no-19").show();
	});
	$("#modal-btn-19").click(function() {
		$("#modal-no-19").hide();
		$("#modal-no-20").show();
	});
	$("#modal-btn-20").click(function() {
		$("#modal-no-20").hide();
		$("#modal-no-21").show();
	});
	$("#modal-btn-21").click(function() {
		$("#modal-no-21").hide();
		$("#modal-no-22").show();
	});
	$("#modal-btn-22").click(function() {
        $("#modal-no-20").hide();
        $("#modal-no-21").hide();
		$("#modal-no-22").hide();
		$("#modal-no-23").show();
	});
	$("#modal-btn-23").click(function() {
		$("#modal-no-23").hide();
		$("#modal-no-24").show();
	});
	$("#modal-btn-24").click(function() {
		$("#modal-no-24").hide();
		$("#modal-no-34").show();
	});
	$("#modal-btn-34").click(function() {
		$("#modal-no-34").hide();
		$("#modal-no-35").show();
	});
	$("#modal-btn-35").click(function() {
		$("#modal-no-23").hide();
        $("#modal-no-24").hide();
        $("#modal-no-34").hide();
        $("#modal-no-35").hide();
		$("#modal-no-36").show();
	});
	$("#modal-btn-36").click(function() {
		$("#modal-no-36").hide();
		$("#modal-no-37").show();
	});
    $("#modal-btn-37").click(function() {
        $("#modal-no-37").hide();
        $("#modal-no-34").show();
    });



////////// js 2 //////////////
 $("#plus-mode3").click(function() {
                // $("#modalbar2-dropdown-li-3").toggle();

                $("#modal-mode3").toggle();
            });

            ////////////////////////
            $("#modalbar2-dropdown-li-8").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#modalbar2-dropdown-li-9").removeClass('active');
                $("#modalbar2-dropdown-li-11").removeClass('active');
                $("#modalbar2-dropdown-li-10").removeClass('active');
                $("#modalbar2-dropdown-li-12").removeClass('active');
                $("#modalbar2-dropdown-li-13").removeClass('active');
                $("#modalbar2-dropdown-li-14").removeClass('active');
                $("#modalbar2-dropdown-li-15").removeClass('active');
                $("#modalbar2-dropdown-li-16").removeClass('active');
                $("#modalbar2-list-9").hide();
                $("#modalbar2-list-10").hide();
                $("#modalbar2-list-11").hide();
                $("#modalbar2-list-15").hide();
                $("#modalbar2-list-16").hide();
                $("#modalbar2-list-13").hide();
                $("#modalbar2-list-12").hide();
                $("#modalbar2-list-14").hide();
                $("#modalbar2-dropdown-li-10").hide();
                $("#modalbar2-list-8").toggle();
                if ($("#modalbar2-dropdown-li-8").hasClass('active')) {
                    $("#modalbar2-dropdown-li-8").removeClass('active');
                } else {
                    $("#modalbar2-dropdown-li-8").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar2-dropdown-li-13").click(function() {
                // $("#modalbar2-dropdown-li-3").toggle();
                $("#modalbar2-dropdown-li-9").removeClass('active');
                $("#modalbar2-dropdown-li-11").removeClass('active');
                $("#modalbar2-dropdown-li-10").removeClass('active');
                $("#modalbar2-dropdown-li-12").removeClass('active');
                $("#modalbar2-dropdown-li-14").removeClass('active');
                $("#modalbar2-dropdown-li-8").removeClass('active');
                $("#modalbar2-dropdown-li-15").removeClass('active');
                $("#modalbar2-dropdown-li-16").removeClass('active');
                $("#modalbar2-list-9").hide();
                $("#modalbar2-list-11").hide();
                $("#modalbar2-list-14").hide();
                $("#modalbar2-list-15").hide();
                $("#modalbar2-list-12").hide();
                $("#modalbar2-list-16").hide();
                $("#modalbar2-list-8").hide();
                $("#modalbar2-list-10").hide();
                $("#modalbar2-list-13").toggle();
                if ($("#modalbar2-dropdown-li-13").hasClass('active')) {
                    $("#modalbar2-dropdown-li-13").removeClass('active');
                } else {
                    $("#modalbar2-dropdown-li-13").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar2-dropdown-li-14").click(function() {
                // $("#modalbar2-dropdown-li-3").toggle();
                $("#modalbar2-dropdown-li-9").removeClass('active');
                $("#modalbar2-dropdown-li-11").removeClass('active');
                $("#modalbar2-dropdown-li-10").removeClass('active');
                $("#modalbar2-dropdown-li-12").removeClass('active');
                $("#modalbar2-dropdown-li-13").removeClass('active');
                $("#modalbar2-dropdown-li-15").removeClass('active');
                $("#modalbar2-dropdown-li-16").removeClass('active');
                $("#modalbar2-dropdown-li-8").removeClass('active');
                $("#modalbar2-list-9").hide();
                $("#modalbar2-list-11").hide();
                $("#modalbar2-list-13").hide();
                $("#modalbar2-list-15").hide();
                $("#modalbar2-list-12").hide();
                $("#modalbar2-list-16").hide();
                $("#modalbar2-list-8").hide();
                $("#modalbar2-list-14").toggle();
                if ($("#modalbar2-dropdown-li-14").hasClass('active')) {
                    $("#modalbar2-dropdown-li-14").removeClass('active');
                } else {
                    $("#modalbar2-dropdown-li-14").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar2-dropdown-li-15").click(function() {
                // $("#modalbar2-dropdown-li-3").toggle();
                $("#modalbar2-dropdown-li-9").removeClass('active');
                $("#modalbar2-dropdown-li-11").removeClass('active');
                $("#modalbar2-dropdown-li-10").removeClass('active');
                $("#modalbar2-dropdown-li-12").removeClass('active');
                $("#modalbar2-dropdown-li-14").removeClass('active');
                $("#modalbar2-dropdown-li-13").removeClass('active');
                $("#modalbar2-dropdown-li-16").removeClass('active');
                $("#modalbar2-dropdown-li-8").removeClass('active');
                $("#modalbar2-list-9").hide();
                $("#modalbar2-list-11").hide();
                $("#modalbar2-list-8").hide();
                $("#modalbar2-list-10").hide();
                $("#modalbar2-list-12").hide();
                $("#modalbar2-list-13").hide();
                $("#modalbar2-list-14").hide();
                $("#modalbar2-list-16").hide();
                $("#modalbar2-list-15").toggle();
                if ($("#modalbar2-dropdown-li-15").hasClass('active')) {
                    $("#modalbar2-dropdown-li-15").removeClass('active');
                } else {
                    $("#modalbar2-dropdown-li-15").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar2-dropdown-li-16").click(function() {
                // $("#modalbar2-dropdown-li-3").toggle();
                $("#modalbar2-dropdown-li-9").removeClass('active');
                $("#modalbar2-dropdown-li-11").removeClass('active');
                $("#modalbar2-dropdown-li-10").removeClass('active');
                $("#modalbar2-dropdown-li-8").removeClass('active');
                $("#modalbar2-dropdown-li-12").removeClass('active');
                $("#modalbar2-dropdown-li-13").removeClass('active');
                $("#modalbar2-dropdown-li-14").removeClass('active');
                $("#modalbar2-dropdown-li-15").removeClass('active');
                $("#modalbar2-list-9").hide();
                $("#modalbar2-list-11").hide();
                $("#modalbar2-list-10").hide();
                $("#modalbar2-list-8").hide();
                $("#modalbar2-list-12").hide();
                $("#modalbar2-list-13").hide();
                $("#modalbar2-list-14").hide();
                $("#modalbar2-list-15").hide();
                $("#modalbar2-list-16").toggle();
                if ($("#modalbar2-dropdown-li-16").hasClass('active')) {
                    $("#modalbar2-dropdown-li-16").removeClass('active');
                } else {
                    $("#modalbar2-dropdown-li-16").addClass('active');


                }
            });





$("#modalbar2-dropdown-li-9").click(function() {
                // $("#modalbar2-dropdown-li-2").toggle();
                $("#modalbar2-dropdown-li-8").removeClass('active');
                $("#modalbar2-dropdown-li-11").removeClass('active');
                $("#modalbar2-dropdown-li-10").removeClass('active');
                $("#modalbar2-dropdown-li-12").removeClass('active');
                $("#modalbar2-dropdown-li-13").removeClass('active');
                $("#modalbar2-dropdown-li-14").removeClass('active');
                $("#modalbar2-dropdown-li-15").removeClass('active');
                $("#modalbar2-dropdown-li-16").removeClass('active');
                $("#modalbar2-list-8").hide();
                $("#modalbar2-list-11").hide();
                $("#modalbar2-list-13").hide();
                $("#modalbar2-list-14").hide();
                $("#modalbar2-list-15").hide();
                $("#modalbar2-list-16").hide();
                $("#modalbar2-list-9").toggle();
                if ($("#modalbar2-dropdown-li-9").hasClass('active')) {
                    $("#modalbar2-dropdown-li-9").removeClass('active');
                } else {
                    $("#modalbar2-dropdown-li-9").addClass('active');

                }
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id4").hover(function() {
                // $("#modalbar2-dropdown-li-2").toggle();
                $("#modalbar2-list-8").hide();
                $("#modalbar2-list-9").hide();
                $("#modalbar2-list-11").hide();
                $("#modalbar2-list-10").hide();
                $("#modalbar2-list-12").hide();
                $("#modalbar2-list-13").hide();
                $("#modalbar2-list-14").hide();
                $("#modalbar2-list-15").hide();
                $("#modalbar2-list-16").hide();
                $("#modalbar2-dropdown-li-8").removeClass('active');
                $("#modalbar2-dropdown-li-9").removeClass('active');
                $("#modalbar2-dropdown-li-11").removeClass('active');
                $("#modalbar2-dropdown-li-10").removeClass('active');
                $("#modalbar2-dropdown-li-12").removeClass('active');
                $("#modalbar2-dropdown-li-13").removeClass('active');
                $("#modalbar2-dropdown-li-14").removeClass('active');
                $("#modalbar2-dropdown-li-15").removeClass('active');
                $("#modalbar2-dropdown-li-16").removeClass('active');
            });
			
		
		
 /////////////////////////////////////////
            $("#modalbar2-dropdown-li-10").click(function() {
                // $("#modalbar2-dropdown-li-8").removeClass('active');
                $("#modalbar2-dropdown-li-9").removeClass('active');
                $("#modalbar2-dropdown-li-11").removeClass('active');
                $("#modalbar2-dropdown-li-12").removeClass('active');
                $("#modalbar2-dropdown-li-13").removeClass('active');
                $("#modalbar2-dropdown-li-14").removeClass('active');
                $("#modalbar2-dropdown-li-15").removeClass('active');
                $("#modalbar2-dropdown-li-16").removeClass('active');
                $("#modalbar2-list-10").toggle();
                if ($("#modalbar2-dropdown-li-10").hasClass('active')) {
                    $("#modalbar2-dropdown-li-10").removeClass('active');
                } else {
                    $("#modalbar2-dropdown-li-10").addClass('active');

                }
            });
            //////////////////////
            $("#modalbar2-dropdown-li-11").click(function() {
                // $("#modalbar2-dropdown-li-3").toggle();
                $("#modalbar2-dropdown-li-8").removeClass('active');
                $("#modalbar2-dropdown-li-9").removeClass('active');
                $("#modalbar2-dropdown-li-10").removeClass('active');
                $("#modalbar2-dropdown-li-12").removeClass('active');
                $("#modalbar2-dropdown-li-13").removeClass('active');
                $("#modalbar2-dropdown-li-14").removeClass('active');
                $("#modalbar2-dropdown-li-15").removeClass('active');
                $("#modalbar2-dropdown-li-16").removeClass('active');
                $("#modalbar2-list-9").hide();
                $("#modalbar2-list-13").hide();
                $("#modalbar2-list-14").hide();
                $("#modalbar2-list-15").hide();
                $("#modalbar2-list-16").hide();
                $("#modalbar2-list-8").hide();
                $("#modalbar2-list-11").toggle();
                if ($("#modalbar2-dropdown-li-11").hasClass('active')) {
                    $("#modalbar2-dropdown-li-11").removeClass('active');
                } else {
                    $("#modalbar2-dropdown-li-11").addClass('active');

                }
            });
            /////////////////////////////
            $("#modalbar2-dropdown-li-12").click(function() {
                $("#modalbar2-dropdown-li-8").removeClass('active');
                $("#modalbar2-dropdown-li-9").removeClass('active');
                // $("#modalbar2-dropdown-li-11").removeClass('active');
                $("#modalbar2-dropdown-li-10").removeClass('active');
                $("#modalbar2-dropdown-li-13").removeClass('active');
                $("#modalbar2-dropdown-li-14").removeClass('active');
                $("#modalbar2-dropdown-li-15").removeClass('active');
                $("#modalbar2-dropdown-li-16").removeClass('active');
                $("#modalbar2-list-12").toggle();
                if ($("#modalbar2-dropdown-li-12").hasClass('active')) {
                    $("#modalbar2-dropdown-li-12").removeClass('active');
                } else {
                    $("#modalbar2-dropdown-li-12").addClass('active');

                }
            });
			


$("#plus-mode4").click(function() {
                // $("#modalbar2-dropdown-li-3").toggle();

                $("#modal-mode4").toggle();
            });

            ////////////////////////
            $("#modalbar3-dropdown-li-8").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#modalbar3-dropdown-li-9").removeClass('active');
                $("#modalbar3-dropdown-li-11").removeClass('active');
                $("#modalbar3-dropdown-li-10").removeClass('active');
                $("#modalbar3-dropdown-li-12").removeClass('active');
                $("#modalbar3-dropdown-li-13").removeClass('active');
                $("#modalbar3-dropdown-li-14").removeClass('active');
                $("#modalbar3-dropdown-li-15").removeClass('active');
                $("#modalbar3-dropdown-li-16").removeClass('active');
                $("#modalbar3-list-9").hide();
                $("#modalbar3-list-10").hide();
                $("#modalbar3-list-11").hide();
                $("#modalbar3-list-15").hide();
                $("#modalbar3-list-16").hide();
                $("#modalbar3-list-13").hide();
                $("#modalbar3-list-12").hide();
                $("#modalbar3-list-14").hide();
                $("#modalbar3-dropdown-li-10").hide();
                $("#modalbar3-list-8").toggle();
                if ($("#modalbar3-dropdown-li-8").hasClass('active')) {
                    $("#modalbar3-dropdown-li-8").removeClass('active');
                } else {
                    $("#modalbar3-dropdown-li-8").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar3-dropdown-li-13").click(function() {
                // $("#modalbar3-dropdown-li-3").toggle();
                $("#modalbar3-dropdown-li-9").removeClass('active');
                $("#modalbar3-dropdown-li-11").removeClass('active');
                $("#modalbar3-dropdown-li-10").removeClass('active');
                $("#modalbar3-dropdown-li-12").removeClass('active');
                $("#modalbar3-dropdown-li-14").removeClass('active');
                $("#modalbar3-dropdown-li-8").removeClass('active');
                $("#modalbar3-dropdown-li-15").removeClass('active');
                $("#modalbar3-dropdown-li-16").removeClass('active');
                $("#modalbar3-list-9").hide();
                $("#modalbar3-list-11").hide();
                $("#modalbar3-list-14").hide();
                $("#modalbar3-list-15").hide();
                $("#modalbar3-list-12").hide();
                $("#modalbar3-list-16").hide();
                $("#modalbar3-list-8").hide();
                $("#modalbar3-list-10").hide();
                $("#modalbar3-list-13").toggle();
                if ($("#modalbar3-dropdown-li-13").hasClass('active')) {
                    $("#modalbar3-dropdown-li-13").removeClass('active');
                } else {
                    $("#modalbar3-dropdown-li-13").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar3-dropdown-li-14").click(function() {
                // $("#modalbar3-dropdown-li-3").toggle();
                $("#modalbar3-dropdown-li-9").removeClass('active');
                $("#modalbar3-dropdown-li-11").removeClass('active');
                $("#modalbar3-dropdown-li-10").removeClass('active');
                $("#modalbar3-dropdown-li-12").removeClass('active');
                $("#modalbar3-dropdown-li-13").removeClass('active');
                $("#modalbar3-dropdown-li-15").removeClass('active');
                $("#modalbar3-dropdown-li-16").removeClass('active');
                $("#modalbar3-dropdown-li-8").removeClass('active');
                $("#modalbar3-list-9").hide();
                $("#modalbar3-list-11").hide();
                $("#modalbar3-list-13").hide();
                $("#modalbar3-list-15").hide();
                $("#modalbar3-list-12").hide();
                $("#modalbar3-list-16").hide();
                $("#modalbar3-list-8").hide();
                $("#modalbar3-list-14").toggle();
                if ($("#modalbar3-dropdown-li-14").hasClass('active')) {
                    $("#modalbar3-dropdown-li-14").removeClass('active');
                } else {
                    $("#modalbar3-dropdown-li-14").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar3-dropdown-li-15").click(function() {
                // $("#modalbar3-dropdown-li-3").toggle();
                $("#modalbar3-dropdown-li-9").removeClass('active');
                $("#modalbar3-dropdown-li-11").removeClass('active');
                $("#modalbar3-dropdown-li-10").removeClass('active');
                $("#modalbar3-dropdown-li-12").removeClass('active');
                $("#modalbar3-dropdown-li-14").removeClass('active');
                $("#modalbar3-dropdown-li-13").removeClass('active');
                $("#modalbar3-dropdown-li-16").removeClass('active');
                $("#modalbar3-dropdown-li-8").removeClass('active');
                $("#modalbar3-list-9").hide();
                $("#modalbar3-list-11").hide();
                $("#modalbar3-list-8").hide();
                $("#modalbar3-list-10").hide();
                $("#modalbar3-list-12").hide();
                $("#modalbar3-list-13").hide();
                $("#modalbar3-list-14").hide();
                $("#modalbar3-list-16").hide();
                $("#modalbar3-list-15").toggle();
                if ($("#modalbar3-dropdown-li-15").hasClass('active')) {
                    $("#modalbar3-dropdown-li-15").removeClass('active');
                } else {
                    $("#modalbar3-dropdown-li-15").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar3-dropdown-li-16").click(function() {
                // $("#modalbar3-dropdown-li-3").toggle();
                $("#modalbar3-dropdown-li-9").removeClass('active');
                $("#modalbar3-dropdown-li-11").removeClass('active');
                $("#modalbar3-dropdown-li-10").removeClass('active');
                $("#modalbar3-dropdown-li-8").removeClass('active');
                $("#modalbar3-dropdown-li-12").removeClass('active');
                $("#modalbar3-dropdown-li-13").removeClass('active');
                $("#modalbar3-dropdown-li-14").removeClass('active');
                $("#modalbar3-dropdown-li-15").removeClass('active');
                $("#modalbar3-list-9").hide();
                $("#modalbar3-list-11").hide();
                $("#modalbar3-list-10").hide();
                $("#modalbar3-list-8").hide();
                $("#modalbar3-list-12").hide();
                $("#modalbar3-list-13").hide();
                $("#modalbar3-list-14").hide();
                $("#modalbar3-list-15").hide();
                $("#modalbar3-list-16").toggle();
                if ($("#modalbar3-dropdown-li-16").hasClass('active')) {
                    $("#modalbar3-dropdown-li-16").removeClass('active');
                } else {
                    $("#modalbar3-dropdown-li-16").addClass('active');


                }
            });
			
$("#modalbar3-dropdown-li-9").click(function() {
                // $("#modalbar3-dropdown-li-2").toggle();
                $("#modalbar3-dropdown-li-8").removeClass('active');
                $("#modalbar3-dropdown-li-11").removeClass('active');
                $("#modalbar3-dropdown-li-10").removeClass('active');
                $("#modalbar3-dropdown-li-12").removeClass('active');
                $("#modalbar3-dropdown-li-13").removeClass('active');
                $("#modalbar3-dropdown-li-14").removeClass('active');
                $("#modalbar3-dropdown-li-15").removeClass('active');
                $("#modalbar3-dropdown-li-16").removeClass('active');
                $("#modalbar3-list-8").hide();
                $("#modalbar3-list-11").hide();
                $("#modalbar3-list-13").hide();
                $("#modalbar3-list-14").hide();
                $("#modalbar3-list-15").hide();
                $("#modalbar3-list-16").hide();
                $("#modalbar3-list-9").toggle();
                if ($("#modalbar3-dropdown-li-9").hasClass('active')) {
                    $("#modalbar3-dropdown-li-9").removeClass('active');
                } else {
                    $("#modalbar3-dropdown-li-9").addClass('active');

                }
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id5").hover(function() {
                // $("#modalbar3-dropdown-li-2").toggle();
                $("#modalbar3-list-8").hide();
                $("#modalbar3-list-9").hide();
                $("#modalbar3-list-11").hide();
                $("#modalbar3-list-10").hide();
                $("#modalbar3-list-12").hide();
                $("#modalbar3-list-13").hide();
                $("#modalbar3-list-14").hide();
                $("#modalbar3-list-15").hide();
                $("#modalbar3-list-16").hide();
                $("#modalbar3-dropdown-li-8").removeClass('active');
                $("#modalbar3-dropdown-li-9").removeClass('active');
                $("#modalbar3-dropdown-li-11").removeClass('active');
                $("#modalbar3-dropdown-li-10").removeClass('active');
                $("#modalbar3-dropdown-li-12").removeClass('active');
                $("#modalbar3-dropdown-li-13").removeClass('active');
                $("#modalbar3-dropdown-li-14").removeClass('active');
                $("#modalbar3-dropdown-li-15").removeClass('active');
                $("#modalbar3-dropdown-li-16").removeClass('active');
            });
			
 /////////////////////////////////////////
            $("#modalbar3-dropdown-li-10").click(function() {
                // $("#modalbar3-dropdown-li-8").removeClass('active');
                $("#modalbar3-dropdown-li-9").removeClass('active');
                $("#modalbar3-dropdown-li-11").removeClass('active');
                $("#modalbar3-dropdown-li-12").removeClass('active');
                $("#modalbar3-dropdown-li-13").removeClass('active');
                $("#modalbar3-dropdown-li-14").removeClass('active');
                $("#modalbar3-dropdown-li-15").removeClass('active');
                $("#modalbar3-dropdown-li-16").removeClass('active');
                $("#modalbar3-list-10").toggle();
                if ($("#modalbar3-dropdown-li-10").hasClass('active')) {
                    $("#modalbar3-dropdown-li-10").removeClass('active');
                } else {
                    $("#modalbar3-dropdown-li-10").addClass('active');

                }
            });
            //////////////////////
            $("#modalbar3-dropdown-li-11").click(function() {
                // $("#modalbar3-dropdown-li-3").toggle();
                $("#modalbar3-dropdown-li-8").removeClass('active');
                $("#modalbar3-dropdown-li-9").removeClass('active');
                $("#modalbar3-dropdown-li-10").removeClass('active');
                $("#modalbar3-dropdown-li-12").removeClass('active');
                $("#modalbar3-dropdown-li-13").removeClass('active');
                $("#modalbar3-dropdown-li-14").removeClass('active');
                $("#modalbar3-dropdown-li-15").removeClass('active');
                $("#modalbar3-dropdown-li-16").removeClass('active');
                $("#modalbar3-list-9").hide();
                $("#modalbar3-list-13").hide();
                $("#modalbar3-list-14").hide();
                $("#modalbar3-list-15").hide();
                $("#modalbar3-list-16").hide();
                $("#modalbar3-list-8").hide();
                $("#modalbar3-list-11").toggle();
                if ($("#modalbar3-dropdown-li-11").hasClass('active')) {
                    $("#modalbar3-dropdown-li-11").removeClass('active');
                } else {
                    $("#modalbar3-dropdown-li-11").addClass('active');

                }
            });
            /////////////////////////////
            $("#modalbar3-dropdown-li-12").click(function() {
                $("#modalbar3-dropdown-li-8").removeClass('active');
                $("#modalbar3-dropdown-li-9").removeClass('active');
                // $("#modalbar3-dropdown-li-11").removeClass('active');
                $("#modalbar3-dropdown-li-10").removeClass('active');
                $("#modalbar3-dropdown-li-13").removeClass('active');
                $("#modalbar3-dropdown-li-14").removeClass('active');
                $("#modalbar3-dropdown-li-15").removeClass('active');
                $("#modalbar3-dropdown-li-16").removeClass('active');
                $("#modalbar3-list-12").toggle();
                if ($("#modalbar3-dropdown-li-12").hasClass('active')) {
                    $("#modalbar3-dropdown-li-12").removeClass('active');
                } else {
                    $("#modalbar3-dropdown-li-12").addClass('active');

                }
            });
			

$("#plus-mode5").click(function() {
                // $("#modalbar2-dropdown-li-3").toggle();

                $("#modal-mode5").toggle();
            });

            ////////////////////////
            $("#modalbar4-dropdown-li-8").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#modalbar4-dropdown-li-9").removeClass('active');
                $("#modalbar4-dropdown-li-11").removeClass('active');
                $("#modalbar4-dropdown-li-10").removeClass('active');
                $("#modalbar4-dropdown-li-12").removeClass('active');
                $("#modalbar4-dropdown-li-13").removeClass('active');
                $("#modalbar4-dropdown-li-14").removeClass('active');
                $("#modalbar4-dropdown-li-15").removeClass('active');
                $("#modalbar4-dropdown-li-16").removeClass('active');
                $("#modalbar4-list-9").hide();
                $("#modalbar4-list-10").hide();
                $("#modalbar4-list-11").hide();
                $("#modalbar4-list-15").hide();
                $("#modalbar4-list-16").hide();
                $("#modalbar4-list-13").hide();
                $("#modalbar4-list-12").hide();
                $("#modalbar4-list-14").hide();
                $("#modalbar4-dropdown-li-10").hide();
                $("#modalbar4-list-8").toggle();
                if ($("#modalbar4-dropdown-li-8").hasClass('active')) {
                    $("#modalbar4-dropdown-li-8").removeClass('active');
                } else {
                    $("#modalbar4-dropdown-li-8").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar4-dropdown-li-13").click(function() {
                // $("#modalbar4-dropdown-li-3").toggle();
                $("#modalbar4-dropdown-li-9").removeClass('active');
                $("#modalbar4-dropdown-li-11").removeClass('active');
                $("#modalbar4-dropdown-li-10").removeClass('active');
                $("#modalbar4-dropdown-li-12").removeClass('active');
                $("#modalbar4-dropdown-li-14").removeClass('active');
                $("#modalbar4-dropdown-li-8").removeClass('active');
                $("#modalbar4-dropdown-li-15").removeClass('active');
                $("#modalbar4-dropdown-li-16").removeClass('active');
                $("#modalbar4-list-9").hide();
                $("#modalbar4-list-11").hide();
                $("#modalbar4-list-14").hide();
                $("#modalbar4-list-15").hide();
                $("#modalbar4-list-12").hide();
                $("#modalbar4-list-16").hide();
                $("#modalbar4-list-8").hide();
                $("#modalbar4-list-10").hide();
                $("#modalbar4-list-13").toggle();
                if ($("#modalbar4-dropdown-li-13").hasClass('active')) {
                    $("#modalbar4-dropdown-li-13").removeClass('active');
                } else {
                    $("#modalbar4-dropdown-li-13").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar4-dropdown-li-14").click(function() {
                // $("#modalbar4-dropdown-li-3").toggle();
                $("#modalbar4-dropdown-li-9").removeClass('active');
                $("#modalbar4-dropdown-li-11").removeClass('active');
                $("#modalbar4-dropdown-li-10").removeClass('active');
                $("#modalbar4-dropdown-li-12").removeClass('active');
                $("#modalbar4-dropdown-li-13").removeClass('active');
                $("#modalbar4-dropdown-li-15").removeClass('active');
                $("#modalbar4-dropdown-li-16").removeClass('active');
                $("#modalbar4-dropdown-li-8").removeClass('active');
                $("#modalbar4-list-9").hide();
                $("#modalbar4-list-11").hide();
                $("#modalbar4-list-13").hide();
                $("#modalbar4-list-15").hide();
                $("#modalbar4-list-12").hide();
                $("#modalbar4-list-16").hide();
                $("#modalbar4-list-8").hide();
                $("#modalbar4-list-14").toggle();
                if ($("#modalbar4-dropdown-li-14").hasClass('active')) {
                    $("#modalbar4-dropdown-li-14").removeClass('active');
                } else {
                    $("#modalbar4-dropdown-li-14").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar4-dropdown-li-15").click(function() {
                // $("#modalbar4-dropdown-li-3").toggle();
                $("#modalbar4-dropdown-li-9").removeClass('active');
                $("#modalbar4-dropdown-li-11").removeClass('active');
                $("#modalbar4-dropdown-li-10").removeClass('active');
                $("#modalbar4-dropdown-li-12").removeClass('active');
                $("#modalbar4-dropdown-li-14").removeClass('active');
                $("#modalbar4-dropdown-li-13").removeClass('active');
                $("#modalbar4-dropdown-li-16").removeClass('active');
                $("#modalbar4-dropdown-li-8").removeClass('active');
                $("#modalbar4-list-9").hide();
                $("#modalbar4-list-11").hide();
                $("#modalbar4-list-8").hide();
                $("#modalbar4-list-10").hide();
                $("#modalbar4-list-12").hide();
                $("#modalbar4-list-13").hide();
                $("#modalbar4-list-14").hide();
                $("#modalbar4-list-16").hide();
                $("#modalbar4-list-15").toggle();
                if ($("#modalbar4-dropdown-li-15").hasClass('active')) {
                    $("#modalbar4-dropdown-li-15").removeClass('active');
                } else {
                    $("#modalbar4-dropdown-li-15").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar4-dropdown-li-16").click(function() {
                // $("#modalbar4-dropdown-li-3").toggle();
                $("#modalbar4-dropdown-li-9").removeClass('active');
                $("#modalbar4-dropdown-li-11").removeClass('active');
                $("#modalbar4-dropdown-li-10").removeClass('active');
                $("#modalbar4-dropdown-li-8").removeClass('active');
                $("#modalbar4-dropdown-li-12").removeClass('active');
                $("#modalbar4-dropdown-li-13").removeClass('active');
                $("#modalbar4-dropdown-li-14").removeClass('active');
                $("#modalbar4-dropdown-li-15").removeClass('active');
                $("#modalbar4-list-9").hide();
                $("#modalbar4-list-11").hide();
                $("#modalbar4-list-10").hide();
                $("#modalbar4-list-8").hide();
                $("#modalbar4-list-12").hide();
                $("#modalbar4-list-13").hide();
                $("#modalbar4-list-14").hide();
                $("#modalbar4-list-15").hide();
                $("#modalbar4-list-16").toggle();
                if ($("#modalbar4-dropdown-li-16").hasClass('active')) {
                    $("#modalbar4-dropdown-li-16").removeClass('active');
                } else {
                    $("#modalbar4-dropdown-li-16").addClass('active');


                }
            });


 $("#modalbar4-dropdown-li-9").click(function() {
                // $("#modalbar4-dropdown-li-2").toggle();
                $("#modalbar4-dropdown-li-8").removeClass('active');
                $("#modalbar4-dropdown-li-11").removeClass('active');
                $("#modalbar4-dropdown-li-10").removeClass('active');
                $("#modalbar4-dropdown-li-12").removeClass('active');
                $("#modalbar4-dropdown-li-13").removeClass('active');
                $("#modalbar4-dropdown-li-14").removeClass('active');
                $("#modalbar4-dropdown-li-15").removeClass('active');
                $("#modalbar4-dropdown-li-16").removeClass('active');
                $("#modalbar4-list-8").hide();
                $("#modalbar4-list-11").hide();
                $("#modalbar4-list-13").hide();
                $("#modalbar4-list-14").hide();
                $("#modalbar4-list-15").hide();
                $("#modalbar4-list-16").hide();
                $("#modalbar4-list-9").toggle();
                if ($("#modalbar4-dropdown-li-9").hasClass('active')) {
                    $("#modalbar4-dropdown-li-9").removeClass('active');
                } else {
                    $("#modalbar4-dropdown-li-9").addClass('active');

                }
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id6").hover(function() {
                // $("#modalbar4-dropdown-li-2").toggle();
                $("#modalbar4-list-8").hide();
                $("#modalbar4-list-9").hide();
                $("#modalbar4-list-11").hide();
                $("#modalbar4-list-10").hide();
                $("#modalbar4-list-12").hide();
                $("#modalbar4-list-13").hide();
                $("#modalbar4-list-14").hide();
                $("#modalbar4-list-15").hide();
                $("#modalbar4-list-16").hide();
                $("#modalbar4-dropdown-li-8").removeClass('active');
                $("#modalbar4-dropdown-li-9").removeClass('active');
                $("#modalbar4-dropdown-li-11").removeClass('active');
                $("#modalbar4-dropdown-li-10").removeClass('active');
                $("#modalbar4-dropdown-li-12").removeClass('active');
                $("#modalbar4-dropdown-li-13").removeClass('active');
                $("#modalbar4-dropdown-li-14").removeClass('active');
                $("#modalbar4-dropdown-li-15").removeClass('active');
                $("#modalbar4-dropdown-li-16").removeClass('active');
            });
			
 /////////////////////////////////////////
            $("#modalbar4-dropdown-li-10").click(function() {
                // $("#modalbar4-dropdown-li-8").removeClass('active');
                $("#modalbar4-dropdown-li-9").removeClass('active');
                $("#modalbar4-dropdown-li-11").removeClass('active');
                $("#modalbar4-dropdown-li-12").removeClass('active');
                $("#modalbar4-dropdown-li-13").removeClass('active');
                $("#modalbar4-dropdown-li-14").removeClass('active');
                $("#modalbar4-dropdown-li-15").removeClass('active');
                $("#modalbar4-dropdown-li-16").removeClass('active');
                $("#modalbar4-list-10").toggle();
                if ($("#modalbar4-dropdown-li-10").hasClass('active')) {
                    $("#modalbar4-dropdown-li-10").removeClass('active');
                } else {
                    $("#modalbar4-dropdown-li-10").addClass('active');

                }
            });
            //////////////////////
            $("#modalbar4-dropdown-li-11").click(function() {
                // $("#modalbar4-dropdown-li-3").toggle();
                $("#modalbar4-dropdown-li-8").removeClass('active');
                $("#modalbar4-dropdown-li-9").removeClass('active');
                $("#modalbar4-dropdown-li-10").removeClass('active');
                $("#modalbar4-dropdown-li-12").removeClass('active');
                $("#modalbar4-dropdown-li-13").removeClass('active');
                $("#modalbar4-dropdown-li-14").removeClass('active');
                $("#modalbar4-dropdown-li-15").removeClass('active');
                $("#modalbar4-dropdown-li-16").removeClass('active');
                $("#modalbar4-list-9").hide();
                $("#modalbar4-list-13").hide();
                $("#modalbar4-list-14").hide();
                $("#modalbar4-list-15").hide();
                $("#modalbar4-list-16").hide();
                $("#modalbar4-list-8").hide();
                $("#modalbar4-list-11").toggle();
                if ($("#modalbar4-dropdown-li-11").hasClass('active')) {
                    $("#modalbar4-dropdown-li-11").removeClass('active');
                } else {
                    $("#modalbar4-dropdown-li-11").addClass('active');

                }
            });
            /////////////////////////////
            $("#modalbar4-dropdown-li-12").click(function() {
                $("#modalbar4-dropdown-li-8").removeClass('active');
                $("#modalbar4-dropdown-li-9").removeClass('active');
                // $("#modalbar4-dropdown-li-11").removeClass('active');
                $("#modalbar4-dropdown-li-10").removeClass('active');
                $("#modalbar4-dropdown-li-13").removeClass('active');
                $("#modalbar4-dropdown-li-14").removeClass('active');
                $("#modalbar4-dropdown-li-15").removeClass('active');
                $("#modalbar4-dropdown-li-16").removeClass('active');
                $("#modalbar4-list-12").toggle();
                if ($("#modalbar4-dropdown-li-12").hasClass('active')) {
                    $("#modalbar4-dropdown-li-12").removeClass('active');
                } else {
                    $("#modalbar4-dropdown-li-12").addClass('active');

                }
            });
						
$("#plus-mode6").click(function() {
                // $("#modalbar2-dropdown-li-3").toggle();

                $("#modal-mode6").toggle();
            });

            ////////////////////////
            $("#modalbar5-dropdown-li-8").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#modalbar5-dropdown-li-9").removeClass('active');
                $("#modalbar5-dropdown-li-11").removeClass('active');
                $("#modalbar5-dropdown-li-10").removeClass('active');
                $("#modalbar5-dropdown-li-12").removeClass('active');
                $("#modalbar5-dropdown-li-13").removeClass('active');
                $("#modalbar5-dropdown-li-14").removeClass('active');
                $("#modalbar5-dropdown-li-15").removeClass('active');
                $("#modalbar5-dropdown-li-16").removeClass('active');
                $("#modalbar5-list-9").hide();
                $("#modalbar5-list-10").hide();
                $("#modalbar5-list-11").hide();
                $("#modalbar5-list-15").hide();
                $("#modalbar5-list-16").hide();
                $("#modalbar5-list-13").hide();
                $("#modalbar5-list-12").hide();
                $("#modalbar5-list-14").hide();
                $("#modalbar5-dropdown-li-10").hide();
                $("#modalbar5-list-8").toggle();
                if ($("#modalbar5-dropdown-li-8").hasClass('active')) {
                    $("#modalbar5-dropdown-li-8").removeClass('active');
                } else {
                    $("#modalbar5-dropdown-li-8").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar5-dropdown-li-13").click(function() {
                // $("#modalbar5-dropdown-li-3").toggle();
                $("#modalbar5-dropdown-li-9").removeClass('active');
                $("#modalbar5-dropdown-li-11").removeClass('active');
                $("#modalbar5-dropdown-li-10").removeClass('active');
                $("#modalbar5-dropdown-li-12").removeClass('active');
                $("#modalbar5-dropdown-li-14").removeClass('active');
                $("#modalbar5-dropdown-li-8").removeClass('active');
                $("#modalbar5-dropdown-li-15").removeClass('active');
                $("#modalbar5-dropdown-li-16").removeClass('active');
                $("#modalbar5-list-9").hide();
                $("#modalbar5-list-11").hide();
                $("#modalbar5-list-14").hide();
                $("#modalbar5-list-15").hide();
                $("#modalbar5-list-12").hide();
                $("#modalbar5-list-16").hide();
                $("#modalbar5-list-8").hide();
                $("#modalbar5-list-10").hide();
                $("#modalbar5-list-13").toggle();
                if ($("#modalbar5-dropdown-li-13").hasClass('active')) {
                    $("#modalbar5-dropdown-li-13").removeClass('active');
                } else {
                    $("#modalbar5-dropdown-li-13").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar5-dropdown-li-14").click(function() {
                // $("#modalbar5-dropdown-li-3").toggle();
                $("#modalbar5-dropdown-li-9").removeClass('active');
                $("#modalbar5-dropdown-li-11").removeClass('active');
                $("#modalbar5-dropdown-li-10").removeClass('active');
                $("#modalbar5-dropdown-li-12").removeClass('active');
                $("#modalbar5-dropdown-li-13").removeClass('active');
                $("#modalbar5-dropdown-li-15").removeClass('active');
                $("#modalbar5-dropdown-li-16").removeClass('active');
                $("#modalbar5-dropdown-li-8").removeClass('active');
                $("#modalbar5-list-9").hide();
                $("#modalbar5-list-11").hide();
                $("#modalbar5-list-13").hide();
                $("#modalbar5-list-15").hide();
                $("#modalbar5-list-12").hide();
                $("#modalbar5-list-16").hide();
                $("#modalbar5-list-8").hide();
                $("#modalbar5-list-14").toggle();
                if ($("#modalbar5-dropdown-li-14").hasClass('active')) {
                    $("#modalbar5-dropdown-li-14").removeClass('active');
                } else {
                    $("#modalbar5-dropdown-li-14").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar5-dropdown-li-15").click(function() {
                // $("#modalbar5-dropdown-li-3").toggle();
                $("#modalbar5-dropdown-li-9").removeClass('active');
                $("#modalbar5-dropdown-li-11").removeClass('active');
                $("#modalbar5-dropdown-li-10").removeClass('active');
                $("#modalbar5-dropdown-li-12").removeClass('active');
                $("#modalbar5-dropdown-li-14").removeClass('active');
                $("#modalbar5-dropdown-li-13").removeClass('active');
                $("#modalbar5-dropdown-li-16").removeClass('active');
                $("#modalbar5-dropdown-li-8").removeClass('active');
                $("#modalbar5-list-9").hide();
                $("#modalbar5-list-11").hide();
                $("#modalbar5-list-8").hide();
                $("#modalbar5-list-10").hide();
                $("#modalbar5-list-12").hide();
                $("#modalbar5-list-13").hide();
                $("#modalbar5-list-14").hide();
                $("#modalbar5-list-16").hide();
                $("#modalbar5-list-15").toggle();
                if ($("#modalbar5-dropdown-li-15").hasClass('active')) {
                    $("#modalbar5-dropdown-li-15").removeClass('active');
                } else {
                    $("#modalbar5-dropdown-li-15").addClass('active');


                }
            });
            ////////////////////////
            $("#modalbar5-dropdown-li-16").click(function() {
                // $("#modalbar5-dropdown-li-3").toggle();
                $("#modalbar5-dropdown-li-9").removeClass('active');
                $("#modalbar5-dropdown-li-11").removeClass('active');
                $("#modalbar5-dropdown-li-10").removeClass('active');
                $("#modalbar5-dropdown-li-8").removeClass('active');
                $("#modalbar5-dropdown-li-12").removeClass('active');
                $("#modalbar5-dropdown-li-13").removeClass('active');
                $("#modalbar5-dropdown-li-14").removeClass('active');
                $("#modalbar5-dropdown-li-15").removeClass('active');
                $("#modalbar5-list-9").hide();
                $("#modalbar5-list-11").hide();
                $("#modalbar5-list-10").hide();
                $("#modalbar5-list-8").hide();
                $("#modalbar5-list-12").hide();
                $("#modalbar5-list-13").hide();
                $("#modalbar5-list-14").hide();
                $("#modalbar5-list-15").hide();
                $("#modalbar5-list-16").toggle();
                if ($("#modalbar5-dropdown-li-16").hasClass('active')) {
                    $("#modalbar5-dropdown-li-16").removeClass('active');
                } else {
                    $("#modalbar5-dropdown-li-16").addClass('active');


                }
            });

 $("#modalbar5-dropdown-li-9").click(function() {
                // $("#modalbar5-dropdown-li-2").toggle();
                $("#modalbar5-dropdown-li-8").removeClass('active');
                $("#modalbar5-dropdown-li-11").removeClass('active');
                $("#modalbar5-dropdown-li-10").removeClass('active');
                $("#modalbar5-dropdown-li-12").removeClass('active');
                $("#modalbar5-dropdown-li-13").removeClass('active');
                $("#modalbar5-dropdown-li-14").removeClass('active');
                $("#modalbar5-dropdown-li-15").removeClass('active');
                $("#modalbar5-dropdown-li-16").removeClass('active');
                $("#modalbar5-list-8").hide();
                $("#modalbar5-list-11").hide();
                $("#modalbar5-list-13").hide();
                $("#modalbar5-list-14").hide();
                $("#modalbar5-list-15").hide();
                $("#modalbar5-list-16").hide();
                $("#modalbar5-list-9").toggle();
                if ($("#modalbar5-dropdown-li-9").hasClass('active')) {
                    $("#modalbar5-dropdown-li-9").removeClass('active');
                } else {
                    $("#modalbar5-dropdown-li-9").addClass('active');

                }
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id7").hover(function() {
                // $("#modalbar5-dropdown-li-2").toggle();
                $("#modalbar5-list-8").hide();
                $("#modalbar5-list-9").hide();
                $("#modalbar5-list-11").hide();
                $("#modalbar5-list-10").hide();
                $("#modalbar5-list-12").hide();
                $("#modalbar5-list-13").hide();
                $("#modalbar5-list-14").hide();
                $("#modalbar5-list-15").hide();
                $("#modalbar5-list-16").hide();
                $("#modalbar5-dropdown-li-8").removeClass('active');
                $("#modalbar5-dropdown-li-9").removeClass('active');
                $("#modalbar5-dropdown-li-11").removeClass('active');
                $("#modalbar5-dropdown-li-10").removeClass('active');
                $("#modalbar5-dropdown-li-12").removeClass('active');
                $("#modalbar5-dropdown-li-13").removeClass('active');
                $("#modalbar5-dropdown-li-14").removeClass('active');
                $("#modalbar5-dropdown-li-15").removeClass('active');
                $("#modalbar5-dropdown-li-16").removeClass('active');
            });

/////////////////////////////////////////
            $("#modalbar5-dropdown-li-10").click(function() {
                // $("#modalbar5-dropdown-li-8").removeClass('active');
                $("#modalbar5-dropdown-li-9").removeClass('active');
                $("#modalbar5-dropdown-li-11").removeClass('active');
                $("#modalbar5-dropdown-li-12").removeClass('active');
                $("#modalbar5-dropdown-li-13").removeClass('active');
                $("#modalbar5-dropdown-li-14").removeClass('active');
                $("#modalbar5-dropdown-li-15").removeClass('active');
                $("#modalbar5-dropdown-li-16").removeClass('active');
                $("#modalbar5-list-10").toggle();
                if ($("#modalbar5-dropdown-li-10").hasClass('active')) {
                    $("#modalbar5-dropdown-li-10").removeClass('active');
                } else {
                    $("#modalbar5-dropdown-li-10").addClass('active');

                }
            });
            //////////////////////
            $("#modalbar5-dropdown-li-11").click(function() {
                // $("#modalbar5-dropdown-li-3").toggle();
                $("#modalbar5-dropdown-li-8").removeClass('active');
                $("#modalbar5-dropdown-li-9").removeClass('active');
                $("#modalbar5-dropdown-li-10").removeClass('active');
                $("#modalbar5-dropdown-li-12").removeClass('active');
                $("#modalbar5-dropdown-li-13").removeClass('active');
                $("#modalbar5-dropdown-li-14").removeClass('active');
                $("#modalbar5-dropdown-li-15").removeClass('active');
                $("#modalbar5-dropdown-li-16").removeClass('active');
                $("#modalbar5-list-9").hide();
                $("#modalbar5-list-13").hide();
                $("#modalbar5-list-14").hide();
                $("#modalbar5-list-15").hide();
                $("#modalbar5-list-16").hide();
                $("#modalbar5-list-8").hide();
                $("#modalbar5-list-11").toggle();
                if ($("#modalbar5-dropdown-li-11").hasClass('active')) {
                    $("#modalbar5-dropdown-li-11").removeClass('active');
                } else {
                    $("#modalbar5-dropdown-li-11").addClass('active');

                }
            });
            /////////////////////////////
            $("#modalbar5-dropdown-li-12").click(function() {
                $("#modalbar5-dropdown-li-8").removeClass('active');
                $("#modalbar5-dropdown-li-9").removeClass('active');
                // $("#modalbar5-dropdown-li-11").removeClass('active');
                $("#modalbar5-dropdown-li-10").removeClass('active');
                $("#modalbar5-dropdown-li-13").removeClass('active');
                $("#modalbar5-dropdown-li-14").removeClass('active');
                $("#modalbar5-dropdown-li-15").removeClass('active');
                $("#modalbar5-dropdown-li-16").removeClass('active');
                $("#modalbar5-list-12").toggle();
                if ($("#modalbar5-dropdown-li-12").hasClass('active')) {
                    $("#modalbar5-dropdown-li-12").removeClass('active');
                } else {
                    $("#modalbar5-dropdown-li-12").addClass('active');

                }
            });
			//new 31-08 podium
          $("#zone.form-control").selectpicker();
		  $("#endtime.form-control").selectpicker();
		  $("#starttime.form-control").selectpicker();
		  $("#score.form-control").selectpicker();
		  $("#status.form-control").selectpicker();
		  $("#level.form-control").selectpicker();
		  
		  //modal 31-08
		  
		  
		  $("#exampleFormControlSelect1.form-control").selectpicker();
		  $("#exampleFormControlSelect2.form-control").selectpicker();
		  $("#exampleFormControlSelect3.form-control").selectpicker();
		  $("#exampleFormControlSelect4.form-control").selectpicker();
		  $("#exampleFormControlSelect14.form-control").selectpicker();
		  $("#exampleFormControlSelect15.form-control").selectpicker();
		  $("#exampleFormControlSelect16.form-control").selectpicker();
		  $("#exampleFormControlSelect17.form-control").selectpicker();
		  $("#exampleFormControlSelect18.form-control").selectpicker();
		  $("#start_time.form-control").selectpicker();
		  $("#end_time.form-control").selectpicker();
		  $("#timezone.form-control").selectpicker();
		  
		  
		  //modal2 31-08
		  
		  
		  $("#exampleFormControlSelect5.form-control").selectpicker();
		  $("#exampleFormControlSelect6.form-control").selectpicker();
		  $("#exampleFormControlSelect7.form-control").selectpicker();
		  $("#exampleFormControlSelect8.form-control").selectpicker();
		   $("#exampleFormControlSelect9.form-control").selectpicker();
		  $("#exampleFormControlSelect10.form-control").selectpicker();
		  $("#exampleFormControlSelect11.form-control").selectpicker();
		  $("#exampleFormControlSelect12.form-control").selectpicker();
		  $("#exampleFormControlSelect13.form-control").selectpicker();
		  

$("#plus-mode").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();

                $("#modal-mode").toggle();
            });
            $("#sidebar-dropdown-li-2").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-list-3").hide();
                $("#sidebar-list-5").hide();
                $("#sidebar-list-4").hide();
                $("#sidebar-list-2").toggle();
            });
            ////////////////////////
            $("#sidebar-dropdown-li-8").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-dropdown-li-10").hide();
                $("#sidebar-list-8").toggle();
                if ($("#sidebar-dropdown-li-8").hasClass('active')) {
                    $("#sidebar-dropdown-li-8").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-8").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-13").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-13").toggle();
                if ($("#sidebar-dropdown-li-13").hasClass('active')) {
                    $("#sidebar-dropdown-li-13").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-13").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-14").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-14").toggle();
                if ($("#sidebar-dropdown-li-14").hasClass('active')) {
                    $("#sidebar-dropdown-li-14").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-14").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-15").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-15").toggle();
                if ($("#sidebar-dropdown-li-15").hasClass('active')) {
                    $("#sidebar-dropdown-li-15").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-15").addClass('active');


                }
            });
            ////////////////////////
            $("#sidebar-dropdown-li-16").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").toggle();
                if ($("#sidebar-dropdown-li-16").hasClass('active')) {
                    $("#sidebar-dropdown-li-16").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-16").addClass('active');


                }
            });

$("#sidebar-dropdown-li-3").click(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-list-2").hide();
                $("#sidebar-list-5").hide();
                $("#sidebar-list-3").toggle();
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id").hover(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-list-2").hide();
                $("#sidebar-list-3").hide();
                $("#sidebar-list-5").hide();
                $("#sidebar-list-4").hide();
                $("#sidebar-list-6").hide();
            });
            /////////////////////////////////////////////////////////////////
            $("#sidebar-dropdown-li-9").click(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-8").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-9").toggle();
                if ($("#sidebar-dropdown-li-9").hasClass('active')) {
                    $("#sidebar-dropdown-li-9").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-9").addClass('active');

                }
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id2").hover(function() {
                // $("#sidebar-dropdown-li-2").toggle();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
            });

$("#sidebar-dropdown-li-4").click(function() {
                $("#sidebar-list-4").toggle();
            });
            //////////////////////
            $("#sidebar-dropdown-li-5").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-list-3").hide();
                $("#sidebar-list-2").hide();
                $("#sidebar-list-5").toggle();
            });
            /////////////////////////////
            $("#sidebar-dropdown-li-6").click(function() {
                $("#sidebar-list-6").toggle();
            });
            /////////////////////////////

            /////////////////////////////////////////
            $("#sidebar-dropdown-li-10").click(function() {
                // $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-10").toggle();
                if ($("#sidebar-dropdown-li-10").hasClass('active')) {
                    $("#sidebar-dropdown-li-10").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-10").addClass('active');

                }
            });
            //////////////////////
            $("#sidebar-dropdown-li-11").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-9").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $("#sidebar-list-8").hide();
                $("#sidebar-list-11").toggle();
                if ($("#sidebar-dropdown-li-11").hasClass('active')) {
                    $("#sidebar-dropdown-li-11").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-11").addClass('active');

                }
            });
            /////////////////////////////
            $("#sidebar-dropdown-li-12").click(function() {
                $("#sidebar-dropdown-li-8").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                // $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
                $("#sidebar-list-12").toggle();
                if ($("#sidebar-dropdown-li-12").hasClass('active')) {
                    $("#sidebar-dropdown-li-12").removeClass('active');
                } else {
                    $("#sidebar-dropdown-li-12").addClass('active');

                }
            });
			
			 $("#modal2-btn-1").click(function() {
                $("#clients-modal1").hide();
                $("#clients-modal2").show();
            });
            $("#modal2-btn-2").click(function() {
                $("#clients-modal2").hide();
                $("#clients-modal3").show();
            });
            $("#modal2-btn-3").click(function() {
				$("#clients-modal1").hide();							  
                $("#clients-modal3").hide();
                $("#clients-modal4").show();
            });
            $("#modal2-btn-4").click(function() {
                $("#clients-modal1").hide();
                $("#clients-modal2").hide();
                $("#clients-modal3").hide();
                $("#clients-modal4").hide();
                $("#clients-modal5").show();
            });
            $("#modal2-btn-5").click(function() {
                $("#clients-modal5").hide();
                $("#clients-modal6").show();
            });
            $("#modal2-btn-6").click(function() {
                $("#clients-modal6").hide();
                $("#clients-modal7").show();
            });
            $("#modal2-btn-7").click(function() {
                $("#clients-modal5").hide();
                $("#clients-modal6").hide();
                $("#clients-modal7").hide();
                $("#clients-modal8").show();
            });
            $("#modal2-btn-8").click(function() {
                $("#clients-modal8").hide();
                $("#clients-modal9").show();
            });
            $("#modal2-btn-9").click(function() {
                $("#clients-modal8").hide();
                $("#clients-modal9").hide();
                $("#clients-modal10").show();
            });
            $("#modal2-btn-10").click(function() {
                $("#clients-modal10").hide();
                $("#clients-modal11").show();
            });
            $("#modal2-btn-11").click(function() {
                $("#clients-modal11").hide();
                $("#clients-modal12").show();
            });
            $("#modal2-btn-12").click(function() {
                $("#clients-modal8").hide();
                $("#clients-modal9").hide();
                $("#clients-modal10").hide();
                $("#clients-modal11").hide();
                $("#clients-modal12").hide();
                $("#clients-modal13").show();
            });
            $("#modal-btn-14").click(function() {
                $("#modal-no-14").hide();
                $("#modal-no-15").show();
            });



$("button").click(function() {
			$(".navbar-toggler-icon").toggleClass("active");
			speed: 0.5
});


$('.moreless-button1').click(function() {
  $('.more-text1').slideToggle();
  // $('.sanj').slideToggle();
  if ($('.moreless-button1').text() == "Read less") {
    $(this).text("Read more")
  } else {
    $(this).text("Read less")
  }
});

$('.moreless-button2').click(function() {
  $('.more-text2').slideToggle();
  if ($('.moreless-button2').text() == "Read more") {
    $(this).text("Read less")
  } else {
    $(this).text("Read more")
  }
});

$('.moreless-button3').click(function() {
  $('.more-text3').slideToggle();
  if ($('.moreless-button3').text() == "Read more") {
    $(this).text("Read less")
  } else {
    $(this).text("Read more")
  }
});

$('.moreless-button4').click(function() {
  $('.more-text4').slideToggle();
  if ($('.moreless-button4').text() == "Read more") {
    $(this).text("Read less")
  } else {
    $(this).text("Read more")
  }
});


$('.moreless-button-d1').click(function() {
  $('.more-text-d1').slideToggle();
  if ($('.moreless-button-d1').text() == "more") {
    $(this).text("less")
  } else {
    $(this).text("more more")
  }
});


$("#plus-mode2").click(function() {
                // $("#sidebar-dropdown-li-3").toggle();

                $("#table-mode2").toggle();
            });


            $("#table-dropdown-li-9").click(function() {
                // $("#table-dropdown-li-2").toggle();
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-8").hide();
                $("#table-list-11").hide();
                $("#table-list-13").hide();
                $("#table-list-14").hide();
                $("#table-list-15").hide();
                $("#table-list-16").hide();
                $("#table-list-9").toggle();
                if ($("#table-dropdown-li-9").hasClass('active')) {
                    $("#table-dropdown-li-9").removeClass('active');
                } else {
                    $("#table-dropdown-li-9").addClass('active');

                }
            });
            // ///////////////////////////////////////////////////////
            $(".fix_id3").hover(function() {
                // $("#table-dropdown-li-2").toggle();
                $("#table-list-8").hide();
                $("#table-list-9").hide();
                $("#table-list-11").hide();
                $("#table-list-10").hide();
                $("#table-list-12").hide();
                $("#table-list-13").hide();
                $("#table-list-14").hide();
                $("#table-list-15").hide();
                $("#table-list-16").hide();
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
            });


$("#table-dropdown-li-10").click(function() {
                // $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-10").toggle();
                if ($("#table-dropdown-li-10").hasClass('active')) {
                    $("#table-dropdown-li-10").removeClass('active');
                } else {
                    $("#table-dropdown-li-10").addClass('active');

                }
            });
            //////////////////////
            $("#table-dropdown-li-11").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-13").hide();
                $("#table-list-14").hide();
                $("#table-list-15").hide();
                $("#table-list-16").hide();
                $("#table-list-8").hide();
                $("#table-list-11").toggle();
                if ($("#table-dropdown-li-11").hasClass('active')) {
                    $("#table-dropdown-li-11").removeClass('active');
                } else {
                    $("#table-dropdown-li-11").addClass('active');

                }
            });
            /////////////////////////////
            $("#table-dropdown-li-12").click(function() {
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-9").removeClass('active');
                // $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-12").toggle();
                if ($("#table-dropdown-li-12").hasClass('active')) {
                    $("#table-dropdown-li-12").removeClass('active');
                } else {
                    $("#table-dropdown-li-12").addClass('active');

                }
            });
        });


        $(document).ready(function() {
            $("#table-dropdown-li-8").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-10").hide();
                $("#table-list-11").hide();
                $("#table-list-15").hide();
                $("#table-list-16").hide();
                $("#table-list-13").hide();
                $("#table-list-12").hide();
                $("#table-list-14").hide();
                $("#table-dropdown-li-10").hide();
                $("#table-list-8").toggle();
                if ($("#table-dropdown-li-8").hasClass('active')) {
                    $("#table-dropdown-li-8").removeClass('active');
                } else {
                    $("#table-dropdown-li-8").addClass('active');


                }
            });
            ////////////////////////
            $("#table-dropdown-li-13").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-11").hide();
                $("#table-list-14").hide();
                $("#table-list-15").hide();
                $("#table-list-12").hide();
                $("#table-list-16").hide();
                $("#table-list-8").hide();
                $("#table-list-10").hide();
                $("#table-list-13").toggle();
                if ($("#table-dropdown-li-13").hasClass('active')) {
                    $("#table-dropdown-li-13").removeClass('active');
                } else {
                    $("#table-dropdown-li-13").addClass('active');


                }
            });
            ////////////////////////
            $("#table-dropdown-li-14").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-11").hide();
                $("#table-list-13").hide();
                $("#table-list-15").hide();
                $("#table-list-12").hide();
                $("#table-list-16").hide();
                $("#table-list-8").hide();
                $("#table-list-14").toggle();
                if ($("#table-dropdown-li-14").hasClass('active')) {
                    $("#table-dropdown-li-14").removeClass('active');
                } else {
                    $("#table-dropdown-li-14").addClass('active');


                }
            });
            ////////////////////////
            $("#table-dropdown-li-15").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-16").removeClass('active');
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-11").hide();
                $("#table-list-8").hide();
                $("#table-list-10").hide();
                $("#table-list-12").hide();
                $("#table-list-13").hide();
                $("#table-list-14").hide();
                $("#table-list-16").hide();
                $("#table-list-15").toggle();
                if ($("#table-dropdown-li-15").hasClass('active')) {
                    $("#table-dropdown-li-15").removeClass('active');
                } else {
                    $("#table-dropdown-li-15").addClass('active');


                }
            });
            ////////////////////////
            $("#table-dropdown-li-16").click(function() {
                // $("#table-dropdown-li-3").toggle();
                $("#table-dropdown-li-9").removeClass('active');
                $("#table-dropdown-li-11").removeClass('active');
                $("#table-dropdown-li-10").removeClass('active');
                $("#table-dropdown-li-8").removeClass('active');
                $("#table-dropdown-li-12").removeClass('active');
                $("#table-dropdown-li-13").removeClass('active');
                $("#table-dropdown-li-14").removeClass('active');
                $("#table-dropdown-li-15").removeClass('active');
                $("#table-list-9").hide();
                $("#table-list-11").hide();
                $("#table-list-10").hide();
                $("#table-list-8").hide();
                $("#table-list-12").hide();
                $("#table-list-13").hide();
                $("#table-list-14").hide();
                $("#table-list-15").hide();
                $("#table-list-16").toggle();
                if ($("#table-dropdown-li-16").hasClass('active')) {
                    $("#table-dropdown-li-16").removeClass('active');
                } else {
                    $("#table-dropdown-li-16").addClass('active');


                }
            });


$('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
	  if (!$(this).next().hasClass('show')) {
		$(this).parents('.dropdown-menu').first().find('.show').removeClass('show');
	  }
	  var $subMenu = $(this).next('.dropdown-menu');
	  $subMenu.toggleClass('show');
	
	
	  $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
		$('.dropdown-submenu .show').removeClass('show');
	  });
	  return false;
	});

$(".fix_id").hover(function() {
   $('.dropdown-submenu .show').removeClass('show');     
  });


	
            // $('.total-bd-area').click(function(){
            //  $('.profile-hover-details3').slideUp();
            // });
 
/*  $(".show-details-new1").hover(function() {
		$(".new-show-div1").show();
	     }, function() {
		 $(".new-show-div1").hide();
 });*/
 
 $(".show-details-new2").hover(function() {
		$(".new-show-div2").show();
	     }, function() {
		 $(".new-show-div2").hide();
 });
 $(".show-details-new3").hover(function() {
		$(".new-show-div3").show();
	     }, function() {
		 $(".new-show-div3").hide();
 });
  $(".show-details-new4").hover(function() {
		$(".new-show-div4").show();
	     }, function() {
		 $(".new-show-div4").hide();
 });
});



 $(document).ready(function(){
		  $(".owl-carousel").owlCarousel({
			autoplay: true,
			dots: false,
			nav: true,
			autoplayTimeout: 5000,
			autoplayHoverPause: true,
			lazyLoad: true,
			loop: true,
			responsive : {
			// breakpoint from 0 up
			0 : {
				items:1,
			},
			// breakpoint from 480 up
			480 : {
				items:1,
			},
			// breakpoint from 768 up
			768 : {
				items:1,
			}
		}
		  });		

});

    $(document).ready(function() {

        $('#example').DataTable({
            "lengthMenu": [
                [10, 100, 200, 300, -1],
                [10, 100, 200, 300, "All"]
            ],
            "aaSorting": [
                [0, 'desc']
            ]
        });

        $('#example2').DataTable({
            "lengthMenu": [
                [10, 100, 200, 300, -1],
                [10, 100, 200, 300, "All"]
            ],
            "aaSorting": [
                [0, 'desc']
            ]
        });

        $('#example3').DataTable({
            "lengthMenu": [
                [40, 100, 200, 300, -1],
                [40, 100, 200, 300, "All"]
            ],
            "aaSorting": [
                [0, 'asc']
            ]
        });
    });

//
//$( ".list-non-active a" ).click(function() {
//  $( this ).toggleClass( "highlight" );
//});


$( ".right-sec-post a" ).click(function() {
  $( this ).toggleClass( "highlight" );
});

$( ".up" ).click(function() {
  $( this ).toggleClass( "highlight" );
});

$( ".follow a" ).click(function() {
  $( this ).toggleClass( "highlight" );
});

$( ".up" ).click(function() {
  $( this ).toggleClass( "highlight" );
});

$( ".download a" ).click(function() {
  $( this ).toggleClass( "highlight" );
});
$( ".up" ).click(function() {
  $( this ).toggleClass( "highlight" );
});

$(document).ready(function(){

  
   
  $("#show2").click(function(){
    $(".chat2").show();
  });
  $(document).ready(function(){
  $("#hide3").click(function(){
    $(".chat3").hide();
  });
  $("#show3").click(function(){
    $(".chat3").show();
	 });
   });
  });
 


$('#click_advance').click(function(){
$('#display_advance').toggle('1000');
$(this).html('<i class="fas fa-minus "></i> Undo');
});
$('.clk a').click(function(){
    $(this).find('i').toggleClass('fas fa-close fas fa-chevron-down');
});



function switchVisible() {
            if (document.getElementById('Div1')) {

                if (document.getElementById('Div1').style.display == 'none') {
                    document.getElementById('Div1').style.display = 'block';
                    document.getElementById('Div2').style.display = 'none';
                }
                else {
                    document.getElementById('Div1').style.display = 'none';
                    document.getElementById('Div2').style.display = 'block';
                }
            }
}










$('.clk2 a').click(function(){
    $(this).find('i').toggleClass('fas fa-close fas fa-chevron-down');
});

$('.clk2 a').click(function() {
            if (document.getElementById('Div3')) {

                if (document.getElementById('Div3').style.display == 'none') {
                    document.getElementById('Div3').style.display = 'block';
                    document.getElementById('Div4').style.display = 'none';
                }
                else {
                    document.getElementById('Div3').style.display = 'none';
                    document.getElementById('Div4').style.display = 'block';
                }
            }
});



$('.clk3 a').click(function(){
    $(this).find('i').toggleClass('fas fa-plus-circle far fa-check-circle');
});


$('.comon-text-a-1').click(function(){
    $(this).find('.icon-1').toggleClass('fas fa-check');
});

      /////////////////////////  Multiple Dropdown ///////////////////
         /*$('.sa-select').click(function() {
            var favorite = [];
            $.each($("input[name='days[]']:checked"), function(){
            favorite.push($(this).val());
            });
            var days = favorite.join(",");
            $('#days').val(favorite.join(","));
            // alert("My favourite sports are: " + days);
            if( $(this).hasClass('active'))
            {
                         
              $(this).removeClass('active');
              $('.dropdown-menu-spl').slideUp();  
            }else
            {
              $(this).addClass('active');
              $('.dropdown-menu-spl').slideDown();  
            }
        });
          $('#Alldays').click(function() {
           $('#Monday').prop( "checked", true );
           $('#Tuesday').prop( "checked", true );
           $('#Wednesday').prop( "checked", true );
           $('#Thursday').prop( "checked", true );
           $('#Friday').prop( "checked", true );
           $('#Saturday').prop( "checked", true );
           $('#Sunday').prop( "checked", true );
            var favorite = [];
            $.each($("input[name='days[]']:checked"), function(){
            favorite.push($(this).val());
            });
            var days = favorite.join(",");
            var day=$('#days').val(days);
            // alert("My favourite sports are: " + favorite.join(", "));
        });
          $('#Weekdays').click(function() {
           $('#Monday').prop( "checked", true );
           $('#Tuesday').prop( "checked", true );
           $('#Wednesday').prop( "checked", true );
           $('#Thursday').prop( "checked", true );
           $('#Friday').prop( "checked", true );
           $('#Saturday').prop( "checked", false );
           $('#Sunday').prop( "checked", false );
            var favorite = [];
            $.each($("input[name='days[]']:checked"), function(){
            favorite.push($(this).val());
            });
            var days = favorite.join(",");
            var day=$('#days').val(days);
            // alert("My favourite sports are: " + favorite.join(", "));
        });
           $('#Weekends').click(function() {
           $('#Monday').prop( "checked", false );
           $('#Tuesday').prop( "checked", false );
           $('#Wednesday').prop( "checked", false );
           $('#Thursday').prop( "checked", false );
           $('#Friday').prop( "checked", false );
           $('#Saturday').prop( "checked", true );
           $('#Sunday').prop( "checked", true );
            var favorite = [];
            $.each($("input[name='days[]']:checked"), function(){
            favorite.push($(this).val());

            });
            var days = favorite.join(",");
            var day=$('#days').val(days);
            // alert("My favourite sports are: " + favorite.join(", "));
        });
  


        // $('.dropdown-spl').focusout(function() {
        //     $(this).removeClass('active');
        //     $(this).find('.dropdown-menu-spl').slideUp(300);
        // });
        $('.dropdown-spl .dropdown-menu-spl li').click(function() {
            $(this).parents('.dropdown-spl').find('span').text($(this).text());
            $(this).parents('.dropdown-spl').find('input').attr('value', $(this).attr('id'));
        });*/
        /*End Dropdown Menu*/

      /////////////////////////  Multiple Dropdown ///////////////////

        // $('.dropdown-menu-spl li').click(function() {
        //     var input = '<strong>' + $(this).parents('.dropdown-spl').find('input').val() + '</strong>',
        //         msg = '<span class="msg">Hidden input value: ';
        //     $('.msg').html(msg + input + '</span>');
        // });
      


$(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  }).datepicker('update', new Date());
});
$(function () {
  $("#datepicker1").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  }).datepicker('update', new Date());
});




//
//$(document).ready(function(){
//  $('.dropdown-submenu a.menu1').on("click", function(e){
//    $(this).next('ul').toggle();
//    e.stopPropagation();
//    e.preventDefault();
//   
//  });
//  $('.dropdown-submenu a.menu2').on("click", function(e){
//    $(this).next('ul').toggle();
//    e.stopPropagation();
//    e.preventDefault();
//
//  });
//  $('.dropdown-submenu a.menu3').on("click", function(e){
//    $(this).next('ul').toggle();
//    e.stopPropagation();
//    e.preventDefault();
//  });
//  $('.dropdown-submenu a.menu4').on("click", function(e){
//    $(this).next('ul').toggle();
//    e.stopPropagation();
//    e.preventDefault();
//  });
//  $('.dropdown-submenu a.menu5').on("click", function(e){
//    $(this).next('ul').toggle();
//    e.stopPropagation();
//    e.preventDefault();
//	
//  });
// 
//});


<!--13-07-2020------->


$('.moreless-button-new').click(function() {
  $('.more-text1').show();
  $('.moreless-button-new').hide();
});

$('#moreless-button-new2').click(function() {
  $('#more-text1-dv1').show();
 $('#moreless-button-new2').hide();
});


$('#moreless-button-new3').click(function() {
  $('#more-text1-dv2').show();
 $('#moreless-button-new3').hide();
});


$("#hide-dl").click(function(){
  $(".chat-dl").hide();
});
$("#show-dl").click(function(){
  $(".chat-dl").show();
});


$("#hide-d3").click(function(){
  $(".chat-d3").hide();
});
$("#show-d3").click(function(){
  $(".chat-d3").show();
});

$("#hide-d4").click(function(){
  $(".chat-d4").hide();
});
$("#show-d4").click(function(){
  $(".chat-d4").show();
});


$("#hide-d5").click(function(){
  $("#chat-d5").hide();
});
$("#show-d5").click(function(){
  $("#chat-d5").show();
});



<!--detal-s 16-07-->
$("#hide-d5-dv").click(function(){
  $(".chat2-new2-dv").hide();
});
$("#show-dv1").click(function(){
  $(".chat2-new2-dv").show();
});

$("#hide-d6").click(function(){
  $("#chat-d6").hide();
});
$("#show-d6").click(function(){
  $("#chat-d6").show();
});


$("#hide-d7").click(function(){
  $("#chat-d7").hide();
});
$("#show-d7").click(function(){
  $("#chat-d7").show();
});

/*18-07*/

$("#hide-d8").click(function(){
  $("#chat-d8").hide();
});
$("#show-d8").click(function(){
  $("#chat-d8").show();
});

$("#hide-d9").click(function(){
  $("#chat-d9").hide();
});
$("#show-d9").click(function(){
  $("#chat-d9").show();
});

$("#hide-d10").click(function(){
  $("#chat-d10").hide();
});
$("#show-d10").click(function(){
  $("#chat-d10").show();
});



$("#hide-d11").click(function(){
  $("#chat-d11").hide();
});
$("#show-d11").click(function(){
  $("#chat-d11").show();
});
$("#hide-d12").click(function(){
  $("#chat-d12").hide();
});
$("#show-d12").click(function(){
  $("#chat-d12").show();
});
$("#hide-d13").click(function(){
  $("#chat-d13").hide();
});
$("#show-d13").click(function(){
  $("#chat-d13").show();
});



<!--13-07-2020 ends------->




$(".sparte").hover(function() {
                // $("#sidebar-dropdown-li-2").toggle();
//                $("").hide();14-09
                $("#sidebar-list-9").hide();
                $("#sidebar-list-11").hide();
                $("#sidebar-list-10").hide();
                $("#sidebar-list-12").hide();
                $("#sidebar-list-13").hide();
                $("#sidebar-list-14").hide();
                $("#sidebar-list-15").hide();
                $("#sidebar-list-16").hide();
                $(".new-1").removeClass('active');
                $("#sidebar-dropdown-li-9").removeClass('active');
                $("#sidebar-dropdown-li-11").removeClass('active');
                $("#sidebar-dropdown-li-10").removeClass('active');
                $("#sidebar-dropdown-li-12").removeClass('active');
                $("#sidebar-dropdown-li-13").removeClass('active');
                $("#sidebar-dropdown-li-14").removeClass('active');
                $("#sidebar-dropdown-li-15").removeClass('active');
                $("#sidebar-dropdown-li-16").removeClass('active');
            });



$(".profile-special1").hover(function() {
		// $("#sidebar-dropdown-li-2").toggle();
		$(".profile-hover-details1").show();
		$(".profile-hover-details2").hide();
		$(".profile-hover-details3").hide();
	});

	$(".profile-special2").hover(function() {
		// $("#sidebar-dropdown-li-2").toggle();
		$(".profile-hover-details2").show();
		$(".profile-hover-details1").hide();
		$(".profile-hover-details3").hide();
	});

	$(".profile-special3").hover(function() {
		// $("#sidebar-dropdown-li-2").toggle();
		$(".profile-hover-details3").show();
		$(".profile-hover-details1").hide();
		$(".profile-hover-details2").hide();
	});
	$(".profile-spl-anchor").hover(function() {
		// $("#sidebar-dropdown-li-2").toggle();
		$(".profile-hover-details").hide();

	});




$(document).ready(function() {
	  $("#toggle-more1").click(function() {
		  var elem = $("#toggle-more1").text();
		  if (elem == "More...") {
			  //Stuff to do when btn is in the read more state
			  $("#toggle-more1").text("Less...");
			  $("#more-list1").show();
		  } else {
			  //Stuff to do when btn is in the read less state
			  $("#toggle-more1").text("More...");
			  $("#more-list1").hide();
		  }
	  });
  });



$(document).ready(function() {
	$("#toggle-more2").click(function() {
		var elem = $("#toggle-more2").text();
		if (elem == "More...") {
			//Stuff to do when btn is in the read more state
			$("#toggle-more2").text("Less...");
			$("#more-list2").show();
		} else {
			//Stuff to do when btn is in the read less state
			$("#toggle-more2").text("More...");
			$("#more-list2").hide();
		}
	});
});



		
 $(document).ready(function() {
var telInput = $("#phone"),
            errorMsg = $("#error-msg"),
            validMsg = $("#valid-msg");

        // initialise plugin
        telInput.intlTelInput({

            allowExtensions: true,
            formatOnDisplay: true,
            autoFormat: true,
            autoHideDialCode: true,
            autoPlaceholder: true,
            defaultCountry: "auto",
            ipinfoToken: "yolo",

            nationalMode: false,
            numberType: "MOBILE",
            //onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
            preferredCountries: ['sa', 'ae', 'qa', 'om', 'bh', 'kw', 'ma'],
            preventInvalidNumbers: true,
            separateDialCode: true,
            initialCountry: "auto",
            geoIpLookup: function(callback) {
                $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
                    var countryCode = (resp && resp.country) ? resp.country : "";
                    callback(countryCode);
                });
            },
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/utils.js"
        });

        var reset = function() {
            telInput.removeClass("error");
            errorMsg.addClass("hide");
            validMsg.addClass("hide");
        };

        // on blur: validate
        telInput.blur(function() {
            reset();
            if ($.trim(telInput.val())) {
                if (telInput.intlTelInput("isValidNumber")) {
                    validMsg.removeClass("hide");
                } else {
                    telInput.addClass("error");
                    errorMsg.removeClass("hide");
                }
            }
        });

        // on keyup / change flag: reset
        telInput.on("keyup change", reset);
		

var telInput = $("#phone"),
            errorMsg = $("#error-msg"),
            validMsg = $("#valid-msg");

        // initialise plugin
        telInput.intlTelInput({

            allowExtensions: true,
            formatOnDisplay: true,
            autoFormat: true,
            autoHideDialCode: true,
            autoPlaceholder: true,
            defaultCountry: "auto",
            ipinfoToken: "yolo",

            nationalMode: false,
            numberType: "MOBILE",
            //onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
            preferredCountries: ['sa', 'ae', 'qa', 'om', 'bh', 'kw', 'ma'],
            preventInvalidNumbers: true,
            separateDialCode: true,
            initialCountry: "auto",
            geoIpLookup: function(callback) {
                $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
                    var countryCode = (resp && resp.country) ? resp.country : "";
                    callback(countryCode);
                });
            },
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/11.0.9/js/utils.js"
        });

        var reset = function() {
            telInput.removeClass("error");
            errorMsg.addClass("hide");
            validMsg.addClass("hide");
        };

        // on blur: validate
        telInput.blur(function() {
            reset();
            if ($.trim(telInput.val())) {
                if (telInput.intlTelInput("isValidNumber")) {
                    validMsg.removeClass("hide");
                } else {
                    telInput.addClass("error");
                    errorMsg.removeClass("hide");
                }
            }
        });

        // on keyup / change flag: reset
        telInput.on("keyup change", reset);

});   

$(document).ready(function() {
	$("#inlineRadio1").click(function() {
		$("#telegraphic-form").hide();
		$("#check-form").show();
	});
	//////////////////////
	$("#inlineRadio2").click(function() {
		$("#check-form").hide();
		$("#telegraphic-form").show();
	});


});

$(document).ready(function(){
  $("#hide-new").click(function(){
    $(".chat-new").hide();
  });
  $("#show-new").click(function(){
    $(".chat-new").show();
  });
 });
 
/*$(document).ready(function(){
  $("#submit1").click(function(){
    $(".email-text").hide();
  });
  $(".show-one").click(function(){
    $(".email-text").slideToggle();
  });
  $("#show-one2").click(function(){
    $(".email-text").show();
  });
 });*/
 


$(document).ready(function() {
            $("#modal2-btn-1").click(function() {
                $("#clients-modal1").hide();
                $("#clients-modal2").show();
            });
            $("#modal2-btn-2").click(function() {
                $("#clients-modal2").hide();
                $("#clients-modal3").show();
            });
            $("#modal2-btn-3").click(function() {
                $("#clients-modal3").hide();
                $("#clients-modal4").show();
            });
            $("#modal2-btn-4").click(function() {
                $("#clients-modal4").hide();
                $("#clients-modal5").show();
            });
            $("#modal2-btn-5").click(function() {
                $("#clients-modal5").hide();
                $("#clients-modal6").show();
            });
            $("#modal2-btn-6").click(function() {
                $("#clients-modal6").hide();
                $("#clients-modal7").show();
            });
            $("#modal2-btn-7").click(function() {
                $("#clients-modal7").hide();
                $("#clients-modal8").show();
            });
            $("#modal2-btn-8").click(function() {
                $("#clients-modal8").hide();
                $("#clients-modal9").show();
            });
            $("#modal2-btn-9").click(function() {
                $("#clients-modal9").hide();
                $("#clients-modal10").show();
            });
            $("#modal2-btn-10").click(function() {
                $("#clients-modal8").hide();
                $("#clients-modal9").hide();
                $("#clients-modal10").hide();
                $("#clients-modal11").show();
            });
            $("#modal2-btn-11").click(function() {
                $("#clients-modal11").hide();
                $("#clients-modal12").show();
            });
            $("#modal2-btn-12").click(function() {
                $("#clients-modal12").hide();
                $("#clients-modal13").show();
            });
            $("#modal-btn-14").click(function() {
                $("#modal-no-14").hide();
                $("#modal-no-15").show();
            });

        });
// ////////////////View More Comments///////////////////////
        $(document).ready(function(){
      
          $(".content").slice(0, 0).show();         
          $(".loadMore").on("click", function(e){
            e.preventDefault();
            $(".content:hidden").slice(0, 4).slideDown();
            if($(".content:hidden").length == 0) {
              $(".loadMore").text("No Comments").addClass("noContent");
            }
          });
        });
        $(document).ready(function(){

        $(".contentt").slice(0, 4).show();         
        $("#loadMore").on("click", function(e){
        e.preventDefault();
        $(".contentt:hidden").slice(0, 4).slideDown();
        if($(".contentt:hidden").length == 0) {
        $("#loadMore").text("No Comments").addClass("noContent");
        }
        });
        });

// $(document).ready(function(){ 14-09
//   $('.show').click(function() {
//			  if ($(this).hasClass('active')) {    
//			  $(this).removeClass('active');
//			  $('.chat').slideUp();
//			  } else {
//			  $('.chat').slideUp();
//			  $('.show').removeClass('active');
//			  $(this).addClass('active');
//			  $(this).next().filter('.chat').slideDown();
//			  }
//			  });
//		   });
            $(document).ready(function(){
            $('.reply-div').click(function() {
            if ($(this).hasClass('active')) {    
            $(this).removeClass('active');
            $('.chat-box-open').slideUp();
            } else {
            $('.chat-box-open').slideUp();
            $('.reply-box').removeClass('active');
            $(this).addClass('active');
            $(this).next().filter('.chat-box-open').slideDown();
            }
            });
            //////////////////////////////////////
           
            // $('.moreless-button').click(function() {
            // if ( $(this).removeClass('active')) {    
            // // $(this).removeClass('active');
            // $(this).hasClass('active')
            // $('.moretext').slideToggle();
            // $('.read_less').slideToggle();
            // if ($(this).text() == "Read more") {
            // $(this).text("Read less")
            // } else {
            // $(this).text("Read more")
            // }
            // } else {
            // $('.moretext').slideUp();
            // // $('.moreless-button').removeClass('active');
            // $(".moreless-button").hasClass('active')
            // $(this).addClass('active');
            // $(this).prev().filter('.moretext').slideDown();
            // if ($(this).text() == "Read more") {
            // $(this).text("Read less")
            // } else {
            // $(this).text("Read more")
            // }
            // }
            // });
            $('#moretext').click(function() {
            $('.read_less').slideToggle();
            $('.moretext').slideToggle();
            if ($('#moretext').text() == "Read more") {
            $(this).text("Read less")
            } else {
            $(this).text("Read more")
            }
            });
            ////////////////////////////////////////////////
            //$('#navbarDropdown').click(function() {
//            $('.sign-up-section').toggle();          
//            });
//            $(document).click(function(){
//            $('.sign-up-section').hide();  
//            });
//            });












<!--subrata off code 14-09-->

//$(document).ready(function() {
//$( '.closeall' ).click( function( e ) {
//	e.preventDefault();
//	$( '.accordion .collapse.show' ).collapse( 'hide' );
//	return false;
//} );
//$( '.openall' ).click( function( e ) {
//	e.preventDefault();
//	$( '.accordion .collapse' ).collapse( 'show' );
//	return false;
//} );
//
//if ( window.location.hash ) {
//	redirect( window.location.hash );
//}
//
//$( 'a[href^="#"]' ).on( 'click', function( e ) {
//	e.preventDefault();
//	var a = document.createElement( 'a' );
//		a.href = this.href;
//	redirect ( a.hash );
//	return false;
//} );
//
//function redirect( hash ) {
//	// $( hash ).attr( 'aria-expanded', 'true' ).focus();
//	// $( hash + '+div.collapse' ).addClass( 'show' ).attr( 'aria-expanded', 'true' );
//	$( hash + '+div.collapse' ).collapse( 'show' );
//
//	// using this because of static nav bar space
//	$( 'html, body' ).animate( {
//		scrollTop: $( hash ).offset().top - 60
//	}, 10, function() {
//	// Add hash (#) to URL when done scrolling (default click behavior)
//		window.location.hash = hash;
//	} );
//}
//
//document.documentElement.setAttribute("lang", "en");
//document.documentElement.removeAttribute("class");
//
//axe.run( function(err, results) {
//  console.log( results.violations );
//} );
//} );



$(document).ready(function(){
   $("#btcom").click(function(){
      $("#ad1").show();
      $("#ad2").hide();
   });
   
   $("#btans").click(function(){
      $("#ad1").hide();
      $("#ad2").show();
   });
     $("#btcom2").click(function(){
      $("#ad3").show();
      $("#ad4").hide();
   });
   
   $("#btans2").click(function(){
      $("#ad3").hide();
      $("#ad4").show();
   });
<!--18-->   
     $("#btcom3").click(function(){
      $("#ad-d3").show();
      $("#ad-d4").hide();
   });
   
   $("#btans3").click(function(){
      $("#ad-d3").hide();
      $("#ad-d4").show();
   });
   
   
});

<!---->


 $('#more-bn-dv1').on('click',function () {
        $('div.detail-dv-textarea').addClass('detail-dv-textarea-next'); 
		 $("#more-bn-dv1").hide();  
    });


function abc()
{
	 document.getElementById("collapse"+id).classList.add(".detail-dv-textarea-next");
	 document.getElementById("collapse"+id).classList.remove(".detail-dv-textarea");
}


$(function () {
  $('#demo-form').parsley().on('field:validated', function() {
    var ok = $('.parsley-error').length === 0;
    $('.bs-callout-info').toggleClass('hidden', !ok);
    $('.bs-callout-warning').toggleClass('hidden', ok);
  })
  .on('form:submit', function() {
    return false; // Don't submit form for this demo
  });
  
  $('select').selectize({
    onInitialize: function(){
      $("#select-country-selectized").attr("data-parsley-errors-container", "#errors");
    }
  });
  
  
    var onClass = "on";
  var showClass = "show";
  
  $("input, .selectize-control ").bind("checkval",function(){
    var label = $(this).parent().find('label');
    if(this.value !== ""){
      label.addClass(showClass);
    } else {
      label.removeClass(showClass);
    }
  }).on("keyup",function(){
    $(this).trigger("checkval");
  }).on("focus",function(){
    $(this).prev("label").addClass(onClass);
  }).on("blur",function(){
      $(this).prev("label").removeClass(onClass);
  }).trigger("checkval");
});


 $('.td-view-d1').hover(function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
   }, function() {
  $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});
});

$(document).ready(function() {
	var select_designatfirst = $('#select_designatfirst'),
	  empSearch = $('#category');
	
	select_designatfirst.on('change', function () {
	  empSearch.attr('placeholder', 'Search ' + select_designatfirst.find(':selected').text());
	});
});

$(document).ready(function() {
$(".new-flex").on("change", "input[type=checkbox]", function(e) {
        totalChecked = $("input[type=checkbox]:checked").length;
        
        if (totalChecked < checkLimit) {
            // keep options open and restore if unchecking option
            $(this).siblings("input[type=checkbox]").each(function() { 
             
            });
        }
  });
});
$(document).ready(function() {
  $("#hide-bn").click(function(){
	$(".comon-more-bn1").hide();
  });
});
$(document).ready(function() {
  $("#show-bn-d1").click(function(){
	$(".red-more-show-d1").show();
  });
});
$(document).ready(function() {
  $("#images").imagepicker()
});

$(document).ready(function(){
  $('.select-pic-pro ul li a').click(function(){
    $('.select-pic-pro li a').removeClass("active");
    $(this).addClass("active");
 });
});

$(document).ready(function(){
  $('.host-section-left-list ul li a').click(function(){
    $('.host-section-left-list li a').removeClass("active");
    $(this).addClass("active");
 });
});

$(document).ready(function(){
  $('.right-cl-dp').hover(function() {
	$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
  }, function() {
	$(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
  });
});




// or in pure javascript
// window.onload=function(){                                              
//    setTimeout(function(){  
//        document.getElementById('user_name').type = 'text';
//    },50000);
//  }   


/*$(document).ready(function () {
$('.sp-drop').hover(function () {
        $(this).find('.dropdown-menu').first().stop(true, true).slideDown(150);
    }, function () {
        $(this).find('.dropdown-menu').first().stop(true, true).slideUp(105)
    });
});
*/


$('#exampleModal-vieo').on('shown.bs.modal', function () {
  $('#video1')[0].play();
})
$('#exampleModal-vieo').on('hidden.bs.modal', function () {
  $('#video1')[0].pause();
})



setTimeout(function() {
  // get the password field
  var pwd = document.getElementById('loginfrm');
  pwd.focus();
  pwd.select();
  var noChars = pwd.selectionEnd;
  // move focus to username field for first-time visitors
  document.getElementById('user_name').focus()
  if (noChars > 0) {
    document.getElementById('login_btn3').disabled = false;
  }
}, 100);

